# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if(!@isdefined(splitargs))
  include("splitargs.jl")
end
function readfile(filename::String,dirs...)
   if(isfile(filename))
     F = open(filename,"r");
     a = readlines(F,keep=true);
     close(F);
     return a;
   else
    for i=1:length(dirs)
      local fn
      try
        fn = dirs[i] * filename;
      catch
        error("not a filename")
      end
      if(isfile(fn))
        F = open(fn,"r");
        a = readlines(F,keep=true);
        close(F);
        return a;
      end
    end
   end
   println("Path:")
   println(dirs...)
  error(@sprintf("file >%s< not found in path",filename))
end

_debugmpp = false
function mpp(filename,outfile="",mod::Module=Main,dirs...)
  if _debugmpp
    # global FDEBUG = STDOUT
    global FDEBUG = open("mppdebug.out","w")
  end
  F = open(filename,"r");
  lines = readlines(F,keep=true);
  close(F);
  global dictDefs = Dict{String,String}()
  txt = myparse(mod,lines,dictDefs,dirs...)
  txt = replace(txt,"%relax%"=>"")
  if(length(outfile)>0)
    repl = split(txt,'\n')
    FF = open(outfile,"w")
    for i=1:length(repl)
      println(FF,repl[i])
    end
    close(FF)
  end
  if _debugmpp
    close(FDEBUG)
  end
  return txt;
end

function myparse(mod::Module,lines::Array{String},dictDefs,dirs...)
  txtFinal = "";
  iLine = 0;
  global _debugmpp
  if(_debugmpp) print(FDEBUG,"\nenter myparse: "); end
  while(iLine < length(lines))
    iLine += 1;
    txt = lines[iLine]
    # println(txt)
    if(_debugmpp) @printf(FDEBUG,"\nline to parse(%d): %s\n",Int(occursin("\n",txt)),txt); end
    addEOL = false
    if(occursin("\n",txt))
      txt = replace(txt,r"\s*$"=>"")
      #txt = replace(txt,"\n"=>"")
      addEOL = true
    end
    iMax = 100000
    for i=1:iMax # max recursion
      if(i==iMax)
        error("too many commands in line")
      end
      if(_debugmpp) @printf(FDEBUG,"txt: %s@@@",txt); end
      m = match(r"(.*?)\b_(\w+)(.*)",txt);
      if m==nothing
        txtFinal *= txt;
        if(addEOL)
          txtFinal *= "\n";
        end
        break;
      else
        bef = m.captures[1]
        cmd = m.captures[2]
        aft = m.captures[3]
        txtFinal *= bef;
        if cmd == "def"
          if(aft[1]=='(')
            (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"def");
            @assert(length(args)==2)
            @assert(args[1][1] == '_')
            dictDefs[args[1][2:end]] = args[2]
            txt = aft1;
          else
            defline = cmd*aft;
            m = match(r"def\s+(?<name>\w+)\((?<args>[^()]+)\)\s+(?<body>.*)",defline)
            if(m==nothing)
              println(defline)
              error("syntax error in mpp")
            end
            args = splitargs(m[:args],',')
            body = m[:body]
            for j=1:length(args)
              simpleArg = @sprintf("#%d",j);
              body = replace(body,Regex("\\b" * args[j] * "\\b")=>simpleArg)
            end
            name = m[:name]
            name = name[2:end]
            dictDefs[name] = body;
            txt = "";  # body goes to the end of the line
          end
        elseif cmd == "incl"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"incl");
          txtFinal *= bef1;
          @assert(length(args)==1)
          lines0 = readfile(args[1],dirs...)
          lines = [lines0;aft1;lines[iLine+1:end]];
          iLine = 0;
          break
        elseif cmd == "eval"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"eval");
          @assert(length(args)==1)
          argi = myparse(mod,args,dictDefs,dirs...);
          local tmp
          try
            tmp = Core.eval(mod,Meta.parse(argi))
          catch
            print("\n")
            println(argi)
            error("could not evaluate")
          end
          res = @sprintf("%d",tmp)
          txt = res * aft1; # * "\n";
        elseif cmd == "evalCmdFinal" # output of cmd is not further preprocessed
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"evalCmdFinal");
          @assert(length(args)==1)
          argi = myparse(mod,args,dictDefs,dirs...);
          #   argi = replace(argi,"\""=>"\\\"")
          tmp__ = Core.eval(Main,Meta.parse(argi))
          txtFinal *= tmp__;
          txt = aft1; # * "\n";
        elseif cmd == "evalCmd"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"evalCmd");
          @assert(length(args)==1)
          argi = myparse(mod,args,dictDefs,dirs...);
          tmp__ = Core.eval(Main,Meta.parse(argi))
          if isa(tmp__,String)
            txt = tmp__ * aft1; # * "\n"; # further preprocessing
          else
            txt =  aft1; # * "\n"; # further preprocessing
          end
        elseif cmd == "if"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"if");
          @assert(length(args)==2)
          arg_cond = myparse(mod,[args[1]],dictDefs,dirs...);
          cond = Core.eval(mod,Meta.parse(arg_cond))
          if(cond)
            txt = args[2] * aft1; # * "\n";
          end
        elseif cmd == "ifelse"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"ifelse");
          @assert(length(args)==3)
          cond = Core.eval(mod,Meta.parse(args[1]))
          if(cond)
            txt = args[2] * aft1; #  * "\n";
          else
            txt = args[3] * aft1; # * "\n";
          end
        elseif cmd == "conc"
          (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),"conc");
          txt = "";
          for ii=1:length(args)
            txt *= myparse(mod,[args[ii]],dictDefs,dirs...); # args are parsed before put back
          end
          txt *= aft1;
        elseif haskey(dictDefs,cmd)
          if(length(aft)>0 && aft[1]=='(')
            try
              (bef1,args,aft1) = splitbyfunc(convert(String,cmd*aft),cmd);
            catch
              println(cmd*aft)
              error("?")
            end
            body = dictDefs[cmd]
            nArgs = @sprintf("%d",length(args))
            body = replace(body,"#0"=>nArgs)
            repl = "";
            j = 1;
            nB = length(body)
            while(j<=nB)
              if(body[j]=='#' && j<nB && occursin(r"[1-9]",body[j+1:j+1]))
                ii = Core.eval(mod,Meta.parse(body[j+1:j+1]))
                repl *= args[ii];
                #repl *= myparse(mod,[args[ii]],dictDefs,dirs...);
                j += 2;
              elseif(body[j]=='#' && j<nB && body[j+1]=='#')
                repl *= body[j:j]
                j += 2; # swallow the second '#'; used for definitions within definitions
              else
                repl *= body[j:j]
                j += 1;
              end
            end
          else
            repl = dictDefs[cmd]
            aft1 = aft;
          end
          txt = repl*aft1; #  * "\n"
          continue
        else
          txtFinal *= "_" * cmd;
          txt = aft;
        end
      end
    end
  end
  return txtFinal;
end

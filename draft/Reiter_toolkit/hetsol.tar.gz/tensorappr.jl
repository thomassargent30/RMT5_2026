# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if !@isdefined(TensorSparse)
  include("polyapprox.jl")
  include("bspline.jl")
  # include("utils.jl")
  mutable struct TensorSparse{T1,T2} <: MultiDimApprox
    f1::T1;
    f2::T2;
  end
  mutable struct GridOfApprox{T,dim} <: MultiDimApprox
    f::T;
    # X::NTuple{dim,Array{Float64,1}}
    nn::NTuple{dim,Int}
  end
end
function Base.copy(x::TensorSparse{T1,T2}) where {T1,T2};
  return TensorSparse{T1,T2}(copy(x.f1),copy(x.f2))
end
function Base.show(io::IO, x::TensorSparse{T1,T2}) where {T1,T2}
  show(x.f1)
  show(x.f2)
end
function saveRaw(F::IOStream,x::TensorSparse{T1,T2}) where {T1,T2}
  writeInt(F,dimen(x.f1))
  saveRaw(F,x.f1)
  writeInt(F,dimen(x.f2))
  saveRaw(F,x.f2)
end
function saveT(F::IOStream,x::TensorSparse{T1,T2}) where {T1,T2}
  i = _typeNumber(TensorSparse)
  writeInt(F,i);
  saveRaw(F,x);
end
function loadRaw(F::IOStream,::Type{TensorSparse{T1,T2}}) where {T1,T2}
  f1 = loadRaw(F,T1)
  f2 = loadRaw(F,T2)
  return TensorSparse{T1,T2}(f1,f2)
end
function loadTensor(F::IOStream)
  n1 = read(F,Int64)
  if n1==1
    f1 = loadBSpl(F)
  else
    f1 = loadTensor(F)
  end
  n2 = read(F,Int64)
  if n2==1
    f2 = loadBSpl(F)
  else
    f2 = loadTensor(F)
  end
  return TensorSparse(f1,f2)
end
function setBounds!(fspace::TensorSparse{T1,T2},
                    xLow::Array{Float64,1},xUpp::Array{Float64,1},center::Array{Float64,1}) where {T1,T2}
  d1 = dimen(fspace.f1)
  d2 = dimen(fspace.f2)
  setBounds!(fspace.f1,xLow[1:d1],xUpp[1:d1],center[1:d1])
  setBounds!(fspace.f2,xLow[d1+1:d1+d2],xUpp[d1+1:d1+d2],center[d1+1:d1+d2])
end
getBounds(f::TensorSparse{T1,T2}) where {T1,T2} = [getBounds(f.f1);getBounds(f.f2)]
nCoeff(f::TensorSparse{T1,T2}) where {T1,T2} = nCoeff(f.f1)*nCoeff(f.f2);
gridDim(f::TensorSparse{T1,T2}) where {T1,T2} = (gridDim(f.f1)...,gridDim(f.f2)...)
dimen(f::TensorSparse{T1,T2}) where {T1,T2} = dimen(f.f1)+dimen(f.f2);
function nodes(f::TensorSparse{T1,T2}) where {T1,T2}
  return tensprod(nodes(f.f1),nodes(f.f2))
end
function basisI(f::TensorSparse{T1,T2},x0::Array{Tx,1}) where {T1,T2,Tx}
  nx = length(x0);
  d1 = dimen(f.f1);
  d2 = dimen(f.f2);
  assert(nx==d1+d2)
  local i1::Array{Int,1}
  local i2::Array{Int,1}
  local b1::Array{Float64,1}
  local b2::Array{Float64,1}
  if d1==1
    (i1,b1,nn1) = basisI(f.f1,x0[1])
  else
    (i1,b1,nn1) = basisI(f.f1,x0[1:d1])
  end
  if d2==1
    (i2,b2,nn2) = basisI(f.f2,x0[end])
  else
    (i2,b2,nn2) = basisI(f.f2,x0[d1+1:end])
  end
  n1 = nCoeff(f.f1)
  n2 = nCoeff(f.f2)
  nn = n1*n2
  nz1::Int = length(i1)
  nz2::Int = length(i2)
  B = Array{Tx}(nz1*nz2)
  ii = Array{Int}(nz1*nz2)
  lauf = 0
  for j=1:nz2
    for i=1:nz1
      lauf += 1;
      @inbounds B[lauf] = b1[i]*b2[j];
      @inbounds ii[lauf]  = (i2[j]-1)*n1 + i1[i];
    end
  end
  return (ii,B,nn)
end
function basis(f::TensorSparse{T1,T2},x0::Array{Tx,1}) where {T1,T2,Tx}
  nx = length(x0);
  d1 = dimen(f.f1);
  d2 = dimen(f.f2);
  assert(nx==d1+d2)
  if d1==1
    (i1,b1) = findnz(basis(f.f1,x0[1]))
  else
    (i1,b1) = findnz(basis(f.f1,x0[1:d1]))
  end
  if d2==1
    (i2,b2) = findnz(basis(f.f2,x0[end]))
  else
    (i2,b2) = findnz(basis(f.f2,x0[d1+1:end]))
  end
  n1 = nCoeff(f.f1)
  n2 = nCoeff(f.f2)
  nn = n1*n2
  nz1 = length(i1)
  nz2 = length(i2)
  B = Array{Tx}(nz1*nz2)
  ii = Array{Int}(nz1*nz2)
  lauf = 0
  for j=1:nz2
    for i=1:nz1
      lauf += 1;
      @inbounds B[lauf] = b1[i]*b2[j];
      @inbounds ii[lauf]  = (i2[j]-1)*n1 + i1[i];
    end
  end
  return sparsevec(ii,B,nn)
end
function feval(f::TensorSparse{T1,T2},x0::Array{Tx,1},coeff::Array{Tc,1}) where {T1,T2,Tx,Tc}
  b = basis(f,x0)
  return dot(b,coeff)
end
function feval(f::TensorSparse{T1,T2},x0::Array{Tx,1},coeff::Array{Tc,2}) where {T1,T2,Tx,Tc}
  b = basis(f,x0)
  a = b'*coeff
  n = length(a)
  aa = Array{typeof(a[1])}(n)
  for i=1:n
    aa[i] = a[i]
  end
  return aa
end
function fevalDer(f::TensorSparse{T1,T2},x0::Array{Tx,1},coeff::Array{Tc,2}) where {T1,T2,Tx,Tc}
  n = length(x0)
  dx0 = indep(Deriv1F{n},c0)
  b = basis(f,dx0)
  a = b'*coeff
  n = length(a)
  aa = Array{typeof(a[1])}(n)
  for i=1:n
    aa[i] = a[i]
  end
  return aa
end
function feval(f::TensorSparse{T1,T2},x0::Array{Tx,2},coeff::Array{Tc,2}) where {T1,T2,Tx,Tc}
  n = size(x0,1)
  nc = size(coeff,2)
  T = typeof(x0[1]*coeff[1])
  res = Array{T}(n,nc)
  for j=1:n
    b = basis(f,x0[j,:])
    res[j,:] = b'*coeff
  end
  return res
end
# much faster for coeff with many variables:  !!!!!!!!!!!!
function fevalTr(f::TensorSparse{T1,T2},x0::Array{Tx,2},coeff::Array{Tc,2}) where {T1,T2,Tx,Tc}
  n = size(x0,1)
  nc = size(coeff,1)
  T = typeof(x0[1]*coeff[1])
  res = Array{T}(n,nc)
  for j=1:n
    b = basis(f,x0[j,:])
    res[j,:] = b'*coeff'
  end
  return res
end
function basis(f::TensorSparse{T1,T2},x::Array{Tx,2}) where {T1,T2,Tx}
  n = size(x,1)
  B = zeros(n,nCoeff(f))
  for i=1:n
    B[i,:] = basis(f,x[i,:])
  end
  return B
end
function fitfun(f::TensorSparse{T1,T2},func::Function) where {T1,T2}
  g = nodes(f)
  n = size(g,1)
  y = map(i->func(g[i,:]),1:n)
  B = hcat(map(i->basis(f,g[i,:]),1:n)...)
  return B'\y
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

stdev(x,i) = sqrt.(var(x,dims=i))
stdev(x::Array{Float64,1}) = sqrt(var(x))
function fillvars(model,x)
  vss = model.vstst
  typev = typeof(vss)
  v = typev()
  offs = 0;
  for a in fieldnames(typev)
    n = length(getfield(vss,a))
    if n==1
      offs += 1
      if offs>length(x)
        setfield!(v,a,0.)
      else
        setfield!(v,a,x[offs])
      end
    else
      if offs+n>length(x)
        setfield!(v,a,zeros(n))
      else
        setfield!(v,a,x[offs.+(1:n)])
      end
      offs += n;
    end
  end
  return v;
end

# raw simulation routine, called by simullin and statslin
function simullin_(A,B,x0,shocks,nSkip)
  T = size(shocks,2)
  T2 = T-nSkip
  x = x0;
  ser = zeros(size(A,1),T2)
  for t=1:T
    x = A*x + B*shocks[:,t]
    if t>nSkip
      ser[:,t-nSkip] = x
    end
  end
  return ser'
end
function simullin(model::LinSol; x0=zeros(size(model.A,1)),
                  T=0,stdev::Array{Float64,1}=fill(0.01,size(model.B,2)),shocks=zeros(0,0),nSkip=0)
  if isempty(shocks)
    assert(T>0)
    shocks = stdev.*randn(size(model.B,2),T)
  end
  return simullin_(model.A,model.B,x0,shocks,nSkip)
end
function statslin(model::LinSol,
                  stdevShock::Array{Float64,1};
                  HP = 1600, # parameter for HP filtering (0: no filter)
                  ref=:GDP,  # variable w.r.t. which the relative stdev is computed
                  nRep=1000, # number of replications 
                  T=200,  # length of each individual simulation
                  nSkip=100, # burn-in period
                  nAve=1)  # time-aggregation over nAve periods
  nVar = size(model.A,1)
  nZ = size(model.B,2)
  vs = model.vstst

  skal = stackFields(Float64,vs)[1:nVar]  # drop shocks
  skal[skal.==0] = 1.0;
  iskal = 1 ./ skal
  std = zeros(nVar)
  stdlev = zeros(nVar)
  stdrel = zeros(nVar)
  ac = zeros(nVar)
  acRaw = zeros(nVar)
  corY = zeros(nVar)
  refVars = [ref;:GDP;:gdp;:Y;:y];
  iY = 0;
  for rv in refVars
    if in(rv,fieldnames(model.vstst))
      iY = posInStruct(model.vstst,rv)[1]
      println("use ",string(rv)," as reference variable, index=",iY)
      break;
    end
  end
  if iY==0
    error("no reference variable found")
  end
  for iRep=1:nRep
    shock = randn(nZ,T+nSkip) .* stdevShock
    ser = simullin_(model.A,model.B,zeros(nVar),shock,nSkip)
    if nAve != 1
      serQu = reducefreq(ser,nAve,"ave"); # averages over quarters
    else
      serQu = ser
    end
    if HP>0
      serDetr = serQu - hpfilter(serQu,HP)
    else
      serDetr = serQu;
    end
    sd = vec(stdev(serDetr,1))
    std += sd
    cc = cor(serDetr)
    corY += cc[:,iY]
    ac += vec(autocorr(serDetr,1))
    acRaw += vec(autocorr(serQu,1))
  end
  facRep = 1/nRep
  res = Dict{Symbol,Any}()
  res[:A] = model.A
  res[:B] = model.B
  res[:stst] = vs
  res[:pars] = copyStruct0(model.pars)
  stdn = std*facRep
  res[:std] = fillvars(model,stdn)
  stdl = stdn .* iskal
  res[:stdlog] = fillvars(model,stdl)
  res[:stdrel] = fillvars(model,stdl./stdl[iY])
  res[:ac] = fillvars(model,ac*facRep)
  res[:acRaw] = fillvars(model,acRaw*facRep)
  res[:corY] = fillvars(model,corY*facRep)
  return res;

end


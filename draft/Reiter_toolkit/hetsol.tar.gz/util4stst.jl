# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

####################################################################
# GENERAL SOLVERS
####################################################################
# solves func(x)=0, assuming that func is linear in x
# Inputs:
#   func: handle or name of function, R^n->R^n
#   n: dimension of domain and range of func
#   varargin: will be passed to func
# function solvelinear1(func,varargin...)
#   f0 = func(0.,varargin...);
#   f1 = func(1.,varargin...);
#   x = -f0/(f1-f0);
#   print(f0,";",f1,";",x,"\n");
#   return x;
# end
function solvelinear1(func)
  # error("done")
  f0 = func(0.);
  f1 = func(1.);
  df = f1-f0;
  if(df==0)
    @printf("f(0) = %e; f(1) = %e\n",f0,f1);
    error("constant function in solvelinear1")
  end
  x = -f0/df;
  return x;
end
function solvelinear(func,n,varargin...)

  z = zeros(n,1);
  f0 = func(z,varargin...);
  if(!all(isfinite.(f0)))
    saveT("flinear.bmt",f0);
    error("value at zero not finite in solvelinear (saved in flinear.bmt)");
  end
  J = zeros(n,n);
  for i=1:n
    z[i] = 1;
    J[:,i] = func(z,varargin...)-f0;
    z[i] = 0;
  end;

  if(!all(isfinite.(J)))
    saveT("Jlinear.bmt",J);
    error("Jacobian not finite in solvelinear (saved in Jlinear.bmt)");
  end

  JLU = lufact(J);
  local x
  try 
    x = -(JLU\f0);
  catch
    saveT("Jlinear.bmt",J);
    error("singular Jacobian in solvelinear; J stored in Jlinear.bmt");
  end
  success = 0;
  local f;
  for i=1:10
    f = func(x,varargin...);
    if(maximum(abs,f)<1e-12)
      success = 1;
      break;
    end
    x = x - JLU\f;
    println(maximum(abs,f))
  end
  if(success == 0)
    if(maxabs(f)>1e-20)
      saveT("Jlinear.bmt",J,f);
      println("cond: ",cond(J),";abs(f): ",maxabs(f))
      warn("equation system ill-conditioned or nonlinear; J and f in Jlinear.bmt");
      stop()
      return x;
    end
  end
  return x;
end
function bisect(f, a, b, tolX=1e-8)
  fa = f(a);
  if(fa==0)
    return (a,0);
  end
  fb = f(b);
  if(fb==0)
    return (b,0);
  end
  if(!(fa*fb<0))
    return (NaN,-1); # -1 signals root not bracketed
  end

  # Iteration loop
  while (b-a>tolX)
    mid = (a+b)/2;
    fmid = f(mid);
    if(fmid==0)
      return (mid,0);
    end
    if(fmid*fb>0) # new interval is (a,mid)
      b = mid;
      fb = fmid;
    else
      a = mid;
      fa = fmid;
    end
  end
  return ((a+b)/2,0);
end


####################################################################
# ADAPT SOLVERS TO STEADY STATE CALCULATIONS:
####################################################################
function solveLinStSt!(args...)
  stst = StStIndex(0)
  n = div(length(args),2)
  disableLog()
  function f1(x) # for single equation
    setstst!(args[1],x)
    resid = args[2](stst)
    return resid
  end
  function f(X)
    resid = zeros(n)
    for i=1:n
      setstst!(args[2*i-1],X[i])
    end
    for i=1:n
      resid[i] = args[2*i](stst)
    end
    return resid
  end
  if(n==1)
    x = solvelinear1(f1)
    X = [x];
  else
    X = solvelinear(f,n);
  end
  for i=1:n
    setstst!(args[2*i-1],X[i])
  end
  enableLog()
  return X;
end

function slss!(args...)
  local X
  n = div(length(args),2)
  try
    X = solveLinStSt!(args...)
  catch myerr
    println(myerr)
    print("in Equations: ")
    for i=1:n
      print(string(args[2*i])[5:end] * ", ")
    end
    println("")
    error("Error in computing steady state: variable not set")
  end
  for i=1:n
    append2Log(namestring(args[2*i-1]),X[i]);
  end
  return X;
end
function bisectTr(name::String,f, a, b, tolX=1e-10)
  (x,flag) = bisect(f,a,b,tolX);
  append2Log(name,x)
  if(flag!=0)
    if(flag==-1)
      @printf("ERROR: root not bracketed in BISECT: f(%g) = %g; f(%g) = %g;\n",
              a,f(a),b,f(b))
    else
      @printf("ERROR: flag %d\n",flag);
    end
    error("bisect failed")
  end
  return (x,flag)
end

# handle log file:
function append2Log(name::String,x::Real)
  if(_glob.disableLog==0)
    FF = open(_modelDir*"stst.log","a")
    @printf(FF,"%s = %f\n",name,convert(Float64,x))
    if(!isfinite(x))
      @printf("%s = %f\n",name,convert(Float64,x))
      error("not finite")
    end
    close(FF)
  end
end
function enableLog()
  if(_glob.disableLog>0)
    _glob.disableLog-=1;
  end
end
function disableLog()
  _glob.disableLog+=1;
end

function loadstst(xGuess)
    loadStruct!("_pars.bmt",_pars);
    loadStruct!("_varss.bmt",_varsStSt);
    for a in fieldnames(typeof(_vars))
      ai = getfield(_vars,a)
      ai.sv = getfield(_varsStSt,a)
    end
    ststv = stackFields(Float64,_varsStSt)
    # resid = ststResid(ststv)
    # if(maxabs(resid)>1e-6)
    #   (ststv,flag) = broydn(ststResid,ststv,[1e-7,0,1,1e-6])
    #   if(flag!=0)
    #     error("broydn does not find steady state")
    #   end
    #   vars2stst!(_varsStSt,_vars); #_vars has been set in ststResid
    # end
    xStSt = Array{Float64}()
end
using DelimitedFiles:writedlm
function dostst!(xGuess,vars,shks,pars,varsStSt)::Array{Float64,1}
  _linsol.inStSt = true
  init!(varsStSt,NaN,pars);
  stst2vars!(vars,varsStSt); # copy the NaN to vars,  
  nGuess = length(xGuess)
  xStSt = fill(0.0,(nGuess))
  if _linsol.loadStSt > 0 && nGuess>0
    xx = loadT(_modelDir*"xstst.bmt")
    xStSt .= xx;
    resid = _ststz(xStSt,vars,shks,pars)
    println("steady state residual at x from xstst.bmt: ",maximum(abs,resid))
  else
    if(nGuess==1)
      (xStSt[1],flag) = fzerobracket(x->_ststz(x,vars,shks,pars)[1],_lowbGuess[1],_uppbGuess[1],
                                  1e-9);
      # writedlm(_modelDir*"xstst.out",xStSt);
      saveT(_modelDir*"xstst.bmt",xStSt);
      if(flag==2)
        error("root not bracketed in steady state computation")
      elseif(flag!=0)
        error("steady state not converged")
      end
    elseif(length(xGuess)==0)
      _ststz([NaN],vars,shks,pars);
    else
      (xx,flag) = broydn(x->_ststz(x,vars,shks,pars),xGuess,
                         tolf=_linsol.ytolStSt,doPrint=_linsol.traceStSt,whichAD="none",
                        stepJacob=_linsol.stepJacob);
      xStSt .= xx;
      if(flag!=0)
        warn("steady state not converged")
        saveT(_modelDir*"xststNotConverged.bmt",xStSt);
      else
        saveT(_modelDir*"xstst.bmt",xStSt);
      end
    end
  end
  vars2stst!(varsStSt,vars,shks); # 
  # global ststVector = stackFields(Float64,varsStSt);
  return xStSt
end

function printstst(_modelDir,_pars,_vars)
  FSV = open(_modelDir*"ststres.out","w")
  println(FSV,"Parameters:")
  for a in fieldnames(typeof(_pars))
    _x = getfield(_pars,a);
    if(isa(_x,Float64))
      @printf(FSV,"%s: %16.12g\n",string(a),_x)
    elseif(isa(_x,Int))
      @printf(FSV,"%s: %d\n",string(a),_x)
    elseif(isa(_x,ParCali))
      @printf(FSV,"%s: %16.12g\n",string(a),_x.v)
    elseif(isa(_x,Array{Float64}))
      @printf(FSV,"%s:\n",string(a))
      writedlm(FSV,_x)
    elseif(isa(_x,Array{Int}))
      @printf(FSV,"%s:\n",string(a))
      writedlm(FSV,_x)
    else
      error("wrong type")
    end
  end
  println(FSV,"\nSteady state values:")
  for a in fieldnames(typeof(_vars))
    _x = getfield(getfield(_vars,a),:sv)
    if(isa(_x,Float64))
      @printf(FSV,"%s: %16.12g\n",string(a),_x)
    elseif(isa(_x,Array{Float64}))
      @printf(FSV,"%s:\n",string(a))
      writedlm(FSV,_x)
    else
      error("wrong type")
    end
  end
  close(FSV);
  saveStruct(_modelDir*"_pars.bmt",_pars);
  saveStruct(_modelDir*"_varss.bmt",_varsStSt);
end

function ifif(cond1,ex1,cond2,ex2,exRest) 
  if cond1!=0
    return ex1 
  elseif cond2!=0
    return ex2 
  else
    return exRest
  end
end
function posInStruct(P,s)
  sum = 0
  pos = 0;
  for a in fieldnames(typeof(P)); 
    n = length(getfield(P,a));
    if(a==s)
      return sum+1:sum+n
    end
    sum += n;
  end
  error("structure does not have field " * string(s))
end
function posInStruct(P)
  names = Dict{Symbol,UnitRange{Int64}}()
  sum = 0
  pos = 0;
  for a in fieldnames(typeof(P)); 
    n = length(getfield(P,a));
    names[a] = sum .+ (1:n)
    sum += n;
  end
  return names
end
# solve discrete Lyapunov equation by doubling algorithm
function doubling(A0,Sig,n::Int)
  (nr,nc) = size(A0)
  if nr==nc
    A = A0';
  else
    @assert nr>nc # remaining columns are supposed to be zero!
    Sig = Sig[1:nc,1:nc]
    A = A0[1:nc,:]'
  end
  for i=1:n-1
    Sig = Sig+A'*(Sig*A);
    A = A*A;
  end
  X = Sig+A'*(Sig*A);
  return X;
end
# Sig is covariance-matrix of shocks
# n=30 gives very precise estimates
function doubling(A,B,Sig,n::Int)
  return doubling(A,B*Sig*B',n);
end
function complement_LB(f,x,a)
  global _linsol
  if _linsol.inStSt
    return fischer_LB(f,x,a)
  else
    return x>a+_linsol.epsComplement ? f : x-a
  end
end
fischer_LB(f,x,a) = f + a-x + sqrt((f)^2 + (a-x)^2)
fischer_UB(f,x,b) = f + b-x - sqrt((f)^2 + (b-x)^2) 
function SUM(f,i1::Int,i2::Int)
  # F = open("sum.log","a")
  # println(F,i1,"-",i2);
  # close(F)
  if(i2<i1)
    tmp = f(1); # must be guaranteed that this can be evaluated
    return zero(typeof(tmp))
  end
  s = f(i1);
  for i=i1+1:i2
    s = s + f(i);
  end
  return s;
end
function solveCompl1Switch(func,xInit0,iSwitchInit)
  nX = length(xInit0)
  function complFunc(X,iSwitch)
    (z,w) = func(X);
    return [w[1:iSwitch];z[iSwitch+1:end]];
  end
  iSwitch = iSwitchInit;
  lastDirect = 0;
  xInit = copy(xInit0)
  while(iSwitch>=0 && iSwitch<=nX)
    # (xx,flag) = wrapBroydn(x->complFunc(x,iSwitch),1e-6,0,xInit);
    (xx,flag) = broydn(x->complFunc(x,iSwitch),xInit,whichAD="sparse")
    if(flag==0)
      println("in solveCompl1Switch: broydn converged for iSwitch = ",iSwitch)
    else
      # try again, this time display intermediate results:
      # (xx,flag) = wrapBroydn(x->complFunc(x,iSwitch),1e-5,1,xx);
      NLres = wrapNLsolve(complFunc,xx,iSwitch)
      xx = copy(NLres.zero);
      # if(flag!=0)
      if(NLres.residual_norm>1e-4)
        return (xx,iSwitch,1) # error("broydn not converged in solveCompl1Switch");
      end
    end
    (z,w) = func(xx);
    tol = -1e-8;
    compl = [z[1:iSwitch];w[iSwitch+1:end]];
    if(minimum(compl[iSwitch-5:iSwitch+5])>=tol)
      return (xx,iSwitch,0); # success
    end
    if(compl[iSwitch+1]<tol)
      Direct = 1;
    elseif(compl[iSwitch]<tol)
      Direct = -1;
    else
      iNeg = mfind(compl.<tol)
      println("neg is:")
      println(iNeg)
      if(all(iNeg.>iSwitch))
        Direct = 1;
      elseif(all(iNeg.<=iSwitch))
        Direct = -1;
      else
        println(iSwitch)
        println(compl[iNeg])
        error("in Compl1")
        return (xx,iSwitch,2)  # error("complementarity violated")
      end
    end
    if(Direct*lastDirect<0)
      # println(compl[iSwitch-5:iSwitch+6])
      warn("changed direction in  solveCompl1Switch")
      # return (xx,iSwitch,3) # error("change direction in solveCompl1Switch")
    end
    iSwitch += Direct;
    lastDirect=Direct
    xInit = xx;
  end
  return (xx,iSwitch,4) # error("change direction in solveCompl1Switch")
end


function write4matlab(F,name,x::Array{T,1}) where T
  Base.print(F,"$name =[",x[1]);
  for i=2:length(x)
    Base.print(F,";",x[i]);
  end
  Base.println(F,"];")
end

function writeStStRes(FSV::IO,pars,vss,commentSign="#")
  parname(a) = "p_" * string(a)
  varname(a) = "v_" * string(a)
  println(FSV,"$commentSign Parameters:")
  for a in fieldnames(typeof(pars))
    _x = getfield(pars,a);
    if(isa(_x,Float64))
      @printf(FSV,"%s = %16.12g;\n",parname(a),_x)
    elseif(isa(_x,Int))
      @printf(FSV,"%s = %d;\n",parname(a),_x)
    elseif(isa(_x,ParCali))
      @printf(FSV,"%s = %16.12g;\n",parname(a),_x.v)
    elseif(isa(_x,Array{Float64,1}))
      write4matlab(FSV,parname(a),_x)
    elseif(isa(_x,Array{Float64,2}))
      println(FSV,parname(a),":[]")
    elseif(isa(_x,Array{Float64,3}))
      println(FSV,parname(a),":[]")
    elseif(isa(_x,Array{Int}))
      write4matlab(FSV,parname(a),_x)
    else
      error("wrong type")
    end
  end
  println(FSV,"\n$commentSign  Steady state values of variables:")
  for a in fieldnames(typeof(vss))
    _x = getfield(vss,a);
    if(isa(_x,Float64))
      @printf(FSV,"%s = %16.12g;\n",varname(a),_x)
    elseif(isa(_x,Array{Float64,1}))
      write4matlab(FSV,varname(a),_x)
    elseif(isa(_x,Array{Float64,2}))
      println(FSV,parname(a),":[]")
    elseif(isa(_x,Array{Float64,3}))
      println(FSV,parname(a),":[]")
    else
      error("wrong type")
    end
  end
end
function writeStStRes(commentSign="#")
  if commentSign=="%"  # for Matlab
    F = open(_modelDir * "ststres.m","w")
  else
    F = open(_modelDir * "ststres.out","w")
  end
  writeStStRes(F,_pars,_varsStSt)
  close(F)
end

# more general utilities:
function logspaceshift(a,b,n,shift)
  A = exp.(range(log(a+shift),stop=log(b+shift),length=n)) .- shift;
  A[1] = a;
  A[end] = b;
  return A;
end

# construct grid equidistant in log(x+shift);
# choose shift such that x-step at lower bounds equals dx_at_a
# y = log(x+shift)
# dy = (log(b+shift)-log(a+shift))/n
# dx = dx/dy*dy = 1/(dy/dx) * dy = (x+shift)*dy
#    = (x+shift)*(log(b+shift)-log(a+shift))/n
function logspaceshiftAtA(a,b,n,dx_at_a)
  resid(shift) = (a+shift)*(log(b+shift)-log(a+shift))/n - dx_at_a;
  if dx_at_a>=(b-a)/n
    warn("dx_at_a too big; return linspace")
    return convert(Array{Float64,1},linspace(a,b,n))
  end
  (shift,flag) = fzero(resid,-a+1e-8,1e8);
  @assert(flag==0)
  return logspaceshift(a,b,n,shift)
end
function insertRes!(resVector,offs::Int,Res,eqNames,name::String,iEqu::Int)
  if isa(Res,Array)
    if iEqu>0
      warn("equation $name[$iEqu] returns an Array")
    end
    n = length(Res)
    for j=1:n
      resVector[offs+j] = Res[j];
    end
    if haskey(eqNames,name)
      #error("equation $name already defined")
    end
    eqNames[name] = offs+1:offs+n
    return offs+n
  else
    i = offs+1;
    resVector[i] = Res;
    if iEqu>0
      name = name*"["*string(iEqu)*"]"
    end
    if haskey(eqNames,name)
      #error("equation $name already defined")
    end
    eqNames[name] = i:i
    return i;
  end
end
function insertRes!(resVector,offs::Int,Res,eqNames,name::String,iEqu::Int,jEqu::Int)
  i = offs+1;
  resVector[i] = Res;
  name = name*"[$iEqu,$jEqu]";
  if haskey(eqNames,name)
    #error("equation $name already defined")
  end
  eqNames[name] = i:i
  return i;
end
function insertResDP!(resVector,offs::Int,Res,eqNames,name::String)
  offs = insertRes!(resVector,offs,Res[1],eqNames,name*"_d",0) # "_d" is extension for distrib.
  offs = insertRes!(resVector,offs,Res[2],eqNames,name*"_v",0) # "_v" is extension for value equ.
  # offs = insertRes!(resVector,offs,Res[1],eqNames,"_d",0) # "_d" is extension for distrib.
  # offs = insertRes!(resVector,offs,Res[2],eqNames,"_v",0) # "_v" is extension for value equ.
  return offs;
end

function compstst(m::LinModel)
  return -((m.Gamma+m.Lambda+m.Phi)\m.Psi)
end

function compstst(m::Module,symbols...)
  global _pars,_vars,_shks;
  ( _G , _L , _F , Psi , Pi_) = _linpert(_vars,_shks,_pars);
  p = m.StructParsAny();
  copyFields!(p,m._pars);
  n = length(symbols)
  ststvec = zeros(n);
  for i=1:n
    ststvec[i] = getfield(m._pars,symbols[i]);
  end
  _d = indep(Deriv1a{n},ststvec);
  for i=1:n
    setfield!(p,symbols[i],_d[i]);
  end
  _allRes = Array{Deriv1a{n}}(0)
  function register(s::String,Res,indx...) end; # donothing
  function handleRes(res); push2!(_allRes,res);end
  m._dynModel(m.StStIndex(0),handleRes,register,p,m._vars,m._shks)
  # print(getjac(_allRes))
  if(size(_G,1)<1000)
    condsys = cond(full(_G+_L+_F));
    if(condsys>1e10)
      @printf("Warning; condition number in compStSt is %e\n",condsys);
    end
  end
  return -((_G+_L+_F)\getjac(_allRes))
end
isnewer(file1::AbstractString,file2::AbstractString) = stat(file1).mtime >= stat(file2).mtime;

# logfunction that is defined on R, but gives very low values for eps<1e-10
function pseudolog(c)
  eps = 1e-10
  if c>=eps
    return log(c)
  else
    dc = (c-eps)
    return log(eps) + 1e10*dc - 1e20*dc*dc/2; # quadratic approximation, twice differentiable
  end
end

function askstop(f::Function=()->nothing)
  if isfile("_stop.jl")
    f()
    rm("_stop.jl")
    error("stopped in askstop")
  end
end
function askstopsave(x...)
  if isfile("_stop.jl")
    saveT("_stop.out",x...)
    rm("_stop.jl")
    error("stopped in askstop")
  end
end
function setstop()
  try 
    F = open("_stop.jl","a")
    close(F)
  catch
    error("cannot open _stop.jl")
  end
end
macro disp(x)
  xs = string(x)
  return esc( quote 
               # print(@__FILE__," line ",@__LINE__,": ")
               println($xs," = ",$x) 
             end
            )
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if !@isdefined BSpl
  mutable struct BSpl{p}
    U::Array{Float64,1};
    grid::Array{Float64,1};
  end
  mutable struct BSplEquidist{p}
    S::BSpl{p}
    c::Float64
    scal::Float64
  end
  # include("approx.jl")
  getval(x::Float64) = x;
  getval(x::Array{Float64}) = x;
end
spldeg(x::BSpl{p}) where p = p;
function saveRaw(F::IOStream,x::BSpl{p}) where p
  saveRaw(F,p)
  saveRaw(F,x.U)
  saveRaw(F,x.grid)
end
function loadRaw(F::IOStream,::Type{BSpl{p}}) where p
  p2 = loadRaw(F,Int64)
  assert(p==p2)
  U = loadRaw(F,Array{Float64,1})
  grid = loadRaw(F,Array{Float64,1})
  return BSpl{p}(U,grid)
end
function loadBSpl(F::IOStream)
  p = loadRaw(F,Int64)
  U = loadRaw(F,Array{Float64,1})
  grid = loadRaw(F,Array{Float64,1})
  return BSpl{p}(U,grid)
end
function Base.show(io::IO, x::BSpl{p}) where p
  @printf("B-Spline degree %d; nCoeff=%d; Grid=(%f,...,%f)\n",p,nCoeff(x),x.grid[1],x.grid[end])
end
function setBounds!(f::BSpl{p},
                    xLow::Array{Float64,1},xUpp::Array{Float64,1},center::Array{Float64,1}) where {p}
  n = length(f.grid) - p + 1;
  breaks = linspaceA(xLow[1],xUpp[1],n)
  U = Array{Float64}(undef,n+2*p);
  for i=1:p
    U[i] = breaks[1];
  end
  for i=p+1:p+n
    U[i] = breaks[i-p];
  end
  for i=p+n+1:length(U)
    U[i] = breaks[n];
  end
  f.U .= U;
  f.grid .= AugmBreaks(p,U);
end
function getBounds(f::BSpl{p}) where p
  return [f.grid[1] f.grid[end]]
end
function AugmBreaks(k::Int,U) 
  breaks = U[k+1:end-k];
  a=breaks[1];
  b=breaks[end];
  n=length(breaks)+k-1;
  x=cumsum([a*ones(k,1);breaks[:];b*ones(k,1)],dims=1);
  x=(x[1+k:n+k]-x[1:n])/k;
  x[1]=a;
  x[end]=b;
  return x
end
function AugmBreaks(S::BSpl{p}) where p 
  return AugmBreaks(p,S.U);
end
function nodes(S::BSpl{p}) where p
  return S.grid;
end
function bSplEquidist(a::Float64,b::Float64,n::Int,p::Int)
  S = bSpl(linspace(a,b,n),3);
  c = -a;
  scal = (b-a)/(n-1)


end
function bSpl(breaks::AbstractArray{Float64,1},p::Int)
  n = length(breaks);
  # set U, cf. page 66
  U = Array{Float64}(undef,n+2*p);
  for i=1:p
    U[i] = breaks[1];
  end
  for i=p+1:p+n
    U[i] = breaks[i-p];
  end
  for i=p+n+1:length(U)
    U[i] = breaks[n];
  end
  return BSpl{p}(U,AugmBreaks(p,U));
end
import Base.copy
function copy(x::BSpl{p}) where p;
  return BSpl{p}(copy(x.U),copy(x.grid))
end

xMin(s::BSpl{p}) where p = s.U[1];
xMax(s::BSpl{p}) where p = s.U[end];
nCoeff(s::BSpl{p}) where p = length(s.U) - p-1;
gridDim(s::BSpl{p}) where p = nCoeff(s)
dimen(s::BSpl{p}) where p = 1;
#inline functions:
#size_t m() const {return length(U)-1;}
#size_t n() const {return m() - p - 1;}
#size_t nCoeff() const {return n()+1;}


#function copy(x::BSpl);
#  return BSpl(copy(x.U),x.p)
#end


@inbounds function findSpan(S::BSpl{p},u) where p
  n = length(S.U) - p - 2;
  if(u>=S.U[n+2])
    return n+1;
  end
  if(u<=S.U[p+1])
    return p+1;
  end

  low  = p+1;
  high = n+2 ; 
  mid = div(low+high,2) ;

  while(u<S.U[mid] || u>= S.U[mid+1])
    if(u<S.U[mid])
      high = mid ;
    else
      low = mid ;
    end
    mid = div(low+high,2) ;
  end
  return mid ;
end


function AugmBreaks(S::BSpl{p}) where p 
  return AugmBreaks(p,S.U);
end

@generated function pRange(::Type{Val{p}},i0::Int) where p
  A = Array{Any}(undef,0)
  push!(A,:i0)
  for i=2:p+1
    push!(A,Expr(:call,:+,:i0,i-1))
  end
  return Expr(:tuple,A...)
end
function basisFuns(S::BSpl{p},u, i::Int) where p
  Tout = typeof(u*1.0)
  left = Array{Tout}(undef,p);  # workspace
  right = Array{Tout}(undef,p);  # workspace
  N = Array{Tout}(undef,p+1);  # workspace
  @inbounds N[1] = 1.0 ;
  for j=1:p
    @inbounds left[j] = u-S.U[i+1-j] ;
    @inbounds right[j] = S.U[i+j]-u ;
    saved =  0.0 *u;
    for r=0:j-1
      @inbounds scal = (right[r+1]+left[j-r]) ;
      @inbounds temp = scal==0.0 ? 0.0 : N[r+1]/scal;
      @inbounds N[r+1] = saved+right[r+1] * temp ;
      @inbounds saved = left[j-r] * temp ;
    end
    @inbounds N[j+1] = saved ;
  end
  return N
end
function basisI(S::BSpl{p},u::Number, i::Int) where p
  b = basisFuns(S,u,i)
  return ((i-p):i,b,nCoeff(S))
end
function basisI(S::BSpl{p},u::Number) where p
  i = findSpan(S,getval(u));
  return basisI(S,u,i)
end
function basis(S::BSpl{p},u::Number, i::Int) where p
  b = basisFuns(S,u,i)
  return sparsevec((i-p):i,b,nCoeff(S))
end
function basis(S::BSpl{p},u::Number) where p
  i = findSpan(S,getval(u));
  return basis(S,u,i)
end
function basis(S::BSpl{p},u::Array{T,1}) where {p,T}
  return vcat( map(x->basis(S,x)',u)... )
end
function feval(S::BSpl{p},u,coeff::Array{T,1}) where {p,T}
  i = findSpan(S,getval(u));
  b = basisFuns(S,u,i)
  i0 = i-p
  f = b[1]*coeff[i0]
  @inbounds for j=1:p
    f += b[j+1]*coeff[i0+j];
  end
  return f;
end
function feval(S::BSpl{p},u,coeff::Array{Float64,2}) where p
  i = findSpan(S,getval(u));
  b = basisFuns(S,u,i)
  i0 = i-p
  nC = size(coeff,2)
  f = Array{typeof(u)}(undef,nC)
  @inbounds for k=1:nC
    f[k] = b[1]*coeff[i0,k]
  end
  @inbounds for j=1:p
    @inbounds for k=1:nC
      f[k] += b[j+1]*coeff[i0+j,k];
    end
  end
  return f;
end
feval(S::BSpl{p},x0::Array{Float64,1},coeff::Array{Float64,1}) where p = feval(S,x0[1],coeff)

feval2(S::BSpl{p},x0::Array{Float64,1},coeff::Array{Float64,1}) where p = map(x->feval(S,x,coeff),x0)

# function specialized for order 3; avoids some allocations
function feval(S::BSpl{3},u::Number,coeff::Array{Float64,1})
  i = findSpan(S,getval(u));
  b = basisFuns3(S,u,i)
  i0 = i-3
  f = b[1]*coeff[i0]
  @inbounds for j=1:3
    f += b[j+1]*coeff[i0+j];
  end
  return f;
end
# fevalFast requires that there are no multiple knot points:
function fevalFast(S::BSpl{3},u::Number,coeff::Array{Float64,1})
  i = findSpan(S,getval(u));
  b = basisNonZero3(S,u,i)
  i0 = i-3
  @inbounds f = (b[1]*coeff[i0] + b[2]*coeff[i0+1]) + (b[3]*coeff[i0+2] + b[4]*coeff[i0+3]);
  return f;
end
function fitfun(S::BSpl{p},func::Function) where p
  g = nodes(S)
  y = func.(g)
  B = hcat(map(x->basis(S,x),g)...)
  return B'\y
end



# avoid allocations; brings big speed advantage
function basisFuns3(S::BSpl{3},u, i::Int)
  N1 = 1.0 ;

  left1 = u-S.U[i] ;
  right1 = S.U[i+1]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left1) ;
  temp = scal==0.0 ? 0.0 : N1/scal;
  N1 = saved+right1 * temp ;
  saved = left1 * temp ;
  N2 = saved ;


  # j = 2
  left2 = u-S.U[i+1-2] ;
  right2 = S.U[i+2]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left2) ;
  temp = scal==0.0 ? 0.0 : N1/scal;
  N1 = saved+right1 * temp ;
  saved = left2 * temp ;
  # r=1
  scal = (right2+left1) ;
  temp = scal==0.0 ? 0.0 : N2/scal;
  N2 = saved+right2 * temp ;
  saved = left1 * temp ;
  N3 = saved ;


  # j = 3
  left3 = u-S.U[i+1-3] ;
  right3 = S.U[i+3]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left3) ;
  temp = scal==0.0 ? 0.0 : N1/scal;
  N1 = saved+right1 * temp ;
  saved = left3 * temp ;
  # r=1
  scal = (right2+left2) ;
  temp = scal==0.0 ? 0.0 : N2/scal;
  N2 = saved+right2 * temp ;
  saved = left2 * temp ;
  # r=2
  scal = (right3+left1) ;
  temp = scal==0.0 ? 0.0 : N3/scal;
  N3 = saved+right3 * temp ;
  saved = left1 * temp ;
  N4 = saved ;

  return (N1,N2,N3,N4)
end
function basisNonZero3(S::BSpl{3},u, i::Int)
  left1 = u-S.U[i] ;
  right1 = S.U[i+1]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left1) ;
  temp = 1.0/scal;
  N1 = saved+right1 * temp ;
  saved = left1 * temp ;
  N2 = saved ;


  # j = 2
  left2 = u-S.U[i+1-2] ;
  right2 = S.U[i+2]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left2) ;
  temp = N1/scal;
  N1 = saved+right1 * temp ;
  saved = left2 * temp ;
  # r=1
  scal = (right2+left1) ;
  temp = N2/scal;
  N2 = saved+right2 * temp ;
  saved = left1 * temp ;
  N3 = saved ;


  # j = 3
  left3 = u-S.U[i+1-3] ;
  right3 = S.U[i+3]-u ;
  saved =  0.0 *u;
  # r=0
  scal = (right1+left3) ;
  temp = N1/scal;
  N1 = saved+right1 * temp ;
  saved = left3 * temp ;
  # r=1
  scal = (right2+left2) ;
  temp = N2/scal;
  N2 = saved+right2 * temp ;
  saved = left2 * temp ;
  # r=2
  scal = (right3+left1) ;
  temp = N3/scal;
  N3 = saved+right3 * temp ;
  saved = left1 * temp ;
  N4 = saved ;

  return (N1,N2,N3,N4)
end

function BSplDefine(breaks,p_::Int)
  p = p_;
  n = length(breaks);
  # set U, cf. page 66
  U = Array{Float64}(undef,n+2*p);
  for i=1:p
    U[i] = breaks[1];
  end
  for i=p+1:p+n
    U[i] = breaks[i-p];
  end
  for i=p+n+1:length(U)
    U[i] = breaks[n];
  end
  return BSpl{p}(U,AugmBreaks(p,U));
end
function solve4coeff(S::BSpl{p},X::Array{Float64},Y::Array{T}) where {p,T}
  n=size(Y,1);
  if(n != nCoeff(S)) 
    error("value vector has wrong size in solve4coeff:",n," rather than ",nCoeff(S));
  end
  if(length(X) != n) 
    error("X-vector has wrong size in solve4coeff:",n," rather than ",length(X));
  end

  p4 = p+1;
  ir = Array{Int}(undef,p4*n);
  ic = Array{Int}(undef,p4*n);
  val = Array{Float64}(undef,p4*n);
  N = Array{Float64}(undef,p+1);
  # N = Array{T}(p+1);
  for i=1:n
    iPos = findSpan(S,X[i]);
    basisFuns!(S,X[i], iPos,N);
    i4 = p4*(i-1);
    for j=1:p4
      ir[i4+j] = i;
      ic[i4+j] = iPos-p4+j;
      val[i4+j] = N[j];
    end
  end
  Sp = sparse(ir,ic,val,n,n);
  if T==Float64
    coeff = Sp\Y;
  else
    coeff = full(Sp)\Y; # could be made more efficient!!??
  end
  # try 
  # catch
  #   saveT("SU.txt",S.U,Y,Sp)
  #   error("could not solve for coeff in Bspl")
  # end
  return coeff;
end

function basisFuns!(S::BSpl{p},u::T, i::Int, N::Array{T}) where {p,T}
  left = Array{T}(undef,p);
  right = Array{T}(undef,p);
  N[1] = T(1.0);
  for j=1:p
    left[j] = u-S.U[i+1-j] ;
    right[j] = S.U[i+j]-u ;
    saved =  0.0 *u;
    for r=0:j-1
      scal = (right[r+1]+left[j-r]) ;
      temp = scal==0.0 ? 0.0 : N[r+1]/scal;
      N[r+1] = saved+right[r+1] * temp ;
      saved = left[j-r] * temp ;
    end
    N[j+1] = saved ;
  end
end


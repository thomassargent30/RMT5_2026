# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using Distributions;
function markovappr(lambda,sigma,m,N,threshold::Float64=0.0)

  # the simple case of approximating first-order 
  # autoregressive process with Markov chain

  # y_t = lambda * y_(t-1) + u_t

  # u_t is a Gaussian white noise process with standard deviation sigma.

  # m determines the width of discretized state space, Tauchen uses m=3
  # ymax=m*vary,ymin=-m*vary, ymax and ymin are two boundary points

  # N is the number of possible states chosen to approximate
  # the y_t process, usually N=9 should be fine

  # Pi is the transition matrix of the Markov chain

  # s is the discretized state space of y_t

  # alambda is the theoretical first order autoregression coefficient 
  # for Markov chain

  # asigma is the theoretical standard deviation for Markov chain Y_t

  #############################################################


  # discretize the state space

  stvy = sqrt(sigma^2/(1-lambda^2)); # standard deviation of y_t

  ymax = m*stvy;                     # upper boundary of state space
  ymin = -ymax;                      # lower boundary of state space

  w = (ymax-ymin)/(N-1);             # length of interval 

  s = range(ymin,stop=ymax,length=N)'';                   # the discretized state space
  s = Array(reshape(s,N)) 

  # calculate the transition matrix

  Pi = zeros(N,N);
  for j=1:N;

    for k=2:N-1;

      Pi[j,k]= cdf(Normal(0,sigma),s[k]-lambda*s[j]+w/2) - cdf(Normal(0,sigma),s[k]-lambda*s[j]-w/2);

    end

    Pi[j,1] = cdf(Normal(0,sigma),s[1]-lambda*s[j]+w/2);
    Pi[j,N] = 1 - cdf(Normal(0,sigma),s[N]-lambda*s[j]-w/2);

  end

  if any(abs.(sum(Pi',dims=1) .- 1) .> 1e-10)
    #str = mfind(Pi'-ones(1,N));  # find rows not adding up to one
    println("error in transition matrix");
    #disp(['rows ',num2str(str),' does not sum to one']);

  end



  # change Michael Reiter, October 2005
  # calculate the invariant distribution of Markov chain
  ePi = eigen(mtr(Pi)); # transpose of Pi
  # @show typeof(ePi.values)
  i1 = mfind(abs.(ePi.values .- 1.0) .< 1e-10)
  @assert(length(i1)==1);
  probst = ePi.vectors[:,i1[1]]   
  probst = probst/sum(probst);



  # calculate the asymptotic second moments of Markov chain


  if(threshold>0)
    for i=1:length(Pi) 
      if(Pi[i]<threshold)
        Pi[i] = 0;
      end
    end
    Pi = Pi ./ repeat(sum(Pi,dims=2),1,N);
  end


  return (Pi,s,probst);
end


function rouwen(rho,  sigma_z, N, threshold)

  p = (1+rho)/2;
  q = p;
  psi = sqrt(N-1)*sigma_z;
  grid = convert(Array{Float64,1},range(-psi,stop=psi,length=N))

  Pi = [(p) (1-p) ; (1-q) q];
  for n=3:N 
    Pi = p *  [Pi zeros(n-1,1); zeros(1,n)]  +  (1-p)* [zeros(n-1,1) Pi ; zeros(1,n)] + (1-q) * [ zeros(1,n);Pi zeros(n-1,1)]  +  q* [zeros(1,n) ; zeros(n-1,1) Pi];
    for i=2:n-1 
      for j=1:n 
        Pi[i,j] /= 2;
      end
    end
  end
  if(threshold>0)
    for i=1:length(Pi) 
      if(Pi[i]<threshold)
        Pi[i] = 0;
      end
    end
    Pi = Pi ./ repeat(sum(Pi,dims=2),1,N);
  end
  return (Pi,grid); 
end


# Changes randomly the state in a model with discrete state space
# Inputs:
#   icurr: index of current state (1 to n)
#   randu: uniform random number (between 0 and 1)
#   transprob: transition probability matrix (row=from; col=to)
# Michael Reiter, October 2005
function changestaterandomly(icurr::Int,randu::Float64, transprob)
  if(randu<0 || randu>1)
    error("invalid random number");
  end
  sum = 0;
  n = size(transprob,2);
  for i=1:n-1
    sum = sum + transprob[icurr,i];  
    if(randu<=sum)
      return i;
    end;
  end;
  return n;
end
function changestaterandomly(icurr::Int,randu::Array{Float64,1}, transprob)
  n = length(randu)
  I = fill(0,n+1)
  I[1] = icurr;
  for t=1:n
    I[t+1] = changestaterandomly(I[t],randu[t],transprob)
  end
  return I;
end

mutable struct MarkovChain # <: SingleShock
  X::Array{Float64,1}
  Pi::Array{Float64,2}
  PiSum::Array{Float64,2}
  i::Int # current state
end
#import Base.var
#function var(s::MarkovChain)
#  p = InvDistrib(s.Pi)
#  m = dot(p,s.X)
#  return dot((s.X .- m).^2,p);
#end
#stdev(s::MarkovChain) = sqrt(var(s))
function condvar(s::MarkovChain)
  n = size(s.Pi,1)
  cv = zeros(n)
  for i=1:n
    m = dot(s.Pi[i,:],s.X)
    cv[i] = dot(s.Pi[i,:],(s.X .- m).^2)
  end
  return cv;
end
condvar(X::Array{Float64,1}, Pi::Array{Float64,2}) = condvar(MarkovChain(X,Pi))
Base.getindex(s::MarkovChain,i::Int) = s.X[i]

function Base.show(io::IO, x::MarkovChain)
  println("Markov chain, number of states = ",length(x.X))
  println(x.X)
end

function MarkovChain( X0::AbstractArray{Float64,1},Pi::Array{Float64,2})
  X = convert(Array{Float64,1},X0)
  n = length(X)
  @assert(size(Pi)==(n,n))
  PiS = similar(Pi)
  for i=1:n # notice that PiS is transposed, for efficiency
    PiS[:,i] = cumsum(Pi[i,:])
  end
  @assert(all(abs.(1 .- PiS[end,:]).<1e-12))
  PiS[end,] = 1.0;
  return MarkovChain(X,Pi,PiS,0)
end
function MarkovChain(method::String, rho::Float64,  sigma_z::Float64, n::Int, width::Float64=2.5)
  threshold = 1e-14
  if method=="Tauchen" || method=="tauchen"
    (Pi,X,probst) = markovappr(rho,sigma_z,width,n,threshold)
  elseif method=="rouwen" || method=="Rouwen" || method=="rouwenhorst" || method=="Rouwenhorst"
    (Pi,X)= rouwen(rho,  sigma_z, n, threshold)
  else
    error("wrong method for MarkovChain")
  end
  return MarkovChain(X,Pi)
end
import Base.*
function *(x::Float64,s::MarkovChain) 
  return MarkovChain(s.X*x,s.Pi,s.PiSum,s.i)
end

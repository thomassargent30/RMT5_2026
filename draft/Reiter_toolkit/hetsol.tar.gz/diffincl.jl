# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

selectnz(A) = A[Main.mfind(map(x->x!=0,A))]

struct Prim
  s::Any
end
struct ElProd
  base::Any
  expo::Any
end
struct ElSum
  elem::Any
  relf::Real
end
struct Prod
  A::Real
  facs::Array{ElProd,1}
end
import Base.==
==(x::ElProd,y::ElProd) = x.base==y.base && x.expo==y.expo
==(x::ElSum,y::ElSum) = x.elem==y.elem && x.relf==y.relf
==(x::Prod,y::Prod) = x.A==y.A && length(x.facs)==length(y.facs) && all(map(==,x.facs,y.facs))
struct Sum
  A::Real
  facs::Array{ElSum}
end
==(x::Sum,y::Sum) = x.A==y.A && length(x.facs)==length(y.facs) && all(map(==,x.facs,y.facs))
struct RealMul
  A::Real
  x::Any
end
==(x::RealMul,y::RealMul) = x.A==y.A && x.x==y.x
==(x::Prim,y::Prim) = x.s==y.s
import Base.convert
convert(::Type{Prod},y::RealMul) = Prod(y.A,[ElProd(y.x,1)])
convert(::Type{Sum},y::RealMul) = Sum(0,[ElSum(y.x,y.A)])


tNumber(::Prim) = 1
tNumber(::RealMul) = 2
tNumber(::Prod) = 3
tNumber(::Sum) = 4
Mytype = Union{Prim,RealMul,Prod,Sum}
NotReal = Union{Prim,Prod,Sum}
NotRealMul = Union{Prim,Prod,Sum,Real}


import Base.^
import Base.*
import Base.+
import Base.-
import Base./
import Base.isless
isless(y::Real,x::Mytype) = true
isless(x::Mytype,y::Real) = false
isless(x::ElProd,y::ElProd) = isless(x.base,y.base)
isless(x::ElSum,y::ElSum) = isless(x.elem,y.elem)

islessSame(x::Prim,y::Prim) = isless(string(x.s),string(y.s))
islessSame(x::RealMul,y::RealMul) = isless(string(x.x),string(y.x))
islessSame(x::Prod,y::Prod) = isless(prod(string.(x.facs)),prod(string.(y.facs)))
islessSame(x::Sum,y::Sum) = isless(prod(string.(x.facs)),prod(string.(y.facs)))


function isless(x::Mytype,y::Mytype) 
  if typeof(x)==typeof(y)
    return islessSame(x,y)
  else
    return tNumber(x)<tNumber(y)
  end
end

# treat RealMul special, depending on operation:
+(x::NotRealMul,y::RealMul) = +(x,convert(Sum,y))
+(x::RealMul,y::NotRealMul) = +(y,x)
+(x::RealMul,y::RealMul) = +(convert(Sum,x),convert(Sum,y))
*(x::NotRealMul,y::RealMul) = *(x,convert(Prod,y))
*(x::RealMul,y::NotRealMul) = *(y,x)
*(x::RealMul,y::RealMul) = *(convert(Prod,x),convert(Prod,y))


^(x::Float64,y::Prim) = pow(x,y)
^(x::Float64,y::RealMul) = pow(x,y)
^(x::Float64,y::Sum) = pow(x,y)
^(x::Float64,y::Prod) = pow(x,y)
^(x::Int,y::Prim) = pow(x,y)
^(x::Int,y::RealMul) = pow(x,y)
^(x::Int,y::Sum) = pow(x,y)
^(x::Int,y::Prod) = pow(x,y)
^(x::Prim,y::Float64) = pow(x,y)
^(x::Prim,y::Int) = pow(x,y)
^(x::Prim,y::Prim) = pow(x,y)
^(x::Prim,y::RealMul) = pow(x,y)
^(x::Prim,y::Sum) = pow(x,y)
^(x::Prim,y::Prod) = pow(x,y)
^(x::RealMul,y::Float64) = pow(x,y)
^(x::RealMul,y::Int) = pow(x,y)
^(x::RealMul,y::Prim) = pow(x,y)
^(x::RealMul,y::RealMul) = pow(x,y)
^(x::RealMul,y::Sum) = pow(x,y)
^(x::RealMul,y::Prod) = pow(x,y)
^(x::Sum,y::Float64) = pow(x,y)
^(x::Sum,y::Int) = pow(x,y)
^(x::Sum,y::Prim) = pow(x,y)
^(x::Sum,y::RealMul) = pow(x,y)
^(x::Sum,y::Sum) = pow(x,y)
^(x::Sum,y::Prod) = pow(x,y)
^(x::Prod,y::Float64) = pow(x,y)
^(x::Prod,y::Int) = pow(x,y)
^(x::Prod,y::Prim) = pow(x,y)
^(x::Prod,y::RealMul) = pow(x,y)
^(x::Prod,y::Sum) = pow(x,y)
^(x::Prod,y::Prod) = pow(x,y)
pow(a,b) = Prod(1,[ElProd(a,b)])   # default for everything
pow(a::Real,b::Real) = a^b
function pow(a::Union{Prim,Sum,Prod},b::Real) 
  if b==0 
    return 1;
  else
    return Prod(1,[ElProd(a,b)]) 
  end
end
pow(a::RealMul,b::Real) = Prod(a.A^b,[ElProd(a.x,b)]) 
function pow(a::Real,b)
  if a==0
    return 0;
  elseif b==1
    return a;
  else
    return Prod(1,[ElProd(a,b)])
  end
end
pow(a::RealMul,b) = Prod(1,[ElProd(a.A,b);ElProd(a.x,b)]) 


flatten(x::Union{Real,Prim}) = x
function flatten(x::RealMul)
  if x.A==0
    return 0;
  elseif x.A==1
    return x.x;
  else
    return x;
  end
end
function flatten(x::Prod)
  # println(sym2e(x))
  if x.A==0
    return 0;
  end
  f = x.facs
  n = length(f)
  keep = 1:n
  g = Array{ElProd}(undef,0)
  totalfac = x.A
  for i=1:n
    fi = f[i]
    if isa(fi.base,Prod) && isa(fi.expo,Real)
      keep = setdiff(keep,i)
      pow = fi.expo
      totalfac *= fi.base.A ^ pow
      args = fi.base.facs
      for j=1:length(args)
        push!(g,ElProd(fi.base.facs[j].base,fi.base.facs[j].expo*pow))
      end
    end
  end
  f = vcat(f[keep],g);
  f = sort(f)
  n = length(f)
  i = 1;
  while i<n
    iBase = i;
    for j=i+1:n
      i = j
      if f[iBase].base==f[j].base
        f[iBase] = ElProd(f[iBase].base,f[iBase].expo+f[j].expo)
        f[j] = ElProd(1,0)
      else
        break
      end
    end
  end
  keep = fill(true,(n,))
  for i=1:n
    if f[i].base==1 || f[i].expo==0
      keep[i] = false
    end
  end
  f = f[Main.mfind(keep)]
  if isempty(f)
    return totalfac
  elseif length(f)==1 && f[1].expo==1
    if totalfac==1
      return f[1].base
    else
      return RealMul(totalfac,f[1].base)
    end
  else
    xx =  Prod(totalfac,f)
    # println("neu: ",sym2e(xx))
    return xx
  end
end

######################################################################
# MULTIPLICATION:
######################################################################
# 1) special treatment for real:
function *(x::Union{Prim,Sum},y::Real)
  if y==0
    return 0;
  elseif y==1
    return x;
  else
    return mymul(x,y)
  end
end
*(x::Prod,y::Real) = Prod(x.A*y,x.facs)
# Alternative: has different properties for simplification in fractions; consider
#   c = ((a+b)*2-a)/(a+2*b)    versus
#   c = (a+b)*3/(a+b)
*(x::Sum,y::Real) = RealMul(y,x) # better this, and handle first case with expand
# *(y::Real,x::Sum) = Sum(y*x.A,map(x->(x[1],x[2]*y),x.facs))

# 1a) reverse order:
*(y::Real,x::NotReal) = *(x,y)

# 2) defer rest to mymul, which does  not check for 0,1:
*(x::NotReal,y::NotReal) = mymul(x,y)

#3) mymul:
function mymul(x::NotReal,y::Real) 
  return RealMul(y,x)
end
mymul(y::Real,x::NotReal) = mymul(x,y)

function mymul(x::NotReal,y::NotReal) 
  if x==y
    return Prod(1,[ElProd(x,2)])
  else
    return Prod(1,sort([ElProd(x,1);ElProd(y,1)]))
  end
end
function mymul(x::Prod,y::Prod)
  z = Prod(x.A*y.A,vcat(x.facs,y.facs))
  return flatten(z)
end
function mymul(x::Prod,y::NotReal)
  z = Prod(x.A,vcat(x.facs,ElProd(y,1)))
  return flatten(z)
end
mymul(y::NotReal,x::Prod) = mymul(x,y)




######################################################################
# DIVISION:
######################################################################
# first unary division:
div1(y::Real) = 1/y
div1(y::Union{Prim,Sum}) = Prod(1,[ElProd(y,-1)])
div1(y::RealMul) = Prod(1/y.A,[ElProd(y.x,-1)])
function div1(y::Prod)
  yminus = map(x->ElProd(x.base,-x.expo),y.facs)
  return Prod(1/y.A,yminus)
end
/(x,y) = *(x,div1(y))
# /(x::Union{Prim,Sum,Prod,RealMul,Real},y::Union{Prim,Sum,Prod,RealMul}) = *(x,div1(y))
# /(x::Union{Prim,Sum,Prod,RealMul},y::Int) = *(x,1//y)
# /(x::Union{Prim,Sum,Prod,RealMul},y::Real) = *(x,1/y)


######################################################################
# ADDITION:
######################################################################
# now special treatment for real
+(x::NotReal,y::NotReal) = myadd(x,y)
+(x::Sum,y::Real) = Sum(x.A+y,x.facs)
+(y::Real,x::Sum) = Sum(x.A+y,x.facs)
function +(x::NotReal,y::Real)
  if y==0
    return x;
  else
    return myadd(x,y)
  end
end
function +(y::Real,x::NotReal)
  if y==0
    return x;
  else
    return myadd(x,y)
  end
end
function myadd(x::NotReal,y::Real) 
  return Sum(y,[ElSum(x,1)])
end
myadd(y::Real,x::NotReal) = myadd(x,y)
function myadd(x::NotReal,y::NotReal) 
  if x==y
    return RealMul(2,x)
  else
    return Sum(0,sort([ElSum(x,1);ElSum(y,1)]))
  end
end
function myadd(x::Sum,y::Sum)
  z = Sum(x.A+y.A,vcat(x.facs,y.facs))
  return flatten(z)
end
function myadd(x::Sum,y::NotReal)
  z = Sum(x.A,vcat(x.facs,ElSum(y,1)))
  return flatten(z)
end
myadd(y::NotReal,x::Sum) = +(x,y)



function flatten(x::Sum)
  f = sort(x.facs)
  n = length(f)
  for i=1:n
    # assert(!isa(f[i].elem,Sum))
    if isa(f[i].elem,Prod) && f[i].elem.A<0
      f[i] = ElSum(Prod(-f[i].elem.A,f[i].elem.facs),-f[i].relf)
    end
  end
  i = 1;
  while i<n
    iBase = i;
    for j=i+1:n
      i = j
      if f[iBase].elem==f[j].elem
        f[iBase] = ElSum(f[iBase].elem,f[iBase].relf+f[j].relf)
        f[j] = ElSum(0,0)
      else
        break
      end
    end
  end
  keep = fill(true,(n,))
  for i=1:n
    if f[i].elem==0 || f[i].relf==0
      keep[i] = false
    end
  end
  f = f[keep]
  if isempty(f)
    return x.A
  elseif x.A==0 && length(f)==1
    return RealMul(f[1].relf,f[1].elem)
  else
    return Sum(x.A,f)
  end
end

######################################################################
# SUBTRACTION:
######################################################################
# first unary minus:
-(y::Prim) = RealMul(-1,y)
-(y::Prod) = Prod(-y.A,y.facs)
-(y::RealMul) = RealMul(-y.A,y.x)
function -(y::Sum)
  yminus = map(x->ElSum(x.elem,-x.relf),y.facs)
  z = Sum(-y.A,yminus)
  return flatten(z)
end
-(x::Union{Prim,Sum,Prod,RealMul,Real},y::Union{Prim,Sum,Prod,RealMul}) = +(x,-y)
-(x::Union{Prim,Sum,Prod,RealMul},y::Real) = +(x,-y)


######################################################################
# convert Expression to symbols:
######################################################################
function e2syme(ex::Real)
  return ex;
end
function e2syme(ex::QuoteNode)
  return ex;
end
function e2syme(ex::Symbol)
  return Prim(ex);
end
function e2syme(ex::Expr)
  # println("expr: ",ex)
  h = ex.head
  if h==:call
    op = ex.args[1]
    args = map(e2syme,ex.args[2:end])
    if op==:+ || op==:- || op==:* || op==:/
      mye = Expr(:call,op,args...)
      return mye
    elseif op==:^  # transform to pow function, to avoid tricks for integer ^ in base
      return Expr(:call,:pow,args...)
    elseif op==:> || op==:< || op==:(==)
      return Prim(Expr(:call,op,args...))
    elseif op==:ifelse
      return Prim(Expr(:call,:ifelse,args...))
    elseif misdefined(op)
      return Expr(:call,op,args...)
    else
      args = map(x->eval(e2syme(x)),ex.args[2:end])
      return Prim(Expr(:call,op,args...))
    end
  elseif h==:ref
    args = map(e2syme,ex.args)
    return Prim(Expr(:ref,args...))
  end
  return h;
end
function e2sym(ex::Real)
  return ex;
end
e2sym(ex::Expr) = eval(e2syme(ex))


######################################################################
# convert symbols to expressions
######################################################################
function sym2e(ex::Expr)
  if ex.head==:call # first argument is preserved; we assume function is defined
    args = map(sym2e,ex.args[2:end])
    if ex.args[1]==:pow
      return Expr(:call,:^,args...)
    else
      return Expr(:call,ex.args[1],args...)
    end
  elseif ex.head==:ref  # first argument replaced by symbol; need not be defined
    return Expr(:ref,map(sym2e,ex.args[1:end])...)
  else
    error("wrong expresseion")
  end
end
function sym2e(ex::QuoteNode)
  return ex.value;
end
function sym2e(ex::Real)
  return ex;
end
function sym2e(ex::RealMul)
  if ex.A==1
    return sym2e(ex.x)
  elseif ex.A==-1
    return Expr(:call,:-,sym2e(ex.x))
  else
    return Expr(:call,:*,ex.A,sym2e(ex.x))
  end
end
function sym2e(ex::Symbol)
  return ex;
end
function sym2e(ex::Prim)
  return sym2e(ex.s)
end
function sym2epow(x,y)
  if y==1
    return sym2e(x)
  else
    return Expr(:call,:^,sym2e(x),sym2e(y))
  end
end
function sym2emul(x)
  if x.relf==1
    return sym2e(x.elem)
  elseif x.relf==-1
    return Expr(:call,:-,sym2e(x.elem))
  elseif isa(x.relf,Real)
    return Expr(:call,:-,Expr(:call,:*,-x.relf,sym2e(x.elem)))
  else
    return Expr(:call,:*,sym2e(x.elem),sym2e(x.relf))
  end
end
function sym2epos(x)
  fac = abs(x.relf);
  if fac==1
    return sym2e(x.elem)
  else
    return Expr(:call,:*,fac,sym2e(x.elem))
  end
end
function sym2epospow(x)
  fac = isa(x.expo,Real) ? abs(x.expo) : sym2e(x.expo)
  if fac==1
    return sym2e(x.base)
  else
    return Expr(:call,:^,sym2e(x.base),fac)
  end
end

function sym2e(S::Sum)
  iPos = Main.mfind(map(x->x.relf>0,S.facs))
  iNeg = Main.mfind(map(x->x.relf<0,S.facs))
  args = vcat(S.A>0 ? S.A : [],map(sym2epos,S.facs[iPos]))
  args = selectnz(args)
  npos = length(args)
  if npos>1
    ePos = Expr(:call,:+,args...)
  elseif npos==1
    ePos = args[1];
  end
  args = vcat(S.A<0 ? -S.A : [],map(sym2epos,S.facs[iNeg]))
  args = selectnz(args)
  nneg = length(args)
  if nneg>1
    eNeg = Expr(:call,:+,args...)
  elseif nneg==1
    eNeg = args[1];
  end
  if nneg==0
    try
      return ePos
    catch
      println(S)
    end
  elseif npos==0
    return Expr(:call,:-,eNeg)
  else
    return Expr(:call,:-,ePos,eNeg)
  end
end
function sym2e(S::Prod)
  if S.A==0
    return 0
  end
  if isempty(S.facs)
    return S.A
  end
  doMinus = S.A<0
  fac = abs(S.A)

  iNeg = Main.mfind(map(x->isa(x.expo,Real) && x.expo<0,S.facs))
  iPos = setdiff(1:length(S.facs),iNeg)

  args = vcat(fac!=1 ? fac : [],map(sym2epospow,S.facs[iPos]))
  npos = length(args)
  if npos>1
    ePos = Expr(:call,:*,args...)
  elseif npos==1
    ePos = args[1];
  else
    ePos = 1
  end
  args = map(sym2epospow,S.facs[iNeg])
  nneg = length(args)
  if nneg>1
    eNeg = Expr(:call,:*,args...)
  elseif nneg==1
    eNeg = args[1];
  end
  if nneg==0
    ratio = ePos
  else
    ratio  = Expr(:call,:/,ePos,eNeg)
  end
  if doMinus
    return Expr(:call,:-,ratio)
  else
    return ratio
  end
end


######################################################################
# DIFFEENTIATION
######################################################################

function diff_(x::QuoteNode,z::Prim)
  if x.value == z
    return 1
  else
    return 0;
  end
end
function diff_(x::Real,z::Prim)
  return 0;
end
function diff_(S::RealMul,z::Prim)
  return S.A * diff_(S.x,z)
end
function diff_(x::Sum,z::Prim)
  d = 0;
  for i=1:length(x.facs)
    xi = x.facs[i]
    d = d + xi.relf*diff_(xi.elem,z)
  end
  return d;
end
function diff_(S::Prod,z::Prim)
  if S.A==0
    return 0;
  end
  d = 0
  n = length(S.facs)
  for i=1:n
    xi = S.facs[i]
    facs = Array{ElProd}(undef,0)
    x = xi.base
    dx = diff_(x,z)
    # println("dx: ",sym2e(dx))
    y = xi.expo
    if y==1
      if dx==0
        continue
      end
      push!(facs,ElProd(dx,1))
    else
      df1 = flatten(y*pow(x,(y-1))*dx)
      dy = diff_(y,z)
      if dy==0
        dfdf = df1
      else
        df2 = flatten(pow(x,y)*log(x)*dy)
        dfdf = flatten(df1+df2)
        println("dfdf: ",sym2e(dfdf))
      end
      if dfdf==0
        continue;
      else
        push!(facs,ElProd(dfdf,1))
      end
    end
    for j=1:n
      xj = S.facs[j]
      if i!=j
        push!(facs,xj)
      end
    end
    dd = flatten(Prod(S.A,facs))
    d = flatten(d + dd)
  end
  return d;
  # if S.A==1
  #   return d
  # elseif S.A==-1
  #   return -d
  # else
  #   return S.A * d;
  # end
end



######################################################################
# HANDLE FUNCTIONS:
######################################################################
include("difffunc.jl")
exp(x::Real) = x==0 ? 1 : Prim(Expr(:call,:exp,x))
erf(x::Real) = x==0 ? 0 : Prim(Expr(:call,:erf,x))
log(x::Real) = x==1 ? 0 : Prim(Expr(:call,:log,x))

simpl(x::String) = sym2e(e2sym(parse(x)))
simpl(x::Expr) = sym2e(e2sym(x))
sdiff(x::String,z::Symbol) = sym2e(diff_(e2sym(parse(x)),e2sym(z)))
sdiff(x::Expr,z::Symbol) = sym2e(diff_(e2sym(x),e2syme(z)))
sdiff(x::String,z::String) = sym2e(diff_(e2sym(parse(x)),e2sym(parse(z))))
sdiff(x::Expr,z::Expr) = sym2e(diff_(e2sym(x),e2sym(z)))
function pdiff(x,z)
  s = sdiff(x,z)
  print(s)
end


# include("subs.jl")
sqrt(x) = x^0.5
id(x) = x
cdfnormal(x,mu,sigma) = 1//2*( 1 + erf( (x-mu)/(sigma*sqrt(2)) ) )
cdflognormal(x,mu,sigma) = cdfnormal(log(x),mu,sigma)

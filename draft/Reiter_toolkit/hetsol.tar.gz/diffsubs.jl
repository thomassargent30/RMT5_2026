# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function subsexpr(ex::Real,s,repl)
  return ex;
end
function subsexpr(ex::Symbol,s,repl)
  if(ex == s)
    return repl;
  else
    return ex;
  end
end
function subsexpr(ex::Expr,s,repl)
  if(ex==s)
    return repl;
  end
  # don't substitute head
  args = map(x->subsexpr(x,s,repl),ex.args)
  return Expr(ex.head,args...)
end

function containsExpr(ex::Real,s...)
  return false;
end
function containsExpr(ex::Symbol,s...)
  for i=1:length(s)
    if(ex == s[i])
      return true;
    end
  end
  return false;
end
function containsExpr(ex::Expr,s...)
  if(containsExpr(ex.head,s...))
    return true;
  end
  for i=1:length(ex.args)
    if(containsExpr(ex.args[i],s...))
      return true;
    end
  end
  return false;
end
function countExpr(ex::Real,s...)
  return false;
end
function countExpr(ex::Symbol,s...)
  c = 0
  for i=1:length(s)
    if(ex == s[i])
      c += 1
    end
  end
  return c;
end
function countExpr(ex::Expr,s...)
  assert(!containsExpr(ex.head,s...))
  c = 0
  for i=1:length(ex.args)
    c += countExpr(ex.args[i],s...)
  end
  return c;
end

function convert2stst(ex::Expr)
  ex = subsexpr(ex,:(t+1),:stst)
  ex = subsexpr(ex,:(t-1),:stst)
  ex = subsexpr(ex,:t,:stst)
  ex = subsexpr(ex,:EXP,:id)
  assert(!containsExpr(ex,:t))
  return ex;
end
function solveNLatstst(str::String,var0::String)
  ex = macroexpand(Meta.parse(str))
  ess = convert2stst(ex)
  var = Meta.parse(var0)
  if isa(var,Symbol)
    vt = Expr(:ref,var,:stst)
  else
    assert(var.head==:ref)
    vt = Expr(:ref,var.args...,:stst)
  end
  sol = solvenl(ex,var,0)
  return sym2e(sol)
end
# function solveatstst(str::String,var0::String)
#   ex = macroexpand(Meta.parse(str))
#   var = Meta.parse(var0)
#   #println("ex: ", ex)
#   ess = convert2stst(ex)
#   println("ess: ", ess)
#   if isa(var,Symbol)
#     vt = Expr(:ref,var,:stst)
#   else
#     assert(var.head==:ref)
#     vt = Expr(:ref,var.args...,:stst)
#   end
#   esym = e2sym(ess) # must make sure this recognizes functions defined in prepro
#   vsym = e2sym(vt)
#   println("Var to solve linearly: ", sym2e(vsym))
#   dedv = diff_(esym,vsym)
#   println("Expr to solve linearly: ", sym2e(esym))
#   # dedv = mydiff.diff_(esym,vsym)
#   assert(dedv!=0)
#   dedv2 = diff_(dedv,vsym)
#   # dedv2 = mydiff.diff_(dedv,vsym)
#   assert(dedv2==0)
# 
#   ess0 = subsexpr(ess,vt,0)
#   sol = -e2sym(ess0) / dedv
#   return sym2e(sol)
# end
# function solveatstst(ex::Expr,var)
#   ess = convert2stst(ex)
#   if isa(var,Symbol)
#     vt = Expr(:ref,var,:stst)
#   else
#     assert(var.head==:ref)
#     vt = Expr(:ref,var.args...,:stst)
#   end
#   dedv = sdiff(ess,vt)
#   assert(dedv!=0)
#   if isa(dedv,Expr)
#     dedv2 = sdiff(dedv,vt)
#     assert(dedv2==0)
#   end
# 
#   ess0 = subsexpr(ess,vt,0)
#   sol = -e2sym(ess0) / e2sym(dedv)
#   return sym2e(sol)
# end

## function solveat(equ0::String,var0::String,mod::Module)
##   equ = Meta.parse(equ0) # is evaluated through sym4ss
##   var = Meta.parse(var0)
##   e0 = subsexpr(equ,var,0)
##   equ0 = eval(mod,:(sym2e($e0)))
##   e_t = eval(mod,equ) # is evaluated through sym4ss
##   v_t = eval(mod,var)
##   dedv = eval(mod,:(diff_($e_t,$v_t)))
##   if dedv==0
##     println(sym2e(v_t))
##     println(sym2e(e_t))
##     error("expression does not contain variable")
##   end
##   dedv2 = eval(mod,:(diff_($dedv,$v_t)))
##   if dedv2!=0
##     println(sym2e(v_t))
##     println(sym2e(e_t))
##     error("expression not linear in variable")
##   end
## 
##   e0 = mod.sym2e(equ0)
##   d0 = mod.sym2e(dedv)
##   sol = -eval(mod,:($e0 / $d0))
##   # sol = equ0 / dedv
##   # sol = -eval(mod,:($equ0 / $dedv))
##   return sym2e(sol)
## end


function evalat(equ0::String)
  # println("in evalat: ",equ0)
  equ = Meta.parse(equ0) # is evaluated through sym4ss
  e_t = eval(equ) # is evaluated through sym4ss
  return sym2e(e_t)
end
function solveat(equ0::String,var0::String)
  # println("in solveat: ",equ0,";",var0)
  equ = Meta.parse(equ0) # is evaluated through sym4ss
  var = Meta.parse(var0)
  e_t = eval(equ) # is evaluated through sym4ss
  v_t = eval(var)
  e0_t = eval(subsexpr(sym2e(e_t),sym2e(v_t),0))
  dedv = diff_(e_t,v_t)
  if dedv==0
    println(sym2e(v_t))
    println(sym2e(e_t))
    error("expression does not contain variable")
  end
  dedv2 = diff_(dedv,v_t)
  if dedv2!=0
    println(sym2e(v_t))
    println(sym2e(e_t))
    error("expression not linear in variable")
  end

  sol = -e0_t / dedv
  return sym2e(sol)
end

#   ex = macroexpand(Meta.parse(str))
function solvelin(ex::Expr,vt::Union{Symbol,Expr})
  dedv = sdiff(ex,vt)
  assert(dedv!=0)
  if isa(dedv,Expr)
    dedv2 = sdiff(dedv,vt)
    assert(dedv2==0)
  end
  ex0 = subsexpr(ex,vt,0)
  # println(e2sym(ex0)
  sol = -flatten(e2sym(ex0) / e2sym(dedv))
  return sym2e(sol)
end

function solvenl(ex::Expr,x::Union{Symbol,Expr},lhs)
  c = countExpr(ex,x)
  if c==0
    println(ex)
    println(x)
    error("Expr does not contain variable")
  elseif c>1
    error("cannot solve")
  end

  assert(ex.head==:call)
  op = ex.args[1]
  args = copy(ex.args[2:end])
  t1 = :t2solve
  for i=1:length(args)
    a = args[i]
    if containsExpr(a,x)
      args[i] = t1
      if op==:+ || op==:- || op==:*
        e2solve = Expr(:call,:-,Expr(:call,op,args...),lhs)
        lhs2 = solvelin(e2solve,t1)
      elseif op==:log
        lhs2 = Expr(:call,:exp,lhs)
      elseif op==:exp
        lhs2 = Expr(:call,:log,lhs)
      elseif op==:/
        if i==1
          lhs2 = Expr(:call,:*,lhs,args[2])
        else
          assert(i==2)
          lhs2 = Expr(:call,:/,args[1],lhs)
        end
      elseif op==:pow || op==:^
        if i==1
          lhs2 = Expr(:call,:pow,lhs,Expr(:call,:/,1,args[2]))
        else
          assert(i==2)
          lhs2 = Expr(:call,:log,Expr(:call,:/,lhs,args[1]))
        end
      else
        error(op)
      end
      # println(t1," = ",sym2e(lhs2))
      if isa(a,Expr)
        sol = solvenl(a,x,lhs2)
      else
        sol = lhs2;
      end
      return sym2e(sol)
    end
  end
end


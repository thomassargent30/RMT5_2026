using SparseArrays
abstract type StructPars end
abstract type StructVars end
abstract type StructVarsStSt{TFloat} end
abstract type StructShks end
struct DPVar
  name::String
  V::String
  D::String
  # DPVar() = new()
end
struct ModelInfo
  id::Int64
  dp::Array{DPVar,1}
end
if !@isdefined _modelinfo
  const _modelinfo = Dict{String, ModelInfo}()
end
function modelname(i::Integer)
  ks = keys(_modelinfo)
  for k in ks
    if _modelinfo[k].id == i;
      return k;
    end
  end
  error("no model with index $i")
end

# mutable struct LinModelID
#   id::Int
#   DPproblems::Array{Symbol,1}
#   DPvalues::Array{String,1}
#   DPdistrs::Array{String,1}
# end
mutable struct LinModel
  info::ModelInfo
 eu::Array{Int,1}
  eigvals::Array{Complex{Float64},1}
  Gamma::SparseMatrixCSC{Float64,Int64}
  Lambda::SparseMatrixCSC{Float64,Int64}
  Phi::SparseMatrixCSC{Float64,Int64}
  Psi::Array{Float64,2}
  Pi::SparseMatrixCSC{Float64,Int64}
  pars::StructPars
  vstst::StructVarsStSt
  equNames::Dict{String,UnitRange{Int}}
  varNames::Dict{Symbol,UnitRange{Int}}
  guess::Array{Float64,1}
end
mutable struct LinSol
  name::String
  A::Array{Float64,2}
  B::Array{Float64,2}
  pars::StructPars
  vstst::StructVarsStSt
  equNames::Dict{String,UnitRange{Int}}
  varNames::Dict{Symbol,UnitRange{Int}}
  id::Int
  guess::Array{Float64,1}
end
nVar(m::LinModel) = size(m.Gamma,1);
nShock(m::LinModel) = size(m.Psi,2);
nShock(m::LinSol) = size(m.B,2);
nVar(m::LinSol) = size(m.A,1);
struct ReduceState
  selectMom::Array{Float64,2}
  proxyD::Array{Float64,2}
  iequ::Array{Int,1}  # index of equations
  ivar::Array{Int,1}  # index of variables
end
nStates(x::LinModel) = nnzcols(x.Lambda)


dimen(x::ReduceState) = size(x.selectMom,1);
struct ReduceValue
  basis::Array{Float64,2}
  project::Array{Float64,2}
  iequ::UnitRange{Int}  # index of equations
  ivar::UnitRange{Int}  # index of variables
end
dimen(x::ReduceValue) = size(x.project,1);
# HETEROGENEOUS AGENT MODELS:
struct Switch{T}
  iState::Tuple{Int,Int,Int}
  iLeft::Int
  iRight::Int
  bLeft::Int
  bRight::Int
  ccLeft::T
  ccRight::T
  pLeft::T
  pRight::T
  fracLeft::T
end
function Base.show(io::IO, x::Switch)
  @printf(io,"At (%d:%0.3f,%d,%d) switch from %f (b=%d;i=%d) to %f (b=%d;i=%d)",
          x.iState[1],getval(x.fracLeft),x.iState[2],x.iState[3], 
          getval(x.ccLeft),x.bLeft,x.iLeft,
          getval(x.ccRight),x.bRight,x.iRight)
end
function pos(sw::Switch,pol)
  g = pol.grid
  x0 = g[sw.iState[1]]
  x1 = g[sw.iState[1]+1]
  p = sw.fracLeft
  return (1-p)*x0 + p*x1;
end
function posSwitch(pol,i::Integer)
  return pos(pol.switches[i],pol);
end
const TypeDC = Int16
const TypeBind = Int8
mutable struct DynProgVal{T}
  grid::Array{Float64,1}
  V::Array{T,3}
  Q::Array{Float64,3}
end
function dynProgVal(grid::Array{Float64,1},nDS::Int,nExog::Int)
  nCS = length(grid) 
  return DynProgVal(grid,fill(0.0,(nCS,nDS,nExog)),fill(0.0,(nCS,nDS,nExog)),fill(0.0,(nCS,nDS,nExog)),fill(0.0,(nCS,nDS,nExog)))
end
dynProgVal(grid::Array{Float64,1},V::Array{T,3}) where T = 
DynProgVal(grid,
           V,
           zeros(size(V)),
           # fill(zero(TypeDC),size(V)),
           # 0.0*V,
           # fill(zero(TypeBind),size(V)),
          )

dynProgVal(grid::Array{Float64,1},V::Array{T,3},Q::Array{Float64,3}) where T = DynProgVal(grid,V,Q)

mutable struct DynProgPol{T}
  grid::Array{Float64,1}
  CC::Array{T,3}
  DC::Array{TypeDC,3}
  DE::Array{TypeDC,3}
  B::Array{TypeBind,3}
  switches::Array{Switch{T},1}
end
struct DynProgPol2{T}
  stst::DynProgPol{Float64}
  fluct::DynProgPol{T}
end
getindex(x::DynProgPol2{T},t::StStIndex) where T = x.stst;
getindex(x::DynProgPol2{T},t::TimeIndex) where T = x.fluct;

dynProgPol(T::DataType,dpstst::DynProgPol{Float64}) = DynProgPol(dpstst.grid,
           fillzero(T,size(dpstst.CC)),
           dpstst.DC,
           #dpstst.I,
           #fillzero(T,size(dpstst.CC)),
           dpstst.DE,
           #fillzero(T,size(dpstst.CC)),
           dpstst.B,
           Array{Switch{T}}(undef,size(dpstst.switches))
)

function dynProgPol(T::DataType,grid::Array{Float64,1},nDS,nExog) 
  nCS = length(grid)
  return DynProgPol( grid,
                    fillzero(T,(nCS,nDS,nExog)),
                    fill(zero(TypeDC),(nCS,nDS,nExog)),
  #fill(zero(Int32),(nCS,nDS,nExog)),
  #fillzero(T,(nCS,nDS,nExog)),
  fill(zero(TypeDC),(nCS,nDS,nExog)),
  #fillzero(T,(nCS,nDS,nExog)),
  fill(zero(TypeBind),(nCS,nDS,nExog)),
  Array{Switch{T}}(undef,0)
          )
end
struct LinSolHA
  model::LinModel
  A::Array{Float64,2}
  B::Array{Float64,2}
  redS::ReduceState
  redV::ReduceValue
  dpProblem::Module  # redundant !!?? symbol is part of model
  val::DynProgVal{Float64}
  pol::DynProgPol2{Deriv4hs}
  # Dstst::Array{Float64,3}
  StatesStSt::Array{Float64,1}
end
function posSwitch(sol::LinSolHA,i::Integer)
  posSwitch(sol.pol.stst,i)
end


nVar(x::LinSolHA) = nVar(x.model)
iStates(x::LinSolHA) = findnzcols(x.model.Lambda)
nStates(x::LinSolHA) = nStates(x.model)
ststVector(x::LinSol) = stackFields(Float64,x.vstst)
ststVector(x::LinSolHA) = stackFields(Float64,x.model.vstst)
ststPointer(x::LinSol) = x.vstst  # danger: any program can change x.vstst
stst(x::LinSol) = copy(x.vstst)
stst(x::LinSolHA) = x.model.vstst
nShock(x::LinSolHA) = nShock(x.model)
ststValue(x::LinSolHA)::Array{Float64,3} = x.val.V;
# ststValue(x::LinSolHA)::Array{Float64,3} = getfield(x.model.vstst,x.dpProblem._V)
ststDistr(x::LinSolHA)::Array{Float64,3} = copy(getfield(x.model.vstst,x.dpProblem._D))
ststOther(x::LinSolHA)::Array{Float64,1} = ststVector(x)[length(ststDistr(x))+1:nStates(x)];
ststState(x::LinSolHA)::Array{Float64,1} = ststVector(x)[1:nStates(x)];
posDistrib(x::LinSolHA) = pos(x,x.dpProblem._D)
pars(x::LinSolHA) = x.model.pars
transExogStSt(x::LinSolHA) = x.dpProblem._transExog(pars(x),stst(x),1)
pos(m::LinSolHA,v::Symbol) = posInStruct(stst(m),v)
function pos(m::Union{LinSol,LinModel},v::Symbol)
  return posInStruct(m.vstst,v)
end
function possh(m::Union{LinSol,LinModel},v::Symbol)
  nVar = size(m.A,1)
  return posInStruct(m.vstst,v)-nVar
end
function aggr(sol::LinSolHA,Xsim)
  nSt = nStates(sol);
  H = aggrMat(sol)
  serOrig = H*Xsim 
  serStSt = H*ststVector(sol)[1:nSt]
  serDev = serOrig .- serStSt
  return (serOrig',serDev');
end

getval(x) = x # default
mutable struct LinsolParams
  tolResidStSt::Float64
  #  tolerance level for the residuals of the model in steady state
  # throws error if not satisfied
  # default = 1e-4; rather mild
  xtolStSt::Float64
  #  tolerance level for the variable that is search for in the steady state fixed point problem
  # (only used in case of a one-dimensional fixed point problem)
  ytolStSt::Float64
  #  tolerance level for the residuals of the steady state fixed point problem
  # - used as termination criterion in case of a multi-dimensional fixed point problem
  # - in all cases, generates error if not satisfied
  loadStSt::Int64
  #  load solution values of the steady state problem
  # if 0: solve the fixed point problem steady state
  # if 1: load values from file "xstst.out"; don't solve the fixed point problem 
  # if 2: steady state values and all parameters, don't calibrate
  checkRankCond::Bool
  #  In test for existence and uniqueness, test by rankconditions (true) or only by
  #    counting criterion (false);
  # default: true
  traceStSt::Int64
  #  trace progress in steady state fixed point problem 
  # (only used in case of a multi-dimensional fixed point problem)
  # values: 0 or 1
  crit::Float64  # threshold for whether eigenvalue is considered stable
  isZero::Float64 # threshold for setting very small numbers to zero in matrices A,B
  nDoQZ::Int # number of variables until which the solution is computed via QZ decomposition;
  # for n>nDoQZ, the linear iteration is used
  iStateReduc::Int  # default:0 (use optimal reduction)
  iSpreadReduc::Int  # default:1 (don't split columns in state reduction)
  inStSt::Bool # internal: signal whether in stst calculations or not 
  stepJacob::Float64  # stepsize for computing forward-difference Jacobian
  inJacob::Bool  # stepsize for computing forward-difference Jacobian
  useQuad::Bool  # quadratic approximation in non-convex DP problems
  epsComplement::Float64 # internal: while not in steady state, determines
  eigs4distrib::Bool
  robustOptim::Int
  printLevel::Int
  nAccel::Int  # number of acceleration steps in dynamic programming solution
end
LinsolParams() = LinsolParams(1e-4,1e-8,1e-6,0,true,1,1.000001,1e-14,1000,0,1,true,1e-5,false,true,1e-4,
                              false,0,0,100);
function Base.show(io::IO, x::LinsolParams)
  printStruct(x)
end

const INFEASIBLE = (-1,(NaN,NaN))
POINT(a) = (0,(a,NaN))
INTERVAL(a,b) = b>a ? (2,(a,b)) : (b==a ? POINT(a) : INFEASIBLE)

function GS(A)
  (m,n) = size(A)
  Q = zeros(m,n);
  R = zeros(n)
  R[1] = norm(A[:,1]);
  Q[:,1] = A[:,1]/R[1];
  for j = 2:n
    R[1:j-1] = Q[:,1:j-1]'*A[:,j];
    v = A[:,j] - Q[:,1:j-1]*R[1:j-1];
    R[j] = norm(v);
    Q[:,j] = v/R[j];
  end
  return Q;
end
function GS(A,Qstart)
  println("gotit")
  (m,n) = size(A)
  (m2,n2) = size(Qstart)
  @assert(m==m2)
  global Q = zeros(m,n);
  Q[:,1:n2] = Qstart;
  j = n2;
  for jA = 1:n
    R = Q[:,1:j]'*A[:,jA];
    v = A[:,jA] - Q[:,1:j]*R;
    normv = norm(v);
    if normv<1e-8
      println(normv)
    end
    if normv>1e-12
      j += 1
      Q[:,j] = v/normv;
    end
  end
  println(j)
  println(n)
  @assert(j==n)
  return Q;
end
# function GS0(A)
#   (m,n) = size(A)
#   Q = zeros(m,n);
#   R = zeros(n,n)
#   R[1,1] = norm(A[:,1]);
#   Q[:,1] = A[:,1]/R[1,1];
#   for j = 2:n
#     R[1:j-1,j] = Q[:,1:j-1]'*A[:,j];
#     v = A[:,j] - Q[:,1:j-1]*R[1:j-1,j];
#     R[j,j] = norm(v);
#     Q[:,j] = v/R[j,j];
#   end
#   return Q;
# end
function GramSchmidt(A,QStart::AbstractArray{Float64,2})
  (m,n) = size(A)
  (m2,n2) = size(QStart)
  @assert(m==m2)
  global Q = zeros(m,n);
  Q[:,1:n2] = QStart;

  j = n2;
  for jA = 1:n
    R = Q[:,1:j]'*A[:,jA];
    v = A[:,jA] - Q[:,1:j]*R;
    normv = norm(v);
    if normv<1e-4
      println("at $jA resid is $normv")
    end
    if normv>1e-12
      j += 1
      Q[:,j] = v/normv;
    end
    if j==n
      break;
    end
  end
  @assert(j==n,@show((j,n)))
  return Q;
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#############################################################################
# STRUCTURES
#############################################################################
# operations for structures of type T for which T() is defined

# SOME BASIC UTILITIES:
using Printf
import Base.print

atoi(str) = parse(Int,convert(String,str));
atof(str) = parse(Float64,convert(String,str));
#if VERSION==VersionNumber(1) || VERSION==VersionNumber(1,0,1) || VERSION==VersionNumber(1,0,2)
  linspace(a::Real,b::Real,n::Int) = range(a,stop=b,length=n);
  logspace(a::Real,b::Real,n::Int) = exp.(range(log(a),stop=log(b),length=n));
#else
#  Base.linspace(a::Real,b::Real,n::Int) = range(a,stop=b,length=n);
#  Base.logspace(a::Real,b::Real,n::Int) = exp.(range(log(a),stop=log(b),length=n));
#end
midpoint(x::Array{Float64,1}) = 0.5.*(x[1:end-1]+x[2:end]);
meye(m::Integer,n::Integer) = Matrix(1.0*I,m,n);
meye(m::Integer) = meye(m,m);
mspeye(n::Integer,m::Integer) = SparseMatrixCSC(1.0*I, n, m);
mspeye(n::Int) = mspeye(n,n);
mtransp(x) = convert(typeof(x),x');
fnt(x) = fieldnames(typeof(x))
mtr(x) = convert(Matrix,x')
myisdefined(x::String) = Core.eval(Main,Expr(:isdefined,Symbol(x)));
myisdefined(x::Symbol) = Core.eval(Main,Expr(:isdefined,x));
mfind(x::BitArray{n}) where n = LinearIndices(x)[findall(x)]
mfind(x::Array{T}) where T = LinearIndices(x)[findall(x.!=0)]
mfind(x::Array{Bool}) = LinearIndices(x)[findall(x)]
mdiagm(x) = Matrix(Diagonal(x))
spDiagm(x) = sparse(Diagonal(x))
function myqr(A)
  x = qr(A);
  return (Matrix(x.Q),x.R);
end
function fillzero(T::Type,sizeA) # make sure you get different copies for each element
  A = Array{T}(undef,sizeA)
  for i=1:length(A)
    A[i] = zero(T)
  end
  return A;
end
function standardize(X)
  m = mean(X,dims=1);
  Xm = X .- m;
  s = sqrt.(var(X,dims=1));
  return Xm ./ s;
end
# replacement for old sub2ind:
s2i(d::Tuple,I::AbstractVector{Integer},args...) = LinearIndices(d)[CartesianIndex.(I, args...)]
s2i(d::Tuple,I::Integer,args...) = LinearIndices(d)[CartesianIndex.(I, args...)]
function findnzcols(A,eps=0.0)
  return mfind(sum(abs.(A),dims=1).>eps)
end
function findnzrows(A,eps=0.0)
  return mfind(sum(abs.(A),dims=2).>eps)
end
function nnzcols(A,eps=0.0)
  return count(x->x>eps,sum(abs.(A),dims=1))
end
function nnzrows(A,eps=0.0)
  return count(x->x>eps,sum(abs.(A),dims=2))
end
function copyFields!(dest,source)
  for a in fieldnames(typeof(dest))
    setfield!(dest,a,getfield(source,a));
  end
end
function fillStruct!(dest,A::Array)
  i = 0;
  for a in fieldnames(typeof(dest))
    if isa(getfield(dest,a),Array)
      b = getfield(dest,a)
      n = length(b)
      b .= reshape(A[i .+ (1:n)],size(b))
      i += n
    else
      i += 1
      setfield!(dest,a,A[i])
    end
  end
end
function copyStruct0(source) # uses constructor will no arguments
  dest = typeof(source)()
  copyFields!(dest,source)
  return dest
end
function copyStruct(s) # uses constructor will all fields as arguments
  return typeof(s)( [getfield(s,x) for x in fieldnames(typeof(s))]...)
end
function copyStruct(newtype::DataType,Struct)
  args = map(x->getfield(Struct,x),fieldnames(newtype))
  return newtype(args...)
end
function opStruct(op,s1,s2)
  s = copyStruct(s1)
  for a in fieldnames(typeof(s))
    setfield!(s,a,op(getfield(s1,a),getfield(s2,a)));
  end
  return s;
end
function dispStruct(s1,s2...)
  for a in fieldnames(typeof(s1))
    @printf("%20s: %12.6f",string(a),getfield(s1,a))
    for i=1length(s2)
      @printf("%12.6f",getfield(s2[i],a))
    end
    print("\n")
  end
end
# only show nonzero elements:
function printnzStruct(dest,F::IO=stdout)
  for a in fieldnames(typeof(dest))
    if isdefined(dest,a)
      ai = getfield(dest,a)
      if !all(ai.==0)
        printShort(ai,string(a),F)
      end
    end
  end
end
function printnzStruct(dest,fname::String,prefix::String="")
  F = open(fname,"w")
  printnzStruct(dest,F)
  close(F)
end
lenStruct(S) = sum(map(x->length(getfield(S,x)),fieldnames(typeof(S))))
function stackFields(T::DataType,str)
  A = Array{T}(undef,0)
  for a in fieldnames(typeof(str))
    x = getfield(str,a)
    if isa(x,Array)
      A = vcat(A,vec(x))
    else
      push!(A,x);
    end
  end
  return A;
end
function updateStSt(vars,deltaV::Array{Float64,1})
  offs = 0;
  for a in fieldnames(typeof(vars))
    v = getfield(vars,a)
    x = getfield(v,:sv)
    n = length(x)
    if isa(x,Number)
      setfield!(v,:sv,x + deltaV[offs+1])
    else
      setfield!(v,:sv,x + reshape(deltaV[offs+1:offs+n],size(x)))
    end
    offs += n;
  end
end

# works only on the command line:
macro getEl(S,T)
  tt = fieldnames(Core.eval(T))
  println(tt)
  A = map(x -> Expr(:(=),x,Expr(:.,S,QuoteNode(x))),tt)
  return esc(Expr(:block,A...))
end
macro defshow(mytype)
  return esc( quote
               import Base.show
               function Base.show(io::IO, x::$mytype)
                 printStruct(x);
               end
             end
            )
end
function collectFields(S,namefield::Symbol)
  D = Dict{Symbol,Any}()
  for a in fieldnames(typeof(S))
    D[a] = getfield(getfield(S,a),namefield)
  end
  return D;
end

# generate a macro that reads in the elements of the structure p
function genGetPar(macroname::String,p)
  T = typeof(p)
  txt = "macro $macroname(_p)\nreturn esc( quote\n"
  for v in fieldnames(T)
    txt *= "$v = \$_p.$v;\n"
  end
  txt *= "  end \n )\n  end\n"
  Core.eval(parse(txt))
  return txt;
  F = open("tmp.jl","w")
  print(F,txt);
  close(F)
end

import SparseArrays.blockdiag
function blockdiag(A::Array{T,2},B::Array{T,2}) where T
  (nr1,nc1) = size(A)
  (nr2,nc2) = size(B)
  D = [ [A zeros(nr1,nc2)]; [zeros(nr2,nc1) B] ];
  return D;
end
function evec(n::Int,i::Int)
  e = zeros(n)
  e[i] = 1;
  return e;
end
iseye(M::Array{Float64,2}) = maximum(abs,M-eye(size(M,1)));
function removeEps(A,eps=1e-16)
  B = copy(A)
  for i=1:length(B)
    if abs(B[i]<eps)
      B[i] = 0;
    end
  end
  return B;
end


#############################
# following can be removed later: !!!???
#############################
function mywarntype(filename::String,func::Function,args...)
  n = length(args)
  A = Array{DataType}(n)
  for i=1:n
    if(isa(args[i],DataType))
      A[i] = args[i];
    else
      A[i] = typeof(args[i]);
    end
  end
  e = eval(Expr(:tuple,A...))
  F = open(filename,"w")
  code_warntype(F,func,e)
  close(F)
  lines = readlines(filename)
  F = open(filename,"w")
  for L in lines
    L = replace(L,"[1m[91m","")
    L = replace(L,"[39m[22m","")
    println(F,L)
  end
  close(F)
end

import Profile
function prof2file(filename)
  F = open(filename,"w")
  Profile.print(F,format=:flat);
  close(F)
end
macro myprof(fname,freq,cmd)
  return esc(quote
    Profile.clear()
    Profile.init(10000000,$freq)
    Profile.@profile($cmd)
    prof2file($fname)
  end)
end
function myprof(fname,freq,func, args...)
    Profile.clear()
    Profile.init(10000000,freq)
    Profile.@profile func( args...)
    prof2file(fname)
    error("done with prof")
end

# utilities for parallelization:
@everywhere function setVar(a::Symbol,b)
  eval( :(global $a = $b) );
  return nothing
end
@everywhere function setcVar(a::Symbol,b)
  eval( :(global const $a = $b) );
  return nothing
end
@everywhere function broadcastVar(a::Symbol,b)
  jobs = map( i->remotecall(setVar,i,a,b), workers())
  return fetch.(jobs)
end
@everywhere function broadcastcVar(a::Symbol,b)
  jobs = map( i->remotecall(setcVar,i,a,b), workers())
  return fetch.(jobs)
end
@everywhere function showVar(a::Symbol)
  eval( :(println($a) ));
end
@everywhere function ashowVar(a::Symbol)
  jobs = map( i->remotecall(showVar,i,a), workers())
  return fetch.(jobs)
end

@everywhere cdfnormal(x, mu=0.0, sig=1.0) =  (1 + erf((x - mu)/sig/sqrt(2)))/2;

function mypush(x)
  global _mystack
  if !@isdefined _mystack
    _mystack = Array{Any}(undef,0)
  end
  push!(_mystack,x)
end
function mypop()
  global _mystack
  return pop!(_mystack)
end

function project(X,y)
  b = X\y;
  yest = X*b;
  r2 = map2cols(norm,yest) ./ map2cols(norm,y)
  return (y=yest,r2=r2)
end

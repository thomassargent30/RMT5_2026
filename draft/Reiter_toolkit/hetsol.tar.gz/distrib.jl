# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


# Purpose: approx uniform distribution given by mean and width 
#   by uniform distributions on bins between grid points such that mean is preserved
# i0: index lowest interval of support
# i1: index highest interval of support
# mean: mean of distribution
# width: width of distribution
# grid: grid of points
# widhtg: width between grid points (= diff(grid))
# midp:  midpoints of grid
# OUTPUT
# pp: mass in intervals
# ii: index of intervals
function preserveMean(i0::Integer,i1::Integer,mean::Number,width::Number, 
                      grid::AbstractArray{Float64,1},widthg,midp)
  n = i1-i0+1
  nG = length(grid)-1
  if n==1
    if mean > midp[i0]
      if i1==nG
        return ([1],i1:i1)
      else
        return preserveMean(i0,i1+1,mean,width,grid,widthg,midp);
      end
    else
      if i0==1
        return ([1],i0:i0)
      else
        return preserveMean(i0-1,i1,mean,width,grid,widthg,midp);
      end
    end
  elseif n==2
    # solve mid[i0]*(1-p) + mid[i1]*p = mean
    p = (mean-midp[i0]) / (midp[i1]-midp[i0]);
    pp = [1-p;p]
  else
    meang = (grid[i0+1]+grid[i1])/2;
    if mean>meang # have to take interval i1 on board:
      smallWidth = grid[i1+1]-grid[i0+1]
      if smallWidth>=width
        i0 += 1 # drop lowest interval
      end
    else
      smallWidth = grid[i1]-grid[i0]
      if smallWidth>=width
        i1 -= 1 # drop highest interval
      end
    end
    if i1==i0+1
      return preserveMean(i0,i1,mean,width,grid,widthg,midp);
    else
      pp = widthg[i0:i1] / width;
      mean -= dot(midp[i0+1:i1-1],pp[2:end-1])
      prob = 1 - sum(pp[2:end-1])
      # solve mid[i0]*(prob-p) + mid[i1]*p = mean
      p = (mean-prob*midp[i0]) / (midp[i1]-midp[i0]);
      pp[1] = prob-p;
      pp[end] = p
    end
  end
  return (pp,i0:i1)
end

function handleInterval!(iFrom,iTo,xVal,
                         sizeDistrib,i,k,j,
                         countT,DE,i0,i1,p0,p1,grid,diffgrid,midgrid,
                         pMass)
  if eltype(iFrom)!=Int # iterate vector forward
    dBeg = iFrom
    dEnd = iTo
    @assert(isempty(xVal))
  end
   xEnd0 = (1-p0)*grid[i0] + p0*grid[i0+1]
   xEnd1 = (1-p1)*grid[i1] + p1*grid[i1+1]
  if(getval(xEnd1) >= xEnd0)
    xLow = xEnd0;
    xUpp = xEnd1;
    iMin = i0
    iMax = i1
  else
    xLow = xEnd1;
    xUpp = xEnd0;
    iMin = i1
    iMax = i0
  end
  width_y = xUpp - xLow;
  m = (xUpp + xLow) / 2;
  (pp,ii) = preserveMean(iMin,iMax,m,width_y, grid,diffgrid,midgrid);
  @assert(all(pp.>=0.0),println(pp))

  # if length(pp)>1000 # was an error at some point
  #   @show length(pp)
  #   @assert(false)
  # end
  iFromCur = s2i(sizeDistrib,i,k,j)

  if eltype(iFrom)==Int # prepare for transition matrix
    for ip = 1:length(pp)
      countT += 1;
      iFrom[countT] =iFromCur 
      iTo[countT]   = s2i(sizeDistrib,ii[ip],DE,j)
      xVal[countT] = pMass*pp[ip];
    end
  else
    for ip = 1:length(pp)
      countT += 1;
      iToCur   = s2i(sizeDistrib,ii[ip],DE,j)
      dEnd[iToCur] += pMass*pp[ip]*dBeg[iFromCur];
    end
  end
  return countT
end

# Purpose: 
# 2 cases:
#   dBeg == nothing: no initial distribution given, compute transition matrix
#   dBeg is initial distribution: compute next period's distribution
#dp: Structure with (at least) the following components:
#    grid
#    I: index of continuous choice (end of period state) in which end of period state lies
#    P: fracHihg of continuous choice within this bin
# 
function transMat(dp::DynProgPol,TransDiscrExogD,dBeg=nothing) 
  grid = dp.grid
  diffgrid = diff(grid)
  midgrid = (grid[1:end-1] + grid[2:end])/2;
  switches = dp.switches
  (nGrid,nDiscr,nExog) = size(dp.CC)
  (I,P) = posInGrid(grid,dp.CC);
  nInterv = nGrid - 1;
  #@assert(length(grid)==nEndog+1)
  xMin = grid[1];
  xMax = grid[end];
  iMin = Array{Int}(undef,nInterv,nDiscr,nExog); # for each interval
  iMax = Array{Int}(undef,nInterv,nDiscr,nExog);
  jLow = Array{Int}(undef,nGrid,nDiscr,nExog);

  nTrans = 0;
  for j=1:nExog
    for k=1:nDiscr
      for i=2:nGrid 
        iMin[i-1,k,j] = min(I[i,k,j],I[i-1,k,j])
        iMax[i-1,k,j] = max(I[i,k,j],I[i-1,k,j])
        nCover = iMax[i-1,k,j] - iMin[i-1,k,j] + 1;
        nTrans += nCover;
      end
    end
  end
  # should be enough, but increase factor "2" if length of iFrom etc. is not sufficient
  nTrans = 2*nTrans + 10*length(switches);
  if dBeg == nothing # compute transition matrix
    iFrom = Array{Int}(undef,nTrans);
    iTo = Array{Int}(undef,nTrans);
    xVal = Array{Float64}(undef,nTrans);
  else
    iFrom = dBeg   # distribution beginning of period
    iTo = 0.0*dBeg # distribution end of period
    xVal = [] # has no role
  end
  iT = 0;
  iSwitch = 0
  for j=1:nExog
    for k=1:nDiscr
      for i=1:nInterv
        DC0 = dp.DC[i,k,j]
        DC1 = dp.DC[i+1,k,j]
        width_x = grid[i+1]-grid[i];
        i0 = I[i,k,j];
        p0 = P[i,k,j];
        i1 = I[i+1,k,j];
        p1 = P[i+1,k,j];
        DE0 = dp.DE[i,k,j];
        if DC0!=DC1 
          iSwitch += 1
          xSw = switches[iSwitch]
          DE1 = dp.DE[i+1,k,j];
          iT = handleInterval!(iFrom,iTo,xVal,(nInterv,nDiscr,nExog),i,k,j,
                               iT, DE0,i0,xSw.iLeft,p0,xSw.pLeft,
                               grid,diffgrid,midgrid, xSw.fracLeft);
          iT = handleInterval!(iFrom,iTo,xVal,(nInterv,nDiscr,nExog),i,k,j,
                               iT, DE1,xSw.iRight,i1,xSw.pRight,p1,
                               grid,diffgrid,midgrid, 1-xSw.fracLeft);
        else
          @assert(DE0 == dp.DE[i+1,k,j])
          iT = handleInterval!(iFrom,iTo,xVal,
                               (nInterv,nDiscr,nExog),i,k,j,
                               iT, DE0,i0,i1,p0,p1,grid,diffgrid,midgrid,
                               1.0);
        end
      end
    end
  end
  @assert(iSwitch==length(switches))
  n = nInterv*nDiscr*nExog;
  nEx = size(TransDiscrExogD,1)
  global N = kron(sparse(TransDiscrExogD'),mspeye(div(n,nEx))); # inefficient for single transition!! fix it!!??
  # @assert(isa(N,SparseMatrixCSC{Float64,Int64} )) # can be Deriv2S
  if !(dBeg==nothing)
    if abs(sum(getval(iTo)) .- 1)>1e-10
      println("sum dEnd = ",sum(getval(iTo)))
    end
    return reshape(N*iTo[:],size(dBeg)); # end of period distribution
  end

  global M = sparse(iTo[1:iT],iFrom[1:iT],xVal[1:iT],n,n);
  @assert(abs(sum(xVal[1:iT])-n)<1e-10,saveT("xval.bmt",xVal[1:iT]));
  @assert(maximum(abs,sum(M,dims=1) .- 1)<1e-12,"wrong M")
  # now the exogenous transitions for both discrete states:
  nV = size(M,1)
  @assert(nV%nEx == 0,println([nV,nEx]));
  # println(maximum(abs,sum(TransDiscrExogD',1)-1));
  # println(maximum(abs,sum(N,1)-1));
  global NM = N*M;
  @assert(isa(NM,SparseMatrixCSC{Float64,Int64} ))
  # println(maximum(abs,sum(NM,1)-1));
  return (NM,M);
end

# function CrossSectionMean(sol::DynProgPol,invD::Array{T},func, t::Union{TimeIndex,StStIndex}) where T
function CrossSectionMean(sol::DynProgPol,invD::Array{T},func, t::Union{TimeIndex,StStIndex,Int}) where T
  CC = sol.CC
  DC = sol.DC
  (nEndog,nDiscr,nExog) = size(CC)
  grid = sol.grid
  nInterv = nEndog-1;
  @assert(length(grid)==nEndog)
  z = zero(T);
  iSw = 0
  for j=1:nExog
    for k=1:nDiscr
      for i=1:nInterv
        DCi = DC[i,k,j]
        DCi1 = DC[i+1,k,j]
        fa = func(grid[i  ],k,j,CC[i  ,k,j],DCi,t)
        fb = func(grid[i+1],k,j,CC[i+1,k,j],DCi1,t)
        if DCi == DCi1
          z += invD[i,k,j]*(fa+fb)/2
        else # account for DE!!!!!
          iSw += 1
          Sw = sol.switches[iSw]
          @assert( (i,k,j) == Sw.iState )
          xSw = Sw.fracLeft*grid[i+1] + (1-Sw.fracLeft)*grid[i];
          fa2 = func(xSw,k,j,Sw.ccLeft,DCi,t)
          fb2 = func(xSw,k,j,Sw.ccRight,DCi1,t)
          term1 = invD[i,k,j]*(fa+fa2)/2
          term2 = invD[i,k,j]*(fb+fb2)/2
          z += term2 + (term1-term2)*Sw.fracLeft; # avoids minimal derivatives when term1==term2
          # z += term1 * Sw.fracLeft;
          # z += term2 * (1-Sw.fracLeft);
          # z += invD[i,k,j]*(fa+fa2)/2 * Sw.fracLeft;
          # z += invD[i,k,j]*(fb+fb2)/2 * (1-Sw.fracLeft);
        end
      end
    end
  end
  @assert(all(isfinite.(z)))
  return z;
end

# Wrapper functions:
function transMat(model::Module,dp::DynProgPol,pars,vars,t,dBeg=nothing)
  TransDiscrExogD = model._transExog(pars,vars,t)
  return transMat(dp::DynProgPol,TransDiscrExogD,dBeg)
end

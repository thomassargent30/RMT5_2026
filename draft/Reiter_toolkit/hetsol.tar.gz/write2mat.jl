# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# using MAT
macro  putInStruct(args...)
  e = Expr(:call,:Dict,map(x->Expr(:call,:(=>),string(x),x),args)...)
  dump(e)
  return e;
end
# transform struct to Dict:
function struct2dict(x)
  s = Dict{String,Any}()
  for a in fieldnames(x)
    s[string(a)] = getfield(x,a)
  end
  return x
end
# transform Dict so that it can be stored for matlab:
function dict2matdict(d::Dict,maxN=10^8)
  matel(x) = x
  matel(x::UnitRange{Int}) = length(x)==1 ? x[1] : convert(Array{Int,1},x)
  matel(x::StepRange{Int}) = length(x)==1 ? x[1] : convert(Array{Int,1},x)
  # in varnames, shocks have numbers greater than number of variables,
  # so subtract nVAR to get nSHOCK
  moduloN(x) = x[1]>maxN ? x-maxN : x;
  D = Dict{String,Any}()
  for a in keys(d)
    xi = d[a]
    s = string(a)
    s = replace(s,r"\[(.+)\]",s"_\1_")
    D[s] = moduloN(matel(xi))
  end
  return D
end
function write2mat(filename::String,x::LinSol)
  ie = dict2matdict(x.equNames)
  iv = dict2matdict(x.varNames,size(x.A,1))
  D = Dict("A"=>x.A,"B"=>x.B,"guess"=>x.guess,
           "vstst"=>struct2dict(x.vstst),
           "ie"=>ie,
           "iv"=>iv
          )
  # Dict("A"=>x.A,"B"=>x.B)
  matwrite(filename*".mat",D)
end
function write2mat(filename::String,x::LinSolHA)
  ie = dict2matdict(x.model.equNames)
  iv = dict2matdict(x.model.varNames,size(x.A,1))
  D = Dict("A"=>x.A,"B"=>x.B,"guess"=>x.model.guess,
           "vstst"=>struct2dict(x.model.vstst),
           "ie"=>ie,
           "iv"=>iv
          )
  # Dict("A"=>x.A,"B"=>x.B)
  matwrite(filename*".mat",D)
end

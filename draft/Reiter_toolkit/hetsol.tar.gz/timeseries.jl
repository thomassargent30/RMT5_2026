# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
using SparseArrays:spdiagm

corr(x::AbstractArray{Float64,1},y::AbstractArray{Float64,1}) = cor(x,y)[1]
corr(x::AbstractArray{Float64,2},y::AbstractArray{Float64,2}) = diag(cor(x,y))
corr(x::AbstractArray{Float64,1},y::AbstractArray{Float64,2}) = vec(cor(x,y))
corr(x::AbstractArray{Float64,2},y::AbstractArray{Float64,1}) = vec(cor(x,y))
# correlation between x(t) and y(t+forw):
function corrforw(x,y,forw) 
  if(forw<0)
    return corrforw(y,x,-forw)
  else
    if ndims(x)==1
      return corr(x[1:end-forw],y[1+forw:end,:]); 
    elseif ndims(y)==1
      return corr(x[1:end-forw,:],y[1+forw:end]); 
    else
      return corr(x[1:end-forw,:],y[1+forw:end,:]); 
    end
  end
end
autocorr(x::AbstractArray{Float64,1},lag=1) = corr(x[1:end-lag],x[1+lag:end]);
function autocorr(x::AbstractArray{Float64,2},lag=1)
  m = mean(x,1)
  xm = broadcast(-,x,m)
  scal = sum(xm.*xm,1)
  return sum(xm[1:end-lag,:].*xm[lag+1:end,:],1) ./ scal
end

function hpfilterMatrix(n::Int, lambda::Real)
  @assert n >= 4

  diag2 = lambda*ones(n-2)
  diag1 = [ -2lambda; -4lambda*ones(n-3); -2lambda ]
  diag0 = [ 1+lambda; 1+5lambda; (1+6lambda)*ones(n-4); 1+5lambda; 1+lambda ]

  # D = sparse(Diagonal((diag2, diag1, diag0, diag1, diag2), (-2,-1,0,1,2)))
  D = spdiagm(-2=>diag2, -1=>diag1, 0=>diag0, 1=>diag1, 2=>diag2)
  return D
end
function hpfilter(y::AbstractArray{Float64}, lambda::Real)
  n = size(y,1)
  D = hpfilterMatrix(n,lambda);
  return D\convert(Array{Float64},y);
end
function polyfilter(y::Array{Float64}, deg::Int)
  T = size(y,1)
  X = broadcast(^,linspace(1.0,T,T),(0:deg)')
  beta = ols_svd(X,y,0.0);
  return X*beta;
end
# deviations from HP trend:
hpdev(x::Array{Float64}, lambda::Float64) = x - hpfilter(x,lambda);
polydev(x::Array{Float64}, dev::Int) = x - polyfilter(x,dev);
meandev(x::Array{Float64,1}) = broadcast(-,x,mean(x[isfinite(x)],1));
function meandev(x::Array{Float64,2}) 
  X = similar(x)
  for i=1:size(x,2)
    X[:,i] = meandev(x[:,i])
  end
  return X;
end
  
function reducefreq(x0::Array{Float64,1},nAve,type_reduce)
  m = length(x0)
  n2 = div(m,nAve)
  if(m!=nAve*n2)
    println(stdout,"Warning: incompatible size in reducefreq: ",m,", ",nAve)
  end
  x = reshape(x0,(nAve,n2));
  if(type_reduce=="sum")
    return vec(sum(x,1))
  elseif(type_reduce=="ave" || type_reduce=="mean")
    return vec(mean(x,1))
  elseif(type_reduce=="end")
    return x[end,:]
  else
    error("wrong type in reducefreq_new");
  end
end
#function reducefreq(x::Array{Float64,2},n,type_reduce)
function reducefreq(x,n,type_reduce)
  nn = size(x);
  t = nn[1];
  if(length(nn)>1)
    m = nn[2];
  else
    m = 1;
  end
  t2 = convert(Int,floor(t/n));
  assert(t2*n==t);
  y = zeros(t2,m);
  for i=1:t2
    i1 = i*n;
    i0 = i1-n+1;
    if(type_reduce=="ave" || type_reduce=="mean")
      y[i,:] = mean(x[i0:i1,:],1);
    elseif(type_reduce=="sum")
      y[i,:] = sum(x[i0:i1,:],1);
    elseif(type_reduce=="end")
      y[i,:] = x[i1,:];
    else
      error("wrong type in reducefreq");
    end
  end
  return y;
end

# solve discrete Lyapunov equation by doubling algorithm
function doubling(A,Sig,n)
  A = A';
  for i=1:n-1
    Sig = Sig+A'*(Sig*A);
    A = A*A;
  end
  X = Sig+A'*(Sig*A);
  return X;
end
# Sig is covariance-matrix of shocks
# n=30 gives very precise estimates
function doubling(A,B,Sig,n)
  return doubling(A,B*Sig*B',n);
end


# General simulation routine for model
# x(t) = A x(t-1) + B eps(t)  # A can be sparse
# where Sigma is covmatrix of eps
# Further inputs:
# T:     length of simulation
# H (optional) : produce output for H*x
# scal (optional): scaling of output
# lambdaHP: HP filter parameter
# Tskip: skip first Tskip data points     
# Output: simulated series
# if Tskip=0, generates one more observations that length of shocks, includes x0
function simul(A,B::Array{Float64,2},shocks)
  (nx,nSt) = size(A);
  nz = size(B,2);
  T = size(shocks,2)
  x = zeros(nx);
  ser = zeros(nx,T+1);
  ser[:,1] = x
  for t=1:T
    x = A*x[1:nSt] + B*shocks[:,t]
    ser[:,t+1] = x
  end
  return ser;
end
function simul(A,B::Array{Float64,2}, 
  x0::Array{Float64,1},Sigma::Array{Float64,2},
  TOrShock,Tskip::Int=0,H=1)

  nx = size(A,1);
  nz = size(B,2);
  C = chol(Sigma)';
  if(isa(TOrShock,Int)) # T is length of series
    T = TOrShock;
    eps = C*randn(nz,T+Tskip-1);
  else # T gives raw shocks
    eps = C*TOrShock';
    T = size(TOrShock,1)+1  - Tskip;
  end

  if(H==1)
    @assert(T>0,println(T))
    ser = Array{Float64}(nx,T);
  else
    ser = zeros(size(H,1),T);
  end
  iStates = mfind(sum(abs.(A),1).>1e-12)
  ns = length(iStates)
  if(H==1)
    x = copy(x0);
    xeps = ones(ns+nz)
    ser[:,1] = x0; # will be overwritten if Tskip>0
    A_ = [A[:,iStates] B]
    for t = 2 : (T+Tskip)
      for j=1:ns
        xeps[j] = x[iStates[j]]
      end
      for j=1:nz
        xeps[ns+j] = eps[j,t-1]
      end
      x .= A_*xeps
      # x = A_*x[iStates] + B*eps[:,t-1];
      if(t>Tskip)
        ser[:,t-Tskip] = x;
      end
    end;
  else
    HA = Array(H*A[:,iStates]);
    HB = Array(H*B);
    A_ = A[iStates,iStates]
    B_ = B[iStates,:]
    ser[:,1] = H*x0; # will be overwritten if Tskip>0
    x = x0[iStates];
    for t = 2 : (T+Tskip)
      e = eps[:,t-1]
      if(t>Tskip)
        ser[:,t-Tskip] = HA*x + HB*e; # compute series from past states
      end
      x = A_*x + B_*e;  # update states
    end;
  end;
  ser = ser';   # each column a variable
  return ser;
end

function momentsHP(A2,B2,Csmall,Sigma,nAggreg,lambdaHP,T)
  # HP filtering:
  if(lambdaHP<=0)
    Bdev = meye(T);  
  else
    BHP = hpfilterMatrix(T,lambdaHP);
    Bdev = meye(T)-inv(Array(BHP));
  end

  # Time aggregation:
  n = size(A2,1);
  #Csmall = meye(n);  # ???
  ii = 1:n;
  SigA2 = doubling(A2,B2*Sigma*B2',30);
  SigAa = zeros(n*nAggreg,n*nAggreg);
  if(nAggreg>1)
    Aa = spzeros(n*nAggreg,n*nAggreg);
    Aa[ii,ii] = A2;
    for i=1:nAggreg-1
      Aa[(i*n)+ii,((i-1)*n+ii)] = meye(n);
    end
    Ca = kron(ones(1,nAggreg)/nAggreg,Csmall);

    S = SigA2;
    for j=0:nAggreg-1
      for i=0:nAggreg-1-j
        SigAa[(i*n)+ii,((i+j)*n)+ii] = S;
        if(j!=0)
          SigAa[((i+j)*n)+ii,(i*n)+ii] = S';
        end
      end
      S = S*A2';
    end
  else
    Aa = A2;
    Ca = Csmall;
    SigAa = SigA2;
  end
  SigmaAggr = Ca*SigAa*Ca';  

  S = SigAa;
  Covt = Array{Array{Float64,2}}(T+1)
  for t=0:T
    Covt[t+1] = Ca*S*Ca';
    for i=1:nAggreg
      S = Aa*S;
    end
  end

  # xDev(t) = sum_a Bdev(t,a)*x(a)
  # sum_t E[xDev(t) xDev(t)'] = sum_{t,a,b} Bdev(t,a)*Bdev(t,b)*E[x(a)*x(b)']

  SigmaHP = 0;
  SigmaHPlag = 0;
  for AminusB=-(T-1):(T-1)
    if(AminusB>=0)
      G = Covt[AminusB+1];
    else
      G = Covt[-AminusB+1]';
    end
    # a goes from 1 to T
    # b goes from 1 to T
    for a=1:T
      b = a - AminusB;
      if(b<1 || b>T)
        continue;
      end
      SigmaHP = SigmaHP + dot(Bdev[:,a],Bdev[:,b])*G;
      SigmaHPlag = SigmaHPlag + dot(Bdev[2:end,a],Bdev[1:end-1,b])*G;
    end
  end
  SigmaHP = SigmaHP/T;
  SigmaHPlag = SigmaHPlag/T;

  return (SigmaAggr,SigmaHP,SigmaHPlag)
end

function deMeaned(X)
  return  broadcast(-,X,mean(X,1))
end
function diffFirst(X)
  return  broadcast(-,X,X[1,:])
end
function diffFirstLog(X)
  return  broadcast(-,log(X),log(X[1,:]))
end

# QNWNORM1 Computes nodes and weights for the univariate standard normal distribution
# USAGE
#    [x,w] = qnwnorm1(n);
# INPUTS
#   n   : number of nodes
# OUTPUTS
#   x   : n by 1 vector of evaluation nodes
#   w   : n by 1 vector of probabilities
 
# Based on an algorithm in W.H. Press, S.A. Teukolsky, W.T. Vetterling
# and B.P. Flannery, "Numerical Recipes in FORTRAN", 2nd ed.  Cambridge
# University Press, 1992.

function qnwnorm1(n::Int);

  maxit = 100;
  pim4 = 1/pi.^0.25;
  m = div(n+1,2);
  x = zeros(n);
  w = zeros(n);
  local pp,zz
  for i=1:m
    # Reasonable starting values 
    if i==1 
      zz = sqrt(2*n+1)-1.85575*((2*n+1).^(-1/6));
    elseif i==2 
      zz = zz-1.14*(n^0.426)/zz;
    elseif i==3 
      zz = 1.86*zz+0.86*x[1];
    elseif i==4 
      zz = 1.91*zz+0.91*x[2];
    else        
      zz = 2*zz+x[i-2];
    end;
    # root finding iterations 
    its=0;
    while its<maxit;
      its = its+1;
      p1 = pim4;
      p2 = 0.0;
      for j=1:n
        p3 = p2;
        p2 = p1;
        p1 = zz.*sqrt(2/j).*p2-sqrt((j-1)/j).*p3;
      end;
      pp = sqrt(2*n).*p2;
      z1 = zz;
      zz  = z1-p1./pp;
      if abs(zz-z1)<1e-14; break; end;
    end;
    if its>=maxit
      error("failure to converge in qnwnorm1")
    end
    x[n+1-i] = zz;
    x[i] = -zz;
    w[i] = 2.0 / (pp.*pp);
    w[n+1-i] = w[i];
  end;
  w = w./sqrt(pi);
  x = x*sqrt(2);
  return (x,w)
end
function qnwnorm1(n::Int,mu::Float64,sigma::Float64)
  (x,w) = qnwnorm1(n);
  return (mu.+sigma.*x,w)
end
function demean(X,dim=1)
  m = mean(X,dim)
  Y = broadcast(-,X,m)
end

# data0 is given with each column a variable
# Sigma is only used for conditional expectation to initialize unobserved variables
# iFit is indx of variables that should be fitted precisely
function fitShocks(A,B,data0,iData,iFit,SigmaEps=meye(1),iUseConditionalMean=false,
                   adjustInitialX=x->x)
  AA = A - B*(B[iFit,:]\A[iFit,:]);
  maxeig = maximum(abs,eigen(AA).values);
  if(maxeig>=1)
    println("maximum eigenvalue: ",maxeig)
    error("fitting shocks to variables gives unstable system")
  end
  n = size(A,1);
  iUnobserved = setdiff(1:n,iData);
  x = zeros(n)
  data = data0';
  x[iData] = data[:,1];
  if(iUseConditionalMean)
    Sigma = doubling(A,B,SigmaEps,30)
    S22 = Sigma[iData,iData];
    S12 = Sigma[iUnobserved,iData];
    x[iUnobserved] = S12*(S22\x[iData]);
  end
  T = size(data,2)
  serExplained = zeros(n,T)
  serExplained[iData,:] = data;
  serExplained[:,1] = x;
  for t=2:T
    xExp = A*x;
    # solve xFit = xExp + B[iFit,:]*eps
    eps = B[iFit,:]\(serExplained[iFit,t] - xExp[iFit]);
    x = xExp + B*eps;
    serExplained[:,t] = x;
  end
  return serExplained'


end

function unif2Shock(x,p,randUnif::Float64)
  nRealiz = length(p)
  pSum = 0.0;
  iEps = nRealiz;
  for i = 1:nRealiz
    pSum += p[i];
    if(pSum>=randUnif)
      iEps = i;
      break;
    end
  end
  if(length(size(x))==1)
    return x[iEps];
  else
    return x[iEps,:];
  end
end
unif2Shock(x::Array{Float64,1},p,randUnif::Array{Float64,1}) = map(r->unif2Shock(x,p,r),randUnif);
function unif2Shock(x::Array{Float64,2},p,randUnif::Array{Float64,1}) 
  n = length(randUnif)
  X = zeros(n,size(x,2))
  for i=1:n
    X[i,:] = unif2Shock(x,p,randUnif[i])
  end
  return X;
end

# gives mean, std, skewness and excess kurtosis:
function moments4(x::Array{Float64,1})
  m1 = mean(x);
  m2 = sqrt(var(x))
  m3 = skewness(x)
  m4 = kurtosis(x)
  return [m1;m2;m3;m4]
end
# leftshift operation, useful for following cohorts in an impulse response function:
function diagrange(IR,width=0)
  (T,nc) = size(IR)
  if width==0
    width=nc-1
  end
  n = 1+2*width
  D = fill(NaN,(min(T,n),n))
  for t=1:size(D,1)
    for m=-width:width
      iCol = m+t
      if iCol>0 && iCol<=nc
        D[t,m+width+1] = IR[t,iCol]
      end
    end
  end
  return D
end
seqa(start,step,n) = map(i->start+i*step,0:n-1)
function cov2cor(Sigma) 
  sig = sqrt.(diag(Sigma))
  return Sigma ./ (sig*sig')
end
function movingAve(x,width)
  n = size(x,1)
  if ndims(x)==1
    y = map(i->mean(x[i-width:i+width]),1+width:n-width)
  end
  return y
end
function movingAve2(x,width)
  n = size(x,1)
  if ndims(x)==1
    y = zeros(n)
    for j = 1:n
      i = min(max(j,1+width),n-width)
      y[j] = mean(x[i-width:i+width])
    end
  end
  return y
end
function localRegression(x0,Y,i0,width,degree)
  n = length(x0)
  if i0<=width
    ii = 1:i0+width
    iRef = i0
  elseif i0>n-width
    ii = i0-width:n
    iRef = width+1
  else
    ii = i0-width:i0+width
    iRef = width+1
  end
  X = ones(length(ii),degree+1)
  x = x0[ii] .- mean(x0[ii]) # demean, to increase numerical precision
  for i=1:degree
    X[:,i+1] = X[:,i].*x
  end
  beta = X\Y[ii];
  f0 = dot(X[iRef,:],beta)
  if degree==1
    return (Y[i0]-f0,beta[2])
  elseif degree==2
    return (Y[i0]-f0,beta[2] + 2*beta[3]*x[iRef])
  else
    return (NaN,NaN)
  end
end


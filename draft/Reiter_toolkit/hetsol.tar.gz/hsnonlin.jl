# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

replSum(x) = x  # FIX IT !!??

mutable struct NLmodel
  dir::String
  nCurrVar::Int
  iState::Array{Int,1}
  iLagState::Array{Int,1}
  iApprox::Array{Int,1}
  nStates::Int;
  nApprox::Int;
  nApprox2::Int;
  nEXPECT::Int;
  nShock::Int;
  nGuessTr::Int;
  nGuessDyn::Int;
  nConstr::Int;
  linModel::LinSol
end
import Base.show
function Base.show(io::IO, x::NLmodel)
  printStruct(x)
end
NLmodel(linmodel,d::String) = NLmodel(d,0,Array{Int}(0),Array{Int}(0),Array{Int}(0),
0,0,0,0,0,0,0,0,linmodel);
import Base.empty!
function empty!(m::NLmodel)
  empty!(m.iState)
  empty!(m.iApprox)
  m.nCurrvar = 0;
  nStates = 0;
  nApprox = 0;
  nApprox2 = 0;
  nEXPECT = 0;
  nShock = 0;
  nGuessTr = 0;
  nGuessDyn = 0;
  nConstr = 0;
end
stateDetermStSt(NL) = transfState(stackFields(Float64,NL.linModel.vstst)[_nl.iState])
function fillcopy(x,sizeA) # make sure you get different copies for each element
  A = Array{typeof(x)}(sizeA)
  for i=1:length(A)
    A[i] = copy(x)
  end
  return A;
end
function putParsInFunc(str,allFuncs,prefix)
  for fname in keys(allFuncs)
    str = replace(str,Regex("(?<![0-9a-zA-Z_\.])" * fname * "\\("),fname * "(" * prefix * ",")
  end
  return str;
end
function appendNL(f,txt)
  txt = replaceNamesbyField(txt,_pars,"_p");
  txt = putParsInFunc(txt,allFuncs,"_p") # perhaps not necessary, funcs already replaced??
  Main.appendf(_nl.dir * f,txt)
end
function appendNL(indx,i0::Int,i1::Int,f,txt)
  ff = _nl.dir * f
  Main.appendf(ff,"for $indx=$i0:$i1")
  Main.appendf(ff,txt)
  Main.appendf(ff,"end")
end
function replIndex(name::String,indxVar::String,indxVal::Int)
  re = Regex("\\b" * indxVar * "\\b");
  indx = string(indxVal)
  return replace(name,re,indx)
end
function pushNL!(s::Symbol,name,indxVar::String,i0,i1)
  if i0==0
    val = posInStruct(_vars,Symbol(name))[1]
    push!(getfield(_nl,s),val)
  else
    error("not properly impl.")
    for i=i0:i1
      nameI = replIndex(name,indxVar,i)
      val = Main.pos(_vars,Symbol(nameI))
      push!(getfield(_nl,s),val)
    end
  end
end
function rmNLfile(fname)
  ff = _nl.dir * fname
  F = open(ff,"w")
  close(F)
end
function forwardequ(eq::String)
  if(occursin(r"\[\bt\s*\+\s*1",eq))
    println(eq)
    error("cannot forward equation with forward term");
  end
  eq1 = replace(eq,r"\bt\s*\)","t+1)");
  eq1 = replace(eq,r"\bt\s*\]","t+1]");
  eq1 = replace(eq1,r"\bt\s*-\s*1","t");

  # eq1 = replace(eq,r"\bt]","t+1]");
  # eq1 = replace(eq1,r"\bt-1]","t]");
  # eq1 = replace(eq1,r"\bt\)","t+1)"); # can also appear in macro
  # eq1 = replace(eq1,r"\bt-1\)","t)");
  return eq1;
end
function initnlfiles()
  # rmNLfile("transffuncs.jl")
  rmNLfile("solve.log")
  rmNLfile("declare.jl")
  # appendNL("declare.jl","_exp = Array{_typeExp}(_nl.nEXPECT)")
  rmNLfile("states.jl")
  rmNLfile("settrans0.jl")
  rmNLfile("settrans1.jl")
  rmNLfile("settrans1a.jl")
  rmNLfile("getvars0.jl")
  rmNLfile("getvars1.jl")
  rmNLfile("approx.jl")
  rmNLfile("defexp.jl")
  rmNLfile("expects0.jl")
  rmNLfile("residequz.jl")
  rmNLfile("residequd.jl")
  rmNLfile("getpar_dyn.jl")
  rmNLfile("resid_dyn.jl")
  rmNLfile("getpar_tr.jl")
  rmNLfile("resid_tr.jl")
end
function convertTime(name,iLag)
  if(contains(name,"["))
    m = match(r"^\s*(?<var>\w+)\[(?<indx>.*)\]\s*$",name)
    assert(m!=nothing)
    args = Main.splitargs(m[:indx],',')
    n = length(args)
    tfunc = @sprintf("_t%d(%s,%d,%s)",n,m[:var],iLag,m[:indx])
  else
    return @sprintf("_t0(%s,%d)",name,iLag)
  end
end
function convertTime(eq)
  #eq = replace(eq,r"(\w+)\[\s*stst\s*]",s"_vars.\1.sv");
  #eq = replace(eq,r"(\w+)\[\s*(\w+)\s*,\s*stst\s*]",s"_vars.\1.sv[\2]");
  eq = replace(eq,r"(\w+)\[\s*stst\s*]",s"_vss.\1");
  eq = replace(eq,r"(\w+)\[\s*(\w+)\s*,\s*stst\s*]",s"_vss.\1[\2]");
  eq = replace(eq,"[(t + 1) - 1]","[t]");
  eq = replace(eq,"[(t+1)-1]","[t]");
  while( (m=match(r"(?<bef>.*?)(?<var>\w+)\[(?<indx>[^\[\]]*?),?\s*\bt(?<offs>(\s*[-+]\s*1)?)\](?<aft>.*)",eq))  !=nothing)
    args = Main.splitargs(m[:indx],',')
    offs = Core.eval(parse(m[:offs]))
    if(typeof(offs)==Void)
      offs = 0;
    end
    n = length(args)
    tfunc = @sprintf("_t%d(%s,%d",n,m[:var],offs)
    eq = m[:bef] * tfunc;
    if(n==0)
      eq *=  ")";
    else
      eq *=  "," * m[:indx] * ")";
    end
    eq *= m[:aft]
  end
  return eq;
end

function extractExpect(equstr)
  global _nl
  while(occursin(r"\bEXP\(",equstr))
    _nl.nEXPECT += 1
    (bef,args,aft) = Main.splitbyfunc(equstr,"EXP");
    myexp = @sprintf("_exp[%d]",_nl.nEXPECT);
    equstr = bef * myexp * aft;
    appendNL("expects0.jl",@sprintf("_EXPECT(%d,%s);",_nl.nEXPECT,convertTime(args[1])))
  end
  return equstr;
end
function extractExpect(equstr,indx,i0,i1)
  global _nl
  nExpInEqu = 0;
  # find number of expectations:
  eq0 = identity(equstr)
  while(occursin(r"\bEXP\(",eq0))
    nExpInEqu += 1
    (bef,args,aft) = Main.splitbyfunc(eq0,"EXP");
    eq0 = aft;
  end
  iEqu = 0;
  while(occursin(r"\bEXP\(",equstr))
    iEqu += 1;
    (bef,args,aft) = Main.splitbyfunc(equstr,"EXP");
    if nExpInEqu == 1
      myexp = @sprintf("_exp[%d+%s]",_nl.nEXPECT,indx);
    else
      myexp = @sprintf("_exp[%d+%d*(%s-1)+%d]",_nl.nEXPECT,nExpInEqu,indx,iEqu)
    end
    equstr = bef * myexp * aft;
    appendNL(indx,i0,i1,"expects0.jl",@sprintf("_EXPECT(%d+%s,%s);",_nl.nEXPECT,indx,args[1]))
  end
  _nl.nEXPECT += nExpInEqu*(i1-i0+1)
  return equstr;
end


macro doApp(fname,appCmd) 
  return esc(quote
               if i1!=0
                 appendNL($fname,"for " * indx * "=" * string(i0) * ":" * string(i1))
               end
               $appCmd
               if i1!=0
                 appendNL($fname,"end")
               end
             end
            )
end
function SHOCK_(name,indx::String="",i0::Int=0,i1::Int=0)
  global _nl; _nl.nShock+=1;
  @doApp("settrans1.jl",appendNL("settrans1.jl",@sprintf("_SHOCK(%d,%s);",_nl.nShock,convertTime(name,1))))
end

function STATE_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  global eq00 = string(replSum(parse(eqs)))
  #println(eq00)
  global eq1 = forwardequ(eq00)
  #println(eq1)
  equForw = convertTime(eq1);
  #println(equForw)
  nameForw = convertTime(name,1);
  nameCur = convertTime(name,0);
  global _nl;
  if i0==0
    _nl.nStates += 1;
    appendNL("settrans1.jl",@sprintf("%s = %s;",nameForw,equForw));
    appendNL("states.jl",@sprintf("_STATE(%d,%s)",_nl.nStates,nameCur));
  else
    bname = namebase(name)
    Core.eval(Main,:(_suffixTmp = "_" * $bname));
    # next one is for temporaries, further improvement!!
    # appendNL(indx,i0,i1,"settrans1a.jl",@sprintf("_assign(%s,%s);",nameForw, string(introTemp(parse(equForw)))))
    appendNL(indx,i0,i1,"settrans1.jl",@sprintf("%s = %s;",nameForw,equForw));
    appendNL(indx,i0,i1,"states.jl",@sprintf("_STATE(%d+%s,%s)",_nl.nStates,indx,nameCur));
    _nl.nStates += i1-i0+1;
  end
  for ii=i0:i1
    push!(_nl.iLagState,0)
  end
  pushNL!(:iState,name,indx,i0,i1);
end
function STATEMARKOV_(name,shocknumber)
  nameForw = convertTime(name,1);
  nameCur = convertTime(name,0);
  global _nl;_nl.nStates += 1;
  appendNL("settrans0.jl",
           @sprintf("initState!(_xp[%d],fptosi(_gridCurr[%s]));",
                    shocknumber,_nl.nStates))
  appendNL("settrans1.jl",@sprintf("(%s,_probi) = realiz(_xp[%d],_ii[%d]);", nameForw,shocknumber,shocknumber));
  appendNL("states.jl",@sprintf("_STATEMARKOV(%d,%d,%s)",_nl.nStates,shocknumber,nameCur));
  # appendNL("states.jl",@sprintf("_STATE(%d,%s)",_nl.nStates,nameCur));

  push!(_nl.iLagState,0)
  pushNL!(:iState,name,"",0,0);
end

function PREDET_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  equCur = convertTime(eq);
  nameCur = convertTime(name,0);
  nameLag = convertTime(name,-1);
  global _nl;
  if i0==0
    _nl.nStates += 1;
    appendNL("settrans0.jl",@sprintf("%s = %s;",nameCur,equCur));
    appendNL("states.jl",@sprintf("_STATE(%d,%s)",_nl.nStates,nameLag));
  else
    appendNL(indx,i0,i1,"settrans0.jl",@sprintf("%s = %s;",nameCur,equCur));
    appendNL(indx,i0,i1,"states.jl",@sprintf("_STATE(%d+%s,%s)",_nl.nStates,indx,nameLag));
    _nl.nStates += i1-i0+1;
  end
  for ii=i0:i1
    push!(_nl.iLagState,-1)
  end
  pushNL!(:iState,name,indx,i0,i1);
end

function SOLVEDYN_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  equCur = convertTime(eq);
  nameCur = convertTime(name,0);
  nameLag = convertTime(name,-1);

  global _nl;
  if i0==0
    _nl.nGuessDyn += 1;
    equCur = extractExpect(equCur)
    appendNL("getpar_dyn.jl",@sprintf("_XDYN(%d,%s);",_nl.nGuessDyn,nameCur));
    appendNL("resid_dyn.jl" ,@sprintf("_RESDYN(%d,%s)",_nl.nGuessDyn,equCur));
  else
    equCur = extractExpect(equCur,indx,i0,i1)
    appendNL(indx,i0,i1,"getpar_dyn.jl",@sprintf("_XDYN(%d+%s,%s);",_nl.nGuessDyn,indx,nameCur));
    appendNL(indx,i0,i1,"resid_dyn.jl" ,@sprintf("_RESDYN(%d+%s,%s)",_nl.nGuessDyn,indx,equCur));
    _nl.nGuessDyn += i1-i0+1;
  end
end
function SOLVETR_(name,eqs_unused,indx::String="",i0::Int=0,i1::Int=0)
  # eq = string(replSum(parse(eqs)))
  # equCur = convertTime(eq);
  nameCur = convertTime(name,0);
  global _nl; 
  if i0==0
    _nl.nGuessTr += 1;
    appendNL("getpar_tr.jl",@sprintf("_XTR(%d,%s)",_nl.nGuessTr,nameCur))
    appendNL("resid_tr.jl",@sprintf("_RESTR(%d,%s)",_nl.nGuessTr,nameCur))
  else
    appendNL(indx,i0,i1,"getpar_tr.jl",@sprintf("_XTR(%d+%s,%s)",_nl.nGuessTr,indx,nameCur))
    appendNL(indx,i0,i1,"resid_tr.jl",@sprintf("_RESTR(%d+%s,%s)",_nl.nGuessTr,indx,nameCur))
    _nl.nGuessTr += i1-i0+1;
  end
end
function DEFINE0_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  equCur = convertTime(eq);
  nameCur = convertTime(name,0);
  if i0==0
    appendNL("getvars0.jl",@sprintf("_ASSIGN(%s,%s)",nameCur,equCur))
  else
    appendNL(indx,i0,i1,"getvars0.jl",@sprintf("_ASSIGN(%s,%s)",nameCur,equCur))
  end
end
function DEFINE1_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  equForw = convertTime(forwardequ(eq));
  nameForw = convertTime(name,1);
  if i0==0
    appendNL("getvars1.jl",@sprintf("_ASSIGN(%s,%s)",nameForw,equForw))
  else
    appendNL(indx,i0,i1,"getvars1.jl",@sprintf("_ASSIGN(%s,%s)",nameForw,equForw))
  end
end
function DEFINE_(name,eq,indx::String="",i0::Int=0,i1::Int=0)
  DEFINE0_(name,eq,indx,i0,i1)
  DEFINE1_(name,eq,indx,i0,i1)
end
function APPROX_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  nameCur = convertTime(name,0);
  # equCur = replSums(equCur)  HANDLE!!!!!!!!!!!!!!!!!!!

  global _nl; 
  assert(_nl.nApprox2==0) # approx2 variables must come last
  if i0==0
    _nl.nApprox += 1;
    eq = extractExpect(eq)
    equCur = convertTime(eq);
    #equCur = convertTime(eq);
    #equCur = extractExpect(equCur)
    appendNL("approx.jl",@sprintf("_APPROX(%d,%s);",_nl.nApprox,nameCur))
    appendNL("residequz.jl",@sprintf("_RESID(%d,%s)",_nl.nApprox,equCur))
    if(occursin(r"\b_exp\[",equCur))
      appendNL("residequd.jl",@sprintf("_ASSIGN_EXP(_resid[%d],%s)",_nl.nApprox,equCur))
    else
      appendNL("residequd.jl",@sprintf("_ASSIGN_STAT(_resid[%d],%s)",_nl.nApprox,equCur))
    end
  else
    equCur = convertTime(eq);
    equCur = extractExpect(equCur,indx,i0,i1)
    appendNL(indx,i0,i1,"approx.jl",@sprintf("_APPROX(%d+%s,%s);",_nl.nApprox,indx,nameCur))
    appendNL(indx,i0,i1,"residequz.jl",@sprintf("_RESID(%d+%s,%s)",_nl.nApprox,indx,equCur))
    if(occursin(r"\b_exp\[",equCur))
      appendNL(indx,i0,i1,"residequd.jl",@sprintf("_ASSIGN_EXP(_resid[%d+%s],%s)",_nl.nApprox,indx,equCur))
    else
      appendNL(indx,i0,i1,"residequd.jl",@sprintf("_ASSIGN_STAT(_resid[%d+%s],%s)",_nl.nApprox,indx,equCur))
    end
    _nl.nApprox += i1-i0+1;
  end
  pushNL!(:iApprox,name,indx,i0,i1);
end

function APPROX2_(name,eq_unused,indx::String="",i0::Int=0,i1::Int=0) # no residual
  global _nl;
  nameCur = convertTime(name,0);
  if i0==0
    _nl.nApprox2 += 1;
    appendNL("approx.jl",@sprintf("_APPROX(%d,%s);",_nl.nApprox,nameCur))
  else
    appendNL(indx,i0,i1,"approx.jl",@sprintf("_APPROX(%d,%s);",_nl.nApprox,nameCur))
    _nl.nApprox2 += i1-i0+1;
  end
  pushNL!(:iApprox,name,indx,i0,i1);
end
function DEFEXP_(name,eqs,indx::String="",i0::Int=0,i1::Int=0)
  eq = string(replSum(parse(eqs)))
  equCur = convertTime(eq);
  nameCur = convertTime(name,0);
  assert(i0==0)
  global _nl; 
  equCur = extractExpect(equCur)
  appendNL("defexp.jl",@sprintf("_ASSIGN(%s,%s)",nameCur,equCur))
end

function SETZERO_(name,eqs_unused,indx::String="",i0::Int=0,i1::Int=0)
  nameCur = convertTime(name,0);
  nameFor = convertTime(name,1);
  if i0==0
    appendNL("getvars0.jl",@sprintf("_ASSIGN(%s,0)",nameCur))
    appendNL("getvars1.jl",@sprintf("_ASSIGN(%s,0)",nameFor))
  else
    appendNL(indx,i0,i1,"getvars0.jl",@sprintf("_ASSIGN(%s,0)",nameCur))
    appendNL(indx,i0,i1,"getvars1.jl",@sprintf("_ASSIGN(%s,0)",nameFor))
  end
end
macro defineVEC(cmd)
  return esc( quote
               function $cmd(name,eq,indxVar::String,i0_::String,i1_::String)
                 local i0,i1
                 try 
                   i0::Int = Core.eval(parse(i0_))
                 catch
                   error("for variable " * name *": cannot evaluate to integer: ",i0_)
                 end
                 try 
                   i1::Int = Core.eval(parse(i1_))
                 catch
                   error("cannot evaluate to integer: ",i1_)
                 end
                 $cmd(name,eq,indxVar,i0,i1)
               end
             end )
  return esc( quote
               function $cmd(name,eq,indxVar::String,indx::String)
                 re = Regex("\\b" * indxVar * "\\b");
                 eq1 = replace(eq,re,indx)
                 name1 = replace(name,re,indx)
                 $cmd(name1,eq1,"",0,0)
               end
             end )
end
@defineVEC STATE_
@defineVEC PREDET_
@defineVEC SOLVEDYN_
@defineVEC DEFINE_
@defineVEC DEFINE0_
@defineVEC DEFINE1_
@defineVEC APPROX_
@defineVEC APPROX2_


function DECLARE_(keyw::String,var::String,sizeA::String)
  if keyw=="STATE"
    appendNL("declare.jl",var*"_cur_ = Array{Float64}"*sizeA)
    appendNL("declare.jl",var*"_for_ = Array{_apprCurType}"*sizeA)
  elseif keyw=="APPROX"
    appendNL("declare.jl",var*"_cur_ = Array{_apprCurType}"*sizeA)
    appendNL("declare.jl",var*"_for_ = Array{_apprForType}"*sizeA)
  elseif keyw=="DEFINE"
    appendNL("declare.jl",var*"_cur_ = Array{_apprCurType}"*sizeA)
    appendNL("declare.jl",var*"_for_ = Array{_apprForType}"*sizeA)
  elseif keyw=="DEFINE0"
    appendNL("declare.jl",var*"_cur_ = Array{_apprCurType}"*sizeA)
  elseif keyw=="DEFINE1"
    appendNL("declare.jl",var*"_for_ = Array{_apprForType}"*sizeA)
  elseif keyw=="SOLVEDYN"
    appendNL("declare.jl",var*"_cur_ = Array{_dynType}"*sizeA)
  end
end

function defmodelnl(linmodel::LinSol,xp;inpDir="",outpDir="")
  nnR = map(numbRealiz,xp)
  nRealiz = prod(nnR)
  if isempty(inpDir)
    inpDir = linmodel.name * "_files/"
  end
  if isempty(outpDir)
    outpDir = inpDir
  end
  global _nl = NLmodel(linmodel,outpDir);
  initnlfiles()
  include(inpDir * "getnonlin.jl") # this sets elements in _nl
  if (_nl.nGuessTr + _nl.nGuessDyn) > 0
    if(nRealiz==0)
      error("for model with inner fixed point problem, you must give number of shock realizations for defmodelnl")
    end
    if _nl.nApprox2>0
      setupNL("nltempldyn2",outpDir,inpDir,nnR)
    else
      setupNL("nltemplarr",outpDir,inpDir,nnR)
    end
  else
    setupNL("nltempl0neu",outpDir,inpDir,nnR)
  end
  return _nl
  include(outpDir*"colloc.jl")
end

function special_promotions(FF)
  txt = """
  function convert(::Type{Deriv1a{nBig}},x::Deriv1F{nSmall}) 
  for i=1:nGuessTr
  assert(x.d[nDyn2+i]==0)
  end
  d = zeros(nBig);
  for i=1:nDyn2
  d[i] = x.d[i];
  end
  return Deriv1a{nBig}(x.v,d)
  end
  function convert(::Type{Deriv1a{nBig}},x::Deriv1a{nSmall}) 
  for i=1:nGuessTr
  @assert(x.d[nDyn2+i]==0);
  end
  d = zeros(nBig);
  for i=1:nDyn2
  d[i] = x.d[i];
  end
  return Deriv1a{nBig}(x.v,d)
  end
  import Base.promote_rule
  promote_rule(::Type{Deriv1a{nBig}},::Type{Deriv1F{nSmall}}) = Deriv1a{nBig};
  promote_rule(::Type{Deriv1a{nBig}},::Type{Deriv1a{nSmall}}) = Deriv1a{nBig};
  """
  print(FF,txt)
  # txt = "promote_rule(::Type{Deriv1a{nBig2}},::Type{Deriv1a{nSmall2}}) = Deriv1a{nBig2};
  # function convert(::Type{Deriv1a{nBig2}},x::Deriv1a{nSmall2}) 
  #   for i=1:nApprox
  #     assert(x.d[nApprox+i]==0)
  #   end
  #   return Deriv1a{nBig2}(x.v,[x.d[1:nApprox];zeros(_eval(nRealiz*nApprox))]);
  # end\n";
  #   print(FF,txt)
end

function setupNL{_n}(scheme,outpDir,inpDir,nnR::NTuple{_n,Int})
  _FD = open(outpDir * "dimension.jl","w");
  global _nl;
  nA = _nl.nApprox;
  nA0 = nA - _nl.nApprox2;
  nParDynOne = _nl.nApprox - _nl.nApprox2 + _nl.nGuessDyn + _nl.nGuessTr;
  print(_FD,"""
        const nParDynOne = $nParDynOne
        if nParDynOne>600
        const TShort = Deriv1a{nParDynOne}
        else
        const TShort = Deriv1F{nParDynOne}
        end
        """)
  nApprox0 = _nl.nApprox - _nl.nApprox2
  @printf(_FD,"if !@isdefined(nStates)\n")
  @printf(_FD,"const nStates = %d;\n",_nl.nStates);
  @printf(_FD,"const nShocks = %d;\n",_nl.nShock);
  @printf(_FD,"const nGuessTr = %d;\n",_nl.nGuessTr);
  @printf(_FD,"const nGuessDyn = %d;\n",_nl.nGuessDyn);
  @printf(_FD,"const nApprox = %d;\n",nA);
  @printf(_FD,"const nApprox2 = %d;\n",_nl.nApprox2);
  @printf(_FD,"const nApprox0 = %d;\n",nApprox0)
  @printf(_FD,"const nCompSlack = %d;\n",_nl.nConstr);
  @printf(_FD,"const nEXPECT = %d;\n",_nl.nEXPECT);
  @printf(_FD,"end\n")

  doDyn1 = false
  nRealiz = prod(nnR)
  if doDyn1
    nParDyn = _nl.nGuessDyn + nRealiz*_nl.nGuessTr;
    nParDynOne = nl.nGuessDyn + _nl.nGuessTr;
    nDyn2 = _nl.nGuessDyn;
  else
    nParDyn = nApprox0 + _nl.nGuessDyn + nRealiz*_nl.nGuessTr;
    nParDynOne = nApprox0  + _nl.nGuessDyn + _nl.nGuessTr;
    nDyn2 = _nl.nGuessDyn+nA0;
  end
  print(_FD,"""
        const nDyn2 = $nDyn2
        const nParDyn = $nParDyn
        const nParDynOne = $nParDynOne
        const TParDynOne = TShort
        """)
  @printf(_FD,"const nBig = nDyn2 + %d\n",nRealiz*_nl.nGuessTr);
  @printf(_FD,"const nSmall =nDyn2 +  %d\n",_nl.nGuessTr);
  @printf(_FD,"const nRealiz = %d\n",nRealiz)
  print(_FD,"const nnRealiz = ",nnR,"\n")
  @printf(_FD,"const nRealiz2 = %d\n",nRealiz * _nl.nGuessTr);
  #@printf(_FD,"const nBig2 = %d\n",nA*(1+nRealiz))
  #@printf(_FD,"const nSmall2 = %d\n",nA*2)
  special_promotions(_FD);
  close(_FD);

  includepath1 = inpDir
  includepath2 = outpDir
  includepath3 = "$hetsolDir/"
  scheme1 = "$hetsolDir/$scheme.jl"
  outfile = outpDir * "colloc.jl"
  # println("now generate colloc.jl in dir ",outpDir)
  mpp(scheme1,outfile,Main,includepath1,includepath2,includepath3)
  # println("done with it")
  include( outpDir * "colloc.jl")
end

# This file contains the functions used in Main, not in the model-Module
function policynl(X::Array{Float64,2},nShocks::Int,
                  pars,vSS,fspace,coef,xp,doSolve=true,coefDyn=Array{Float64}(0,0))
  TSS = typeof(vSS)
  c = TSS()
  l = TSS()
  f = TSS()
  init!(c,NaN,pars)
  init!(l,NaN,pars)
  init!(f,NaN,pars)
  allVars = Dict{Symbol,Array{Float64,2}}()
  if isempty(coefDyn)
    forwfunc = (x,shock) -> colloc_f!(c,l,f,feval(fspace,x,coef),pars,vSS,x,xp,shock);
  else
    currDyn = feval(fspace,x0,coefDyn)
    forwfunc = (x,shock)->colloc_f!(c,l,f,coef,currDyn,pars,vSS,x,fspace,xp,shock,doSolve)
  end
  T = size(X,1)
  for t=1:T
    x = X[t,:]
    y = forwfunc(x,0.5*ones(nShocks))
    if isempty(allVars)
      nVars = 0;
      for v in fieldnames(typeof(c)) 
        len = length(getfield(c,v))
        nVars += len
        allVars[v] = fill(NaN,(T,len))
      end
    end
    for v in fieldnames(typeof(c)) 
      ci = getfield(c,v)
      allVars[v][t,:] = ci
    end
  end
  return allVars;
end
function simulnl(NL,x0,fspace,coef,xp,unifShocks,doSolve=true,coefDyn=Array{Float64}(0,0))
  model = NL.linModel
  pars = model.pars
  vSS = model.vstst
  TSS = typeof(vSS)
  c = TSS()
  l = TSS()
  f = TSS()
  init!(c,NaN,pars)
  init!(l,NaN,pars)
  init!(f,NaN,pars)
  allVars = Dict{Symbol,Array{Float64,2}}()
  if isempty(coefDyn)
    # forwfunc = (x,shock) -> colloc_f!(c,l,f,coef, pars,vSS,x,fspace,xp,shock)
    forwfunc = (x,shock) -> colloc_f!(c,l,f,feval(fspace,x,coef),pars,vSS,x,xp,shock);
  else
    currDyn = feval(fspace,x0,coefDyn)
    # forwfunc = (x,shock) -> colloc_f!(c,l,f,coef,feval(fspace,x,coefDyn), pars,vSS,x,fspace,xp,shock,doSolve)
    forwfunc = (x,shock)->colloc_f!(c,l,f,coef,currDyn,pars,vSS,x,fspace,xp,shock,doSolve)
  end
  x = copy(x0)
  T = size(unifShocks,2)
  for t=1:T
    # if mod(t,1000)==0
    #   println("in simulnl, iter = ",t)
    # end
    xx = copy(x)
    x = forwfunc(x,unifShocks[:,t]);
    x = forwfunc(xx,unifShocks[:,t]);
    if isempty(allVars)
      nVars = 0;
      for v in fieldnames(typeof(c)) 
        len = length(getfield(c,v))
        nVars += len
        allVars[v] = fill(NaN,(T,len))
      end
    end
    for v in fieldnames(typeof(c)) 
      ci = getfield(c,v)
      allVars[v][t,:] = ci
    end
  end
  return allVars;
end
function cumulGrowth(allVars0,growthVar::Symbol)
  allVars = copy(allVars0)
  g = allVars[growthVar]
  G = cumprod(g);
  for v in keys(allVars) 
    if v==growthVar
      Gsym = Symbol(v,"_cumul")
      if !haskey(allVars,Gsym)
        allVars[Gsym] = G.*allVars[v];
      end
    else
      allVars[v] = G.*allVars[v];
    end
  end
  return allVars
end
function logGrowth(allVars0,growthVar::Symbol,ststG::Float64)
  allVars = copy(allVars0)
  g = allVars[growthVar]
  G = cumprod(g/ststG); # everything relative to balanced growth
  for v in keys(allVars) 
    if v==growthVar
      allVars[v] = log.(allVars[v][2:end,:])
    else
      x = G.*allVars[v]
      if any(x.<=0)
        allVars[v] = diff(x,1);
      else
        allVars[v] = diff(log.(x),1);
      end
    end
  end
  return allVars
end
function logGrowthOLG(allVars0,OLGvar::Symbol,growthVar::Symbol)
  g = allVars[growthVar]
  G = cumprod(g);
  X = allVars[OLGvar];
  (T,nCoh) = size(X)
  dX = Array{Float64}(T-1,nCoh-1)
  for t=1:T-1
    for j=1:nCoh-1
      dX[t,j] = log.(X[t+1,j+1]/X[t,j])
    end
  end
  return dX;
end

function weightResiduals(resid,ResWeight)
  nDims = ndims(resid)
  nn = size(resid)
  if size(ResWeight,1)==0  # also works for LU factorizations, unlike "isempty"
    if nDims ==2
      return vec(resid);
    else
      return reshape(resid,nn[1]*nn[2],nn[3])
    end
  else
    if nDims ==2
      return vec(ResWeight*resid);
    else
      if supertype(typeof(ResWeight))==Factorization{Float64}
        resid = ResWeight \ reshape(resid,nn[1],nn[2]*nn[3])
      else
        resid = ResWeight * reshape(resid,nn[1],nn[2]*nn[3])
      end
      return reshape(resid,size(resid,1)*nn[2],nn[3])
    end
  end
end
function solveColloc{N}(coef0,solDyn0,opts,pars,vSS,Grid,fspace,xp::NTuple{N,SingleShock}, 
                        ResWeight,
                        direct::Array{SparseMatrixCSC{Float64,Int},1} = fill(mspeye(1),(0,)))
  iW = workers()
  local cSolve, flag
  solDyn = solDyn0
  flag = 1
  if _nl.nGuessDyn==0
    if opts.doTimeIter > 0
      coef = coef0;
      Basis = basis(fspace,Grid)
      Appr = fill(NaN,(size(Grid,1),size(coef,2)));
      for i=1:1000
        println(" timestep ",i)
        maxdist = timeiterStep(solve1_z,Appr,coef,pars,vSS,Grid,fspace,xp)
        coef = Basis\Appr;
        if maxdist<1e-8 || (maxdist<1e-7 && i>50)
          flag = 0
          cSolve = coef;
          break;
        end
      end
    else
      RW = full(ResWeight)
      # global s0 = colloc_z(vec(coef0),pars,vSS,Grid,fspace,xp,RW);
      # global sval = colloc_d(vec(coef0),pars,vSS,Grid,fspace,xp,RW)[1];
      # global jac = colloc_d(vec(coef0),pars,vSS,Grid,fspace,xp,RW)[2];
      (cSolve,flag) = broydn( 
                             c -> colloc_z(c,pars,vSS,Grid,fspace,xp,RW),
                             coef0[:],
                             tolf=1e-6,doPrint=1,
                             dfunc=c -> colloc_d(c,pars,vSS,Grid,fspace,xp,RW)[2]);
    end
  else
    if nApprox2==0
      nW = nworkers()
      if opts.doTimeIter > 0
        flag = 1;
        cSolve = vec(coef0)
        local J, linOp, Bas2
        B = basis(fspace,Grid);
        if size(B,1)==size(B,2)
          Binv = lufact(B)
        else # use LS:
          Binv = svdfact(B)
        end
        allSteps = Array{Array{Float64,2}}(0)
        for iter=1:opts.maxTimeIter
          pars.iterSigma = iter
          touch(_modelDir * "startiter.log")

          cSol2 = reshape(cSolve,size(coef0))
          # solDyn = feval2(fspace,Grid,cDyn')'
          # optBr = Options(:tolf,1e-6,:maxIter,20,:useADNewton,1,:doPrint,0)
          nA = size(solDyn,1)
          func = (a,g,optBr) ->  colloc_zsolve1(a, cSol2,
                                                      pars,vSS,
                                                      g,
                                                      fspace,
                                                      xp,
                                                      LOWBOUND!=0,
                                                      optBr
                                                     )
          # func(solDyn[:,1],Grid[1,:]); println("made it")
          ## if iter==2
          ## solDyn2 = distribTask(1,solDyn,Grid,func,optBr,distanceEuklid)
          ## solDyn2 = distribTask(nW,solDyn,Grid,func,optBr,distanceEuklid)

          ## _t0 = time_ns()
          ## solDyn2 = distribTask(nW,solDyn,Grid,func,optBr,distanceEuklid)
          ## _t1 = time_ns()
          ## println("para: ",(_t1-_t0)/1e9)

          ## _t0 = time_ns()
          ## solDyn2 = distribTask(1,solDyn,Grid,func,optBr,distanceEuklid)
          ## _t1 = time_ns()
          ## println("single: ",(_t1-_t0)/1e9)

          ## stop()
          ## end
          _t0 = time_ns()
          solDyn = distribTask(nW,solDyn,Grid,func,optBr,distanceEuklid)
          _t1 = time_ns()
          timeSeconds = (_t1-_t0)/1e9;
          appendf(_modelDir*"solve.log","time distribTask: "*string(timeSeconds))
          _t0 = time_ns()
          res = distribTask12(colloc_z,iW,Grid,solDyn,cSol2,pars,vSS,
                              fspace,xp, false,false)
          _t1 = time_ns()
          timeSeconds = (_t1-_t0)/1e9;
          appendf(_modelDir*"solve.log","time distribTask12: "*string(timeSeconds))
          _t0 = time_ns()
          nG = size(Grid,1);
          nA = div(length(res),nG)
          residCols = reshape(res,nG,nA) # directions to change parameters
          resProject = Binv\residCols; # translate residuals into parameters
          maxres = maximum(abs,resProject)
          maxres2 = maximum(abs,res)
          meanres2 = norm(res)
          @printf("res: %0.4e %0.4e   %0.4e  %0.4e; time=%0.f   \n",
                  maxres,norm(resProject), maxres2,norm(res),timeSeconds)
          # if(maxres<opts.ftolTimeIter)
          if min(maxres,meanres2) < opts.ftolTimeIter
            flag = 0;
            break;
          end
          push!(allSteps,resProject)
          if opts.doTimeIter == 1 || length(allSteps) < 8 # || maxres > 5e-6
            cSolve += vec(resProject)
          else # if opts.doTimeIter == 2
            println("now do OLS step")
            directMat = cat(3,allSteps...)
            direct = map(i->sparse(directMat[:,i,:]),1:nA)
            empty!(allSteps)
            J = ParaColloc(colloc_d,iW,Binv,
                           cSolve,solDyn,pars,vSS,Grid,fspace,xp,direct)
            # lambdaUpdate = -(Binv\J)\vec(resProject)
            lambdaUpdate = -J\vec(resProject)
            # lambdaUpdate *= 1.0/maximum(lambdaUpdate)
            DD = blockdiag(direct)
            # for lam in 0.1:0.1:2
            #   cTry = cSolve + DD*(lambdaUpdate*lam)
            #   res = ParaColloc(colloc_z,iW,ResWeight,cTry,solDyn,pars,vSS,
            #                    Grid,fspace,xp, true,true)
            #   residCols = reshape(res,nG,nA) # directions to change parameters
            #   resProject = Binv\residCols; # translate residuals into parameters
            #   maxres = maximum(abs,resProject)
            #   maxres2 = maximum(abs,res)
            #   @printf("res: %0.4e %0.4e   %0.4e  %0.4e   \n",
            #           maxres,norm(resProject), maxres2,norm(res))
            # end
            cSolve += DD*lambdaUpdate
            # res2 = ParaColloc(colloc_z,iW,ResWeight,cSolve,solDyn,pars,vSS, Grid,fspace,xp, true,true)
            # dd1 = res2-res
            # dd2 = J*lambdaUpdate
          end
          _t1 = time_ns()
          timeSeconds = (_t1-_t0)/1e9;
          appendf(_modelDir*"solve.log","time restiter: "*string(timeSeconds))

          ## Core.eval(model,:(doLinBackw = true))
          ## if iter>=1
          ##   J = colloc_d(cSolve,solDyn,pars,vSS,Grid,fspace,xp);
          ##   Bas = basis(fspace,Grid)
          ##   Bas2 = kron(mspeye(nApprox),inv(Bas))
          ##   println(size(Bas2))
          ##   println(size(J))
          ##   linOp = Bas2 * J;
          ## end
          ## # (ev,eV) = eigen(linOp);
          ## # println("maxeig: ",maximum(abs(ev)))
          ## cc = cSolve
          ## dc = Bas2*res
          ## for it=1:100
          ##   cc2 = cSolve + dc + linOp*(cc-cSolve);
          ##   if maximum(abs,cc2-cc)<1e-10
          ##     break;
          ##   end
          ##   cc = cc2;
          ## end
          ## dist = maximum(abs,cc-cSolve)
          ## cSolve = cc
          ## println(dist)
          ## if(dist<1e-8)
          ##   flag = 0;
          ##   break;
          ## end
          ## Core.eval(model,:(doLinBackw = false)) # restore old value
        end
      else # quasi-Newton
        if  isempty(direct)
          function solve4p!(cSol,solDyn)
            cSol2 = reshape(cSol,size(coef0))
            # optBr = Options(:tolf,1e-6,:maxIter,40,:useADNewton,1,:doPrint,0,:whenRestart,5)
            func = (a,g,optBr) ->  colloc_zsolve1(a, cSol2,
                                                        pars,vSS,
                                                        g,
                                                        fspace,
                                                        xp,
                                                        LOWBOUND!=0,
                                                        optBr
                                                       )
            solDyn2 = distribTask(nworkers(),solDyn,Grid,func,optBr,distanceEuklid)
            solDyn .= solDyn2
            resid = distribTask12(colloc_z,iW,Grid,solDyn,cSol2,pars,vSS,
                                  fspace,xp, false,false)
            return weightResiduals(resid,ResWeight)
          end
          (cSolve,flag) = newtonScaled(p -> solve4p!(p,solDyn),
                                       # p->ParaColloc(colloc_z,iW,ResWeight,p,solDyn,pars,vSS,Grid,fspace,xp,true,true),
                                       coef0[:],
                                       [opts.tolf,opts.useADNewton,1,opts.stepJacob,opts.maxIter],
                                       p->ParaColloc(colloc_d,iW,ResWeight,p,solDyn,pars,vSS,Grid,fspace,xp));
        else
          cc = coef0[:]
          BD = blockdiag(direct)
          BDprime = BD';
          assert(isempty(ResWeight))
          # @time resz = colloc_z(cc,solDyn,pars,_varsStSt,Grid,fspace,xp, true,true, zeros(0,0)) ;
          @time resz = ParaColloc(colloc_z,iW,ResWeight,cc,solDyn,pars,vSS,Grid,fspace,xp,true,true)
          println("max: ",maximum(abs,resz),"mean: ",mean(abs.(resz)))
          res2 = BDprime*resz;
          println(maximum(abs,res2))
          @time resd = ParaColloc(colloc_d,iW,ResWeight,cc,solDyn,pars,vSS,Grid,fspace,xp,direct)
          BDR = (BDprime*resd)
          # println("cond: ",cond(BDR))
          dx = BDR\res2;
          cc = cc - BD*dx;
          @time resz = ParaColloc(colloc_z,iW,ResWeight,cc,solDyn,pars,vSS,Grid,fspace,xp,true,true)
          println("max: ",maximum(abs,resz),"mean: ",mean(abs.(resz)))
          res2 = BDprime*resz;
          println(maximum(abs,res2))
          dx = (BDprime*resd)\res2;
          cc = cc - BD*dx;
          resz = ParaColloc(colloc_z,iW,ResWeight,cc,solDyn,pars,vSS,Grid,fspace,xp,true,true)
          println("max: ",maximum(abs,resz),"mean: ",mean(abs.(resz)))
          res2 = BDprime*resz;
          println(maximum(abs,res2))
          # saveT("cc.bmt",cc)
          return (reshape(cc,size(coef0)),solDyn)
        end
      end
    else # nApprox2 > 0
      if fspace.degree==1 || fspace.degree==-2
        if isempty(direct)
          nC = nCoeff(fspace)
          ii = 1:nC:length(coef0)
          iKeep = setdiff(1:length(coef0),ii[end-nApprox2+1:end])
          (cSolve,flag) = nllsfit( 
                                  p -> colloc_z(p,solDyn,pars,_varsStSt,Grid,fspace,xp, true,true) ,
                                  p -> colloc_d(p,solDyn,pars,_varsStSt,Grid,fspace,xp),
                                  coef0[:],0,iKeep);
        else
          cc = coef0[:]
          BD = blockdiag(direct)
          BDprime = BD';
          # (cSolve,flag) = nllsfit( 
          # p -> colloc_z(p,solDyn,pars,_varsStSt,Grid,fspace,xp, true) ,
          # p -> colloc_d(p,solDyn,pars,_varsStSt,Grid,fspace,xp,direct),
          # coef0[:],0,BD);
          resz = colloc_z(cc,solDyn,pars,_varsStSt,Grid,fspace,xp, true,
                                zeros(0,0)) ;
          println(maximum(abs,resz))
          res2 = BDprime*resz;
          println(maximum(abs,res2))
          resd = colloc_d(cc,solDyn,pars,_varsStSt,Grid,fspace,xp,
                                zeros(0,0),direct)
          dx = (BDprime*resd)\res2;
          cc = cc - BD*dx;
          resz = colloc_z(cc,solDyn,pars,_varsStSt,Grid,fspace,xp, true,
                                zeros(0,0)) ;
          println(maximum(abs,resz))
          res2 = BDprime*resz;
          println(maximum(abs,res2))
          return (cc,solDyn)
        end
      else
        error("not yet implemented")
      end
    end
  end
  println("time for solving:")

  if(flag!=0)
    resBr = ParaColloc(model.colloc_z,iW,ResWeight,cSolve[:],solDyn,pars,vSS,Grid,fspace,xp,true,true);
    @printf("broydn not converged; flag = %d; maximum(abs,res) = %e\n",flag,maximum(abs,resBr))
  end
  coef = reshape(cSolve,size(coef0))
  # if(flag==0)
  #   coef = reshape(cSolve,size(coef0))
  # else
  #   assert(false)
  # end
  return (coef,solDyn)
end
function scalUp(a,b,grid0)
  width = (b-a)'/2;
  mean = (b+a)'/2;
  Grid = broadcast(*,grid0,width); Grid = broadcast(+,Grid,mean);
  return  Grid
end
function scalUp(fspace,grid0)
  return scalUp(fspace.a,fspace.b,grid0);
end
function scalDown(fspace::MultiDimApprox,grid0)
  width = (fspace.b-fspace.a)'/2;
  mean = (fspace.b+fspace.a)'/2;
  Grid = broadcast(-,grid0,mean);
  Grid = broadcast(/,Grid,width);
  return  Grid
end
function scalDown(fspaceE::PolyApprExt,grid0)
  fspace = fspaceE.PExt;
  width = (fspace.b-fspace.a)'/2;
  mean = (fspace.b+fspace.a)'/2;
  Grid = broadcast(-,grid0,mean);
  Grid = broadcast(/,Grid,width);
  return  Grid
end

function iterNonl{N}(NL::NLmodel,fspace, xp::NTuple{N,SingleShock};
                     coef0 = zeros(0,0),
                     scaleShocks=[linspace(0.1,1,11); ones(3)],
                     homotopy=zeros(0,0),
                     soldyn=0,scalefunc=scaleFunc_default,weightfunc=weightFunc_default,
                     opts=Options(),
                     shocks::Array{Float64,2}=zeros(0,0),
                     width::Float64=4.0,
                     seed=0,
                     grid=GridGeneration(),
                     direct::Array{SparseMatrixCSC{Float64,Int},1} = fill(mspeye(1),(0,)))
  model = NL.linModel
  pars = model.pars;
  vSS = model.vstst;
  sigShock = tuple2array(map(stdev,xp))
  (meanLinear,sig) = momentsState(NL,transfState,sigShock);
  stdxLinear = max.(1e-4,sqrt.(diag(sig))); # guarantee minimum size of state space
  setBounds!(fspace, 
             meanLinear-width*stdxLinear*scaleShocks[1],
             meanLinear+width*stdxLinear*scaleShocks[1], meanLinear);
  if isempty(coef0)
    coef0 = initCoeff(NL,fspace)
  end

  coef = copy(coef0)

  g = grid
  g.width = width
  if !g.useFixed
    if g.useNodes
      g.grid0 = nodes01(fspace)
      # g.grid0 = rect2ball((1+grid0a)/2);
    else
      grid0a = rand(3*nCoeff(fspace),dimen(fspace))
      g.grid0 = rect2ball(grid0a)
    end
  end

  tSol0=time_ns()
  ResWeight = weightfunc(fspace,g.grid0)

  nStates = dimen(fspace);
  nIter = length(scaleShocks)
  touch(_modelDir * "startsolve.log")
  local coefDyn, solDyn
  for iterSigma=1:nIter
    scaleStdev = scaleShocks[iterSigma];
    if isdefined(pars,:homotopyPar)
      nH = length(pars.homotopyPar)
      @assert(nH == size(homotopy,1),println(nH,":",size(homotopy)))
      for i=1:nH
        pars.homotopyPar[i] = homotopy[i,iterSigma];
      end
    end
    xpScal = scaleStdev*xp;
    println("*****************")
    @printf("iter = %d/%d; scale StDev = %f;\n",iterSigma,nIter,scaleStdev)


    if iterSigma>1
      fspaceOld = copy(fspace);
      (a,b,center) = scalefunc(g.path,scaleShocks[iterSigma],scaleShocks[iterSigma-1],width) 
      setBounds!(fspace,a,b,center)
      coef = changeScale(coef,fspaceOld,fspace)
      if @isdefined(coefDyn) && !isempty(coefDyn)
        coefDyn = changeScale(coefDyn,fspaceOld,fspace)
      end
    end

    if !g.useFixed # otherwise, g.grid must be set before
      if g.useSimul # otherwise, g.grid must be set before
        ng = g.nRandom*nCoeff(fspace)
        iSelect = map(roundI,linspace(1,size(g.path,1),ng))
        g.grid = g.path[iSelect,:]
      else
        g.grid = scalUp(fspace,g.grid0)
      end
    end
    if NL.nGuessDyn>0
      if iterSigma == 1
        if isa(soldynFunc,Function)
          solDyn = map2rows(soldynFunc,g.grid)' # soldyn and grid differently ordered, fix it!!!!!
        else
          solDyn = initParDyn(NL,size(g.grid0,1),vSS) # also done in iternonl
        end
      elseif scaleShocks[iterSigma]!=scaleShocks[iterSigma-1]
        solDyn = feval(fspace,g.grid,coefDyn)'
      end
    else
      solDyn = zeros(0,0)
    end

    tIter0=time_ns()

    if isempty(shocks)
      shocks = rand(length(xp),1000)  ; # not used for scaling anyway
    end
    opts.lenSimul = size(shocks,2)
    (coef,solDyn) = solveColloc(coef,solDyn,opts,pars,vSS,g.grid,fspace,xpScal,ResWeight,direct)
    tIter1=time_ns()
    appendf(_modelDir*"solve.log", @sprintf("time iterSigma %d: %f",iterSigma,(tIter1-tIter0)/1e9))

    bounds = hcat(fspace.a,fspace.b)
    if NL.nGuessDyn==0
      forwfunc = (x,shock) -> colloc_f(feval(fspace,x,coef),pars,vSS,x,xpScal,shock);
    else
      coefDyn = basis(fspace,g.grid)\solDyn';
      forwfunc = (x,shock) -> colloc_f(coef,feval(fspace,x,coefDyn),pars,vSS,x,fspace,xpScal,shock,false)
    end
    # xnext = forwfunc(fspace.center,rand(1))
    # try 
    #   xnext = forwfunc(fspace.center,rand(1))
    # catch
    #   error("forwfunc failed")
    # end
    g.path = SimulAntithetic(forwfunc, fspace.center, shocks, opts, bounds);
  end
  tSol1=time_ns()
  appendf(_modelDir*"solve.log", @sprintf("time solve: %f",(tSol1-tSol0)/1e9))

  if NL.nGuessDyn==0
    return coef
  else
    return (coef,coefDyn,solDyn)
  end
end



function inBounds!(x::Array{Float64,1},a::Array{Float64,1},b::Array{Float64,1})
  n = length(x)
  for i=1:n
    x[i] = max(min(x[i],b[i]),a[i])
  end
end
# forwfunc takes (x,shock) as arguments
function SimulAntithetic(forwfunc, x0,shocks_unif, opts, bounds=[])

  nS = length(x0)
  T = opts.lenSimul;
  assert(T>0)  # is set to 0 by default constructor of options
  Tskip = opts.lenSkipSimul;
  assert(size(shocks_unif,2)>=T+Tskip)
  path1 = zeros(T,nS)
  path2 = zeros(T,nS)
  if isempty(bounds)
    doBounds = false;
  else
    doBounds = true;
    lowB = bounds[:,1]
    uppB = bounds[:,2]
  end

  x1 = copy(x0);
  x2 = copy(x0);
  for t=1:T+Tskip
    #try
    x1 = forwfunc(x1,shocks_unif[:,t]);
    #catch
    #  catch_backtrace()
    #  println(x1)
    #  error("error sim1")
    #end
    #try
    x2 = forwfunc(x2,1-shocks_unif[:,t]);
    # catch
    #   catch_backtrace()
    #   println(x2)
    #   error("error sim2")
    # end
    if doBounds
      inBounds!(x1,lowB,uppB)
      inBounds!(x2,lowB,uppB)
    end
    if(t>Tskip)
      path1[t-Tskip,:] = x1;
      path2[t-Tskip,:] = x2;
    end
  end
  path = vcat(path1,path2)
  Xmean = mean(path,1);
  Xmedian = median(path,1);
  Xmin = minimum(path,1);
  Xmax = maximum(path,1);
  SigmaPath = 0.5*(cov(path1) + cov(path2));
  if(opts.printSimul>0)
      _minpath = minimum(path,1);
      _maxpath = maximum(path,1);
      for j=1:size(path2,2)
        @printf("Var %d: mean = %10.4f; median = %10.4f; min,max = (%0.4f,%0.4f); bounds=(%0.4f,%0.4f)\n",
                j, Xmean[j],Xmedian[j],_minpath[j],_maxpath[j],lowB[j],uppB[j])
      end
    end
    pathScaled = scalDown(fspace,path);
    XminScal = minimum(pathScaled,1);
    XaxScal = maximum(pathScaled,1);
    for j=1:size(path2,2)
      if(opts.printSimul>1 || XminScal[j]<-1.0001 || XaxScal[j]>1.0001)
        @printf("Var %d: mean = %10.4f; Minscal = %10.4f Maxscal = %10.4f\n",j,Xmean[j],XminScal[j],XaxScal[j]);
      end
    end
    if(any(XminScal.<-1) || any(XaxScal.>1))
      print("Warning: SIMULATION OUT OF BOUNDS\n");
    end
  return [path1;path2];
  # return (Xmean,Xmedian,Xmin,Xmax,SigmaPath,[path1;path2]);
end

# mean and variance matrix of states of model defined by model and _nl:
function momentsState(_nl,transfState::Function, diagSigma::Array{Float64,1})
  model = _nl.linModel;
  iState = _nl.iState

  ssVec = stackFields(Float64,model.vstst)
  ststS = ssVec[iState];

  ststStransf = transfState(ststS,model.pars);
  SigmaEps = mdiagm(diagSigma);
  SigmaX = doubling(model.A,model.B,SigmaEps,30)
  SigmaS = SigmaX[iState,iState]
  J = jacob(transfState,ststS,1e-6)
  SigmaStrans = J*SigmaS*J' # not scaled!
  return (ststStransf,SigmaStrans)
end
function ols_ridge(X,Y,tol=1e-12)
  (U,s,V) = svd(X);
  sInv = 1.0 ./ max.(s,s[1]*tol);
  beta = V*mdiagm(sInv)*U'*Y;
end
function var2ss(A,B,iState,iLag,iJump,StStvalues=[])
  nA = size(A,1);
  if(isempty(iJump))
    iJump = setdiff(1:nA,iState);
  end

  nz = size(B,2);
  nj = length(iJump);
  ns = length(iState);

  T = max(max(3*ns,3*length(iJump)),100);
  shocks = randn(nz,T);
  x = zeros(nA,1);
  # x = randn(nA,1);
  xx = zeros(T,nA);
  for t=1:T
    x = A*x + B*shocks[:,t];
    # x[iState] += 1e-2*randn(ns) 
    xx[t,:] = x';
  end
  tt = 2:T;
  nSt = length(iState);
  X = zeros(length(tt),nSt);
  for i=1:nSt
    X[:,i] = xx[tt+iLag[i],iState[i]];
  end
  y = xx[tt,iJump];
  std = sqrt.(var(X,1))
  if(any(std.<1e-12))
    println(var(X,1))
    warn("var2ss: constant elements in state vector")
    iZ = mfind(std.<1e-12)
    inZ = setdiff(1:nSt,iZ)
    Q = zeros(nSt,size(y,2))
    Q[inZ,:] = ols_ridge(X[:,inZ],y,1e-12);
  else
    Q = ols_ridge(X,y,1e-12);
  end
  if(!all(isfinite.(Q)))
    error("error in var2ss");
  end
  resid = y - X*Q;
  normB = maximum(abs,resid);
  if(normB>1e-6)
    @printf("condition number of X in var2ss: %e\n",cond(X))
    println(normB);
    warn(@sprintf("resid for jump variables in var2ss is %e\n",normB));
    error("done")
  end
  Qconst = zeros(length(iJump));
  if(!isempty(StStvalues))
    # y = ystst + Q*(x-xstst)
    Qconst = StStvalues[iJump] - Q'*StStvalues[iState];
  end
  return (Q',Qconst);
end
function ststPol(model::Module,iState,iApprox,iLagState)
  ststJ = model._ststVector[iApprox];
  return x -> ststJ;
end
ststPol(model::Module,nl) = ststPol(model,nl.iState,nl.iApprox,nl.iLagState)
function linPol(model::LinSol,iState,iApprox,iLagState)
  # if all(iLagState.==0)  ## DOES NOT ALWAYS WORK!
  #   slope = var2ss(model._A,model._B,iState,iApprox)
  # else
  #   (slope,Qunused) = var2ss(model._A,model._B,iState,iLagState,iApprox)
  # end
  (slope,Qunused) = var2ss(model.A,model.B,iState,iLagState,iApprox)
  ssVec = stackFields(Float64,model.vstst)
  ststS = ssVec[iState];
  ststJ = ssVec[iApprox];
  return x -> ststJ + slope*(x-ststS)
end
linPol(nl) = linPol(nl.linModel,nl.iState,nl.iApprox,nl.iLagState)
# give xp as argument if fspace contains MarkovChains, xp then gives grids for those
function initCoeff(_nl,fspace)
  model = _nl.linModel
  # transform:
  # coefficients for approximation of transformed variables in transformed grid:
  # basis of approximating functions, in transformed variables:
  stp = linPol(_nl)
  # stp = ststPol(model,_nl)
  ff(x) = stp(invtransfState(x))
  coef = fitfun2(fspace,ff)
  # check the result:
  ssVec = stackFields(Float64,model.vstst)
  ststS = ssVec[_nl.iState];
  ststJ = ssVec[_nl.iApprox];
  ststStransf = transfState(ststS,model.pars);
  jump = feval(fspace,ststStransf,coef);
  check = maximum(abs,vec(jump) - ststJ);
  if(check>1e-10)
    display([vec(ststJ) vec(jump)])
    error("wrong in initcoeff")
  end
  coef[abs.(coef).<1e-14] = 0;
  return coef
end
function initParDyn(model::Module,nGrid::Int,vSS)
  solDyn = Array{Float64}(model.nParDyn,nGrid) # default values for solDyn: steady state
  for i=1:nGrid
    model.initpar_dyn!(view(solDyn,:,i),vSS);
  end
  return solDyn
end

## function gridFunc_default(fspace)
##   global grid0
##   return scalUp(fspace,grid0)
##   # if size(grid0,1) == nCoeff(fspace)
##   #   return (scalUp(fspace,grid0),zeros(0,0))
##   # else
##   #   B = basis(fspace,grid0)
##   #   ResWeight = (B'*B)\B';
##   #   return (scalUp(fspace,grid0),ResWeight)
##   # end
## end
function weightFunc_default(fspace,grid0)
  n = nCoeff(fspace)
  if size(grid0,1) == n
    return spzeros(0,0)
  else
    fs2 = copy(fspace);
    fill!(fs2.a,-1)
    fill!(fs2.b,1)
    B = basis(fs2,grid0)
    ResWeight = (B'*B)\B';
    for i=1:length(ResWeight)
      if(abs(ResWeight[i])<1e-14)
        ResWeight[i] = 0;
      end
    end
    return sparse(ResWeight)
  end
end
function scaleFunc_default(paths,scal,scalLast,width::Float64)
  center = vec(mean(paths,1));
  std = sqrt.(vec(var(paths,1))) * (scal/scalLast);
  std = max.(std,1e-4);
  return (center-width*std,center+width*std,center)
end
function statsResid(resid,filename::String,header::String)
  FOUT = open(filename,"a")
  println(FOUT,header)
  println(FOUT,"Mean and max errors in accuracy check:")
  meanres = mean(resid,1)
  meanabs = mean(abs.(resid),1)
  medabs = median(abs.(resid),1)
  maxabs = maximum(abs.(resid),1)
  println(FOUT,meanabs)
  println(FOUT,maxabs)
  close(FOUT)
  return [meanabs;maxabs;medabs;meanres]
end
function statsResid(resid,FOUT=stdout)
  meanres = mean(resid,1)
  meanabs = mean(abs.(resid),1)
  maxabs = maximum(abs.(resid),1)
  println(FOUT,"Mean and max errors in accuracy check:")
  println(FOUT,meanabs)
  println(FOUT,maxabs)
  return [meanabs;maxabs;meanres]
end

function step1(model,x0,pars,vSS,fspace,coef,xp,unifShocks::Array{Float64,1},coefDyn=Array{Float64}(0,0))
  c = model.StructVarsStSt{Float64}()
  l = model.StructVarsStSt{Float64}()
  f = model.StructVarsStSt{Float64}()
  model.init!(c,NaN,pars)
  model.init!(l,NaN,pars)
  model.init!(f,NaN,pars)
  if isempty(coefDyn)
    forwfunc = (x,shock) -> model.colloc_f!(c,l,f,coef,
                                            pars,vSS,x,fspace,xp,shock)
  else
    doSolve=true
    if ndims(coefDyn)==2
      forwfunc = (x,shock) -> model.colloc_f!(c,l,f,coef,feval(fspace,x,coefDyn),
                                              pars,vSS,x,fspace,xp,shock,doSolve)
    elseif ndims(coefDyn)==1
      forwfunc = (x,shock) -> model.colloc_f!(c,l,f,coef,coefDyn,
                                              pars,vSS,x,fspace,xp,shock,doSolve)
    else
      error("wrong dimension")
    end
  end
  x = forwfunc(copy(x0),unifShocks);
  return x;
end
function stochstst(model,xStart,pars,vSS,fspace,coef,xp,coefDyn=Array{Float64}(0,0))
  unifShocks = 0.5*ones(length(xp))
  # opts = Options(:tolf,1e-6,:doPrint,1,:useADNewton,0)
  println("compute stochastic steady state")
  (xstst,flag) = broydn( x -> step1(model,x,pars,vSS,fspace,coef,xp,unifShocks,coefDyn) - x,
                        xStart,
                        tolf=1e-6,doPrint=1,whichAD="none")
  if(flag!=0)
    error("stochstst not converged")
  end
  return xstst;
end


function timeiterStep!(Appr,func,_coef,_p,_vss,Grid,_fspace,xp)
  nA = _nl.nApprox;
  nG = size(Grid,1)
  assert(size(Appr) == (nG,nA))
  maxdist = 0;
  imax = 0;
  for i=1:nG
    gridCurr = Grid[i,:]
    approx0 = Appr[i,:];
    if !isfinite(approx0[1])
      maxdist = 1;
      approx0 = feval(_fspace,gridCurr,_coef);
    end

    (approx1,flag) = broydn( 
                            a -> func(a,_coef,_p,_vss,gridCurr,_fspace,xp),
    approx0[:];
    tolf=1e-6,doPrint=0,whichAD="dense",
    dfunc=a -> getjac(func(indep(Deriv1F{nA},a),_coef,_p,_vss,gridCurr,_fspace,xp))
   )
    if(flag==0)
      Appr[i,:] = approx1
      dd = norm(approx1-approx0)
      if(dd>maxdist)
        maxdist = dd
        imax = i;
      end
    else
      println("grid point ",i)
      println(gridCurr)
      println(approx1)
      df = func(indep(Deriv1F{nA},approx1),_coef,_p,_vss,gridCurr,_fspace,xp)
      saveT("df.bmt",gridCurr,approx1,getval(df),getjac(df))


      global _c = StructVarsStSt1{Float64}()
      global _l = StructVarsStSt1{Float64}()
      global _f = StructVarsStSt1{Float64}()
      init!(_c,NaN,_p)
      init!(_l,NaN,_p)
      init!(_f,NaN,_p)
      colloc_f!(_c,_l,_f,approx1,_p,_vss,gridCurr,xp,0.5*ones(length(xp)))
      show(_c)
      error("done")
      # approx0 = feval(_fspace,Grid[i+1,:],_coef);
      (approx1,flag) = broydn( 
                              a -> func(a,gridCurr,_coef,_p,_vss,_fspace,xp),
      approx1[:],
      opts,
      a -> getjac(func(indep(Deriv1F{nA},a),gridCurr,_vss,_coef,_p,_fspace,xp))
     )
      if(flag==0)
        Appr[i,:] = approx1
        dd = norm(approx1-approx0)
        if(dd>maxdist)
          maxdist = dd
          imax = i;
        end
      else
        println("not converged in timestep")
        res = func(approx1,gridCurr,_coef,_vss,_p,_fspace,xp);
        if(maxabs(res)>1e-5)
          FF = open("resid.out","w")
          println("grid point ",i)
          println(FF,gridCurr)
          println(FF,_fspace.a)
          println(FF,_fspace.b)
          println(FF,approx1)
          println(FF,res)
          close(FF)
          p = _varsStSt.p
          # p = approx1[end]
          pspace = linspace(p-0.05,p+0.05,101)
          # pspace = linspace(_varsStSt.p-0.05,_varsStSt.p+0.05,101)
          resp = zeros(101)
          flag = 1
          local a1
          for ii = 1:length(pspace)
            (a1,flag) = broydn( 
            a -> func([a;pspace[ii]],gridCurr,_coef,_vss,_p,_fspace,xp)[1:7],
            flag==0 ? a1 : vec(approx1[1:7]), # _ststVector[iApprox[1:7]],
            [_opt.tolf,1,0,1e-6,20],
            a -> getjac(func(indep(Deriv1F{nA},[a;pspace[ii]]),gridCurr,_coef,_vss,_p,_fspace,xp))[1:7,1:7]
            )
            if(flag!=0)
              print("n")
            else
              print("c")
            end
            resp[ii]= func([a1;pspace[ii]],gridCurr,_coef,_vss,_p,_fspace,xp)[8];
            FF = open("resid.out","a")
            @printf(FF,"f%dp:%0.4f;res:%0.5f;",flag,pspace[ii],resp[ii];)
            println(FF,"e:",a1)
            close(FF)
            # print(resp[ii],";")
          end
          plot(pspace,resp)
          plot(_varsStSt.p*ones(2),[-0.02;0.02])
          plot(pspace,0*pspace)
          global localenv = Dict{Symbol,Any}()
          localenv[:args] = (_coef,_vss,_p,_fspace,xp)
          localenv[:func] = func
          localenv[:Grid] = Grid
          localenv[:gcurr] = gridCurr
          localenv[:Appr] = Appr
          localenv[:a1] = a1

          stop()
          error("broydn in timeiter not converged at ",i)
          Appr[i,:] = approx0
        end
      end
    end
  end
  if(!all(isfinite.(Appr)))
    saveT("appr.bmt",Appr)
    error("appr not finite")
  end
  println("maxdist in timeiter = ",maxdist," at ",imax)
  return maxdist;
end

function timeiterStep(func,Appr,_coef,_p,_vss,Grid,_fspace,xp)
  nA = _nl.nApprox;
  nG = size(Grid,1)
  maxdist = timeiterStep!(Appr,func,_coef,_p,_vss,Grid,_fspace,xp)
  return maxdist;
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# Michael Reiter, IHS

function hswarn(arg1,args...)
  print("WARNING: ",arg1)
  for i=1:length(args)
    print(" ",args[i])
  end
  print("\n")
end
import Base.getindex
struct ConstantVar{T} # same value for each index
  x::T
end
getindex(S::ConstantVar{T},i) where T = S.x;
Main.convert(::Type{ConstantVar{Float64}},x::Float64) = ConstantVar{Float64}(x)
struct StStVar
  x::Float64
end
getindex(V::StStVar,t::Int) = V.x;
import Base.zero
zero(::Type{StStVar}) = StStVar(0.0)

struct PriceVar
  x::Float64
end
getindex(V::PriceVar,t::Int) = t==1 ? indep(Deriv22,V.x,1) : convert(Deriv22,V.x)
zero(::Type{PriceVar}) = PriceVar(0.0)

abstract type AggrGridStruct end;




function maxQuad(x0,x1,x2,v0,v1,v2)
  y1 = x1-x0;
  y2 = x2-x0;
  z1 = y1/y2;
  #zstat0 = (v0*z1^2 - v0 + v1 - v2*z1^2)/(2*(v0*z1 - v0 + v1 - v2*z1))
  tmp1 = (v0-v2)*z1;
  tmp2 = v1-v0;
  zstat = (tmp1*z1 + tmp2) / (2*(tmp1+tmp2))
  #@assert(abs(zstat-zstat0)<1e-12)
  xstat = zstat*y2 + x0
  vstat = (v2-v0)*z1 + (v0-v1)/z1  + v2
  return (xstat,vstat)
end
function maxQuadSafe(x0::Float64,x2::Float64,v0::T,v1::T,v2::T)::T where T  # x1 is midpoint between x0 and x2
  dx2 = x2-x0
  dx = dx2/2;
  dv1 = (v2-v0) / dx2
  x1 = (x2+x0)/2;
  dv2 = (v2-2*v1+v0)/dx^2
  if dv2>=0
    return x1
  else
    return x1 - dv1/dv2
  end
end

function goldenSearchMax(f,ax,bx,cx,tol)
  R =  0.61803399
  C =  (1.0-R)

  x0=ax;
  x3=cx;
  if (abs(cx-bx) < abs(bx-ax)) 
    x1=bx;
    x2=bx+C*(cx-bx);
  else
    x2=bx;
    x1=bx-C*(bx-ax);
  end
  f0=f(x0);
  f1=f(x1);
  f2=f(x2);
  f3=f(x3);
  while (abs(x3-x0) > tol*(max(1,abs(x1)+abs(x2)))) 
    if (f2 > f1 || (f2==f1 && f3>f2)) 
      x0=x1;x1=x2;x2=R*x1+C*x3
      f0=f1;f1=f2;f2=f(x2)
    else
      x3=x2;x2=x1;x1=R*x2+C*x0
      f3=f2;f2=f1;f1=f(x1)
    end
  end
  #println([f0 f1 f2 f3])
  if (f2 > f1 || (f2==f1 && f3>f2)) 
    if (f2 > f3) 
      return (x2,f2);
    else
      return (x3,f3);
    end
  else
    if (f0 > f1) 
      return (x0,f0);
    else
      return (x1,f1);
    end
  end
end

function interiorMax(func,x1,x2,f1,f2,n=50,tol=0.)::Tuple{Float64,Float64}
  if tol<=0
    tol = (x2-x1)/1000
  end
  xx = convert(Array{Float64,1},linspace(x1,x2,n))
  ff = fill(0.0,(n,))
  ff[1] = f1
  ff[n] = f2
  for i=1:n
    ff[i] = func(xx[i]);
  end
  xBest = NaN
  fBest::Float64 = -1e100
  nLocMax = 0
  if ff[1]>=ff[2]
    nLocMax += 1
    (xTry,fTry) = goldenSearchMax(func,xx[1],(xx[1]+xx[2])/2,xx[2],tol)
    if fTry>fBest
      fBest=fTry
      xBest=xTry
    end
  end
  if ff[n]>=ff[n-1]
    nLocMax += 1
    (xTry,fTry) = goldenSearchMax(func,xx[n-1],(xx[n-1]+xx[n])/2,xx[n],tol)
    if fTry>fBest
      fBest=fTry
      xBest=xTry
    end
  end
  for i=2:n-1
    if ff[i]>=ff[i-1] && ff[i]>=ff[i+1]
      nLocMax += 1
      (xTry,fTry) = goldenSearchMax(func,xx[i-1],xx[i],xx[i+1],tol)
      if fTry>fBest
        fBest=fTry
        xBest=xTry
      end
    end
  end
  if(nLocMax>1)
    # println("Warning: nLocMax = ",nLocMax)
    # ii = mfind(ff.>-1e99)
    # plot(xx[ii],ff[ii])
    # global xxx = xx;
    # global fff = ff;
    # error("nLocMax")
  end
  # println("max is at ",xBest)
  return (fBest,xBest)
end

# function interp(dp::DynProgVal{T},x,j::Int,k::Int) where T
#   (i,p) = posInGrid(dp.grid,x) #use that cc = xEnd
#   v = (1-p)*dp.V[i,j,k] + p*dp.V[i+1,j,k] + p*(p-1)*dp.Q[i,j,k];
#   return v
# end

mutable struct DynProg
  val::DynProgVal{Float64}
  pol4v::DynProgPol{Float64}
  polstst::DynProgPol{Float64}
  pol::DynProgPol{Deriv4hs}
  DynProg() = new()
end

mutable struct DynProgRes
  gridEndog::Array{Float64,1}
  V::Array{Float64,3}
  CC::Array{Float64,3}
  DC::Array{Int,3}
  I::Array{Int,3}
  P::Array{Float64,3}
  DE::Array{Int,3}
  U::Array{Float64,3}
  B::Array{Int,3}
  switches::Array{Switch{Float64},1}
end
dynProgRes(nCS,nDS,nExog) = DynProgRes(
                                       fill(0.0,(nCS,)),
                                       fill(0.0,(nCS,nDS,nExog)),
                                       fill(0.0,(nCS,nDS,nExog)),
                                       fill(0,(nCS,nDS,nExog)),
                                       fill(0,(nCS,nDS,nExog)),
                                       fill(0.0,(nCS,nDS,nExog)),
                                       fill(0,(nCS,nDS,nExog)),
                                       fill(0.0,(nCS,nDS,nExog)),
                                       fill(0,(nCS,nDS,nExog)),
                                       Array{Switch}(0)
                                      );

function dpNonConvex1d!(model,pars, aggr, dpVal::DynProgVal{T}, nAccel, tt) where T
  # nAccel = 1
  (nCS,nDS,nExog) = size(dpVal.V)
  size3 = (nCS,nDS,nExog)
  I = fill(zero(Int32),size3)
  P = fill(0.0,size3)
  U = fill(0.0,size3)
  gridCS = dpVal.grid
  @assert(nCS == length(gridCS))
  transExogPrime = Array(model._transExog(pars,aggr,StStIndex(0))');
  if nExog*nDS != size(transExogPrime,1)
    println("inconsistent discrete states: $nExog* $nDS not equal ",size(transExogPrime,1))
  end
  nDC::Int = model._nDC(pars)

  # use same grid as for value function:
  dpPol = dynProgPol(Float64,gridCS,nDS,nExog) 
  if typeof(tt)==StStIndex
    allIter = 0:10000 # maximum 10000 iterations
  else 
    allIter = tt;
  end
  distance = 1;
  Qend = zeros(nCS,nDS,nExog);
  QisSet = false
  if _linsol.inJacob 
    dpVal.V *= 0.0; # to ensure equal starting condition within Jacobian computation
  end
  for iter in allIter
    if typeof(tt)==StStIndex
      t = tt
    else
      t = iter
    end
    if _linsol.useQuad && !QisSet && distance<1e-6
      pos2X!(dpPol.CC,I,P,gridCS) 
      deriv4q = getDeriv1(model,pars,aggr,dpVal,dpPol) 
      setQ2!(dpVal.Q,deriv4q,dpVal.grid,dpPol,50)
      if _linsol.printLevel>0
        println("now set quadratic terms in value function")
        @show maximum(dpVal.Q)
        @show minimum(dpVal.Q)
      end
      QisSet = true
    end
    Vcontz = condExpectExog(dpVal.V,transExogPrime)
    Qend .= condExpectExog(dpVal.Q,transExogPrime)
    Vcont = copy(dpVal.V); # copy, to measure change in V below
    jobs = Array{Future}(undef,nExog)
    ### if nworkers()>1
    ###   data = RemoteChannel(()->Channel{Tuple}(4));
    ###   results = RemoteChannel(()->Channel{Tuple}(nExog));
    ###   jobs = RemoteChannel(()->Channel{Tuple}(nExog));
    ### end
    if nworkers()>1
      myPool = CachingPool(workers())
    end
    if(mod(iter,nAccel)==0)  # do optimization
      ta = time_ns();
      if nworkers()>1
        ngs = _opt.nGridSearch[1]
        jobs = pmap(j->optimAtExog(pars,aggr,
                                   model._disc, model._util, model._prep!, model._range, 
                                   model.TempParam{Float64},
                                   j,gridCS,nDC, 
                                   Vcontz,
                                   Qend,
                                   gridCS,
                                   ngs, _linsol,t),
                    myPool,1:nExog)
        for j=1:nExog # for each value of exogenous state
          # (dpVal.V[:,:,j], dpPol.CC[:,:,j],dpPol.DC[:,:,j],dpPol.I[:,:,j],
          (dpPol.DC[:,:,j],I[:,:,j],
           P[:,:,j],dpPol.DE[:,:,j],U[:,:,j],dpPol.B[:,:,j]) = fetch(jobs[j]);
        end
        dpPol.CC .= NaN;

      else
        for j=1:nExog # for each value of exogenous state
          #(dpVal.V[:,:,j], dpPol.CC[:,:,j],dpPol.DC[:,:,j],dpPol.I[:,:,j],
          (dpPol.DC[:,:,j],I[:,:,j],
           P[:,:,j],dpPol.DE[:,:,j],U[:,:,j],dpPol.B[:,:,j]) = 
          optimAtExog(pars,aggr,
                      model._disc, model._util, model._prep!, model._range, 
                      model.TempParam{Float64},
                      j,gridCS,nDC, Vcontz,Qend,dpVal.grid,
                      _opt.nGridSearch[1],_linsol, t);
        end
      end
      tb = time_ns();
      #println("time for optimatexog: ",(tb-ta)/1e9);
    end
    # else # acceleration step: use action from last optimization
      for j=1:nExog # for each value of exogenous state
        for k=1:nDS # for each value of discrete state
          disc::Float64 = model._disc(pars,aggr,k,j,t) 
          for i=1:nCS # for each value of exogenous state
            iT = I[i,k,j]
            p = P[i,k,j]
            iDnext = dpPol.DE[i,k,j]
            dpVal.V[i,k,j] = U[i,k,j] + 
            disc*((1-p)*Vcontz[iT,iDnext,j] + p*Vcontz[iT+1,iDnext,j] 
                  + p*(p-1)*Qend[iT,iDnext,j])
          end
        end
      end
     # @show dpVal.V[1]
    if(mod(iter,nAccel)==0)
      dv = abs.(dpVal.V[:]-Vcont[:]);
      iM = argmax(dv);
      distance = dv[iM];
      if _linsol.printLevel>0
        @printf("iter = %d, distance = %e at %d,%d,%d\n",iter,distance,
                ind2sub(size(Vcont),iM)...)
      end
      if(iter>0 && distance<1e-8)
        break;
      end
    end
  end

  pos2X!(dpPol.CC,I,P,gridCS) 
  global _QcontAGlob = dpVal.Q;
  # global _QcontAzGlob = Qend;
  return dpPol
end

function condExpectExog(V,transExogPrime::AbstractMatrix)
  (n1,n2,n3) = size(V)
  Vcont = reshape(V,(n1*n2,n3));
  Vcontz0 = Vcont*transExogPrime; # taking expectations over future z; discounting done in optimAt
  Vcontz = reshape(Vcontz0,n1,n2,n3)
  return Vcontz
end

function evalPol(model,pars, aggr, 
                #  dpVal::DynProgVal{T}, 
                gridV,V::Array{T},Q,
                 gridPol,t) where T
  (nCS,nDS,nExog) = size(V)
  # gridV = dpVal.grid
  @assert(nCS == length(gridV))
  transExog = model._transExog(pars,aggr,t)
  @assert(nExog*nDS == size(transExog,1))

  Vcontz = condExpectExog(V,transExog');
  Qend = condExpectExog(Q,transExog');
  nDC = model._nDC(pars)


  global dpPol = dynProgPol(T,gridPol,nDS,nExog) # use same grid as for value function


  pT = model.TempParam{Float64}()
  for j=1:nExog # for each value of exogenous state
    optimAtExog!(dpPol,pars,aggr,
                 model._disc, model._util, model._prep!, model._range, pT,
                 j,gridPol,nDC, Vcontz[:,:,j],Qend[:,:,j],gridV,50, _linsol,t)
  end
  # find switch points:
  dpPol.switches = Array{Switch{Float64}}(undef,0)
  for j=1:nExog # for each value of exogenous state
    for k=1:nDS # for each value of endogenous discrete state
      disc = model._disc(pars,aggr,k,j,t) # discount factor depends only on discrete states
      VcontzJ = disc*Vcontz[:,:,j]
      QendJ = disc*Qend[:,:,j]
      for i=1:length(gridPol)-1 # for each value of endogenous state
        DC0 = dpPol.DC[i,k,j]
        DC1 = dpPol.DC[i+1,k,j]
        if DC0!=DC1
          switchZero(x) = 
          optimAtPoint(pars,aggr,
                       x,k,DC0, j,1,length(gridV)-1, # search over all points; inefficient!!
                       model._disc, model._util, model._prep!, model._range, pT,
                       VcontzJ,QendJ, gridV, _linsol, t)[1] -
          optimAtPoint(pars,aggr,
                       x,k,DC1, j,1,length(gridV)-1,
                       model._disc, model._util, model._prep!, model._range, pT,
                       VcontzJ,QendJ, gridV, _linsol,t)[1];

          (xSwitch,flag) = bisect(switchZero,gridPol[i],gridPol[i+1],1e-8)
          if flag!=0
            @warn("problem bisect at grid point $i $k $j between choices $DC0 $DC1")
            @show flag
            # xSwitch = mean(gridPol[i:i+1])
            println("xSwitch: $xSwitch")
            xx = linspace(gridPol[i],gridPol[i+1],200);
            yy = map(switchZero,xx);
            saveT("xyswitch.bmt",xx,yy)
            @assert(flag==0)
          end
          epsx = 1e-6
          (v0,cc0,bind0,i0_,p0_) = optimAtPoint(pars,aggr,
                                xSwitch-epsx,k,DC0, j,1,length(gridV)-1,
                                model._disc, model._util, model._prep!, model._range, pT,
                                VcontzJ,QendJ, gridV,_linsol, t);
          (i0,p0) = posInGrid(gridPol,cc0) #use that cc = xEnd; i0_ is in terms of gridV!!
          (v1,cc1,bind1,i1_,p1_) = optimAtPoint(pars,aggr,
                                xSwitch+epsx,k,DC1, j,1,length(gridV)-1,
                                model._disc, model._util, model._prep!, model._range, pT,
                                VcontzJ,QendJ, gridV,_linsol, t);
          (i1,p1) = posInGrid(gridPol,cc1) #use that cc = xEnd; 
          # myWarn(abs(v1-v0)<1e-4,"v1:",v1,"v0:",v0)
          fracLeft = (xSwitch-gridPol[i]) / (gridPol[i+1]-gridPol[i]);
          push!(dpPol.switches,Switch{Float64}((i,k,j),
                                               i0,i1,bind0,bind1,cc0,cc1,p0,p1,fracLeft))
        end
      end
    end
  end
  return dpPol
end

# p = x/step
# dv/dx = dv/dp/step
# d2v/dx2 = d2v/dp2/step^2
function valueAndPos(utilFunc::Function,pars,aggr,pT,gridV::Array{Float64,1},xCS,iDS,iZ,xCC,iDC,Vcontz,Qend::Array{Float64,2},t)
  ut = utilFunc(pars,aggr,pT,xCS,iDS,iZ,xCC,iDC,t)
  xCE = xCC;
  # iLo = pT.iLo
  iLo = 1;
  (i,p) = posInGrid(gridV,xCE,iLo)
  # pT.iLo = i; # iLo
  iDE = pT.iDE
  v = ut + (1-p)*Vcontz[i,iDE] + p*Vcontz[i+1,iDE] + p*(p-1)*Qend[i,iDE]
  return (v,i,p);
end

# differentiate the policy function:
function evalPol!(model,pars, aggr, 
                  gridV,Vcontz,Qend,
                  dpPol::DynProgPol{T},
                  dpPolStSt,t) where T
  (nCSval,nDS,nExog) = size(Vcontz)
  @assert(nCSval == length(gridV))
  pT = model.TempParam{T}()
  pTss = model.TempParam{Float64}()

  V = similar(Vcontz);
  
  gridPol = dpPol.grid
  for iZ=1:nExog # for each value of exogenous state
    diffAtExog!(model,dpPol,dpPolStSt,
                pars,aggr,iZ,Vcontz[:,:,iZ],Qend[:,:,iZ],gridV, t)
  end
  # find switch points:
  switchSS = dpPolStSt.switches
  dpPol.switches = Array{Switch{Float64}}(undef,0)
  iSw = 0
  global _nFL;
  posX::Int = _nFL+1;
  posC::Int = _nFL+2;
  for iZ=1:nExog # for each value of exogenous state
    for iDS=1:nDS # for each value of discrete state
      disc = model._disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
      VcontzJ = disc*Vcontz[:,:,iZ]; # initialize
      QendJ = disc*Qend[:,:,iZ]; # initialize
      function valueAt2(xCS,cc,dc,pT) 
        model._prep!(pars,aggr,pT,xCS,iDS,iZ,dc,t) 
        return valueAndPos(model._util,pars,aggr,pT,gridV,xCS,iDS,iZ,cc,dc,VcontzJ,QendJ,t)
      end
      valueAt(xCS,cc,dc,pT)  = valueAt2(xCS,cc,dc,pT)[1];
      for i=1:length(gridPol)-1 # for each value of endogenous state
        DC0 = dpPol.DC[i,iDS,iZ]
        DC1 = dpPol.DC[i+1,iDS,iZ]
        if DC0!=DC1 # interval contains switch point
          iSw += 1
          sSS = switchSS[iSw]
          @assert( (i,iDS,iZ) == sSS.iState )

          xSwitch = gridPol[i] + sSS.fracLeft*(gridPol[i+1]-gridPol[i]);
          dxSwitch = indep(Deriv2s,xSwitch,posX); 

          # end point of left interval
          model._prep!(pars,aggr,pT,dxSwitch,iDS,iZ,DC0,t) 
          (isDiscrete,ccRange) =model._range(pars,aggr,pT,dxSwitch,iDS,iZ,DC0,t)
          b = sSS.bLeft
          if isDiscrete==2 && b==0 # unconstrained
            ccLeft = dpPol.CC[i,iDS,iZ]  # just initialize
            ccLeft.v = sSS.ccLeft;
            ccLeft.d .= 0.0; # derivative does not matter because of envelope condition
          else
            ccLeft = ccRange[b]
          end
          (ObjLeft,iLeft,pLeft) = valueAt2(dxSwitch,ccLeft,DC0,pT)
          dObjLeft = getjac(ObjLeft)

          # end point of right interval:
          model._prep!(pars,aggr,pT,dxSwitch,iDS,iZ,DC1,t) 
          (isDiscrete,ccRange) = model._range(pars,aggr,pT,dxSwitch,iDS,iZ,DC1,t)
          b = sSS.bRight
          if isDiscrete==2 && b==0 # unconstrained
            ccRight = dpPol.CC[i+1,iDS,iZ] 
            ccRight.v = sSS.ccRight;
            ccRight.d .= 0.0; # derivative does not matter because of envelope condition
          else
            ccRight = ccRange[b]
          end
          (ObjRight,iRight,pRight) = valueAt2(dxSwitch,ccRight,DC1,pT)
          dObjRight = getjac(ObjRight)
          vLeft  = getval(ObjLeft)
          vRight  = getval(ObjRight)
          if abs(vRight-vLeft)>1e-6
            hswarn("values at switch point not exactly equal",vLeft,"!=",vRight)
          end

          ddObj = dObjRight-dObjLeft;
          if ddObj[posX]==0
            @show (i,iDS,iZ)
            @show (dObjLeft[posX],iLeft) # ,pLeft)
            @show norm(getjac(pLeft))
            @show (dObjRight[posX],iRight) # ,pRight)
            @show norm(getjac(pRight))
            @show getjac(ccRight)[posX]
            @show getjac(ccLeft)[posX]
            @warn("cannot differentiate switch point; set derivative to 1000; assumes no mass at this point")
            # error("cannot differentiate switch point; set derivative to zero")
            dFracLeft = -ddObj / 1e6 / ( gridPol[i+1]- gridPol[i] );
          else
            dFracLeft = -ddObj / ddObj[posX] / ( gridPol[i+1]- gridPol[i] );
          end

          push!(dpPol.switches,Switch{T}((i,iDS,iZ),
                                         sSS.iLeft,sSS.iRight,
                                         sSS.bLeft,sSS.bRight,
                                         ccLeft,ccRight,pLeft,pRight,
                                         T(sSS.fracLeft,dFracLeft)))
        end
      end
    end
  end
  return V
end


function evalVal(model,pars, aggr, gridV,Vcontz::Array{T,3},Qend, dpPolStSt,t) where T
  # V = fillzero(eltype(Vcont),(nCS,nDS,nExog))
  V = similar(Vcontz);
  for j=1:size(V,3) # for each value of exogenous state
    V[:,:,j] = diffVAtExog!(model,dpPolStSt,
                            pars,aggr,j,Vcontz[:,:,j],Qend[:,:,j],gridV, t)
  end
  return V
end



function forward(Dbeg0,TransEndogPrime,transExog)
  nExog = length(TransEndogPrime)
  nEndog = div(length(Dbeg0),nExog)
  Dbeg = reshape(Dbeg0,nEndog,nExog);
  Dmed = zeros(nEndog,nExog);
  for j=1:nExog
    Dmed[:,j] = TransEndogPrime[j]*Dbeg[:,j];
  end

  # Second step: exogenous change of productivity:
  #  notice that new entries are also subject to prod. change
  Dend = Dmed*transExog;
  # make column vector
  Dend = Dend[:];
  if abs(sum(Dend)-1)>1e-10
    saveT("dd.bmt",full(Dbeg0),full(Dend))
    println("error in forward")
    stop()
  end
  return Dend 
end


function localMaxima(v)
  lM = Array{Float64}(0)
  n = length(v)
  if v[1]>=v[2]
    push!(lM,v[1])
  end
  for i=2:n-1
    if v[i]>=v[i-1] && v[i]>=v[i+1]
      push!(lM,v[i])
    end
  end
  if v[n]>=v[n-1]
    push!(lM,v[n])
  end
  return lM
end

include("isrch.jl")

function optimAtExog!(dpPol::DynProgPol{Float64},pars,aggr,
                      _disc::Function,
                      _util::Function,
                      _prep!::Function,
                      _range::Function,
                      pT,
                      iZ::Int,
                      gridCS::Array{Float64,1},
                      nDC::Int,
                      VcontzUndisconted::Array{Float64,2},
                      QendUndisconted,
                      gridV,
                      widthStep,
                      _linsol::LinsolParams,
                      t) 
  nCS = length(gridCS)
  nxD = size(VcontzUndisconted,2)
  V = fillzero(Float64,(nCS,nxD))
  nV = length(gridV)

  tolVmax = 10.;
  vOptJ = fill(-1e100,(nDC,))
  pOptJ = fillzero(Float64,(nDC,)) # optimial continuous choice
  iOptJ = fill(-1,(nDC,))   # discrete state end of period
  eOptJ = fill(-1,(nDC,))   # discrete state end of period
  bOptJ = fill(-1,(nDC,))   # bounds binding
  for iDS=1:nxD
    disc = _disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
    VcontzJ = disc*VcontzUndisconted # end of period, after discounting
    QendJ = disc*QendUndisconted # end of period, after discounting
    VcontzJval = getval(VcontzJ)
    iStartSearch = fill(1,(nDC))
    for iEndog=1:nCS
      # if iEndog>1; error("done"); end
      xCS::Float64 = gridCS[iEndog];
      local iDE::Int
      for iDC = 1:nDC
        widthSearch = 16
        if iEndog==1 || _linsol.robustOptim < 0 # first try
          iLo = 1
          iHi = length(gridV)-1;
        else
          iMid::Int = iStartSearch[iDC]
          iLo = iMid-widthSearch+1
          iHi = iMid+widthSearch
        end
        @assert(iLo<=iHi)
        (vOptJ[iDC],cBest,bOptJ[iDC],iOptJ[iDC],pOptJ[iDC],eOptJ[iDC]) = 
        optimAtPoint(pars,aggr,
                     xCS,iDS,iDC, iZ,iLo,iHi,
                     _disc,
                     _util,
                     _prep!,
                     _range,
                     pT,
                     VcontzJ,QendJ,
                     gridV,
                     _linsol,
                     t) 
        iStartSearch[iDC] = iOptJ[iDC]
      end
      iaBest = argmax(vOptJ)
      _prep!(pars,aggr,pT,xCS,iDS,iZ,iaBest,t) 
      V[iEndog,iDS] = vOptJ[iaBest] 
      if !(V[iEndog,iDS]>-1e99)
        @show (iEndog,vOptJ)
        @show aggr
        error("seems infeasible")
      end
      dpPol.B[iEndog,iDS,iZ] = bOptJ[iaBest] 
      p = pOptJ[iaBest];
      iI = iOptJ[iaBest];
      xCC = (1-p)*gridV[iI] + p*gridV[iI+1];
      dpPol.CC[iEndog,iDS,iZ] = xCC 
      dpPol.DC[iEndog,iDS,iZ] = iaBest # optimal discrete choice
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t); error("done")
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,indep(Deriv21,xCC),iaBest,t); error("done")
      ut = _util(pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t);
      xCE = xCC;
      #(dpPol.I[iEndog,iDS,iZ],dpPol.P[iEndog,iDS,iZ]) = posInGrid(gridCS,xCE)
      #dpPol.U[iEndog,iDS,iZ] = ut;
      dpPol.DE[iEndog,iDS,iZ] = eOptJ[iaBest];
    end
  end
  return V;
end



# gives derivative of value function, using envelope condition at interior point of solution:
function envelope(model,_p,aggr,pT,kBeg0,iSD,iExog,xCC0,iDC,t)
  kBeg = indep(Deriv1F{2},kBeg0,1)
  xCC = indep(Deriv1F{2},xCC0,2)
  cf = model._util(_p,aggr,pT,kBeg,iSD,iExog,xCC,iDC,t)
  xCE = xCC
  dcdx = - xCE.d[1]/xCE.d[2]; # change of continuous choice to keep xCE unchanged
  Vprime = cf.d[1] + cf.d[2]*dcdx;
  return Vprime;
end
function setDeriv!(model,pars,aggr,dpVal,dpPol,horizon::Int) # in steady state
  nMovAve = 5
  (n1,n2,n3) = size(dpVal.V)
  grid = dpVal.grid
  dgrid = diff(grid)
  @assert(length(grid)==n1)
  for k=1:n3
    for j=1:n2
      der1 = diff(dpVal.V[:,j,k]) ./ dgrid
      push!(der1,der1[end])
      for i=1:n1-1
        deltax = grid[i+1]-grid[i]
        dv1 = der1[i]
        # second derivative d2v/dx2:
        der2 = (der1[i+1]-dv1) / deltax
        # approximation, using p = x/deltax (p is probHi)
        # v = v0*(1-p) + v1*p + Q*p*(p-1)
        # then
        # dv/dx = ... + 2*Q*p/deltax
        # d2v/dx2 = 2*Q/deltax/deltax
        # therefore
        dpVal.Q[i,j,k] = der2*deltax^2/2
      end
      dpVal.Q[:,j,k] = movingAve2(dpVal.Q[:,j,k],20)
    end
  end
end
function setDerivC!(model,pars,aggr,dpVal,dpPol,horizon::Int) # in steady state
  horizon = 1
  (nCS,nDS,nExog) = size(dpVal.V)
  gridCS = dpVal.grid;
  transExogPrime = model._transExog(pars,aggr,StStIndex(0))'
  global deriv1 = fill(zero(Float64),(nCS,nDS,nExog))
  pT = model.TempParam{Deriv1F{2}}()
  derivcontrol = similar(deriv1)
  for iter = horizon:-1:1
    t = StStIndex(0)
    deriv1_ = reshape(deriv1,nCS,nDS*nExog)*TransExogPrime; 
    deriv1end = reshape(deriv1_,nCS,nDS,nExog)
    for iZ=1:nExog # for each value of exogenous state
      for iDS=1:nDS # for each value of endogenous dscrete state
        disc = model._disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
        for iCS=1:nCS # for each value of endogenous continuous state
          xCS = gridCS[iCS];
          dCS = indep(Deriv1F{2},xCS,1)
          iDC = dpPol.DC[iCS,iDS,iZ]
          model._prep!(pars,aggr,pT,dCS,iDS,iZ,iDC,t) 
          if iter<horizon && iCS>1 && iDC!=dpPol.DC[iCS-1,iDS,iZ]
            continue
          end
          if iter<horizon && iCS<nCS && iDC!=dpPol.DC[iCS+1,iDS,iZ]
            if iCS>1
              deriv1[iCS,iDS,iZ] = deriv1[iCS-1,iDS,iZ]
            end
            if iCS<nCS-1
              deriv1[iCS+1,iDS,iZ] = deriv1[iCS+2,iDS,iZ]
            end
            continue
          end
          pT.iDE = dpPol.DE[iCS,iDS,iZ]
          (isDiscrete,ccRange) =model._range(pars,aggr,pT,dCS,iDS,iZ,iDC,t)
          if isDiscrete ==0
            cChoice = ccRange[1]
          elseif isDiscrete == 1
            cChoice = ccRange[iDC]
          else # interval
            b = dpPol.B[iCS,iDS,iZ]
            if b>0 # bounds binding
              cChoice = ccRange[b]
            else
              cc = dpPol.CC[iCS,iDS,iZ]
              deriv1[iCS,iDS,iZ] = envelope(model,pars,aggr,pT,xCS,iDS,iZ,cc,iDC,t);
              continue
            end
          end
          if iter==horizon
            if iCS==1
              deriv1[iCS,iDS,iZ] = (dpVal.V[2,iDS,iZ]-dpVal.V[2,iDS,iZ])/ (gridCS[2]-gridCS[1])
            elseif iCS==nCS
              deriv1[iCS,iDS,iZ] = (dpVal.V[nCS,iDS,iZ]-dpVal.V[nCS-1,iDS,iZ])/ 
              (gridCS[nCS]-gridCS[nCS-1])
            else
              deriv1[iCS,iDS,iZ] = (dpVal.V[iCS+1,iDS,iZ]-dpVal.V[iCS-1,iDS,iZ])/ 
              (gridCS[iCS+1]-gridCS[iCS-1])
            end
          else
            ut = model._util(pars,aggr,pT,dCS,iDS,iZ,cChoice,iDC,t);
            xCE = cChoice;
            i = dpPol.I[iCS,iDS,iZ]
            p = dpPol.P[iCS,iDS,iZ]
            # interpolate linearly the future derivative:
            iDE = dpPol.DE[iCS,iDS,iZ]
            derEnd = disc*((1-p)*deriv1end[i,iDE,iZ] + p*deriv1end[i+1,iDE,iZ])
            deriv1[iCS,iDS,iZ] = ut.d[1] + xCE.d[1]*derEnd;
          end
        end
      end
    end
    if iter<horizon
      dist = maximum(abs,deriv1-derivcontrol)
      # println("distance in setDeriv! at iter $iter = $dist")
      if dist<1e-10
        break;
      end
      derivcontrol = copy(deriv1)
    end
  end
  saveT("deriv1.bmt",deriv1,dpVal.grid,dpVal.V); error("done")
  setQ!(dpVal.Q,deriv1,dpVal.grid)
end

function setQ!(Q,der1::Array{Float64,3},grid::Array{Float64,1})
  (n1,n2,n3) = size(der1)
  @assert(length(grid)==n1)
  for k=1:n3
    for j=1:n2
      for i=1:n1-1
        deltax = grid[i+1]-grid[i]
        dv1 = der1[i,j,k]
        # second derivative d2v/dx2:
        der2 = (der1[i+1,j,k]-dv1) / deltax
        # approximation, using p = x/deltax (p is probHi)
        # v = v0*(1-p) + v1*p + Q*p*(p-1)
        # then
        # dv/dx = ... + 2*Q*p/deltax
        # d2v/dx2 = 2*Q/deltax/deltax
        # therefore
        Q[i,j,k] = der2*deltax^2/2
      end
    end
  end
  # println("maxd orig: ",maximum(abs,der1))
  # println("maxq orig: ",maximum(abs,Q))
end
function intQuad(V::Array{Float64,1},Q::Array{Float64,1},grid::Array{Float64,1},x)
  (i,p) = posInGrid(grid,getval(x))
  v0 = V[i]
  v1 = V[i+1]
  return v0*(1-p) + v1*p + Q[i]*p*(p-1)
end

function diffAtExog!(model,
                         dpPolFluct::DynProgPol{T},
                         dpPolstst::DynProgPol{Float64},
                         pars,aggr,
                         iZ::Int,
                         VcontzUndisconted::Array{T,2},
                         QendUndisconted::Array{Float64,2},
                         gridV,
                         t) where T
  gridCS = dpPolstst.grid;
  pT = model.TempParam{T}()
  nCS = length(gridCS)
  nxD = size(VcontzUndisconted,2)
  global _nFL;
  posC::Int = _nFL+1;
  for iDS=1:nxD
    disc = model._disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
    VcontzJ = disc*VcontzUndisconted # end of period, after discounting
    QendJ = disc*QendUndisconted # end of period, after discounting
    for iCS=1:nCS
      # if iCS>1; error("done"); end
      xCS::Float64 = gridCS[iCS];
      iDC = dpPolstst.DC[iCS,iDS,iZ]
      model._prep!(pars,aggr,pT,xCS,iDS,iZ,iDC,t) 
      iDE = pT.iDE
      valueAtCCd(cc) = valueAndPos(model._util,pars,aggr,pT,gridV,xCS,iDS,iZ,cc,iDC,VcontzJ,QendJ,t)[1]
      valueAtCCdzero(cc) = valueAndPos(model._util,pars,aggr,pT,gridV,xCS,iDS,iZ,cc,iDC,VcontzJ,0.0*QendJ,t)[1]
      xCC = dpPolstst.CC[iCS,iDS,iZ];
      if dpPolstst.B[iCS,iDS,iZ]==0  # improve interior solution
        if T==Deriv4hs
          _DoSecondSparse[1] = true
          cTry2 = indep(Deriv4hs,xCC,posC)
          vTry2 = valueAtCCd(cTry2);
          dd = getjac(vTry2);
          hh = gethesCol(vTry2,posC);
          d2vdc2 = hh[posC]
          cCorrect = 0; # -dd[posC] / d2vdc2; avoid the correction here
          if abs(cCorrect)>1e-5
            println("first deriv at ",(iCS,iDS,iZ)," = ",dd[posC])
          end
          if(getval(d2vdc2)==0)
            error(@sprintf("zero second derivative at i=%d,j=%d,k=%d",iCS,iDS,iZ))
          end
          dCCdOmega = -hh/d2vdc2
          if false  # use for checking only
            vTry3 = valueAtCCdzero(cTry2);
            dd = getjac(vTry3);
            hh = gethesCol(vTry3,posC);
            d2vdc3 = hh[posC]
            dCCdOmega = -hh/d2vdc3
          end

          _DoSecondSparse[1] = false
          dCCdOmega[posC] = 0;
          dpPolFluct.CC[iCS,iDS,iZ] = Deriv4hs(xCC+cCorrect,dCCdOmega)
        else
          (isDiscrete,ccRange) =model._range(pars,aggr,pT,xCS,iDS,iZ,iDC,t)
          if  xCC>ccRange[1]+1e-6 && xCC<ccRange[2]-1e-6 # ensure interior
            clow = xCC-1e-6
            cupp = xCC+1e-6
            dpPolFluct.CC[iCS,iDS,iZ] = 
            maxQuadSafe(clow,cupp,valueAtCCd(clow),valueAtCCd(xCC),valueAtCCd(cupp))
          else
            dpPolFluct.CC[iCS,iDS,iZ] = xCC # sets zero deriative if xCC too close to boundary
          end
        end
      else
        dpPolFluct.CC[iCS,iDS,iZ] = xCC 
      end
      #ut = model._util(pars,aggr,pT,xCS,iDS,iZ,dpPolFluct.CC[iCS,iDS,iZ],iDC,t)
      # xCE = dpPolFluct.CC[iCS,iDS,iZ]
      # dpPolFluct.U[iCS,iDS,iZ] = ut;
      # (ii,dpPolFluct.P[iCS,iDS,iZ]) = posInGrid(gridCS,xCE)
    end
  end
end

function diffVAtExog!(model,
                      dpPol::DynProgPol{Float64}, # only StSt information needed
                      pars,aggr,
                      iZ::Int,
                      VcontzUndisconted::Array{T,2},
                      QendUndisconted::Array{Float64,2},
                      gridV,
                      t) where T
  gridCS = dpPol.grid;
  pT = model.TempParam{T}()
  nCS = length(gridCS)
  nxD = size(VcontzUndisconted,2)
  V = similar(VcontzUndisconted)
  for iDS=1:nxD
    disc = model._disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
    VcontzJ = disc*VcontzUndisconted # end of period, after discounting
    QendJ = disc*QendUndisconted # end of period, after discounting
    for iCS=1:nCS
      xCS::Float64 = gridCS[iCS];
      iDC = dpPol.DC[iCS,iDS,iZ]
      model._prep!(pars,aggr,pT,xCS,iDS,iZ,iDC,t) 
      iDE = pT.iDE
      valueAtCCd(cc) = valueAndPos(model._util,pars,aggr,pT,gridV,xCS,iDS,iZ,cc,iDC,VcontzJ,QendJ,t)[1]
      xCCstst = dpPol.CC[iCS,iDS,iZ];
      iB = dpPol.B[iCS,iDS,iZ]
      if iB==0  # at interior solution, use envelope theorem, keep xCC fixed
        V[iCS,iDS] = valueAtCCd(xCCstst)
      else # constrained solution, compute gradient of xCC:
        (isDiscrete,ccRange) =model._range(pars,aggr,pT,xCS,iDS,iZ,iDC,t)
        xCCd = ccRange[iB]
        V[iCS,iDS] = valueAtCCd(xCCd)
      end
    end
  end
  return V;
end




include("setder.jl")
function residDP(model,pars,vars,
                 V,D,
                 dpValStSt::DynProgVal{Float64}, # steady state value function
                 dpPol::DynProgPol2{Deriv4hs},  # policy at distribution grid
                 dpPolVStSt::DynProgPol{Float64}, # policy at value grid
                 t) 
  stst = StStIndex(0)
  T=eltype(V[t])
  global dpValCont = dynProgVal(dpValStSt.grid,V[t+1],dpValStSt.Q);

  TEprime = Array(model._transExog(pars,vars,t)');
  Vcontz = condExpectExog(dpValCont.V,TEprime);
  Qend = condExpectExog(_QcontAGlob,getval(TEprime));
  # computing derivative of V does not need derivative of Pol:
  vt = evalVal(model,pars, vars, dpValCont.grid,Vcontz,Qend,dpPolVStSt,t) 
  resid1 = V[t] - vt;
  @show maximum(abs,getval(resid1))
  global resglob = resid1;
  global Vglob = V[t];
  global Vglob2 = vt;
  if T==Float64
    @assert(isa(t,StStIndex))
  else
    @assert(isa(t,TimeIndex))
    evalPol!(model,pars, vars, dpValCont.grid,Vcontz,Qend, dpPol[t],dpPol[stst],t) 
  end
  Dend = transMat(model,dpPol[t],pars,vars,t,D[t-1]);
  resid2 = D[t]-Dend
  return (resid2[:],resid1[:])
end
#=
global hhprob_polv = dpNonConvex1d!(hhprob,_pars, _vars,hhprob_val, nAccel, stst)
1) dpNonConvex1! (calls dpoptimAtExog!) : does optimization without the quadratic approximation at the end; does not compute switches (not necessary on value grid); sets Q
2)evalPol: call  (also calls dpoptimAtExog!); computes switches afterwards, applied at
distribution grid

3)evalPol!: call  (calls diffAtExog!!); differentiates both policy functions and switches


=#

function distribAtSwitch(pol,D,width)
  n = length(pol.switches)
  ds = zeros(2*width+1,n)
  tt = -width:width
  for iS=1:n
    sw = pol.switches[iS]
    (i,j,k) = sw.iState
    if i>width
      d = D[i-width:i+width,j,k];
    else
      mis = width-i+1
      d = vcat(zeros(mis),D[1:i+width,j,k]);
    end
    dscaled = d / sum(D[:,j,k]);
    if iS==1
      plot(tt,dscaled)
    else
      plot!(tt,dscaled)
    end
    ds[:,iS] = d
  end
  return ds;
end
# function distribAtSwitch(mod::LinModel,dpName,width)
#   pol2 = Core.eval(Symbol(dpName,"_pol"));
#   pol = pol2.stst;
#   D = mod.varNames(Symbol(dpName,""))
# end
function printSwitch(pol,model,F)
  p = pol.fluct;
  grid = p.grid
  n = length(p.switches)
  # iVar = model.varNames[var][1]
  nV = nVar(model)
  X = zeros(length(p.switches[1].fracLeft.d))
  X[2*nV + model.varNames[:firmprob_v]] = F[:,1]
  for i=1:n
    Sw = p.switches[i]
    (i,k,j) = Sw.iState 
    x = Sw.fracLeft*grid[i+1] + (1-Sw.fracLeft)*grid[i];
    println([x.v;dot(x.d,X);k;j])
  end
end
include("dp2.jl")
include("dp3.jl")
include("dpex.jl")

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import Base.+
import Base.-
import Base.*
import Base./
import Base.^
import Base.==
import Base.!=
import Base.>
import Base.>=
import Base.<
import Base.<=
import Base.min
import Base.max
import Base.convert;
import Base.zero;

import Base.exp
import Base.sqrt
import Base.log
import Base.abs
import SpecialFunctions.erf
import Base.sin
import Base.cos
import Base.tan

  @defD2FFunc1(-,-1,0)
  @defD2FFunc1(log,1/x,-1/x^2)
  @defD2FFunc1(exp,exp(x),exp(x))
  @defD2FFunc1(sqrt,1/(2*sqrt(x)),-1/(4*x^(3/2)))
  @defD2FFunc1(erf,2*exp(-x^2)/sqrt(pi),-4*x*exp(-x^2)/sqrt(pi))
  @defD2FFunc1(sin,cos(x),-sin(x))
  @defD2FFunc1(cos,-sin(x),-cos(x))
  @defD2FFunc1(tan,tan(x)^2 + 1,(2*tan(x)^2 + 2)*tan(x))
  @defD2FFunc1(abs,x>=0.0 ? 1.0 : -1.0,0.0);

@eval begin
  @defD2FFunc2(+,1,1,0,0,0)
  @defD2FFunc2(-,1,-1,0,0,0)
  @defD2FFunc2(*,y,x,0,0,1)
  @defD2FFunc2(/,1/y,-x/y^2,0,2*x/y^3,-1/y^2)
  @defD2FFunc2(^,x^(y - 1)*y,x^y*log(x),x^(y - 2)*y*(y - 1),x^y*log(x)^2,x^(y - 1)*(y*log(x) + 1))

  @defD2FFunc2(min,x<y ? 1.0 : 0.0,x<y ? 0.0 : 1.0,0.0,0.0,0.0);
  @defD2FFunc2(max,x>y ? 1.0 : 0.0,x>y ? 0.0 : 1.0,0.0,0.0,0.0);

  @defD2FBool(==);
  @defD2FBool(!=);
  @defD2FBool(>);
  @defD2FBool(>=);
  @defD2FBool(<);
  @defD2FBool(<=);
end

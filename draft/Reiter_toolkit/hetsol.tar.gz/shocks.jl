# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include("markovappr.jl")
abstract type SingleShock end
type DiscreteIID <: SingleShock
  X::Array{Float64,1};
  p::Array{Float64,1};
  pCumul::Array{Float64,1};
end
DiscreteIID(X,p) = DiscreteIID(X,p,cumsum(p))
import Base.*
function *(x::Float64,s::DiscreteIID) 
  return DiscreteIID(s.X*x,s.p,s.pCumul)
end
function iRealiz(xp::DiscreteIID,shock::Float64) 
  return bisectLE(xp.pCumul,shock)
end
function xRealiz(xp::DiscreteIID,shock::Float64) 
  j = iRealiz(xp,shock)
  return xp.X[j];
end
function xRealiz(xp::DiscreteIID,j::Int) 
  return xp.X[j];
end
function realiz(s::DiscreteIID,j::Int)
  @inbounds x::Float64 = s.X[j]
  @inbounds p::Float64 = s.p[j]
  return (x,p)
end

function initState!(s::DiscreteIID,x::Float64)
  error("DiscriteShock cannot be initialized; use MarkovChain instead")
end
function numbRealiz(s::DiscreteIID)
  return length(s.X) # can be made more efficient
end
function epsNext(s::DiscreteIID,j::Int)
  return s.X[j];
end
function pNext(s::DiscreteIID,j::Int)
  return s.p[j];
end
function xNext(s::DiscreteIID,j::Real)
  error("no transition function xNext for DiscreteIID")
  return NaN;
end
import Base.mean
mean(s::DiscreteIID) = dot(s.X,s.p);
import Base.var
function var(s::DiscreteIID)
  m = mean(s);
  return dot((s.X-m).^2,s.p);
end
stdev(s::DiscreteIID) = sqrt(var(s))
function StatsBase.skewness(x::DiscreteIID)
  m = mean(x);
  s = stdev(x)
  return dot((x.X-m).^3,x.p) / s^3;
end
function StatsBase.kurtosis(x::DiscreteIID)
  m = mean(x);
  s = stdev(x)
  # excess kurtosis
  return dot((x.X-m).^4,x.p) / s^4 -3; 
end


mutable struct MarkovChain <: SingleShock
  X::Array{Float64,1}
  Pi::Array{Float64,2}
  PiSum::Array{Float64,2}
  i::Int # current state
end
function var(s::MarkovChain)
  p = InvDistrib(s.Pi)
  m = dot(p,s.X)
  return dot((s.X .- m).^2,p);
end
stdev(s::MarkovChain) = sqrt(var(s))
function condvar(s::MarkovChain)
  n = size(s.Pi,1)
  cv = zeros(n)
  for i=1:n
    m = dot(s.Pi[i,:],s.X)
    cv[i] = dot(s.Pi[i,:],(s.X .- m).^2)
  end
  return cv;
end
condvar(X::Array{Float64,1}, Pi::Array{Float64,2}) = condvar(MarkovChain(X,Pi))
Base.getindex(s::MarkovChain,i::Int) = s.X[i]

function Base.show(io::IO, x::MarkovChain)
  println("Markov chain, number of states = ",length(x.X))
  println(x.X)
end

function MarkovChain( X0::AbstractArray{Float64,1},Pi::Array{Float64,2})
  X = convert(Array{Float64,1},X0)
  n = length(X)
  @assert(size(Pi)==(n,n))
  PiS = similar(Pi)
  for i=1:n # notice that PiS is transposed, for efficiency
    PiS[:,i] = cumsum(Pi[i,:])
  end
  @assert(all(abs.(1 .- PiS[end,:]).<1e-12))
  PiS[end,] = 1.0;
  return MarkovChain(X,Pi,PiS,0)
end
function MarkovChain(method::String, rho::Float64,  sigma_z::Float64, n::Int, width::Float64=2.5)
  threshold = 1e-14
  if method=="Tauchen" || method=="tauchen"
    (Pi,X,probst) = markovappr(rho,sigma_z,width,n,threshold)
  elseif method=="rouwen" || method=="Rouwen" || method=="rouwenhorst" || method=="Rouwenhorst"
    (Pi,X)= rouwen(rho,  sigma_z, n, threshold)
  else
    error("wrong method for MarkovChain")
  end
  return MarkovChain(X,Pi)
end
function *(x::Float64,s::MarkovChain) 
  return MarkovChain(s.X*x,s.Pi,s.PiSum,s.i)
end

function bisectExact(X,x)
  n = length(X)
  i0 = 0;
  i2 = n+1;
  while i2>i0+1
    i1 = div(i0+i2,2)
    if(x<X[i1])
      i2 = i1-1; # new upper boundk
    else
      i0 = i1 # new lower bound
    end
  end
  if x==X[i0]
    return i0
  else
    @assert(x==X[i2])
    return i2;
  end
end
# return smallest i  such that x<=X[i]
function bisectLE(X,x)
  n = length(X)
  i0 = 1; # if x < X[1], returns 1
  i2 = n+1; # if x>X[n], returns n+1 
  while i2>i0
    i1 = div(i0+i2,2)
    if(x<=X[i1])
      i2 = i1; # new upper boundk
    else
      i0 = i1+1 # new lower bound
    end
  end
  return i0;
end
function initState!(s::MarkovChain,x::Float64)
  s.i = bisectExact(s.X,x)
end
function initState!(s::MarkovChain,i::Int)
  s.i = i;
end
function numbRealiz(s::MarkovChain)
  return length(s.X) # can be made more efficient
end
function epsNext(s::MarkovChain,j::Int)
  return j;
end
function xNext(s::MarkovChain,j::Int)
  return s.X[j];
end
function pNext(s::MarkovChain,j::Int)
  return s.Pi[s.i,j];
end
function xNext(s::MarkovChain,i::Int,shockUnif::Float64)
  s.i = i;
  j = bisectLE(s.PiSum[:,i],shockUnif)
  return j;
end
function realiz(s::MarkovChain,j::Int)
  return (s.X[j],s.Pi[s.i,j]); # returns Float, but not used as input to xNext
end
function xNext(s::MarkovChain,i::Int)
  return s.X[i];
end
function xNext(s::MarkovChain,x::Float64,shockUnif::Float64)
  initState!(s,x);
  i = s.i
  j = bisectLE(s.PiSum[:,i],shockUnif)
  return s.X[j];
end
function simul(s::MarkovChain,i0::Int,shocksUnif::Array{Float64,1})
  n = length(shocksUnif)
  ser = Array{Int}(n+1)
  ser[1] = i0;
  for t=1:n
    ser[t+1] = xNext(s,ser[t],shocksUnif[t])
  end
  return ser;
end
function simul(s::MarkovChain,x0::Float64,shocksUnif::Array{Float64,1})
  initState!(s,x0);
  indx = simul(s,s.i,shocksUnif)
  return s.X[indx]
end


shockArray(args...) = convert(Array{SingleShock,1},vcat(args...))
function *{N}(fac::Float64,A::NTuple{N,SingleShock})
  return map(x->fac*x,A)
end
function numbRealiz{N}(A::NTuple{N,SingleShock})
  return prod(map(numbRealiz,A))
end
function iRealiz{N}(A::NTuple{N,SingleShock},u::Array{Float64,1})
  @assert(length(u)==N)
  ii = Array{Int}(N)
  iEps = iRealiz(A[N],u[N]) - 1
  ii[N] = iEps+1
  for i=N-1:-1:1
    iEps2 = iRealiz(A[i],u[i])
    ii[i] = iEps2
    iEps = iEps*numbRealiz(A[i]) + iEps2-1
  end
  return (iEps+1,ii)
end
function *(fac::Float64,A::Array{SingleShock,1})
  return shockArray(map(x->fac*x,A)...)
end


#=
Steps:
1) for each shock, get the epsilon-realization and its probability
  2) for each state, given the epsilon-realizations, get the new state

    A) For Markov chains, probabilities and number of possible realizations
    depend on current state
    needs an initialization of the shock structure
    B) For an AR process, step 1 is independent of current state;
    initialization does nothing
    =# 





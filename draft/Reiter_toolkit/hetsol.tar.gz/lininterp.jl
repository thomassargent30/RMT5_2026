# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function huntfast(xx::AbstractArray{T,1}, x::T, jlo) where T
  @assert(jlo>0,println("wrong jlo on input"))
  @assert(x>=xx[1],@show(x,xx[1]))
  @assert(x<=xx[end],println("x=",x," above upper bound ",xx[end]))
  n = length(xx);
  inc=1;
  if (x >= xx[jlo]) 
    if(x>=xx[n])
      return n-1;
    end
    jhi=jlo+1;
    while (x >= xx[jhi]) 
      jlo=jhi;
      inc += inc;
      jhi=jlo+inc;
      if (jhi > n-1) 
        jhi=n;
        break;
      end
    end
  else
    if (jlo == 0) 
      return jlo;
    end
    jhi=jlo
    jlo -= 1;
    while (x < xx[jlo]) 
      jhi=jlo;
      inc *=2;
      if (inc >= jhi) 
        jlo=1;
        break;
      else 
        jlo=jhi-inc;
      end
    end
  end
  while (jhi-jlo != 1) 
    jm=div(jhi+jlo,2);
    if (x >= xx[jm]) # in case of equality, set jlo to jm
      jlo=jm;
    else
      jhi=jm;
    end
  end
  return jlo;
end
function huntfast(xx::AbstractArray{T,1}, x::AbstractArray{T,1}, jlo) where T
  n = length(x)
  I = Array{Int}(n)
  for i=1:n
    jlo = huntfast(xx,x[i],jlo)
    I[i] = jlo;
  end
  return I;
end
function huntfast!(I::Array{Int,1},xx::AbstractArray{T,1}, x::AbstractArray{T,1}, jlo) where T
  n = length(x)
  for i=1:n
    jlo = huntfast(xx,x[i],jlo)
    I[i] = jlo;
  end
end

# function posInGrid(grid::AbstractArray{T,1},x::T,iLow=1) where T
#   iLow::Int = huntfast(grid,getval(x),iLow)
#   pUpp::T = (x-grid[iLow])./(grid[iLow+1]-grid[iLow]); 
#   return (iLow,pUpp)
# end
function posInGrid(grid,x,iLow=1) 
  iLow::Int = huntfast(grid,getval(x),iLow)
  pUpp = (x-grid[iLow])./(grid[iLow+1]-grid[iLow]); 
  return (iLow,pUpp)
end
function pos2X!(X,I::Union{Array{Int},Array{Int32}},P,grid) 
  for j=1:length(X)
    p = P[j];
    i = I[j];
    X[j] = (1-p)*grid[i] + p*grid[i+1]
  end
end
function posInGrid!(I::Array{Int},P,grid,X) 
  iLow::Int=1
  @inbounds for i=1:length(X)
    x = X[i];
    iLow = huntfast(grid,getval(x),iLow)
    pUpp = (x-grid[iLow])./(grid[iLow+1]-grid[iLow]); 
    I[i] = iLow;
    P[i] = pUpp;
  end
end
function posInGrid(grid,X::Array{T}) where T
  nn = size(X)
  I = Array{Int}(undef,nn)
  P = Array{T}(undef,nn)
  posInGrid!(I,P,grid,X);
  return (I,P);
end




const intp_assert = 0;  # assert than within bounds
const intp_extrapol = 1;  # extrapolate outside bounds
const intp_trunc = 2; # truncate at bound

mutable struct PosInGrid
  jLow::Int;
  weight0;
  weight1;
end
PosInGrid() = PosInGrid(0,0.,0.);
function set!(pos::PosInGrid,Grid::Array{Float64}, x, jl::Int)
  pos.jLow = jl;
  x1 = Grid[jl];  
  x2 = Grid[jl+1];
  pos.weight1 = (x-x1)/(x2-x1);
  pos.weight0 = 1.0-pos.weight1;
end


# to search for position, both Grid and x have to be of double-type:
function interp1!(pos::PosInGrid,Grid, x,  lowb=intp_assert, uppb=intp_assert)
  pos.jLow=0; # default: produce an error when pos is used
  n = length(Grid)
  if(x < Grid[1])
    if (lowb==intp_trunc)
      pos.jLow=1;
      pos.weight0 = 1;
      pos.weight1 = 0;
    elseif(lowb==intp_assert)
      return -1
    else  # extrapolate
      set!(pos,Grid,x,1);
    end
    return 0
  end
  if(x >= Grid[n])
    if(uppb==intp_trunc)
      pos.jLow=n-1;
      pos.weight0 = 0;
      pos.weight1 = 1;
    elseif(uppb==intp_assert)
      return -2
    else  # extrapolate
      set!(pos,Grid,x,n-1);
    end
    return 0;
  end 
  jLow = huntfast(Grid, getval(x), 1);
  set!(pos,Grid,x,jLow);
  return 0;
end

##  ##define Ty typename tArrY::value_type
##  template<class tArrY,class Ty>
function addTo1!(pos::PosInGrid,AY,jCol::Int,y)
  AY[pos.jLow,jCol] += pos.weight0*y;
  AY[pos.jLow+1,jCol] += pos.weight1*y;
end
##  template<class tArrY,class Ty>
function int1(pos::PosInGrid,AY)
  return Y[pos.jLow] * pos.weight0 + Y[pos.jLow+1] * pos.weight1;
end
function int1(pos::PosInGrid,AY,jCol::Int)
  return Y[pos.jLow,jCol] * pos.weight0 + Y[pos.jLow+1,jCol] * pos.weight1;
end
function int2(pos::PosInGrid,AY,jRow::Int)
  return Y[jRow,pos.jLow] * pos.weight0 + Y[jRow,pos.jLow+1] * pos.weight1;
end
##      template<class tArrY,class Ty>
##        Ty int1(const tArrY &AY, int jCol){ # jCol has zero-offset
##          size_t n = AY.n_rows;
##          const Ty *x = AY.begin() + jLow+n*jCol;
##          return x[0]*weight0 + x[1]*weight1;
##        }
##      template<class tArrY,class Ty>
##        Ty int2(const tArrY &AY, int jRow){
##          size_t n = AY.n_rows;
##          const Ty *x = AY.begin() + jRow + jLow*n;
##          return x[0]*weight0 + x[n]*weight1;
##        }
##  #undef Ty
##  
##  


#  template<class T1, class T2, class TFUNC>
function Markov_interpol!(
  Kendfunc::Function,
  DistStart,
  gridStart::Array{Float64},
  DistEnd, 
  gridEnd::Array{Float64})
  p = PosInGrid();
  fill(DistEnd,0.);
  for i=1:length(DistStart);
    Kend = Kendfunc(gridStart[i]);
    interp1!(p,
    gridEnd,
    Kend, # Kendfunc must be within gridEnd!!
    intp_assert,intp_assert
    );
    addTo1!(p,DistEnd,DistStart[i]);  # what to add
  end
  #printf("sum dist at end: %f\n",getval(sum(DistEnd)));
end

function extrapolate_cubic(X::Array{Float64},V::Array{Float64},x5::Float64)
  XX = [ones(4,1) X X.^2 X.^3];
  coef = XX\V;
  v5 = [1 x5 x5.^2 x5.^3]*coef;
  return v5;
end


##  template<class tArrY,class Ty>
function LinearInterp(V::Array{Float64},X::Array{Float64},grid::Array{Float64})
  VInt = Array{Float64}(size(X));
  iPos = Array{Int}(size(X));
  jlo = 1;
  for i=1:length(X)
    x = X[i];
    jlo = huntfast(grid, x, jlo);
    pHi = (x-grid[jlo])/(grid[jlo+1]-grid[jlo]);
    #assert(pHi>=0 && pHi<=1);
    VInt[i] = (1-pHi)*V[jlo] + pHi*V[jlo+1];
    iPos[i] = jlo;
  end
  return (VInt,iPos)
end
function LinearInterp(V::Array{Float64},ic::Int,x::Float64,jlo::Int,grid::Array{Float64})
  # give whole matrix and column index as arguments; much faster than V[:,ic] [MR,3.1.16]
  pHi = (x-grid[jlo])/(grid[jlo+1]-grid[jlo]);
  return (1-pHi)*V[jlo,ic] + pHi*V[jlo+1,ic];
end
function LinearInterp(V::Array{Float64},ic::Int,pos::PosInGrid)
  return pos.weight0*V[pos.jLow,ic] + pos.weight1*V[pos.jLow+1,ic];
end

if !@isdefined(LinIntParams)
  mutable struct LinIntParams
    jlo::Int
  end
  const _linIntParams = LinIntParams(1);
end

function LinearInterpGen(V,x,grid::Array{Float64})
  _linIntParams.jlo = huntfast(grid, getval(x),_linIntParams.jlo);
  jlo = _linIntParams.jlo
  pHi = (x-grid[jlo])/(grid[jlo+1]-grid[jlo]);
  assert(pHi>=0 && pHi<=1);
  return (1-pHi)*V[jlo] + pHi*V[jlo+1];
end
# X is endogenous variable that depends on exogenous Z, which is given by Markov transition TransZ
# returns tensor grid combining X and Z
# and joint transition matrix
function discrApproxLin1D(meanX,rho,dxdz,gridX,gridZ,TransZ)
  assert(meanX>gridX[1] && meanX<gridX[end])
  nZ = length(gridZ)
  nX = length(gridX)
  grid = tensprod(gridX,gridZ)
  n = nX*nZ
  Trans = zeros(n,n)
  for i=1:n
    (iX,iZ) = ind2sub((nX,nZ),i)
    x = gridX[iX]
    for iZ2=1:nZ # next period's Z
      z = gridZ[iZ2]
      xnext = meanX + rho*(x-meanX) + dxdz*z
      xnext = min(max(xnext,gridX[1]),gridX[end])
      (iLo,p) = posInGrid(gridX,xnext)
      j = s2i((nX,nZ),iLo,iZ2)
      Trans[i,j] = (1-p)*TransZ[iZ,iZ2];
      j = s2i((nX,nZ),iLo+1,iZ2)
      Trans[i,j] = p*TransZ[iZ,iZ2];
    end
  end
  return (grid,Trans)
end

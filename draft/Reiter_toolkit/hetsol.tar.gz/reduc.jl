# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


using SuiteSparse
using LinearAlgebra

include("gram.jl")
include("findexog.jl")

function singvals(A)
  (U,s,Vt) = svd(Array(A));
  return s;
end
function colspace(A,eps=1e-14)
  (U,s,Vt) = svd(Array(A));
  ii = findall(s.>s[1]*eps);
  return U[:,ii];
end
function rowspace(A,eps=1e-14)
  (U,s,Vt) = svd(Array(A));
  ii = findall(s.>s[1]*eps);
  return Array(Vt[:,ii]');
end
function dropDependentCols(X,eps=1e-14)
  (Q,R) = myqr(X);
  iKeep = mfind(abs.(diag(R)).>eps)
  return X[:,iKeep]
end
function orth(A0,eps::Float64=1e-15,doNormalize::Bool=false)
  if doNormalize
    A = copy(A0);
    for j=1:size(A,2)
      aj = A0[:,j]
      A[:,j] = aj / norm(aj)
    end
  else
    A = A0
  end
  (U,s,Vt) = svd(Array(A));
  ii = mfind(s .> s[1]*eps);
  return U[:,ii]
end
function orthrows(A)
  (U,s,Vt) = svd(Matrix(mtransp(A)));
  ii = mfind(s .> s[1]*1e-11);
  return U[:,ii]'
end
function residcols(X,y)
  b = X\y;
  resid = y-X*b;
  return resid
end
residrows(X,y) = residcols(X',y')'
function spancols(X,y)
  resid = residcols(X,y)
  return maximum(abs,resid)
end
function spancols2(X,y) # output for each column
  resid = residcols(X,y)
  return maximum(abs,resid,dims=1)
end
function oneMinusR2(X,y,addConst=false)
  if addConst
    resid = residcols(hcat(ones(size(X,1)),X),y)
  else
    resid = residcols(X,y)
  end
  return vec(var(resid,dims=1) ./ var(y,dims=1));
end
function eliminateMeanDist(M0,nExog::Int)
  # eliminate mean from moments:
  M1 = M0[1:end-nExog,1:end-nExog];
  M1 = orthrows(M1 .- mean(M1,2))
  M1 = hcat(M1,zeros(size(M1,1),nExog))
  M2 = M0[end-nExog+1:end,:];
  M = vcat(M1,M2);
  return M;
end
function sigmaStSt(vs,M,mindist::Float64,returnBoth=false)
  vs = max.(vs,mindist/length(vs));
  SM = vs .* M'
  sigM = M*SM; # vstst or vstst.^2 ???
  sigM = (sigM+sigM')/2;
  if returnBoth
    return (sigM,SM);
  else
    return sigM;
  end
end
function regularizedCov(A,B,stdEps,M,ststVec,mindist::Float64,phifac::Float64)
  ii = findnzcols(A)
  n = length(ii)
  @assert(size(M,1)==n)
  nStates = size(M,2);
  @assert(n==maximum(ii)); # state variables come first

  Sigma = doubling(A[ii,ii],B[ii,:],mdiagm(stdEps.^2),30);
  Sigma = (Sigma+Sigma')/2;
  # std = sqrt.(diag(Sigma));
  # iKeep = mfind(std.>1e-12);
  # M = M[iKeep,:];
  # Sigma = Sigma[iKeep,iKeep];
  sigR = sigmaStSt(ststVec[1:nStates],M,mindist)

  lamM = maximum(eigen(Sigma).values);
  lamR = maximum(eigen(sigR).values);
  phi = phifac*lamM/lamR; # weighting of regularization part
  sigReg = Sigma + phi*sigR;
  return sigReg
end
function rotatedMoments(A,B,stdEps,M,vstst,mindist::Float64,phifac::Float64,
                        excludeLast::Int = 0)
  # ii = findnzcols(A)
  # n = length(ii)
  # @assert(size(M,1)==n)
  # nStates = size(M,2);
  # @assert(n==maximum(ii)); # state variables come first

  # sigM = doubling(A[ii,ii],B[ii,:],mdiagm(stdEps.^2),30);
  # sigM = (sigM+sigM')/2;
  # lamM = maximum(eigen(sigM).values);
  # # regularization part of covariance matrix:
  # sigR = sigmaStSt(vstst[1:size(M,2)],M,mindist)
  # lamR = maximum(eigen(sigR).values);
  # phi = phifac*lamM/lamR; # weighting of regularization part
  # println("phi: ",phi)
  # sigReg = sigM + phi*sigR;
  # sigReg = (sigReg+sigReg')/2;

  sigReg = regularizedCov(A,B,stdEps,M,vstst,mindist,phifac)
  ii = 1:size(sigReg,1)-excludeLast
  if excludeLast>0
    (evec,s,V) = svd(sigReg[ii,ii]); # var(M) = U*s*V'
    Mupd = blockdiag(evec',meye(excludeLast))
  else
    # do a PCA:
    (evec,s,V) = svd(sigReg); # var(M) = U*s*V'
    # (eval,evec) = eigen(sigReg); # var(M) = evec*eval*evec'
    #  @assert(all(abs.(1-sum(evec.^2,1)).<1e-12)); # make sure eigenvectors are normalized
    # rotate moments:
    Mupd = evec';
  end
  Mreg = Mupd*M;
  sigupd = Mupd*sigReg*Mupd';
  std = sqrt.(diag(sigupd))
  cormat = sigupd./(std*std')
  cormat = cormat - mdiagm(diag(cormat)); # eliminate main diagonal
  @show maximum(abs,cormat[ii,ii])
  return (Mreg,sigReg,sigupd);
  # sigMreg = Mrotate*sigReg*Mrotate';
  # return (Mreg,sigReg)
end
struct InverseOpPrime
  Tfact::SuiteSparse.UMFPACK.UmfpackLU{Float64,Int64}
  S::SparseMatrixCSC{Float64,Int64}
end
import Base.*
*(op::InverseOpPrime,b) = op.S*(op.Tfact\b);
size(op::InverseOpPrime) = (size(op.S,1),size(op.Tfact,2))
# splitjac:  #generates matrices T, D etc. from filename

function splitequ(model::LinModel,equStates::Array{String}=fill("",0))
  dpname = model.info.dp[1].name
  ieS_dp = model.equNames["$(dpname)_d"];
  ieS = ieS_dp;
  if !isempty(equStates)
    for equ in equStates
      ieS = vcat(ieS,model.equNames[equ])
    end
  else
    ivSall = findnzcols(model.Lambda) # all state variables
    dname = Symbol(model.info.dp[1].D)
    ivS = setdiff(ivSall, model.varNames[dname])
    ivSnames = map(x->findIndexInDict(model.varNames,x),ivS);
    ieSnames = map(string,ivSnames);
    return splitequ(model,ieSnames);
    # ieSall = findnzrows(model.Lambda)
    # ivS = findnzcols(model.Lambda)
    # ieSextra = setdiff(ieSall,ieS)
    # for i in ieSextra
    #   iG = mfind(model.Gamma[i,:].!=0)
    #   iL = mfind(model.Lambda[i,:].!=0)
    #   if length(iG)==1 && in(iG[1],iL)
    #     ieS = vcat(ieS,i)
    #     println("splitequ: identify state equation $i")
    #   end
    # end
    # @assert(length(ivS)==length(ieS))
  end
  ieV_dp = model.equNames["$(dpname)_v"];
  ieV = ieV_dp;
  # iEquForw = union(ieV_dp,findnzrows(model.Phi))
  # iEquBack = findnzrows(model.Lambda)
  # ieV = setdiff(iEquForw,ieS_dp);
  # # ieV = setdiff(iEquForw,iEquBack);
  # nameValue = Symbol(_DP[string(dp)].V);
  # ivV0 = model.varNames[nameValue]
  # ivV = union(ivV0,findnzcols(model.Phi));
  # if length(ieV)!=length(ivV)
  #   @show length(ieV)
  #   @show length(ivV)
  #   error("cannot automatically determine forward looking equations")
  # end
  ieY = setdiff(1:nVar(model),union(ieS,ieV));
  nSt = length(ieS)
  nS1 = length(ieS_dp)
  ieS[nS1+1:end] = sort(ieS[nS1+1:end]);
  return (ieS,ieV,ieY);
end

function splitequ(model::LinModel,equStates::Array{String},equForw)
  dpname = model.info.dp[1].name
  ieS = model.equNames["$(dpname)_d"];
  for equ in equStates
    ieS = vcat(ieS,model.equNames[equ])
  end
  ieV = model.equNames["$(dpname)_v"];
  for equ in equForw
    ieV = vcat(ieV,model.equNames[equ])
  end
  ieY = setdiff(1:nVar(model),union(ieS,ieV));
  return (ieS,ieV,ieY);
end

# function splitequ(equNames,equStates::Array{String},equForw)
#   dpname = string(dp)
#   # dpname = string(model.DPproblems[1]);
#   ieS = equNames["$(dpname)_d"];
#   for equ in equStates
#     ieS = vcat(ieS,equNames[equ])
#   end
#   ieV = equNames["$(dpname)_v"];
#   for equ in equForw
#     ieV = vcat(ieV,equNames[equ])
#   end
#   ieY = setdiff(1:nVar(model),union(ieS,ieV));
#   return (ieS,ieV,ieY);
# end

struct StateSpaceInfo
  Tprime::InverseOpPrime
  C::Array{Float64,2}
  GamPrimeInv::SuiteSparse.UMFPACK.UmfpackLU{Float64,Int64}
  iExog::Array{Int,1}
end
function stateSpaceInfo(model,ieS,ieV,ieY)
  Gam = model.Gamma;
  Lam = model.Lambda;
  Phi = model.Phi;
  Psi = model.Psi;


  n = size(Gam,1)
  ivV = findnzcols(Phi);
  ivS = findnzcols(Lam);
  if ivS[end]!=length(ivS)
    vname = findIndexInDict(model.varNames,ivS[end]);
    error("state variables are not the first variables (necessary for HA models); Example: $vname")
  end
  ivY = setdiff(1:n,union(ivV,ivS))

  ieYall = setdiff(1:n,union(ieV,ieS))
  mytest = map(i->in(i,ieYall),ieY)
  @assert(all(mytest))

  ivYinV = ieY[findnzcols(Gam[ieV,ieY])]; # the variables that are used in value equations
  ivYinS = ieS[union(findnzcols(Gam[ieS,ieY]),findnzcols(Lam[ieS,ieY]))];

  Lss = Lam[ieS,ivS];
  Lys = Lam[ieY,ivS];
  @assert(iszero(Lam[ieV,ivS]))
  # @assert(iszero(Gam[ieV,ivS])) # no state variables in forward equ. ; WHY NOT??
  @assert(iszero(Psi[ieV,:]))

  Gss = Gam[ieS,ivS];
  if size(Gss,1)!=size(Gss,2)
    error(string(size(Gss,1)) * " equations but " * string(size(Gss,2)) * " variables")
  end
  Gssinv = lu(Gss);
  Lss = Lam[ieS,ivS];
  Lys = Lam[ieY,ivS];
  Gys = Gam[ieY,ivS];
  # T = InverseOp(lufact(Gss),-Lss);
  GamPrimeInv = lu(mtransp(Gss))
  Tprime = InverseOpPrime(GamPrimeInv,-Lss');
  LG = [Lys;Gys]
  oLG = orthrows(LG)
  n1 = size(LG,1)
  n2 = size(oLG,1)
  println("state reduction: $n1 linear combinations considered, having rank $n2")
  iExog = sort(findexog(Gam,Lam,Phi)); # check consistency with ieS !!??
  return StateSpaceInfo(Tprime,oLG,GamPrimeInv,iExog)
end

function gramianspace(RI::StateSpaceInfo,n::Int64)

  A = RI.Tprime
  h0 = RI.C'

  # if(n==0 || n*length(A)<1e7)
  #   str = gramianspace_ex(A,h0,n);
  #   return;
  # end

  (na,na2) = size(A);
  h = h0;
  n1 = convert(Int,ceil(n/4));
  n2 = n - 3*n1;
  nn = [n1 n1 n1 n2];
  steps = [1;2;4;8];
  steps2 = [fill(steps[1],nn[1]);fill(steps[2],nn[2]);fill(steps[3],nn[3]);fill(steps[4],nn[4])];
  (nh1,nh2) = size(h);
  Gramian = zeros(nh1,nh2*(n+1))
  Gramian[:,1:nh2] = h;
  offs = nh2;
  norm0 = norm(h);
  iDone = false;
  steps2 = fill(1,(n,))
  for iter=1:n
    for l=1:steps2[iter]
      try
        h = A*h;
      catch
        @show iter
        @show norm(h)
        error("multiplication in gramianspace failed")
      end
    end
    h = h ./ sqrt.(sum(h.^2,dims=1))
    # @show norm(h)
    # if(max(abs(h))>max(abs(h0))*1e6)
    #   fprintf(1,'WARNING: stop in gramianspace because of likely instability of A');
    #   break;
    # end
    Gramian[:,offs+1:offs+nh2] = h;
    offs += nh2;
  end
  (nr,nc) = size(Gramian)
  println("size of Gramian for model reduction: $nr x $nc")
  nExog = length(RI.iExog);
  iEndog = setdiff(1:nr,RI.iExog);
  (U,s,V) =  svd(Gramian[iEndog,:]);
  n = length(mfind(s.>s[1]*1e-12))
  println("$n singular values chosen")
  Hprime = zeros(nr,n+nExog);
  Hprime[RI.iExog,1:nExog] = meye(nExog)
  Hprime[iEndog,nExog+1:end] = U[:,1:n];
  H = Hprime';
  # println("orthogonality check on H: ",maximum(abs,H*H'-meye(size(H,1))))
  hatT = (H*(A*Hprime))'

  ## # some checks:
  ## HT = (A*H')';
  ## TH = hatT*H;
  ## check = HT - TH;
  ## println("gramianspace, check commute: ",maximum(abs,check))
  ## println("gramianspace, check span: ", spancols(H',h0))

  return (H,hatT)
end

#=
H T = hatT H   ==>
H T H' = hatT H H' = hatT
and
H T H' = (H T' H')'
=#


function elimRedundant(ranges,n::Int)
  nR = length(ranges)
  # means = map(i->sum(Dstst[ranges[i]]),1:nR)
  iDrop = map(i->ranges[i][end],1:nR)
  iKeep = setdiff(1:n,iDrop)
  H = mspeye(n)[iKeep,:];
  PD = mspeye(n);
  for i=1:nR
    id = iDrop[i]
    PD[id,ranges[i]] = -1
  end
  PD = PD[:,iKeep]
  return (H,PD);
end

function separateExogVar(HA,PD,nExogVars::Int)
  nSt = size(HA,2)
  iiExog = (nSt-nExogVars+1):nSt;
  (nm,nv) = size(HA)
  if nExogVars==1
    iExog = iiExog[1]
    i = argmax(abs.(HA[:,iExog]));
    iOther = setdiff(1:nm,i)
    saveT("ha",HA,iOther,iExog)
    @assert(maximum(abs,HA[iOther,iExog])<1e-12, @show(maximum(abs,HA[iOther,iExog])<1e-12))
    @assert(maximum(abs,HA[i,setdiff(1:nv,iExog)])<1e-12)
    haI = HA[i,iExog]
    @assert(abs(abs(haI)-1)<1e-13);
    HAordered = HA[[iOther;i],:];
    HAordered[end,:] /= haI;
    PDordered = PD[:,[iOther;i]]
    PDordered[:,end] *= haI;
    println("check prime: ",maximum(abs,HAordered-PDordered'))
  else
    i = map(ie->argmax(abs.(HA[:,ie])),iiExog);
    iOther = setdiff(1:nm,i)
    @assert(maximum(abs,HA[iOther,iiExog])<1e-12)
    HAordered = vcat(HA[iOther,:],Array(eyeii(size(HA,2),iiExog)));
    # @assert(maximum(abs,HA[i,setdiff(1:nv,iiExog)])<1e-12)
    # haI = HA[i,iiExog]
    # println(haI)
    # @assert(all(abs.(diag(haI)-1).<1e-13));
    # HAordered = HA[[iOther;i],:];
    # HAordered[end,:] /= haI;
    # PDordered = PD[:,[iOther;i]]
    # PDordered[:,end] *= haI;
    PDordered = HAordered';
    println("check prime: ",maximum(abs,HAordered-PDordered'))
  end
  return (HAordered,PDordered)
end

struct Concat
  ops::Array{Any,1}
end
import Base.*
function *(A::Concat,x::Array{Float64})
  y = A.ops[1]*x;
  for i=2:length(A.ops)
    y = A.ops[i]*y;
  end
  return y;
end
size(x::Concat) = (size(x.ops[end],1),size(x.ops[1],2));
function concat(ops...)
  n = length(ops)
  a = Array{Any}(n)
  for i=1:n
    a[i] = ops[i]
  end
  return Concat(a)
end
function reduceV(linModel,nameDP0, horiz = 200);
  Gamma = linModel.Gamma
  Lambda = linModel.Lambda
  Phi = linModel.Phi
  Psi = linModel.Psi
  Pi = linModel.Pi
  n = size(Gamma,1)
  # iiEV = equNames["_v"]; # the extension _v is used in function insertResDP!
  nameDP = linModel.info.dp[1].name
  iiEV = linModel.equNames[string(nameDP)*"_v"]; # the extension _v is used in function insertResDP!
  nameValue = Symbol(linModel.info.dp[1].V)
  iiVV = pos(linModel,nameValue) # index of value function variables
  nV = length(iiVV)
  iVB = setdiff(1:n,iiVV);  # index of all other variabls

  gamEB = Gamma[iiEV,iVB]; # part of Gamma where non-value variables appear in value equations
  i0 = findnzcols(gamEB); # which variables are this?
  phiEB = Phi[iiEV,iVB];
  i1 = findnzcols(phiEB);  # those variables must not appear  at t+1
  @assert(isempty(i1));
  lamEB = Lambda[iiEV,iVB];
  i2 = findnzcols(lamEB);  # those variables must not appear  at t-1
  @assert(isempty(i2));


  gamVV = Gamma[iiEV,iiVV];
  @assert(gamVV==mspeye(nV)) # not general enough!!
  phiVV = -Phi[iiEV,iiVV];

  n0 = length(i0);
  # println("there are $n0 variables affecting the Bellman equation")
  VV = zeros(nV,n0*horiz)
  lauf = 0
  for i = 1:n0
    v = gamEB[:,i0[i]];
    for t=1:horiz
      # v = v / norm(v);
      lauf += 1;
      VV[:,lauf] = v;
      v = phiVV*v;
    end
  end
  # @show size(VV)
  (U,s,V) = svd(VV);
  ii = mfind(s.>s[1]*1e-16);
  UVal = U[:,ii]
  WVal = inv(UVal'*UVal)*UVal';


  iiV = linModel.varNames[nameValue]
  # Phi2 = Phi[:,iiV]*UVal;
  return ReduceValue(UVal,WVal,iiEV,iiV)
end

# estimate maximum eigenvalue by simulation:
function maxeigsimul(A,iter=1000)
  n = nVar(A);
  x = randn(n,1);
  local x2;
  for i=1:iter
    x2 = A*x;
    x = x2;
  end
  return norm(x2)/norm(x);
end


function reduceModel(model,redS,redV,RI::StateSpaceInfo)
  HA = redS.selectMom;
  redSGam = ReduceState((RI.GamPrimeInv\(HA'))',redS.proxyD,redS.iequ,redS.ivar);

  g0 = compress(model.Gamma,redSGam,redV);
  l0 = compress(model.Lambda,redSGam,redV);
  f0 = compress(model.Phi,redSGam,redV);
  p0 = compress(model.Pi,redSGam,redV);
  h0 = compressEqus(model.Psi,redSGam,redV); # only reduce equations
  return (g0,l0,f0,h0,p0)
end

# eliminate unit root due to dynamics of distribution:
function removeUnitRoot!(model::LinModel,iDrop::Int)
  model.Lambda[iDrop,:] .= 0.;
  model.Gamma[iDrop,:] .= 0.;
  model.Phi[iDrop,:] .= 0.;
  model.Psi[iDrop,:] .= 0.;
  nameMod::Module = Core.eval(Main,Symbol(model.info.dp[1].name));
  nameD = Symbol(model.info.dp[1].D)
  iD = model.varNames[Symbol(nameD)];
  model.Gamma[iDrop,iD] .= 1.0 ;
end
function aggrbin(sizeD,Dststvec::Array{Float64,1},sizeRanges::Array{Int,1})
  (n1,n2,n3) = sizeD;
  @assert(sum(sizeRanges)==n1)
  sr2 = repmat(sizeRanges,n2)
  iRange = cumsum([1;vec(sr2)])
  # iiRange = iRange .+ n1*linspace(0,n2-1,n2)';
  # iiRange = map(i->(iRange[i]):(iRange[i+1]-1),1:length(iRange)-1)
  # Dstst = reshape(Dststvec,n1*n2,n3)
  offs = 0;
  nn = n1*n2*n3
  Z = zeros(nn,0)
  for i3=1:n3
    for i=1:length(iRange)-1
      z = zeros(nn)
      ii = offs+iRange[i]:offs+iRange[i+1]-1
      z[ii] .= 1
      Z = hcat(Z,z)
    end
    offs += n1*n2;
  end
  return Z;
end
function aggrbin(mod::LinModel,pol,nStep::Int, RI::StateSpaceInfo )
  # pol2 = Core.eval(Symbol(dp,"_pol"))
  # pol = pol2.stst;
  dname = Symbol(model.info.dp[1].D)
  pos2Aggr = mod.varNames[dname]
  (nEndog,nDiscr,nExog) = size(pol.CC); # number of intervals
  nInterv = nEndog - 1;
  nStates = nnzcols(mod.Lambda);
  posTakeAll = setdiff(findnzcols(mod.Lambda),pos2Aggr);
  println("aggrbin: include following states: ",posTakeAll);
  # posTakeAll = vcat(map(x->mod.varNames[x],varTakeAll)...)
  HA = eyeii(nStates,posTakeAll)
  PD = copy(HA);
  g = pol.grid; # grid where distribution is defined
  bounds = [1:nStep:nInterv-1;nInterv+1];
  switchPoints = fill(0,(0,))
  for i=1:length(pol.switches)
    nn = pol.switches[i].iState
    j = s2i((nEndog-1,nDiscr,nExog) ,nn...)
    jj = pos2Aggr[j]
    push!(switchPoints,jj)
    _m = sparse([1],[jj],[1.0],1,nStates);
    HA = [HA;_m];
    _m = sparse([1],[jj],[1.0],1,nStates);
    PD = [PD;_m];
  end
  for j = 1:nExog
    for k = 1:nDiscr
      offset = ((j-1)*nDiscr+k-1)*nInterv;
      offset += pos2Aggr[1] - 1;

      for i=1:length(bounds)-1
        ii = offset+(bounds[i]:bounds[i+1]-1)
        ii = setdiff(ii,switchPoints)
        n = length(ii)
        _m = sparse(fill(1,(n,)),ii,ones(n),1,nStates);
        HA = [HA;_m];
        #_ssii = max(1e-6,ststVector[ii])
        #_m = sparse(fill(1,(n,)),ii,_ssii./sum(_ssii),1,nStates);
        _m = sparse(fill(1,(n,)),ii,ones(n)/n,1,nStates);
        PD = [PD;_m];
      end
    end
  end

  ststVector = stackFields(Float64,mod.vstst);
  Omega=max.(ststVector[1:nStates].^2,1e-12);
  # @time HA = orthrows([HA;RI.C]);
  HA = vcat(HA,orthrows(residrows(HA,RI.C)));
  OmH = Omega.*HA';
  HOH = HA*OmH
  PD = OmH*inv(Array(HOH))
  return (HA,PD);
end

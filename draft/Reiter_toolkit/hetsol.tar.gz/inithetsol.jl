# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# hetsolDir = @__DIR__

using Printf
macro hetsol()
  return esc(
             quote
               _dirAplic = pwd() * "/";
               if(!isdir($hetsolDir))
                 error($hetsolDir," is not a directory")
               end
               if(!isfile(hetsolDir*"/hsstart.jl"))
                 error($hetsolDir," does not contain a hetsol distribution")
               end
               if !@isdefined(_modelNames)
                 global _modelNames = Dict{Int,String}()
               end
               if !@isdefined(prepro)
                 include(hetsolDir * "/hsstart.jl")
    end
  end
 )
end
macro hetsolHA()
  return esc( quote
               @hetsol
               initha()
             end
            )
end
macro dolin(iModel)
  return :(dolin(iModel,_startGuess,_vars,_shks,_pars,_varsStSt,false,false));
end
linsol(iModel::Int) =dolin(iModel,_startGuess,_vars,_shks,_pars,_varsStSt,false,false)
dolin() =dolin(_lastModel,_startGuess,_vars,_shks,_pars,_varsStSt,false,false)
macro linsol(name)
  str = string(name)
  return esc(
             quote
               if !@isdefined(prepro)
                 @hetsol;
               end
               iModel = defmodel($str);
               $name = dolin($str,_startGuess,_vars,_shks,_pars,_varsStSt,false,false)
               # $name = @dolin(iModel);
             end
            )
end
macro linsolHA(name)
  str = string(name)
  return esc(
             quote
               if !@isdefined(prepro)
                 @hetsol;
               end
               if !@isdefined(solveiter)
                 initha()
               end
               iModel = defmodel($str);
               $name = linsolHA($str);
             end
            )
end
macro dostst(iModel)
  return :(dolin(iModel,_startGuess,_vars,_shks,_pars,_varsStSt,true,false));
end
macro stst(name)
  str = string(name)
  return esc(
             quote
               if !@isdefined(prepro)
                 @hetsol;
               end
               iModel = defmodel($str);
               $name = @dostst(iModel);
             end
            )
end
macro hetsol2(dir)
  hetsoldir = dir
  return esc(
             quote
               _dirAplic = pwd() * "/";
               if(!isdir($hetsolDir))
                 error($hetsolDir," is not a directory")
               end
               if(!isfile(hetsolDir*"/hsstart.jl"))
                 error($hetsolDir," does not contain a hetsol distribution")
               end
               include(hetsolDir*"/hsstart.jl")
             end
            )
end
macro db(a)
  if @isdefined(mydebug)
    return esc(:(mydebug.@db($a)))
  else
    return esc(a); # by default: @db does nothing (overturn by @dodebug)
  end
end


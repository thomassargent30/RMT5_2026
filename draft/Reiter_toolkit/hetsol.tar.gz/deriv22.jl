# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# df(z) / dx1 = f'(z) * dz/dx1
# d2f(z) / dx1 dx2 = d[f'(z) * dz/dx1] / dx2 = f''(z)*dz/dx1*dz/dx2 + f'(z)*d2z/dx1dx2

# dg(z1,z2) / dx1 = g_1(z_1,z_2)*dz1/dx1 + g_2(z_1,z_2)*dz2/dx1
# d2g(z1,z2) /dx1dx2 = 
#   (g_11(z_1,z_2)*dz1/dx2 + g_12(z_1,z_2)*dz2/dx2)*dz1/dx1 + g_1(z_1,z_2)*d2z1/dx1dx2 
#   + 
#   (g_21(z_1,z_2)*dz1/dx2 + g_22(z_1,z_2)*dz2/dx2)*dz1/dx1 + g_2(z_1,z_2)*d2z1/dx1dx2 

if(!@isdefined(Deriv22))
  struct Deriv22 <: Deriv2
    v::Float64;
    d::Tuple{Float64,Float64}
    H::Tuple{Float64,Float64,Float64}
  end
end
import Base.convert;
import Base.promote_rule;
import Base.isfinite

convert(::Type{Deriv22},x::Real) = Deriv22(convert(Float64,x),(0.,0.),(0.,0.,0.));
nIndep(::Type{Deriv22}) = 2


function compress(dx::Tuple{Float64,Float64})
  return (dx[1]^2,dx[1]*dx[2],dx[2]^2)
end
function compress2(dx::Tuple{Float64,Float64},dy::Tuple{Float64,Float64})
  return (2*dx[1]*dy[1],dx[1]*dy[2]+dx[2]*dy[1],2*dx[2]*dy[2])
end



+(x::Tuple{Float64,Float64},y::Tuple{Float64,Float64}) = (x[1]+y[1],x[2]+y[2])
*(a::Real,x::Tuple{Float64,Float64,Float64}) = (a*x[1],a*x[2],a*x[3])
*(a::Real,x::Tuple{Float64,Float64}) = (a*x[1],a*x[2])

function indep(::Type{Deriv22},v1::Float64,v2::Float64)
  return (Deriv22(v1,(1.,0.),(0.,0.,0.)) ,Deriv22(v2,(0.,1.),(0.,0.,0.)))
end
function indep(::Type{Deriv22},v::Float64,i::Int)
  if i==1
    return Deriv22(v,(1.,0.),(0.,0.,0.));
  else
    assert(i==2)
    return Deriv22(v,(0.,1.),(0.,0.,0.));
  end
end

function Deriv22(v2::Float64,D1::Deriv22,df1::Real,df2::Real)
  return Deriv22(v2,D1.d*df1,D1.H*df1 + compress(D1.d)*df2)
end
function Deriv22(v2::Float64,D1::Deriv22,df1::Real,D2::Deriv22,df2::Real,
                 df11::Real, df22::Real, df12::Real)
  return Deriv22(v2,
                 df1*D1.d + df2*D2.d,
                 df11*compress(D1.d) + df12*compress2(D1.d,D2.d)
                 + df22*compress(D2.d) 
                 + df1*D1.H
                 + df2*D2.H
                )
end

promote_rule(::Type{Deriv22}, ::Type{Float64} ) = Deriv22
promote_rule(::Type{Deriv22}, ::Type{Int} ) = Deriv22
getval(x::Deriv22) = x.v
isfinite(x::Deriv22) = isfinite(x.v);
function getval(x::Array{Deriv22})
  nn = size(x)
  n = length(x);
  v = zeros(nn);
  for i=1:n
    v[i] = x[i].v;
  end
  return v;
end




macro defD2FFunc1(ff,ex1,ex11)
  return esc(
             quote
               function $ff(X::Deriv22)
                 x = X.v;
                 dx = $ex1;
                 dy = $ex11;
                 return Deriv22($ff(x),X,dx,dy);
               end
             end
            )
end
macro defD2FFunc2(op,ex1,ex2,ex11,ex22,ex12)
  return esc(
             quote
               function $op(X::Deriv22, Y::Deriv22)
                 x = X.v;
                 y = Y.v;
                 dx = $ex1;
                 dy = $ex2;
                 dxx = $ex11;
                 dyy = $ex22;
                 dxy = $ex12;
                 return Deriv22($op(x,y),X,dx,Y,dy,dxx,dyy,dxy);
               end
               function $op(X::Deriv22, y::Float64)
                 x = X.v;
                 dx = $ex1;
                 dxx = $ex11;
                 return Deriv22($op(x,y),X,dx,dxx);
               end
               function $op(x::Float64, Y::Deriv22)
                 y = Y.v;
                 dy = $ex2;
                 dyy = $ex22;
                 return Deriv22($op(x,y),Y,dy,dyy);
               end
               $op(X::Deriv22, y::Int) = $op(X,convert(Float64,y));
               $op(x::Int, Y::Deriv22) = $op(convert(Float64,x), Y);
             end
            )
end
macro defD2FBool(fop)
  return esc(
             quote
               function $fop(x::Deriv22, y::Deriv22)
                 return  $fop(x.v,y.v)
               end
               function $fop(x::Deriv22, yv::Float64)
                 return  $fop(x.v,yv)
               end
               function $fop(xv::Float64,y::Deriv22)
                 return  $fop(xv,y.v)
               end
               function $fop(x::Deriv22, yv::Int)
                 return  $fop(x.v,yv)
               end
               function $fop(xv::Int,y::Deriv22)
                 return  $fop(xv,y.v)
               end
             end
            )
end

include("deriv2incl.jl")

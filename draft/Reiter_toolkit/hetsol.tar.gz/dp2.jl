include("isrch.jl")
#= isDiscrete:
0: only one feasible point
1: only finitely many feasible points
2: bound contrained (handles unconstrained by large bounds

Outcomes:
0: interior point
i from 1 to n: at discrete point (in case iSDete==1
1: at lower bound (in case iSDete==2)
2: at upper bound (same)
=#


# if !@isdefined(iiLocMax)
#   global const iiLocMax = fill(-1,(1000)) # not more than 100 local maxima possible
# end

# Output:
#     (vBest,cBest,bBest,iBest,pBest,iDE) 


macro returnFromOptim() # requires vBest,iBest,pBest,iDE to be set before
  return esc( quote
               @assert(pBest>=0.0 && pBest<=1.0)
               cBest = (1-pBest)*gridV[iBest] + pBest*gridV[iBest+1]
               @assert(isfinite(cBest))
               if cBest<ccRange[1]+1e-6
                 bBest = 1;
               elseif cBest>ccRange[2]-1e-6
                 bBest = 2;
               else
                 bBest = 0;
               end
               # attention: iBest is index in gridV, not gridD!
               return (vBest, cBest,bBest, iBest,pBest,iDE)
             end
            )
end


function optimAtPoint(pars,aggr,
                      xCS::Float64,iDS,iDC, iZ::Int,iLoSearch,iHiSearch,
                      _disc::Function,
                      _util::Function,
                      _prep!::Function,
                      _range::Function,
                      pt0,
                      VendJ::Array{Float64,2},Q,
                      gridV,
                      linsol::LinsolParams,
                      t) :: Tuple{Float64,Float64,Int,Int,Float64,Int}
  iRobustOptim = linsol.robustOptim;
  nV = length(gridV)
  tolVmax = 10.;
  pT = typeof(pt0)();

  VendJval = getval(VendJ)

  # sets everything independent of xCE:
  _prep!(pars,aggr,pT,xCS,iDS,iZ,iDC,t) 
  iDE = pT.iDE
  (isDiscrete::Int,ccRange::Tuple{Float64,Float64}) =_range(pars,aggr,pT,xCS,iDS,iZ,iDC,t)
  valueAtCC2(cc) = valueAndPos(_util,pars,aggr,pT,gridV,xCS,iDS,iZ,cc,iDC,VendJval,Q,t)
  valueAtP(p,iV) = valueFuncI(_util,pars,aggr,pT,gridV,xCS,iDS,iZ,iDC,VendJ,Q,t,iV,p)
  utilAtII!(V,offs,n) = _util!(V,_util,offs,n,pars,aggr,pT,xCS,iDS,iZ,gridV,iDC,t);
  if isDiscrete < 0  # not feasible
    return (-Inf,NaN,-1,0,NaN,iDE)
  elseif isDiscrete ==0
    cChoice = ccRange[1]
    (vOpt,iPos,pPos) = valueAtCC2(cChoice)
    return (vOpt,cChoice,1,iPos,pPos,iDE)
  else # case continuous choice
    @assert(isDiscrete == 2)

    # first round of grid search, search over grid:
    @assert(ccRange[2]<=gridV[end],@show(iDC,ccRange[2]))
    @assert(ccRange[1]>=gridV[1],@show(iDC,ccRange[1]))
    (iLoFeas,pLowB) = posInGrid(gridV,ccRange[1])
    (iHiFeas,pUppB) = posInGrid(gridV,ccRange[2])
    if iLoFeas==iHiFeas
      (pBest,vBest) = maxIn01(valueAtP,iLoFeas,iRobustOptim,(pLowB+pUppB)/2,pLowB,pUppB)
      iBest = iLoFeas;
      @returnFromOptim()
    end

    if gridV[iLoFeas] < ccRange[1] # make sure all points on search grid are feasible
      iLoFeas += 1;
    end

    # Determine search grid:
    widthSearch = 16
    iLoSearch = max(iLoSearch,iLoFeas)
    iHiSearch = min(iHiSearch,iHiFeas)
    (nLocalMax,iiLocMax) = integerSearch2(utilAtII!,iHiSearch-iLoSearch+1,
                                          iLoSearch,iHiSearch,iLoFeas,iHiFeas,tolVmax, VendJ, iDE) ;
    while nLocalMax < 0
      widthSearch = iHiSearch-iLoSearch
      if nLocalMax == -1
        iLoSearch -= widthSearch
      else
        iHiSearch += widthSearch
      end
      iLoSearch = max(iLoSearch,iLoFeas)
      iHiSearch = min(iHiSearch,iHiFeas)
      (nLocalMax,iiLocMax) = integerSearch2(utilAtII!,iHiSearch-iLoSearch+1,
                                            iLoSearch,iHiSearch,iLoFeas,iHiFeas,tolVmax, 
                                            VendJ, iDE) ;
    end

    # SECOND STEP: fine grid search around local maxima on search grid
    vBest = -1e100
    pBest = NaN;
    bBest = -1;
    iBest = -1;
    for iS=1:nLocalMax 
      p1 = NaN;
      v1 = -1e100;
      p2 = NaN;
      v2 = -1e100;
      ii = iiLocMax[iS]
      if ii==iLoFeas # at lowest interval
        if gridV[ii] > ccRange[1] # otherwise v1 stays at -INF
          pLower = (ccRange[1]-gridV[ii-1])/(gridV[ii]-gridV[ii-1])
          (p1,v1) = maxIn01(valueAtP,ii-1,iRobustOptim,1.0,pLower,1.0)
        end
        if ii<iHiFeas 
          (p2,v2) = maxIn01(valueAtP,ii,iRobustOptim,0.0)
        elseif gridV[ii] < ccRange[2] # check whehter lower bound is below lowest interval
          pBound = (ccRange[2]-gridV[ii])/(gridV[ii+1]-gridV[ii])
          (p2,v2) = maxIn01(valueAtP,ii,iRobustOptim,0.0,0.0,pBound)
        end
      elseif ii==iHiFeas
        (p1,v1) = maxIn01(valueAtP,ii-1,iRobustOptim,1.0)
        if gridV[ii] < ccRange[2] # otherwise v2 stays at -INF 
          pBound = (ccRange[2]-gridV[ii])/(gridV[ii+1]-gridV[ii])
          (p2,v2) = maxIn01(valueAtP,ii,iRobustOptim,0.0,0.0,pBound)
        end
      else
        (p1,v1) = maxIn01(valueAtP,ii-1,iRobustOptim,1.0)
        (p2,v2) = maxIn01(valueAtP,ii,iRobustOptim,0.0)
      end
      vMax = max(v1,v2)
      if vMax>vBest
        vBest = vMax
        if v1>v2
          iBest = ii-1
          pBest = p1
        else
          iBest = ii
          pBest = p2
        end
      end
    end
    if iBest==nV # special case: optimum is maximum of grid
      iBest = nV-1
      pBest = 1.0;
    end
    @returnFromOptim()
  end
end 

function valueFuncI(utilFunc::Function,pars,aggr,pT,gridV::Array{Float64,1},xCS,iDS,iZ,iDC,Vend,Qend::Array{Float64,2},t,iV::Int,pHi::T) where T
  xCC::T = (1-pHi)*gridV[iV] + pHi*gridV[iV+1];
  ut = utilFunc(pars,aggr,pT,xCS,iDS,iZ,xCC,iDC,t)
  xCE = xCC;
  iDE = pT.iDE
  v = ut + (1-pHi)*Vend[iV,iDE] + pHi*Vend[iV+1,iDE] + pHi*(pHi-1)*Qend[iV,iDE]
  return v;
end


# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include("sym.incl")
function setindex!(x::SymVar,y,t::StStIndex)
  x.s = y;
end
function getindex(x::SymVar,t::StStIndex)
  return Prim(Expr(:ref,x.s,:stst))
end
function getindex(x::SymVar,i::Int,t::TimeIndex)
  xi = Symbol(x.s,"_",i)
  if t.lead==0
    return Prim(Expr(:call,xi,:t))
  elseif t.lead==1
    return Prim(Expr(:call,xi,:(t+1)))
  elseif t.lead==-1
    return Prim(Expr(:call,xi,:(t-1)))
  elseif t.lead==2
    warn("time index 2")
    return 0;
  else
    error("wrong time index")
  end
end
function getindex(x::SymVar,t::TimeIndex)
  if t.lead==0
    # return Symbol(x.s)
    # return QuoteNode(Symbol(x.s))
    return Prim(Expr(:ref,x.s,:t))
  elseif t.lead==1
    return Prim(Expr(:ref,x.s,:(t+1)))
  elseif t.lead==-1
    return Prim(Expr(:ref,x.s,:(t-1)))
  elseif t.lead==2
    warn("time index 2")
    return 0;
  else
    error("wrong time index")
  end
end
mutable struct SymShock
  c::Symbol
end
function getindex(x::SymShock,t::StStIndex)
  return 0;
end
function getindex(x::SymShock,t::TimeIndex)
  if t.lead==0
    return Prim(x.c);
  else
    error("wrong time index in shock")
  end
end




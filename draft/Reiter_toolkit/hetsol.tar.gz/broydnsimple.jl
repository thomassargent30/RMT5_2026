
function solvesimple(func::Function,xold::AbstractArray{Float64,1};
                tolf::Float64=1e-6,
                whenRestart::Int = 3,
                maxIter::Int = 50,
                doPrint::Int = 0,
                stepJacob::Float64 = 1e-5)
  xold = xold[:];
  x = xold;
  EPS = 1.0e-7;
  TOLX = EPS;
  STPMX = 100.0;
  TOLMIN = 1.0e-6;
  n=size(x,1);

  (f,fvec)=fmin_br(x,func);
  fvcold = fvec;
  fold=f;
  fx = fvec;
  if abs(fvec[1])>=1e100
    warn("overflow in function given to broydn at initial vector");
    return (x, -1)
  end;
  #stpmax=STPMX*max(sqrt(dot(x,x)),n);
  stpmax=1000.;




  since_restrt = 0;
  alam = 1;
  for its=1:maxIter
    since_restrt = since_restrt+1;
    txt = @sprintf("its:  %d; f:  %e; step size taken: %e\n",its,getval(f),alam);
    if(doPrint>0)
      print(txt)
      if(!isempty(outpFile))
        FF = open(outpFile,"a");
        print(FF,txt);
        if(doPrint>2)
          println(FF,x);
          println(FF,fvec);
        end
        close(FF)
      end;
    end
    # determine whether restart (new computation of Jacobian):
    if(restrt>0 || since_restrt>=whenRestart) 
      since_restrt = 0;
      if(doPrint>1)
        println("now do Jacobian")
      end
      B = jacob(func,x,stepJacob);
      BhasbeenComputed = true

      if useInitB>1
        _broydnFactor.factB = factB;
        _broydnFactor.B = B;
      end
    elseif(doUpdate && its>1 && !issparse(B))
      s = x - xold;
      skip=1;
      w = (fvec-fvcold) - B*s;
      for i=1:n
        if abs(w[i]) >= EPS*(abs(fvec[i])+abs(fvcold[i]))
          skip=0;
        else
          w[i]=0.0;
        end;
      end;
      if skip==0
        B = B + w*s' / dot(s,s);
      end;
    end;
    condB = cond(Bscaled);
    @printf("condition Jacobian in Broydn: %e\n",condB)
    p = - (factB\fvec);
    g = B'*fvec;
    xold = x;
    fvcold = fvec;
    fold=f;
    check::Int = 1;
    try
      (xTry,f,fvec,check,alam) = lnsrch_br(xold,fold,g,p,stpmax,func);
      x = xTry

      fx = fvec;
      test = maximum(abs.(fvec));
      if (test < tolf)
        if(doPrint>0)
          @printf("maxerror at exit of broydn: %0.3e\n",test)
        end
        return (x, 0)
      end;
    catch
      # saveT("broydn.out",x,f,fvec,check,xold,fold,g,p,stpmax,func);
    end
    if check==1
      if (restrt>0)
        return (x, 1)
      else 
        test=0.0;
        den=max(f,0.5*n);
        test = maximum(abs.(g) .* maximum([abs.(x');ones(1,n)])') / den;
        if (test < TOLMIN)
          return (x, 5)
        else
          restrt+=1;
        end;
      end;
    else 
      restrt=0;
      if(alam<1e-3)
        restrt=1;
      end
      test= maximum(abs.(x-xold) ./ maximum([abs.(x');ones(1,n)])');
      # if (test < TOLX)
      #   return (x, 0)
      # end;
    end;
  end;
  return (x, 3)
end

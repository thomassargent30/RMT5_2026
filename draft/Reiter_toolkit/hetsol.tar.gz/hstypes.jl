# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

const Deriv4hs = Deriv2s
const EPSGRID = 1e-8;
# include("timeindex.jl")

###################################################################
# STEADY STATE VARIABLES
###################################################################

# type definition of a steady state variable:
mutable struct VarShock <: Real 
  sv::Float64 # steady state value
  der::Deriv2s
  #pos::Int;
  iName::String;
end
import Base.zero
zero(::Type{VarShock}) = VarShock(0.0,zero(Deriv2s),"nullshock")
getval(x::VarShock) = x.sv;
getval(x::Array{VarShock}) = map(getval,x)

# import Base.call
(_x::VarShock)(i::StStIndex) = _x.sv;
function Base.getindex(_x::VarShock,i::StStIndex)
  return _x.sv;
end
function Base.getindex(_x::VarShock,t::TimeIndex)
  if(t.lead!=0)
    error("time index of shock must be t")
  end
  return _x.der;
end
(_x::VarShock)(t::TimeIndex) = _x[t];
mutable struct ParCali  <: Real
  s::Symbol
  v::Float64 #  value
end


mutable struct ArrayShock
  sv::Array{Float64}
  der::Array{Deriv4hs}
end
import Base.length
length(x::ArrayShock) = length(x.sv);
function Base.getindex(x::ArrayShock,i::Int,::StStIndex)
  return x.sv[i];
end
function Base.getindex(x::ArrayShock,i::Int,j::Int,::StStIndex)
  return x.sv[i,j];
end
function Base.getindex(x::ArrayShock,::StStIndex)
  return x.sv;
  #return Variable(x.offs + (i-1)*x.stride1);
end
(x::ArrayShock)(::StStIndex) = x.sv;
function Base.getindex(x::ArrayShock,::Colon,j::Int,::StStIndex)
  return x.sv[:,j];
end
function Base.getindex(x::ArrayShock,i::Int,t::TimeIndex)
  assert(t.lead==0)
  return x.der[i];
end
function Base.getindex(x::ArrayShock,i::Int,j::Int,t::TimeIndex)
  return x.der[i,j,2+t.lead];
end
function Base.getindex(x::ArrayShock,::Colon,j::Int,t::TimeIndex)
  return x.der[:,j,2+t.lead];
end
function Base.getindex(x::ArrayShock,j::Int,::Colon,::StStIndex)
  return x.sv[j,:];
end
function Base.getindex(x::ArrayShock,j::Int,::Colon,t::TimeIndex)
  return x.der[j,:,2+t.lead];
end
function Base.getindex(x::ArrayShock,::Colon,j::Int) # necessary?
  return ArrayShock(x.iName,x.posName,x.sv[:,j],x.der[:,j,:]);
end
#function Base.getindex(x::ArrayShock,j::Int,::Colon) # necessary?
#  return ArrayShock(x.iName,x.posName,x.sv[j,:],x.der[j,:,:]);
#end
function Base.getindex(x::ArrayShock,i::Int,j::Colon)
  return ArrayShock(posName,offs+j-1,n2,1,stride2,-1000000); # convert row to column vector
end
function Base.setindex!(_x::ArrayShock,y::Array{Float64},::StStIndex)
  _x.sv = y;
end
function Base.setindex!(_x::ArrayShock,y::Float64,i::Int,::StStIndex)
  _x.sv[i] = y;
end
function Base.setindex!(_x::ArrayShock,y::Float64,i::Int,j::Int,::StStIndex)
  _x.sv[i,j] = y;
end
function Base.getindex(x::ArrayShock,t::TimeIndex)
  n = size(x.sv);
  if(length(n)==2)
    return convert(Array{Deriv4hs},x.der[:,2+t.lead]);
  elseif(length(n)==2)
    return convert(Array{Deriv4hs},x.der[:,:,2+t.lead]);
  elseif(length(n)==3)
    return convert(Array{Deriv4hs},x.der[:,:,:,2+t.lead]);
  else
    println(n)
    @assert(false,print("not implemented for this dimension"))
  end
end
(x::ArrayShock)(t::TimeIndex) = x[t];
getval(x::ArrayShock) = x.sv;


parCali( s::Symbol,v::Float64) = ParCali(s,v);
mutable struct ParCaliArr1
  s::Symbol
  v::Array{Float64,1} #  value
end
mutable struct ParCaliView
  PC::ParCaliArr1;
  i::Int;
end

function parCali( s::Symbol,n::Int,v::Float64)
  V = fill(v,(n,))
  P = ParCaliArr1(s,V)
  return P;
end
mutable struct ParCaliArr2
  s::Symbol
  v::Array{Float64,2} #  value
end
function parCali( s::Symbol,n::Tuple{Int,Int},v::Float64)
  V = fill(v,n)
  P = ParCaliArr2(s,V)
  return P;
end
import Base.promote_rule
import Base.convert
import Base.-
import Base.+
import Base.*
import Base./
import Base.^
convert(::Type{Float64}, x::ParCali) = x.v;
promote_rule(::Type{Float64}, ::Type{ParCali} ) = Float64
promote_rule(::Type{Int64}, ::Type{ParCali} ) = Float64
convert(::Type{Float64}, x::ParCaliView) = x.v;
promote_rule(::Type{Float64}, ::Type{ParCaliView} ) = Float64
promote_rule(::Type{Int64}, ::Type{ParCaliView} ) = Float64
promote_rule(::Type{ParCali}, ::Type{ParCaliView} ) = Float64
for op in (:+,:-,:*,:/,:^)
  Core.eval(Main,:(($op)(x::ParCali,y::ParCali) = ($op)(x[],y[])))
  Core.eval(Main,:(($op)(x::ParCaliView,y::ParCaliView) = ($op)(x[],y[])))
end

# convert(::Type{AbstractFloat}, x::ParCali) = convert(Float64,x);
#+(x::ParCali,y::ParCali) = +(x[],y[])
#*(x::ParCali,y::ParCali) = *(x[],y[])
#-(x::ParCali,y::ParCali) = -(x[],y[])
#/(x::ParCali,y::ParCali) = /(x[],y[])
#^(x::ParCali,y::ParCali) = ^(x[],y[])
#promote_rule(::Type{Real}, ::Type{ParCali} ) = Float64
#promote_rule(::Type{AbstractFloat}, ::Type{ParCali} ) = Float64
# promote_rule(::Type{ParCali}, ::Type{ParCali} ) = Float64
## ParCali(j::Int) = ParCali(NaN,j)

function saveRaw(F::IOStream,x::ParCali)
  write(F,x.v);
  write(F,x.s);
end
function loadRaw(F::IOStream,::Type{ParCali})
  x = read(F,Float64)
  s = read(F,Symbol)
  return ParCali(x,s);
end
function printShort(x::ParCali,name::String,F=stdout)
  @printf(F,"%20s: %14.8f (calibrated)\n",name,x.v)
end

# function Base.getindex(x::ParCali,::Function)
#   if(x.v==x.v)
#     return x.v;
#   else
#     error(@sprintf("calibrated parameter %d not yet set",x.i))
#   end
# end
function Base.getindex(x::ParCali)
  if(x.v==x.v)
    return x.v;
  else
    error(@sprintf("calibrated parameter %s not yet set",string(x.s)))
  end
end
(x::ParCali)() = x[]
function Base.getindex(x::ParCaliArr1,i::Int)
  return ParCaliView(x,i)
end
function Base.getindex(x0::ParCaliView)
  x = x0.PC;
  if(x.v[i]==x.v[i])
    return x.v[i];
  else
    error(@sprintf("calibrated parameter %s not yet set",string(x.s)))
  end
end
# function Base.setindex!(x::ParCali,z::Real,::Function)
#   return x.v = z;
# end
function Base.setindex!(x::ParCali,z::Real)
  return x.v = z;
end
function namestring(x::ParCali) 
  return string(x.s)
end

mutable struct Variable <: Real
  sv::Float64 # steady state value
  der::Array{Deriv4hs,1}
  #pos::Int;
  iName::String;
end
Main.copy(x::Variable) = Variable(x.sv,copy(x.der),x.iName)
function Base.show(io::IO, x::Variable)
  if isempty(x.der)
    println(x.iName,": stst: ",x.sv)
  else
    println(x.iName,": stst: ",x.sv,"; Der[1]: ",x.der[1].d)
  end
end

function namestring(x::Variable) 
  return x.iName
end
# function pos(x::Variable)
#   (I,J,V) = findnz(x(t-1).d)
#   assert(length(J)==1);
#   return I[1];
# end
# function pos(X::Array{Variable})
#   return map(x->pos(x),X);
# end
function Base.getindex(_x::Variable,i::StStIndex)
  if(_x.sv==_x.sv)
    return _x.sv;
  else
    println(_x)
    error(@sprintf("variable %s not set",_x.iName));
    #error("variable ",x.name," not set");
  end
end
(_x::Variable)(i::StStIndex) = _x[i];
function Base.setindex!(_x::Variable,y::Real,i::StStIndex)
  _x.sv = y;
end
(_x::Variable)(t::TimeIndex) = _x.der[2+t.lead];
function Base.getindex(_x::Variable,t::TimeIndex)
  return _x.der[2+t.lead];
end
#function Base.setindex!(x::Variable,y::Deriv4hs,i::TimeIndex)
#  global _xFluct;
#  global _nVAR;
#  return _xFluct[x.pos + i.lead*_nVAR] = y; # does not contain _raiseTimeIndex!!
#end
import Base.isfinite
isfinite(x::ParCali) = isfinite(x.v);
ststSet(x::Variable) = isfinite(x.sv);
ststSet(x::ParCali) = isfinite(x.v);


import Base.promote
convert(::Type{AbstractFloat}, x::Variable) = convert(Float64,x);
# convert(::Type{Number}, x::Variable) = convert(Float64,x);
function convert(::Type{Float64}, x::Variable) 
  global _VarNames;
  error(@sprintf("variable %s must be used with time index",x.iName));
  return  x[t]
end
promote_rule(::Type{Float64}, ::Type{Variable} ) = Float64
promote_rule(::Type{AbstractFloat}, ::Type{Variable} ) = Float64
promote_rule(::Type{Int64}, ::Type{Variable} ) = Float64
-(x::Variable) = -convert(Float64,x);
-(x::ParCali) = -convert(Float64,x);
# conversion rules for derivative objects:
for Der1 in (:Deriv1F,:Deriv1a,:Deriv1S,:Deriv2S)
  @eval begin
    convert(::Type{$Der1{T}}, x::ParCali) where T = convert($Der1{T},convert(Float64,x))
    promote_rule(::Type{$Der1{T}}, ::Type{ParCali} ) where T = $Der1{T}
  end
end

# macro funcCali2(op)
#   return esc(:($op(x::ParCali,y::ParCali) = $op(convert(Float64,x),convert(Float64,y))))
# end
# @funcCali2(+)
# @funcCali2(-)
# @funcCali2(*)
# @funcCali2(/)
# @funcCali2(^)
# @funcCali2(abs)


# import Base.-
# -(x::Variable) = -(convert(Float64,x));
# -(x::Variable,y::Variable) = -(convert(Float64,x),convert(Float64,y));
# import Base.+
# +(x::Variable,y::Variable) = +(convert(Float64,x),convert(Float64,y));
# +(x::Variable,y::Float64) = +(convert(Float64,x),y);
# import Base.*
# *(x::Variable,y::Variable) = *(convert(Float64,x),convert(Float64,y));
# *(x::Variable,y::Float64) = *(convert(Float64,x),y);
# import Base./
# /(x::Variable,y::Variable) = /(convert(Float64,x),convert(Float64,y));



mutable struct ArrayVar
  sv::Array{Float64}
  der::Array{Deriv4hs}
  iName::String;
end
function ststVal(v::ArrayVar,ii...)
  x = getindex(v.sv,ii...)
  if(x==x)
    return x;
  else
    indxstr = *(map(x->string(x)*",",ii)...)
    error(@sprintf("variable %s not set at index %s",v.iName,indxstr));
    return NaN;
  end
end
import Base.length
length(x::ArrayVar) = length(x.sv);
function Base.getindex(x::ArrayVar,i::Int,::StStIndex)
  return ststVal(x,i);
end
function Base.getindex(x::ArrayVar,i::Int,j::Int,::StStIndex)
  return ststVal(x,i,j);
end
function Base.getindex(x::ArrayVar,::StStIndex)
  # if !all(isfinite.(x.sv))  ## TOO RESTRICTIVE
  #   error("Steady State of "*x.iName*" not finite")
  # end
  return x.sv;
end
(x::ArrayVar)(::StStIndex) = x.sv;
function Base.getindex(x::ArrayVar,::Colon,j::Int,::StStIndex)
  return x.sv[:,j];
end
function Base.getindex(x::ArrayVar,i::Int,t::TimeIndex)
  return x.der[i,1,2+t.lead];
end
function Base.getindex(x::ArrayVar,i::Int,j::Int,t::TimeIndex)
  return x.der[i,j,2+t.lead];
end
function Base.getindex(x::ArrayVar,::Colon,j::Int,t::TimeIndex)
  return x.der[:,j,2+t.lead];
end
function Base.getindex(x::ArrayVar,j::Int,::Colon,::StStIndex)
  return x.sv[j,:];
end
function Base.getindex(x::ArrayVar,j::Int,::Colon,t::TimeIndex)
  return x.der[j,:,2+t.lead];
end
function Base.getindex(x::ArrayVar,::Colon,j::Int) # necessary?
  return ArrayVar(x.iName,x.posName,x.sv[:,j],x.der[:,j,:]);
end
#function Base.getindex(x::ArrayVar,j::Int,::Colon) # necessary?
#  return ArrayVar(x.iName,x.posName,x.sv[j,:],x.der[j,:,:]);
#end
function Base.getindex(x::ArrayVar,i::Int,j::Colon)
  return ArrayVar(posName,offs+j-1,n2,1,stride2,-1000000); # convert row to column vector
end
function Base.setindex!(_x::ArrayVar,y::Array{Float64},::StStIndex)
  _x.sv = y;
end
function Base.setindex!(_x::ArrayVar,y::Float64,i::Int,::StStIndex)
  _x.sv[i] = y;
end
function Base.setindex!(_x::ArrayVar,y::Float64,i::Int,j::Int,::StStIndex)
  _x.sv[i,j] = y;
end
function Base.getindex(x::ArrayVar,t::TimeIndex)
  n = size(x.sv);
  if(length(n)==2)
    return convert(Array{Deriv4hs},x.der[:,2+t.lead]);
  elseif(length(n)==2)
    return convert(Array{Deriv4hs},x.der[:,:,2+t.lead]);
  elseif(length(n)==3)
    return convert(Array{Deriv4hs},x.der[:,:,:,2+t.lead]);
  else
    println(n)
    @assert(false,print("not implemented for this dimension"))
  end
end
(x::ArrayVar)(t::TimeIndex) = x[t];
# function pos(x::ArrayVar)
#   n = size(x.sv);
#   if(length(n)==2)
#     (I,J,V) = findnz(getjac(x.der[:,:,1]))
#   elseif(length(n)==3)
#     (I,J,V) = findnz(getjac(x.der[:,:,:,1]))
#   else
#     @assert(false,print("not implemented for this dimension"))
#   end
#   @assert(length(I)==length(x.sv),@printf("I:%d,J:%d,x:%d\n",length(I),length(J),length(x.sv)));
#   return J;
# end

function _setval!(_x::Float64,z::Variable)
  stst = StStIndex(0)
  z[stst] = _x; 
end
function _setval!(_x::Float64,z::ParCali)
  z[] = _x; 
end

# function _setval!(_x::Float64,z::Float64)
#   _name = string(z);
#   Core.eval(:( global $_name; $_name = $_x) )
# end


function _gen_eval!(_x::Float64,z::Variable,_eq::Function)
  stst = StStIndex(0)
  z[stst] = _x; 
  return _eq(stst);
end

function _gen_eval!(_x::Float64,z::ParCali,_eq::Function)
  z[] = _x; 
  stst = StStIndex(0)
  return _eq(stst);
end

function _gen_eval!(_x::Float64,z::Float64,_eq::Function)
  _name = string(z);
  Core.eval(Main,Meta.parse(:( global $_name; $_name = $_x) ))
  # Core.eval(Main,Meta.parse(:( global $_name; $_name = $_x) ))
  return _eq();
end

function _gen_eval!(_x::Array{Float64},z::Array{Variable},_eq::Array{Function})
  n = length(_x);
  if(n!=length(z) || n!=length(_eq))
    error("wrong sizes in solver");
  end
  for i=1:n
    z[i][0] = _x[i]; 
  end
  resid = zeros(n,1);
  for i=1:n
    resid[i] = _eq[i]();
  end
  return resid;
end


function _solvelin1!(z::Variable,_eq::Function)
  _x = solvelinear1(y::Float64->_gen_eval!(y,z,_eq));
  print(_VarNames[z.iName],": ",_x,"\n");
  stst = StStIndex(0)
  z[stst] = _x; 
  return _x;
end

function _solvelin1!(z::ParCali,_eq::Function)
  _x = solvelinear1(y::Float64->_gen_eval!(y,z,_eq));
  #print(_VarNames[z.pos],": ",_x,"\n");
  z[] = _x; 
  return _x;
end

function _solvelin1!(z::Float64,_eq::Function)
  #_x = solvelinear1(_gen_eval!,z,_eq);
  _x = solvelinear1(y::Float64->_gen_eval!(y,z,_eq));
  print(string(z),": ",_x,"\n");
  #z[t] = _x; 
  return _x;
end
function _bisect!(z::Variable,_eq::Function,a,b)
  (_x,flag) = bisect(x->_gen_eval!(x,z,_eq),a,b);
  if(flag==-1)
    error(@sprintf("root not bracketed in BISECT: f(a) = %g; f(b) = %g",
    _gen_eval!(a,z,_eq),_gen_eval!(b,z,_eq)))
  elseif(flag!=0)
    println(flag)
    error("BISECT not converged")
  end
  stst = StStIndex(0)
  z[stst] = _x; 
  return _x;
end
function _bisect!(z::Float64,_eq::Function,a,b)
  _x = bisect(_gen_eval!,a,b,z,_eq);
  z = _x; 
  return _x;
end
#end

if @isdefined(BSpl)
function basisFuns!(S::BSpl,u::Deriv4hs, i::Int, N::Array{Deriv4hs}) 
  p = S.p
  left = Array{Deriv4hs}(p);
  right = Array{Deriv4hs}(p);
  N[1] = Deriv4hs(1.0);
  for j=1:p
    left[j] = u-S.U[i+1-j] ;
    right[j] = S.U[i+j]-u ;
    saved =  0.0 *u;
    for r=0:j-1
      scal = (right[r+1]+left[j-r]) ;
      temp = scal==0.0 ? 0.0 : N[r+1]/scal;
      N[r+1] = saved+right[r+1] * temp ;
      saved = left[j-r] * temp ;
    end
    N[j+1] = saved ;
  end
end

function evalspl(S::BSpl,X::Deriv4hs, coeff) 
  p4 = S.p+1;
  iPos = findSpan(S,X);
  N = Array{Deriv4hs}(S.p+1);
  basisFuns!(S,X, iPos,N);
  Y = 0.0;
  for j=0:S.p
    Y += N[j+1] * coeff[iPos-S.p+j];
  end
  return Y;
end
end

function pderiv(y::Deriv4hs,x::Deriv4hs)
  (I,J,V) = findnz(x.d);
  if(length(I)!=1 || V[1]!=1.0)
    error("x not an independent variable in pderiv")
  end
  n = I[1]; # x is n-th independent variable
  return y.d[n];
end

mutable struct KSinfo
  vALM;
  eALM;
  vExog;
  eExog;
  vDec;
  eDec
  Apattern;
  Bpattern;
end
# mutable struct linModel
#   Gamma::SparseMatrixCSC{Float64,Int};
#   Lambda::SparseMatrixCSC{Float64,Int};
#   Phi::SparseMatrixCSC{Float64,Int};
#   Psi::SparseMatrixCSC{Float64,Int};
#   GamInv:: Base.SparseArrays.UMFPACK.UmfpackLU{Float64,Int};
# end

# solve linearly:
function solveLinStSt!(args...)
  stst = StStIndex(0)
  n = div(length(args),2)
  disableLog()
  function f1(x) # for single equation
    setstst!(args[1],x)
    resid = args[2](stst)
    return resid
  end
  function f(X)
    resid = zeros(n)
    for i=1:n
      setstst!(args[2*i-1],X[i])
    end
    for i=1:n
      resid[i] = args[2*i](stst)
    end
    return resid
  end
  if(n==1)
    x = solvelinear1(f1)
    X = [x];
  else
    X = solvelinear(f,n);
  end
  for i=1:n
    setstst!(args[2*i-1],X[i])
  end
  enableLog()
  return X;
end
function append2Log(name::String,x::Real)
  if(_glob.disableLog==0)
    FF = open(_modelDir*"stst.log","a")
    @printf(FF,"%s = %f\n",name,convert(Float64,x))
    if(!isfinite(x))
      @printf("%s = %f\n",name,convert(Float64,x))
      error("not finite")
    end
    close(FF)
  end
end
function enableLog()
  if(_glob.disableLog>0)
    _glob.disableLog-=1;
  end
end
function disableLog()
  _glob.disableLog+=1;
end
function slss!(args...)
  X = solveLinStSt!(args...)
  n = div(length(args),2)
  for i=1:n
    append2Log(namestring(args[2*i-1]),X[i]);
  end
  return X;
end
function bisectTr(name::String,f, a, b, tolX=1e-10)
  (x,flag) = bisect(f,a,b,tolX);
  append2Log(name,x)
  if(flag!=0)
    if(flag==-1)
      @printf("ERROR: root not bracketed in BISECT: f(%g) = %g; f(%g) = %g;\n",
      a,f(a),b,f(b))
    else
      @printf("ERROR: flag %d\n",flag);
    end
    error("bisect failed")
  end
  return (x,flag)
end

# possible syntax:
# x
# x:e
# x[i,j]
# x[i,j]:e  A BIT STRANGE!
# x[i,j]:e[k,l]

mutable struct FuncBind1StSt
  f::Function
  i1::Int
end
(FV::FuncBind1StSt)(tt::StStIndex) = FV.f(FV.i1,tt)
mutable struct FuncBind2StSt
  f::Function
  i1::Int
  i2::Int
end
(FV::FuncBind2StSt)(tt::StStIndex) = FV.f(FV.i1,FV.i2,tt)
FBS(f,i1) = FuncBind1StSt(f,i1);
FBS(f,i1,i2) = FuncBind2StSt(f,i1,i2);

# mutable struct ArrayVarTimed
#   v::ArrayVar
#   t::TimeIndex
# end
# function Base.getindex(x::ArrayVar,t::TimeIndex)
#   return ArrayVarTimed(x,t)
# end
# function Base.getindex(x::ArrayVarTimed,ii...)
#   return getindex(x.v,ii...,x.t)
# end
function Base.getindex(x::ArrayVar,t::TimeIndex)
  n = size(x.sv);
  if(length(n)==1)
    return convert(Array{Deriv4hs},x.der[:,2+t.lead]);
  elseif(length(n)==2)
    return convert(Array{Deriv4hs},x.der[:,:,2+t.lead]);
  elseif(length(n)==3)
    return convert(Array{Deriv4hs},x.der[:,:,:,2+t.lead]);
  else
    println(n)
    @assert(false,print("not implemented for this dimension"))
  end
end
mutable struct ArrayVarView1
  v::ArrayVar
  i1::Int
end
mutable struct ArrayVarView2
  v::ArrayVar
  i1::Int
  i2::Int
end
function Base.getindex(x::ArrayVar,i::Int)
  return ArrayVarView1(x,i)
end
function Base.getindex(x::ArrayVarView1,t::Union{TimeIndex,StStIndex})
  return x.v[x.i1,t];
end
function Base.getindex(x::ArrayVar,i::Int,j::Int)
  assert(ndims(x.sv)==2)
  return ArrayVarView2(x,i,j)
end
function setstst!(x::ArrayVarView1,y::Real,doLog=true)
  x.v.sv[x.i1] = y;
  if(doLog)
    append2Log(namestring(x),y)
  end
end
function setstst!(x::ArrayVarView2,y::Real,doLog=true)
  x.v.sv[x.i1,x.i2] = y;
  if(doLog)
    append2Log(namestring(x),y)
  end
end
function namestring(x::ArrayVarView1) 
  global _VarNames;
  return @sprintf("%s[%d]",x.v.iName,x.i1);
end
function namestring(x::ArrayVarView2) 
  global _VarNames;
  return @sprintf("%s[%d,%d]",x.v.iName,x.i1,x.i2);
end

function setstst!(x::Variable,y::Real,doLog=true)
  x.sv = y;
  if(doLog)
    append2Log(namestring(x),y)
  end
end
function unsetstst!(x::Variable)
  x.sv = NaN;
end
function unsetstst!(x::ArrayVar)
  x.sv = NaN*x.sv;
end
function setstst!(x::ParCali,y::Real,doLog=true)
  x.v = y;
  setfield!(_pars,x.s,y)
  if(doLog)
    append2Log(namestring(x),y)
  end
end
function unsetstst!(x::ParCali)
  x.v = NaN;
end
function setstst!(x::ParCaliView,y::Real,doLog=true)
  i = x.i
  x.PC.v[i] = y;
  getfield(_pars,x.s)[i] = y
  if(doLog)
    append2Log(namestring(x),y)
  end
end
function unsetstst!(x::ParCaliView)
  setstst!(x,NaN,false);
end

# set the derivatives before linear perturbation step
function initDeriv!(V,S)
  _nVAR = lenStruct(V)
  _iVAR = 0;
  for a in fieldnames(typeof(V))
    _x = getfield(V,a);
    if(isa(_x,Variable))
      _iVAR +=1;
      _x.der = 
      [indep(Deriv4hs,_x.sv,_iVAR);
      indep(Deriv4hs,_x.sv,_nVAR+_iVAR);
      indep(Deriv4hs,_x.sv,2*_nVAR+_iVAR)];
    elseif(isa(_x,ArrayVar))
      _x.der = reshape([indep(Deriv4hs,_x.sv,_iVAR);
      indep(Deriv4hs,_x.sv,_nVAR+_iVAR);
      indep(Deriv4hs,_x.sv,2*_nVAR+_iVAR)],size(_x.sv,1),size(_x.sv,2),size(_x.sv,3),3);
      nv = length(_x.sv);
      _iVAR +=nv;
    else
      error("wrong element in variable structure")
    end
  end
  # mnow handle shocks:
  _iSHOCK = 0;
  for a in fieldnames(typeof(S))
    _x = getfield(S,a);
    if(isa(_x,VarShock))
      _iSHOCK +=1;
      _x.der = indep(Deriv4hs,_x.sv,3*_nVAR+_iSHOCK;)
    elseif(isa(_x,ArrayShock))
      sv = getval(_x)
      _x.der = reshape(indep(Deriv4hs,sv,3*_nVAR+_iSHOCK),size(sv))
      # _x.iName = _iSHOCK+1;
      nv = length(sv);
      _iSHOCK +=nv;
    else
      println(string(_x))
      println(typeof(_x))
      error("wrong element in variable structure")
    end
  end
end

function pos(v::Variable,t::TimeIndex)
  (I,V) = findnz(v[t].d)
  assert(length(I)==1);
  return I[1];
end
macro pos(var)
  ii = posInStruct(_varsStSt,var);
  if length(ii) == 1
    return ii[1]
  else
    return ii;
  end
end
# set all fields in a structure PStSt that contains the steady state elements of P:
function vars2stst!(PStSt,P,Sh)
  for a in fieldnames(typeof(PStSt))
    if in(a,fnt(Sh))# this must be name of a SHOCK; not contained in P
      #println(a)
      #println(typeof(getfield(Sh,a)))
      sv = getval(getfield(Sh,a))
      if isa(sv,Array)
        setfield!(PStSt,a,zeros(size(sv)))
      else
        setfield!(PStSt,a,0.0)
      end
    else
      setfield!(PStSt,a,getfield(getfield(P,a),:sv))
      # error(@printf("problem with element %s",string(a)))
    end
  end
end
function stst2vars!(P,PStSt)
  for a in fieldnames(typeof(P))
    setfield!(getfield(P,a),:sv,getfield(PStSt,a))
  end
end




mutable struct GlobalPars
  nStates::Int;
  iState::Array{Int};
  iStateCur::Array{Int};
  nGuessTr::Int;
  nGuessDyn::Int;
  nApprox::Int;
  iApprox::Array{Int};
  nApprox2::Int;
  nRealiz::Int;
  nCompSlack::Int;
  iTrace::Int;
  inNonlinear::Int;
  simplifyStochPerturb::Int;
  degreePerturbation::Int;
  enforce_prepro::Bool;
  functions_are_read::Bool;
  stst_is_compiled::Bool;
  linappr_is_compiled::Bool;
  nonlin_is_compiled::Bool;
  disableLog::Int;
  parameterFile::String;
  stretchSimul::Float64;
  numbClusters::Int; # number of Clusters in case clustering
  keepInBounds::Float64;
  iterSimulated::Int;  # at which iteratino to start simulations; default = big
  doTimeIter::Int;  # do time iterations (0 = none; 1 = standard; 2 = accelerated)
  maxTimeIter::Int;  # maximum number of iterations in time iteration
  ftolTimeIter::Float64;  # convergence tolerance in time iteration
  epsRegularize::Float64;  # parameter for Tychonov regularization; used in TimeIer
  RBF::Int;  
  homotopyPar::Array{Float64,1}
  isBinding::Array{Float64,1}
  lineWidthIR::Float64  # line width in impulse responses
end
function Base.show(io::IO, x::GlobalPars)
  printStruct(x)
end
if !@isdefined(_glob)
const _glob = GlobalPars(-1,Array{Int}(undef,0),Array{Int}(undef,0),-1,-1,-1,Array{Int}(undef,0),-1,-1,-1,0,0,
0, # simplify _s in symbolic diff.
2, # degree perturbation
false,false,false,false,false,
0, # disableLog
"", # parameterFile
1.0,100,0.0, 100000000,
0,100,1e-5,1e-12, 0, # params for TimeIter
Array{Float64}(undef,0),zeros(10),
5.0);
end



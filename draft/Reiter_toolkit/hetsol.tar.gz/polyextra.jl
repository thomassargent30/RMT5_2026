# allow additional basis functions, with powers chosen manually
# notice that this does not generate extra nodes, they must be 
function ComplPolyIndx2(d::Int,p::Int,selectFunc=0,Bextra=0)
  nC = nCoeff(d,p);

  B = fill(0,(d,nC));

  if(p==-2) # special case: order 1+
    for i=1:d
      B[i,i+1] = 1;
      B[i,d+i+1] = 2;
    end
  else
    z = fill(0,d)
    lauf = 0;
    while(z[1]<=p)
      for i=0:p+1
        z[d] = i;
        if(sum(z)>p)
          succ = 0;
          for m=d-1:-1:2
            if(sum(z[1:m])<p)
              z[m]=z[m]+1;
              z[m+1:d].=0;
              succ = 1;	    
              break;
            end
          end
          if(succ==0)
            z[1] = z[1]+1;
            z[2:d] .= 0;
          end
          break;
        end
        lauf += 1;
        B[:,lauf]= z;
      end
    end
    @assert(lauf==nC);
  end
  if isa(selectFunc,Function)
    doKeep = map(i->selectFunc(B[:,i]),1:size(B,2))
    B = B[:,doKeep]
    nC = size(B,2)
    println(size(B))
  end
  if isa(Bextra,AbstractArray{Int})
    B = [B Bextra]
    nC += size(Bextra,2)
  else
    @assert(Bextra==0) # make sure that input Bextra has right type
  end
  Changes = fill(0,(3,nC));
  # sort in ascending order of polynomial degree:
  indx = sortperm(vec(sum(B,dims=1)));
  #B = B[:,indx];  

  for j=2:nC
    b0 = B[:,j];
    iChange=argmax(b0);# which dimension to change  # indmin does not work
    degChange = b0[iChange];
    b0[iChange] = 0;
    succ = false;
    for k=1:j-1
      if(B[:,k]==b0)
        Changes[1,j] = k; # which basis element to start from
        Changes[2,j] = iChange;# which dimension to change
        Changes[3,j] = degChange;#factor to multiply with
        succ = true;
        break;
      end
    end
    @assert(succ);
  end
  Changes[1,1] = 0; # which basis element to start from
  Changes[2,1] = 0;# which dimension to change
  Changes[3,1] = 0;#factor to multiply with

  ChangesDer = Array{Int}(undef,4,0)
  for i=1:d
    has_i = mfind(B[i,:] .> 0)
    Bi = B[:,has_i]
    n = length(has_i)
    iBasis = Array{Int}(undef,n)
    for j=1:n
      bi = Bi[:,j];
      bi[i] = 0;
      iBas = findall(i->B[:,i] == bi,1:nC) # seems to be inefficient!!
      @assert(length(iBas)==1)
      iBasis[j] = iBas[1]
    end
    CDi = [fill(i,(n)) vec(has_i) vec(iBasis) vec(Bi[i,:])]'
    ChangesDer = [ChangesDer CDi]
  end
  @assert(d<1024)
  # lexicographic criterion: first the number of the coefficient, then dimension of derivative
  indx = ChangesDer[1,:] + 1024*ChangesDer[2,:] 
  ii = sortperm(indx)
  ChangesDer = ChangesDer[:,ii]
  return ComplPolyIndx(B,Changes,ChangesDer);
end
function add2PolyIndx(CPI::ComplPolyIndx,Bextra)
  lenBOld = size(CPI.B,2);
  # sort in ascending order of polynomial degree:
  indx = sortperm(vec(sum(Bextra,dims=1)));
  B = [CPI.B Bextra[:,indx]]
  #B = B[:,indx];  

  nC = size(Bextra,2);
  Changes = [CPI.Changes fill(0,(3,nC))];
  for j=lenBOld .+ (1:nC)
    b0 = B[:,j];
    iChange=argmax(b0);# which dimension to change  # indmin does not work
    degChange = b0[iChange];
    b0[iChange] = 0;
    succ = false;
    for k=1:j-1
      if(B[:,k]==b0)
        Changes[1,j] = k; # which basis element to start from
        Changes[2,j] = iChange;# which dimension to change
        Changes[3,j] = degChange;#factor to multiply with
        succ = true;
        break;
      end
    end
    @assert(succ);
  end

  global ChangesDer = CPI.ChangesDer;
  d = size(B,1);
  for i=1:d
    has_i = mfind(B[i,:] .> 0)
    Bi = B[:,has_i]
    n = length(has_i)
    iBasis = Array{Int}(undef,n)
    for j=1:n
      bi = Bi[:,j];
      bi[i] = 0;
      iBas = findall(i->B[:,i] == bi,1:nC)
      @assert(length(iBas)==1)
      iBasis[j] = iBas[1]
    end
    CDi = [fill(i,(n)) vec(has_i) vec(iBasis) vec(Bi[i,:])]'
    ChangesDer = [ChangesDer CDi]
  end
  @assert(d<1024)
  # lexicographic criterion: first the number of the coefficient, then dimension of derivative
  indx = ChangesDer[1,:] + 1024*ChangesDer[2,:] 
  ii = sortperm(indx)
  ChangesDer = ChangesDer[:,ii]
  return ComplPolyIndx(B,Changes,ChangesDer);
end
function indexB(dim,degree,selectDegree=degree,dimBig=dim,iiBig=1:dim)
  B = ComplPolyIndx(dim,degree).B
  ii = findall(vec(sum(B,dims=1)).>=selectDegree)
  Bbig = fill(0,dimBig,length(ii))
  Bbig[iiBig,:] = B[:,ii]
  return Bbig;
end



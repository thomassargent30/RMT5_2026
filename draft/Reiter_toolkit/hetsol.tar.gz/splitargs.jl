# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function removeSpace(str)
  m = match(r"^\s*(\S.*?)\s*$",str);
  if(m==nothing)
    return "";
  else
    return m.captures[1];
  end
end

function numbargs(str,pattern=',')
  if(str[1]=='(')
    a = splitargs(str[2:end-1],pattern)
  else
    a = splitargs(str,pattern)
  end
  return length(a)
end
function splitargs(str,pattern)
  plevel=0;
  ptype = Array{Char}(undef,100);
  n = length(str);
  startj = 1;
  args = Array{String}(undef,0)
  for i=1:n
    c = str[i]
    if(c=='(' || c=='[' || c=='{' )
      plevel+=1;
      ptype[plevel] = c;
      continue
    end
    if(c==')')
      if(plevel<1)
        println(str)
        error("nesting error");
      end
      if('(' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      continue
    end
    if(c==']')
      if(plevel<1)
        println(str)
        error("nesting error");
      end
      if('[' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      continue
    end
    if(c=='}')
      if(plevel<1)
        println(str)
        error("nesting error");
      end
      if('{' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      continue
    end
    if(plevel==0 && c==pattern) 
      argj = str[startj:i-1]
      push!(args,removeSpace(argj));
      startj = i+1;
      continue
    end
  end
  if(n>=startj)
    argj = str[startj:end];
    push!(args,removeSpace(argj));
  end
  return args;
end

function splitbyfunc(str,funcname)
  m = match(Regex(funcname * "\\("),str);
  if(m==nothing)
    println(str)
    println(funcname)
    error("no match in splitbyfunc");
  end
  bef = str[1:m.offset-1];
  plevel=0;
  ptype = Array{Char}(undef,100);
  n = length(str);
  args = Array{String}(undef,0)
  jStart = m.offset+length(funcname);
  for i=jStart:n
    c = str[i]
    if(c=='(' || c=='[' || c=='{' )
      plevel+=1;
      ptype[plevel] = c;
      continue
    end
    if(c==')')
      if('(' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      if(plevel<0)
        error("nesting error");
      end
      if(plevel==0)
        txtargs = str[jStart+1:i-1];
        aft = str[i+1:end]
        args = splitargs(txtargs,',');
        return (bef,args,aft)
      end
      continue
    end
    if(c==']')
      if('[' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      if(plevel<0)
        error("nesting error");
      end
      continue
    end
    if(c=='}')
      if('{' != ptype[plevel])
        error(@sprintf("wrong parenthesis atn str: %c %c",ptype[plevel],c));
      end
      plevel-=1;
      if(plevel<0)
        error("nesting error");
      end
      continue
    end
  end
end

function expandSum(func::String,i1s::String,i2s::String)
  i1 = Core.eval(parse(i1s));
  i2 = Core.eval(parse(i2s));
  if(i2<i1)
    return "0";
  else
    m = match(r"^\s*(\w+)\s*->(.*)$",func)
    if(m==nothing)
      m = match(r"^\s*\(\s*(\w+)\s*->(.*)\)\s*$",func)
    end
    if(m==nothing)
      println(func)
      error(" not a sum expression")
    end
    var = m.captures[1];
    expr = m.captures[2];
    re = Regex("\\b" * var * "\\b")
    txt = "(";
    for i=i1:i2
      expr_i = replace(expr,re,@sprintf("%d",i))
      if(i==i1)
        txt *= expr_i
      else
        txt*= "+" * expr_i;
      end
    end
  end
  return txt * ")"
end

function replaceFuncInTxt(txt::String,func,replacement)
  re = Regex("\\b" * func * "\\(");
  while(occursin(re,txt))
    (bef,args,aft) = splitbyfunc(txt,func);
    repl = replacement(args...)
    txt = bef * repl * aft;
  end
  return txt;
end



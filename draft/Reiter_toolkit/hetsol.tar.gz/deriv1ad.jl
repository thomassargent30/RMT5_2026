# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using SparseArrays
using Printf
abstract type Deriv1 <: Number end
import Base.conj
conj(x::Deriv1) = x;
if !@isdefined Deriv1F
  struct Deriv1F{T} <: Deriv1
    v::Float64;
    d::NTuple{T,Float64};
    # d::Vec{T,Float64};
  end
  mutable struct Deriv1a{T} <: Deriv1
    v::Float64;
    d::Array{Float64,1};
  end
  mutable struct Deriv1S{T} <: Deriv1
    v::Float64;
    d::SparseVector{Float64,Int};
    # d::SparseMatrixCSC{Float64,Int};
  end
end
import Base.convert;
import Base.promote_rule;
import Base.isfinite

Base.abs2(x::Deriv1a{N}) where N = x*x
Base.real(x::Deriv1a{N}) where N = x
Base.sign(x::Deriv1a{N}) where N = sign(getval(x))
Base.copysign(x::Deriv1a{N},y::Deriv1a{N}) where N = sign(x)==sign(y) ? x : -x

@generated function zerotuple(::Type{Val{T}}) where T
  return Expr(:tuple,zeros(T)...)
end
@generated function unittuple(::Type{Val{T}},::Type{Val{i}}) where {T,i}
  A = zeros(T)
  A[i] = 1.0;
  return Expr(:tuple,A...)
end
# convert(::Type{Deriv1F{T}},x::Real) where T = Deriv1F(convert(Float64,x) where T,Vec{T}(0.0))
convert(::Type{Deriv1F{T}},x::Real) where T = Deriv1F{T}(convert(Float64,x), zerotuple(Val{T}))
convert(::Type{Deriv1a{T}},x::Real) where T = Deriv1a{T}(convert(Float64,x),zeros(T));
convert(::Type{Deriv1S{T}},x::Real) where T = Deriv1S{T}(x,spzeros(T))
nIndep(::Type{Deriv1F{T}}) where T = T
nIndep(::Type{Deriv1a{T}}) where T = T
nIndep(::Type{Deriv1S{T}}) where T = T
Deriv1F(::Type{Val{T}},v::Real,d::AbstractArray{Float64,1}) where T = Deriv1F{T}(convert(Float64,v), arr2tuple(Val{T},d))
Deriv1a(::Type{Val{T}},v::Real,d::AbstractArray{Float64,1}) where T = Deriv1a{T}(convert(Float64,v), d)


function indep(::Type{Deriv1a{T}},v::Float64,i::Int) where T
  d = zeros(T);
  d[i] = 1.0;
  return Deriv1a{T}(v,d);
end
function indep(::Type{Deriv1F{T}},v::Float64,i::Int) where T
  return Deriv1F{T}(v,unittuple(Val{T},Val{i}))
end
import Base.+
@generated function +(a::NTuple{T,Real},b::NTuple{T,Real}) where T
  A = Array{Any}(undef,0)
  for i=1:T
    push!(A,Expr(:call,:+,Expr(:ref,:a,i),Expr(:ref,:b,i)))
  end
  return Expr(:tuple,A...)
end
import Base.*
@generated function *(a::NTuple{T,Real},b::Real) where T
  B = Array{Any}(undef,0)
  for i=1:T
    push!(B,Expr(:call,:*,Expr(:ref,:a,i),:b))
  end
  return Expr(:tuple,B...)
end
@generated function addmul2(a::NTuple{T,Real},b::Real,c::NTuple{T,Real},d::Real) where T
  B = Array{Any}(undef,0)
  for i=1:T
    push!(B,
    Expr(:call,:+,
    Expr(:call,:*,Expr(:ref,:a,i),:b),
    Expr(:call,:*,Expr(:ref,:c,i),:d)
    ))
  end
  return Expr(:tuple,B...)
end
function indep(::Type{Deriv1F{T}},v::Array{Float64,1}) where T
  a = zeros(T)
  n = length(v)
  @assert(T == n)
  D = Array{Deriv1F{T}}(undef,n)
  for i=1:n
    a[i] = 1;
    D[i] = Deriv1F{T}(v[i],arr2tuple(Val{T},a))
    a[i] = 0;
  end
  return D;
  # return Deriv1F{T}(v,convert(Vec{T},a))
end
function indep(::Type{Deriv1S{T}},v::Float64,i::Int) where T
  return Deriv1S{T}(v,sparsevec([i],[1.0],T));
end
indep(::Type{Deriv1S{T}},v::Float64,d::Array{Float64,1},ii::Array{Int,1}) where T = Deriv1S{T}(v,sparsevec(ii,d,T))
indep(::Type{Deriv1S{T}},v::Float64,d::Array{Float64,1},ii::UnitRange{Int}) where T = Deriv1S{T}(v,sparsevec(ii,d,T))
function getjac!(J::Array{Float64,2},x::Array{Deriv1a{T}}) where T
  n = length(x);
  if(!(size(J)==(n,T)))
    @printf("%d,%d vs. %d,%d\n",size(J,1),size(J,2),n,T)
    error("wrong size in getjac")
  end
  for i=1:n
    xi = x[i]
    for j=1:T
      J[i,j] = xi.d[j]
    end
  end
  return J;
end
getjac(x::Deriv1a{T}) where T = x.d
function getjac(x::Array{Deriv1a{T}}) where T
  n = length(x);
  J = Array{Float64}(undef,n,T);
  getjac!(J,x)
  return J;
end

getjac(x::Deriv1F{T}) where T = collect(x.d)
function getjac!(J::Array{Float64,2},x::Array{Deriv1F{T}}) where T
  n = length(x);
  if(!(size(J)==(n,T)))
    @printf("%d,%d vs. %d,%d\n",size(J,1),size(J,2),n,T)
    error("wrong size in getjac")
  end
  for i=1:n
    xi = x[i]
    for j=1:T
      J[i,j] = xi.d[j]
    end
  end
end
function getjac(x::Array{Deriv1F{T}}) where T
  n = length(x);
  J = Array{Float64}(undef,n,T);
  getjac!(J,x)
  return J;
end

getjac(x::Deriv1S{T}) where T = x.d
function getjac(x::Array{Deriv1S{T}}) where T
  n = length(x);
  p = length(x[1].d);
  # println([n p])
  nz = 0;
  for i=1:n
    nz += nnz(x[i].d)
  end
  iRow = Array{Int}(undef,nz);
  iCol = Array{Int}(undef,nz);
  Val = Array{Float64}(undef,nz);
  nz = 0;
  for i=1:n
    (I,V) = findnz(x[i].d)
    iz =  length(I)
    # iz =  nnz(x[i].d)
    iRow[nz+1:nz+iz] = i;
    iCol[nz+1:nz+iz] = I
    Val[nz+1:nz+iz] = V
    nz += iz;
  end
  nz2 = length(iCol)
  if(nz<nz2) # can sometimes happen: nnz finds more than findnz!
    for i=nz+1:nz2
      iRow[i] = 1;
      iCol[i] = 1;
      Val[i] = 0.;
    end
  end
  return sparse(iRow,iCol,Val,n,p);
end
# the same, but now transposed:
function getjacTr!(J::Array{Float64,2},x::Array{Deriv1a{T}}) where T
  n = length(x);
  if(!(size(J)==(T,n)))
    @printf("%d,%d vs. %d,%d\n",size(J,1),size(J,2),n,T)
    error("wrong size in getjacTr")
  end
  for i=1:n
    xi = x[i]
    for j=1:T
      J[j,i] = xi.d[j]
    end
  end
  return J;
end
getjacTr(x::Deriv1a{T}) where T = x.d
function getjacTr(x::Array{Deriv1a{T}}) where T
  n = length(x);
  J = Array{Float64}(undef,T,n);
  getjacTr!(J,x)
  return J;
end

getjacTr(x::Deriv1F{T}) where T = collect(x.d)
function getjacTr!(J::Array{Float64,2},x::Array{Deriv1F{T}}) where T
  n = length(x);
  if(!(size(J)==(T,n)))
    @printf("%d,%d vs. %d,%d\n",size(J,1),size(J,2),n,T)
    error("wrong size in getjacTr")
  end
  for i=1:n
    xi = x[i]
    for j=1:T
      J[j,i] = xi.d[j]
    end
  end
end
function getjacTr(x::Array{Deriv1F{T}}) where T
  n = length(x);
  J = Array{Float64}(undef,T,n);
  getjacTr!(J,x)
  return J;
end

function Deriv1F(v2::Float64,D1::Deriv1F{T},fac1::Float64) where T
  return Deriv1F(v2,D1.d*fac1)
end
function Deriv1F(v2::Float64,D1::Deriv1F{T},fac1::Float64,D2::Deriv1F{T},fac2::Float64) where T
  return Deriv1F(v2,addmul2(D1.d,fac1 , D2.d,fac2))
  # return Deriv1F(v2,D1.d*fac1 + D2.d*fac2)
end
function Deriv1S(v2::Float64,D1::Deriv1S{T},fac1::Float64) where T
  return Deriv1S{T}(v2,D1.d*fac1)
end
function Deriv1S(v2::Float64,D1::Deriv1S{T},fac1::Float64,D2::Deriv1S{T},fac2::Float64) where T
  return Deriv1S{T}(v2,D1.d*fac1 + D2.d*fac2)
end
function Deriv1a(v2::Float64,D1::Deriv1a{T},fac1::Float64) where T
  z = Deriv1a{T}(v2,Array{Float64}(undef,T))
  @inbounds @simd for i=1:T
    z.d[i] = fac1*D1.d[i];
  end
  return z
end
function Deriv1a(v2::Float64,D1::Deriv1a{T},fac1::Float64,D2::Deriv1a{T},fac2::Float64) where T
  z = Deriv1a{T}(v2,Array{Float64}(undef,T))
  @inbounds @simd for i=1:T
    z.d[i] = fac1*D1.d[i] + fac2*D2.d[i];
  end
  return z
end

for Der1 in (:Deriv1F,:Deriv1a,:Deriv1S)
  @eval begin
    # $Der1(x::Float64) where T = convert($Der1,x);
    # Base.zero(x::$Der1{T}) where T = $Der1{T}(0.0);
    promote_rule(::Type{$Der1{T}}, ::Type{Float64} ) where T = $Der1{T}
    promote_rule(::Type{$Der1{T}}, ::Type{Int} ) where T = $Der1{T}
    getval(x::$Der1{T}) where T = x.v
    function getval(x::Array{$Der1{T}}) where T
      nn = size(x)
      n = length(x);
      v = zeros(nn);
      for i=1:n
        v[i] = x[i].v;
      end
      return v;
    end
    isfinite(x::$Der1{T}) where T = isfinite(x.v);
  end
end
for Der1 in (:Deriv1a,:Deriv1S)
  @eval begin
    function indep(::Type{$Der1{T}},v::Array{Float64}) where T
      n = length(v)
      @assert(T == n)
      D = Array{$Der1{T}}(undef,n)
      for i=1:n
        D[i] = indep($Der1{T},v[i],i)
      end
      return D;
    end
    function indep(::Type{$Der1{T}},v::Array{Float64},offs::Int) where T
      nv = length(v);
      nI = T
      @assert(nv+offs<=nI);
      D = Array{$Der1{T}}(undef,nv)
      for i=1:nv
        D[i] = indep($Der1{T},v[i],offs+i)
      end
      return D;
    end
  end
end




macro defD1FFunc1(Der1,ff,ex1)
  return esc(
  quote
    function $ff(X::$Der1{n}) where n
      x = X.v;
      dx = $ex1;
      return $Der1($ff(x),X,dx);
    end
  end
  )
end
macro defD1FFunc2(Der1,op,ex1,ex2)
  return esc(
  quote
    function $op(X::$Der1{n}, Y::$Der1{n}) where n
      x = X.v;
      y = Y.v;
      dx = $ex1;
      dy = $ex2;
      return $Der1($op(x,y),X,dx,Y,dy);
    end
    function $op(X::$Der1{n}, y::Float64) where n
      x = X.v;
      dx = $ex1;
      return $Der1($op(x,y),X,dx);
    end
    function $op(x::Float64, Y::$Der1{n}) where n
      y = Y.v;
      dy = $ex2;
      return $Der1($op(x,y),Y,dy);
    end
    $op(X::$Der1{n}, y::Int) where n = $op(X,convert(Float64,y));
    $op(x::Int, Y::$Der1{n}) where n = $op(convert(Float64,x), Y);
  end
  )
end
macro defD1FBool(Der1,fop)
  return esc(
  quote
    function $fop(x::$Der1{n}, y::$Der1{n}) where n
      return  $fop(x.v,y.v)
    end
    function $fop(x::$Der1{n}, yv::Float64) where n
      return  $fop(x.v,yv)
    end
    function $fop(xv::Float64,y::$Der1{n}) where n
      return  $fop(xv,y.v)
    end
    function $fop(x::$Der1{n}, yv::Int) where n
      return  $fop(x.v,yv)
    end
    function $fop(xv::Int,y::$Der1{n}) where n
      return  $fop(xv,y.v)
    end
  end
  )
end

import Base.+
import Base.-
import Base.*
import Base./
import Base.^
import Base.==
import Base.!=
import Base.>
import Base.>=
import Base.<
import Base.<=
import Base.min
import Base.max
import Base.convert;
import Base.zero;

import Base.exp
import Base.sqrt
import Base.log
import Base.abs
import SpecialFunctions.erf

for Der1 in (:Deriv1F,:Deriv1a,:Deriv1S)
  @eval begin
    @defD1FFunc2($Der1,*,y,x);
    @defD1FFunc2($Der1,/,1.0/y,-x/y^2);
    @defD1FFunc2($Der1,-,1.0,-1.0);
    @defD1FFunc2($Der1,+,1.0,1.0);
    @defD1FFunc2($Der1,^,y*(x^(y-1)),(x^y)*log(x));
    @defD1FFunc2($Der1,min,x<y ? 1.0 : 0.0,x<y ? 0.0 : 1.0);
    @defD1FFunc2($Der1,max,x>y ? 1.0 : 0.0,x>y ? 0.0 : 1.0);
    @defD1FFunc1($Der1,-,-1.0);
    @defD1FFunc1($Der1,sqrt,0.5*x^(-0.5));
    @defD1FFunc1($Der1,exp,exp(x));
    @defD1FFunc1($Der1,log,1.0/x);
    @defD1FFunc1($Der1,abs,x>=0.0 ? 1.0 : -1.0);
    @defD1FFunc1($Der1,erf,2/sqrt(acos(-1))*exp(-x^2));
    @defD1FBool($Der1,==);
    @defD1FBool($Der1,!=);
    @defD1FBool($Der1,>);
    @defD1FBool($Der1,>=);
    @defD1FBool($Der1,<);
    @defD1FBool($Der1,<=);
  end
end

# choose which type of Deriv1 to use, depending on size of gradient:
function deriv1aType(n::Int)
  if(n<=30)
    return Deriv1F{n} # allocate on stack
  else
    return Deriv1a{n} # allocate on heap, to avoid stack overflow
  end
end

function sumv(x::Array{Deriv1a{T}}) where T
  y = zero(Deriv1a{T})
  for i=1:length(x)
    xi = x[i];
    y.v += xi.v
    @simd for j=1:T
      @inbounds y.d[j] += xi.d[j]
    end
  end
  return y;
end
if !@isdefined RowView
  struct RowView{T} <: AbstractArray{T,1}
    A::Array{T,2}
    iRow::Int
  end
  struct ColView{T} <: AbstractArray{T,1}
    A::Array{T,2}
    iCol::Int
  end
end
import Base.getindex
getindex(cv::RowView{T},i::Int) where T = cv.A[cv.iRow,i];
getindex(cv::ColView{T},i::Int) where T = cv.A[i,cv.iCol];
import Base.size
size(cv::ColView{T}) where T = (size(cv.A,1),)


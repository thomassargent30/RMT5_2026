# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

arg1funcs = fill(:a,(0,))
push!(arg1funcs,:log)
log(x) = Prim(Expr(:call,:log,x))
push!(arg1funcs,:exp)
exp(x) = Prim(Expr(:call,:exp,x))
push!(arg1funcs,:erf)
erf(x) = Prim(Expr(:call,:erf,x))
push!(arg1funcs,:sin)
sin(x) = Prim(Expr(:call,:sin,x))
push!(arg1funcs,:cos)
cos(x) = Prim(Expr(:call,:cos,x))
push!(arg1funcs,:tan)
tan(x) = Prim(Expr(:call,:tan,x))
push!(arg1funcs,:asin)
asin(x) = Prim(Expr(:call,:asin,x))
push!(arg1funcs,:acos)
acos(x) = Prim(Expr(:call,:acos,x))
push!(arg1funcs,:atan)
atan(x) = Prim(Expr(:call,:atan,x))
push!(arg1funcs,:sinh)
sinh(x) = Prim(Expr(:call,:sinh,x))
push!(arg1funcs,:cosh)
cosh(x) = Prim(Expr(:call,:cosh,x))
push!(arg1funcs,:tanh)
tanh(x) = Prim(Expr(:call,:tanh,x))
push!(arg1funcs,:asinh)
asinh(x) = Prim(Expr(:call,:asinh,x))
push!(arg1funcs,:acosh)
acosh(x) = Prim(Expr(:call,:acosh,x))
push!(arg1funcs,:atanh)
atanh(x) = Prim(Expr(:call,:atanh,x))
function diff_(S::Prim,z::Prim)
  if isa(S.s,Symbol)
    if S==z
      return 1
    else
      return 0;
    end
  end
  if S.s.head==:ref
    if S==z
      return 1
    else
      return 0;
    end
  else
    @assert(S.s.head==:call)
    func = S.s.args[1]
    if func==:ifelse
      cond = S.s.args[2]
      x = S.s.args[3]
      dx = diff_(x,z)
      y = S.s.args[4]
      dy = diff_(y,z)
      return Prim(Expr(:call,:ifelse,cond,dx,dy))
    end
    if func in arg1funcs
    x = S.s.args[2]
    dx = diff_(x,z)
    if func==:log
      df = 1/x
    elseif func==:exp
      df = exp(x)
    elseif func==:erf
      df = 2*exp(-x^2)/sqrt(pi)
    elseif func==:sin
      df = cos(x)
    elseif func==:cos
      df = -sin(x)
    elseif func==:tan
      df = tan(x)^2 + 1
    elseif func==:asin
      df = 1/sqrt(-x^2 + 1)
    elseif func==:acos
      df = -1/sqrt(-x^2 + 1)
    elseif func==:atan
      df = 1/(x^2 + 1)
    elseif func==:sinh
      df = cosh(x)
    elseif func==:cosh
      df = sinh(x)
    elseif func==:tanh
      df = -tanh(x)^2 + 1
    elseif func==:asinh
      df = 1/sqrt(x^2 + 1)
    elseif func==:acosh
      df = 1/sqrt(x^2 - 1)
    elseif func==:atanh
      df = 1/(-x^2 + 1)
  end
  return df*dx
  
    else # undefined funcs
      args = map(x->diff_(x,z),S.s.args[2:end])
      s = 0
      for i=2:length(S.s.args)
        df = diff_(S.s.args[i],z)
        fi = Symbol(func,"_",i-1)
        s = s + Prim(Expr(:call,fi,S.s.args[i])) * df
      end
      return s;
end
  end
end

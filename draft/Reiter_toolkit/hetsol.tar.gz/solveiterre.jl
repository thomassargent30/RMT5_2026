# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using SuiteSparse
#include("solvers.jl")
function sherman(b, A,U,VT)
  n = size(U,2);
  Ab = A\b;
  c = VT*Ab
  c = (meye(n,n)+VT*(A\U))\c;
  c = A\(U*c);
  x = Ab - c;
  return x;
end
function shermanIdent(b, U,VT)
  n = size(U,2);
  c = VT*b
  c = (meye(n,n)+VT*U)\c;
  c = (U*c);
  x = b - c;
  return x;
end
function sherman(b, A,U,VT,IVGAUfact)
  Ab = A\b;
  c = VT*Ab
  c = IVGAUfact\c;
  c = A\(U*c);
  x = Ab - c;
  return x;
end

struct SysmatIter
  GamInv;
  Lambda;
  U;
  VT;
  IVGAUfact
end
import Base.*
*(A::SysmatIter,x) = sherman(A.Lambda*(-x),A.GamInv,A.U,A.VT,A.IVGAUfact);
nVar(A::SysmatIter) = size(A.U,1);
function nVar(A::AbstractArray{Float64,2})
  (nr,nc) = size(A)
  @assert(nr==nc)
  return nr;
end
function Base.getindex(A::SysmatIter,i::Int)
  x = zeros(nVar(A));
  x[i] = 1;
  return A*x;
end
function Base.getindex(A::SysmatIter,i::Int,j::Int)
  x = zeros(nVar(A));
  x[j] = 1;
  return (A*x)[i];
end

if !@isdefined(IterSol)
  struct IterSol
    GamInv::SuiteSparse.UMFPACK.UmfpackLU{Float64,Int64}
    basisV::Array{Float64,2}
    F0::Array{Float64,2}
    iiF::Array{Int,1}
  end
end
function solveiter(model::LinModel,
                   redS::ReduceState, redV::ReduceValue; # info on state and value reduction
                   redV2=0,
                   doPrint=100,tolResid=1e-3)

  Lambda = model.Lambda
  GamInv = lu(model.Gamma);


  n = size(Lambda,1)
  nH = size(redS.selectMom,1);
  iiS = findnzcols(Lambda);
  iiV = union(findnzcols(model.Phi),redV.ivar)
  if isa(redV2,ReduceValue)
    iiV = union(iiV,redV2.ivar)
    basisV = blockdiag(redV.basis,redV2.basis)
  else
    basisV = redV.basis
  end
  PhiBasis = model.Phi[:,iiV]*basisV;
  nJ = size(PhiBasis,2)



  Forec = zeros(nJ,nH)
  LamProxy = Array(Lambda[:,iiS]*redS.proxyD);
  selectS = spzeros(nH,size(Lambda,1));
  selectS[:,iiS] = redS.selectMom;


  GILamProxy = GamInv\LamProxy;
  GIPhiBasis = GamInv\PhiBasis;
  momGILamProxy = selectS*GILamProxy;
  momGIPhiBasis = selectS*GIPhiBasis;

  VprojGILamProxy = redV.project*GILamProxy[iiV,:];
  VprojGIPhiBasis = redV.project*GIPhiBasis[iiV,:];

  resid = 1;
  maxIter = 10000;  # maximum number of iterations
  local resid1
  for i=1:maxIter
    if dimen(redV)>dimen(redS)
      c = (meye(nH,nH)+momGIPhiBasis*Forec)\(momGILamProxy)
    else
      c = shermanIdent(momGILamProxy,momGIPhiBasis,Forec);
    end
    # @show cond(meye(nH,nH)+momGIPhiBasis*Forec); error("done");
    #Fnew = -GILamProxy + GIPhiBasis *(Forec*c); 
    #F3 = project * Fnew[iiV,:];
    F3 = -VprojGILamProxy + VprojGIPhiBasis *(Forec*c); 
    resid = maximum(abs,F3-Forec);
    if i==1
      resid1 = resid;
      tolResid *= resid; # set it relative to initial error
      println("tolResid set to $tolResid")
    end
    if i==1000 && resid>resid1
      error("solveier does not converge; residual increased from $resid1 to $resid")
    end
    if(doPrint>0 && i%doPrint==0)
      @printf("iteration %d in solveiterRE; residual is %e\n",i,resid);
    end
    Forec = F3;
    if(resid<=tolResid)
      break;
    end
  end
  return IterSol(GamInv,basisV,Forec,iiV)
  # return (Forec,resid)
end
function sysmat(mod::LinModel,sol::IterSol,redS::ReduceState)
  GamInv = sol.GamInv
  F = sol.basisV * sol.F0
  iiF = sol.iiF;
  H = redS.selectMom;

  Phi = mod.Phi
  ForecSeries = F*H;
  (d,m) = size(F);
  # in the inner part, the term UV' equals
  # Phi[:,iiF]*F*H
  # n*d d*m m*n
  n = nVar(mod)
  if(isempty(H))
    #iiS = findnzcols(mod.Lambda);
    #H = eyeii(n,iiS);
    H = mspeye(n)
  elseif size(H,2)!=n
    H = hcat(H,spzeros(size(H,1),n-size(H,2)))
  end
  if(d<m)  # Case 1: d<m
    println("use case 1");
    U = mod.Phi[:,iiF];
    VT= F*H
    IVGAUfact = lu(meye(d,d)+F*H*(GamInv\Array(mod.Phi[:,iiF])))
  else  # Case 2: m<d
    println("use case 2");
    U = mod.Phi[:,iiF]*F; 
    VT= H
    IVGAUfact = lu(meye(m,m)+H*(GamInv\U))
  end
  A = SysmatIter( GamInv, mod.Lambda,U, VT, IVGAUfact);
  B = -sherman(mod.Psi,GamInv,U,VT,IVGAUfact);
  return (A,B)
end

#break solution problem in smaller problems, to avoid memory error:
function solve_stepwise(selectRows,A,b)
  (nrb,nc) = size(b);
  nr = size(selectRows,1);
  x = zeros(nr,nc);
  n1 = 100; # take 100 columns in one step
  mstep = div(nc,n1);
  for i=1:mstep
    x[:,(i-1)*n1+1:i*n1] = selectRows*(A\Array(b[:,(i-1)*n1+1:i*n1]));
  end
  if(nc>mstep*n1)
    x[:,mstep*n1+1:end] = selectRows*(A\Array(b[:,mstep*n1+1:end]));
  end
  return x;
end

# Inputs:
#   iiJ:   index of variables appearing in expectations
#   HAggr: aggregation matrix for "moments": m = HAggr*x (default: identity matrix)
#   PD:    proxy distribution in case of aggregation (only necessary if HAggr!=meye)
#          approximately x(states) = PD*m; has as many rows as there are state variables
# Outputs:
#   Forec:  forecast matrix
#   resid:  deviation from fixed point
function solveiterRE(GCinv,Lambda,Phi,Psi;
                     tolResid=1e-6,iiJ=[],HAggr=[],PD=[],Forec=[],doPrint=100)
  @assert(tolResid<1e-3)
  global selectS
  if(isempty(iiJ))
    iiJ = findnzcols(Phi); # all variables that appear in time t+1
  end
  iiS = findnzcols(Lambda);

  if(isempty(HAggr))
    nStates = length(iiS);
    nH = nStates;
    HAggr = mspeye(nH,nH);
    GlagPD = Array(Lambda[:,iiS]);
  else
    nH = size(HAggr,1);
    GlagPD = Array(Lambda[:,iiS]*PD);
  end

  selectS = spzeros(nH,size(Lambda,1));
  selectS[:,iiS] = HAggr;
  if(isempty(Forec))
    nJ = length(iiJ);
    Forec = zeros(nJ,nH)
  end

  #Lam = GCinv\GlagPD;
  #Gam = GCinv\Array(Phi[:,iiJ]);
  n = size(Lambda,1)
  sLam = solve_stepwise(selectS,GCinv,GlagPD);
  sGam = solve_stepwise(selectS,GCinv,Phi[:,iiJ]);
  Lam = solve_stepwise(eyeii(n,iiJ),GCinv,GlagPD);
  Gam = solve_stepwise(eyeii(n,iiJ),GCinv,Phi[:,iiJ]);


  resid = 1;
  maxIter = 100000;  # maximum number of iterations
  for i=1:maxIter
    c = shermanIdent(sLam, sGam,Forec)
    # c = (meye(nH,nH)+sGam*Forec)\(sLam)
    F3 = -Lam + Gam *(Forec*c); 
    resid = maximum(abs,F3-Forec);
    if(doPrint>0 && i%doPrint==0)
      @printf("iteration %d in solveiterRE; residual is %e\n",i,resid);
    end
    Forec = F3;
    if(resid<=tolResid)
      break;
    end
  end
  return (Forec,resid)
end
function solveIter(g0,l0,f0,h0,p0)
  g0inv = lu(g0)
  (F1,resid) = solveiterRE(g0inv, l0,f0,h0);
  (A2,B2) = iter2ab(g0inv, l0,f0,h0,F1);
end
# old version, keep for comparison
## function simulate(HA,Hstats,Hser,iiError,HCinv,Hl,Hf,Fbig,Fsmall,eps)
##   nVAR = size(Hf,1);
##   HAzero = [HA spzeros(size(HA,1),nVAR-nStates)]
##   nHz = size(HAzero,1);
## 
## 
##   HFF = Hf*Fsmall
##   x = zeros(nVAR);
##   T = size(eps,2);
##   SM0 = 0.;
##   SM01 = 0.;
##   SM11 = 0.;
##   IVGAUfact = lu(meye(nHz,nHz)+HAzero*(HCinv\HFF))
##   nSer = size(Hser,1);
##   series = zeros(T,nSer);
##   errorser = zeros(T,length(iiError));
##   for i=1:T
##     xLast = x;
##     xs = x[1:nStates]
##     xExp = Fbig*(HA*xs)
##     x = - sherman(Hl*xs,HCinv,HFF,HAzero,IVGAUfact);
##     experror = x-xExp;
##     errorser[i,:] = (experror[iiError])';
##     x += Bbin*eps[:,i];
##     series[i,:] = (Hser*x)';
##     if(i%1000 == 0)
##       @printf("i = %d\n",i);
##     end
##     #y = x[1:nStates]; SM += y*(Hstats*y)';
##     m0 = Hstats*x;
##     m1 = Hstats*xLast;
##     SM0 += x*m0';   # EXP 
##     SM01 += m0*m1';
##     SM11 += m1*m1';
##   end
##   SM0 = SM0./T;
##   SM01 = SM01./T;
##   SM11 = SM11./T;
##   #hsh = Hstats*SM;
##   return (series,errorser,SM0,SM01,SM11)
## end


function solveiterRE2(GCinv,Lambda,Phi2,Psi,tolResid,HAggr,PD,iiV,WVal,doPrint=100)
  @assert(tolResid<1e-3)
  n = size(Lambda,1)
  nH = size(HAggr,1);
  nJ = size(Phi2,2)
  iiS = findnzcols(Lambda);

  Forec = zeros(nJ,nH)
  GlagPD = Array(Lambda[:,iiS]*PD);
  selectS = spzeros(nH,size(Lambda,1));
  selectS[:,iiS] = HAggr;


  Lam = GCinv\GlagPD;
  Gam = GCinv\Phi2;
  sLam = selectS*Lam;
  sGam = selectS*Gam;

  LamSmall = WVal*Lam[iiV,:];
  GamSmall = WVal*Gam[iiV,:];

  resid = 1;
  maxIter = 10000;  # maximum number of iterations
  for i=1:maxIter
    # @time c = (meye(nH,nH)+sGam*Forec)\(sLam)
    # c = sherman(sLam,mspeye(nH,nH),sGam,Forec);
    c = shermanIdent(sLam,sGam,Forec);
    #Fnew = -Lam + Gam *(Forec*c); 
    #F3 = WVal * Fnew[iiV,:];
    F3 = -LamSmall + GamSmall *(Forec*c); 
    resid = maximum(abs,F3-Forec);
    if i==1
      tolResid *= resid; # set it relative to initial error
      println("tolResid set to $tolResid")
    end
    if(doPrint>0 && i%doPrint==0)
      @printf("iteration %d in solveiterRE; residual is %e\n",i,resid);
    end
    Forec = F3;
    if(resid<=tolResid)
      break;
    end
  end
  return (Forec,resid)
end

# compute solution matrices A,B for reduced model:
# notice: input H must be the big version, as function of all x, not s
function reducAB(mod,F,H,PD,iiF=[])
  n = size(mod.Gamma,1);
  (nr,nc) = size(H);
  if nc<n
    H = hcat(H,zeros(nr,n-nc));
  end
  Phi = mod.Phi
  if(isempty(iiF))
    iiF = findnzcols(Phi); # variables in forward equations
  end
  (d,m) = size(F);
  # in the inner part, the term UV' equals
  # Phi[:,iiF]*F*H
  # n*d d*m m*n
  U = mod.Phi[:,iiF]*F; 
  VT= H
  IVGAUfact = lu(meye(m,m)+H*(GamInv\U))

  # x = -sherman(mod.Lambda*x+mod.Psi*eps[:,t],GamInv,U,VT,IVGAUfact);
  iiS = findnzcols(mod.Lambda);
  Abig = -sherman(mod.Lambda[:,iiS]*PD,GamInv,U,VT,IVGAUfact);
  Bbig = -sherman(mod.Psi,GamInv,U,VT,IVGAUfact);
  A = H*Abig;
  B = H*Bbig;
  return (A,B,Abig,Bbig)
end


function simulate(mod::LinModel,F,H,eps;
                  x::Array{Float64,1}=zeros(nVar(mod)),
                  Hser::SparseMatrixCSC{Float64,Int64}=mspeye(nVar(mod)),
                  iiF::AbstractArray{Int,1}=findnzcols(mod.Phi),
                  doAccuracy::Bool=false)
  Phi = mod.Phi
  ForecSeries = F*H;
  (d,m) = size(F);
  # in the inner part, the term UV' equals
  # Phi[:,iiF]*F*H
  # n*d d*m m*n
  n = nVar(mod)
  if(isempty(H))
    #iiS = findnzcols(mod.Lambda);
    #H = eyeii(n,iiS);
    H = mspeye(n)
  elseif size(H,2)!=n
    H = hcat(H,spzeros(size(H,1),n-size(H,2)))
  end
  if(d<m)  # Case 1: d<m
    println("use case 1");
    U = mod.Phi[:,iiF];
    VT= F*H
    IVGAUfact = lu(meye(d,d)+F*H*(GamInv\Array(mod.Phi[:,iiF])))
  else  # Case 2: m<d
    println("use case 2");
    U = mod.Phi[:,iiF]*F; 
    VT= H
    IVGAUfact = lu(meye(m,m)+H*(GamInv\U))
  end
  T = size(eps,2);
  nSer = size(Hser,1);
  series = zeros(nSer,T);
  if doAccuracy
    expser = zeros(4,T);
  end
  for t=1:T
    # x = -sherman(mod.Lambda*x+mod.Psi*eps[:,t],GamInv,U,VT,IVGAUfact);
    # separate expected component from innovation:
    if doAccuracy
      xForec = ForecSeries*x
      x2 = -sherman(hcat(mod.Lambda*x,mod.Psi*eps[:,t]),GamInv,U,VT,IVGAUfact);
      xRealiz = x2[iiF,1];
      x = sum(x2,dims=2)
      Hx2 = Hser*x2;
      series[:,t] = sum(Hx2,dims=2)
      xError = xRealiz-xForec
      expser[:,t] = [mean(xError);mean(abs.(xError)); maximum(abs,xError); maximum(abs,diff(xError))]
    else
      x = -sherman(mod.Lambda*x+mod.Psi*eps[:,t],GamInv,U,VT,IVGAUfact);
      series[:,t] = (Hser*x)
    end
    if(t%100 == 0)
      @printf("t = %d\n",t);
    end
  end
  if doAccuracy
    return (series,expser);
  else
    return series;
  end
end

function simulate(A,B,eps;
                  x::Array{Float64,1}=zeros(nVar(A)),
                  doAccuracy::Bool=false,
                  Hser::SparseMatrixCSC{Float64,Int64}=mspeye(nVar(A)))
  n = nVar(A)
  T = size(eps,2);
  nSer = size(Hser,1);
  series = zeros(nSer,T);
  if doAccuracy
    expser = zeros(4,T);
  end
  for t=1:T
    if doAccuracy
      # xForec = ForecSeries*x
      # x2 = -sherman(hcat(mod.Lambda*x,mod.Psi*eps[:,t]),GamInv,U,VT,IVGAUfact);
      # xRealiz = x2[iiF,1];
      # x = sum(x2,dims=2)
      # Hx2 = Hser*x2;
      # series[:,t] = sum(Hx2,dims=2)
      # xError = xRealiz-xForec
      # expser[:,t] = [mean(xError);mean(abs.(xError)); maximum(abs,xError); maximum(abs,diff(xError))]
    else
      x = A*x+B*eps[:,t];
      series[:,t] = (Hser*x)
    end
  end
  if doAccuracy
    return (series,expser);
  else
    return series;
  end
end

# epsNull = zeros(1,4);
# x = randn(n)
# t1 = simulate(mytest,F,HA,epsNull;x=x,iiF=mytest.varNames[:firmprob_v]);
# t2 = simulate(A,B,epsNull;x=x);

#  iiF: variables in forward equations
function simulateSlow(GamInv,Lambda,Phi,Psi,F,H,Hser,eps,iiF = findnzcols(Phi))
  global BB,U,VT
  U = Phi[:,iiF]*F; 
  VT= H
  x = zeros(size(Phi,1));
  T = size(eps,2);
  nSer = size(Hser,1);
  series = zeros(T,nSer);
  (d,m) = size(F);
  IVGAUfact = lu(meye(m,m)+H*(GamInv\U))
  for t=1:T
    println("t = ",t)
    x2 = -sherman(mod.Lambda*x+mod.Psi*eps[:,t],GamInv,U,VT,IVGAUfact);
    x = - sherman(Lambda*x + Psi*eps[:,t],GamInv,U,VT);
    println(maximum(abs,x-x2))
    if(t==1)
      BB = - sherman(Array(Psi), GamInv,U,VT);
    end
    series[t,:] = (Hser*x)';
  end
  return series;
end

# function simulate(mod,Fbin,HA,posVars::Array{Int,1},eps)
#   nVar = size(Gamma,1);
#   Hser = eyeii(nVar,posVars);
#   println(posVars)
#   println(Hser)
# 
#   iiS = findnzcols(Lambda);
#   if(isempty(HA))
#     H = eyeii(nVar,iiS)
#   else
#     H = zeros(size(HA,1),nVar);
#     H[:,iiS] = HA;
#   end
#   ser = simulate(mod,Fbin,H,Hser,eps);
#   return ser;
# end


safeDiv(x,y) = x==0 ? x : x/y;
# function checkAccuracy(model::LinModel,A::Array{Float64,2},B,doScale::Bool=false)
#   nz = size(B,2)
#   nx = nVar(model)
#   nt = 10
#   errAll = zeros(nx,nt-2)
#   errSkal = zeros(nx,nt-2)
#   if doScale # scale equations
#     skal = maximum(abs.(model.Lambda),dims=2) + maximum(abs.(model.Gamma),dims=2) + 
#     maximum(abs.(model.Phi),dims=2);
#     skalmat = spDiagm(vec(skal))
#     LL = skalmat*model.Lambda
#     GG = skalmat*model.Gamma
#     PP = skalmat*model.Phi
#   else
#     LL = model.Lambda
#     GG = model.Gamma
#     PP = model.Phi
#   end
#   for i=1:nz
#     eps = zeros(nz,nt)
#     eps[i,1] = 0.01;
#     global IR = simulate(A,B,eps);
#     if nVar(A)>nx
#       println("reduce dimension of simul in checkAccuracy")
#       IR = IR[1:nx,:];
#     end
#     for t=2:nt-1
#       e1 = LL*IR[:,t-1];
#       e2 = GG*IR[:,t];
#       e3 = PP*IR[:,t+1] ;
#       skal = abs.(e1) + abs.(e2) + abs.(e3);
#       eall = abs.(e1 + e2 + e3);
#       errAll[:,t-1] = eall;
#       errSkal[:,t-1] = skal; # safeDiv.(eall,skal);
#     end
#     println("accuracy IR $i: ")
#     # println(mean(errAll,1))
#     println("mean:           ",mean(abs.(errAll),1))
#     #println("mean, scaled:   ",mean(abs.(errSkal),1))
#     #println("median, scaled: ",median(abs.(errSkal),1))
#     println("max:            ",maximum(abs.(errAll),1))
#     #println("max, scaled:    ",maximum(abs.(errSkal),1))
#   end
#   return (errAll,errSkal);
# end

# function checkAccuracy2(model,sol,redV,H)
#   F = sol.basisV*sol.F0;
#   nz = 1; # fix
#   nx = nVar(model)
#   nt = 10
#   errAll = zeros(nx,nt-2)
#   errSkal = zeros(nx,nt-2)
#   for i=1:nz
#     eps = zeros(nz,nt)
#     eps[i,1] = 0.01;
#     global IR = simulate(model,F,H,eps;iiF=redV.ivar);
#     for t=2:nt-1
#       e1 = model.Lambda*IR[:,t-1];
#       e2 = model.Gamma*IR[:,t];
#       e3 = model.Phi*IR[:,t+1] ;
#       skal = abs.(e1) + abs.(e2) + abs.(e3);
#       eall = abs.(e1 + e2 + e3);
#       errAll[:,t-1] = eall;
#       errSkal[:,t-1] = skal; # saveDiv.(eall,skal);
#     end
#     println("accuracy IR $i: ")
#     # println(mean(errAll,1))
#     println("mean:           ",mean(abs.(errAll),1))
#     #println("mean, scaled:   ",mean(abs.(errSkal),1))
#     #println("median, scaled: ",median(abs.(errSkal),1))
#     println("max:            ",maximum(abs.(errAll),1))
#     #println("max, scaled:    ",maximum(abs.(errSkal),1))
#   end
#   return (errAll,errSkal);
# end


# function checkAccuracy(model,IR::Array{Float64,2})
#   (nx,nt) = size(IR)
#   errAll = zeros(nx,nt-2)
#   for t=2:nt-1
#     e1 = model.Lambda*IR[:,t-1];
#     e2 = model.Gamma*IR[:,t];
#     e3 = model.Phi*IR[:,t+1] ;
#     errAll[:,t-1] = abs.(e1 + e2 + e3);
#   end
#   println("mean:           ",mean(abs.(errAll),1))
#   println("max:            ",maximum(abs.(errAll),1))
#   return errAll
# end

function checkAccuracy(model,IR::Array{Float64,2})
  (nx,nt) = size(IR)
  errAll = zeros(nx,nt-2)
  errAllSkal = zeros(nx,nt-2)
  # scale equations # NOT NECESSARY
  # skal = maximum(abs.(model.Lambda),dims=2) + maximum(abs.(model.Gamma),dims=2) + maximum(abs.(model.Phi),dims=2);
  # skalmat = spDiagm(vec(skal))
  # LL = skalmat*model.Lambda
  # GG = skalmat*model.Gamma
  # PP = skalmat*model.Phi
  LL = model.Lambda
  GG = model.Gamma
  PP = model.Phi
  j = 23811
  for t=2:nt-1
    e1   = LL*IR[:,t-1];
    e1sk = LL*spDiagm(IR[:,t-1]);
    e2   = GG*IR[:,t];
    e2sk = GG*spDiagm(IR[:,t]);
    e3   = PP*IR[:,t+1] ;
    e3sk = PP*spDiagm(IR[:,t+1]);
    skal = sum(abs.(e1sk),dims=2) + sum(abs.(e2sk),dims=2) + sum(abs.(e3sk),dims=2);
    ee = abs.(e1 + e2 + e3)
    errAll[:,t-1] = ee;
    errAllSkal[:,t-1] = safeDiv.(ee,skal);
  end
  println("mean:           ",mean(abs.(errAll),dims=1))
  println("max:            ",maximum(abs.(errAll),dims=1))
  println("mean scaled     ",mean(abs.(errAllSkal),dims=1))
  println("max scaled      ",maximum(abs.(errAllSkal),dims=1))
  return (errAll,errAllSkal);
end




function iter2ab(GamInv,Lambda,Phi, Psi,F;
                 iiF::AbstractArray{Int,1}=findnzcols(Phi));
  n = nVar(Lambda)
  H = mspeye(size(F,2),n); # assumes state variables come first
  ForecSeries = F*H;
  (d,m) = size(F);
  # in the inner part, the term UV' equals
  # Phi[:,iiF]*F*H
  # n*d d*m m*n
  if(d<m)  # Case 1: d<m
    println("use case 1");
    U = Phi[:,iiF];
    VT= F*H
    IVGAUfact = lu(meye(d,d)+F*H*(GamInv\Array(Phi[:,iiF])))
  else  # Case 2: m<d
    println("use case 2");
    U = Phi[:,iiF]*F; 
    VT= H
    IVGAUfact = lu(meye(m,m)+H*(GamInv\U))
  end
  A = -sherman(Array(Lambda),GamInv,U,VT,IVGAUfact);
  B = -sherman(Array(Psi),GamInv,U,VT,IVGAUfact);
  return (A,B)
end


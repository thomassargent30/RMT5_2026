# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


function InvDistrib(ForwardMat::Array{Float64})
  (e,v) = eigen(mtr(ForwardMat)); # transpose of ForwardMat
  ii = mfind(abs.(abs.(e) .- 1).<1e-10);
  n = length(ii);
  if(n==0)
    error("not a probability matrix");
  elseif(n>1)
    error("invariant distribution not unique");
  end
  D = real(v[:,ii]);
  D = D/sum(D);
  return D;
end


function InvDistrib(ForwardMat::SparseMatrixCSC{Float64,Int})
  if maximum(abs,sum(ForwardMat,dims=1) .- 1.)>1e-12
    println("sum ForwardMat-1: ", maximum(abs,sum(ForwardMat,1)-1))
    error("incorrect transition matrix in InvDistrib")
  end
  n0 = size(ForwardMat,1)
  x = ones(n0,1)/n0;
  for i=1:10
    x = ForwardMat*x;
  end
  iDrop = mfind(x.==0) # cannot be part of invariant distribution
  nDrop = length(iDrop)
  if nDrop>0
    iKeep = setdiff(1:n0,iDrop)
    FM2 = ForwardMat[iKeep,iKeep];
    # println("drop $nDrop points from distribution")
  else
    FM2 = ForwardMat
  end
  if _linsol.eigs4distrib
    (ee,ev) = eigs(FM2,sigma=1+1e-8);
    i1 = mfind(isreal.(ee) .& (abs.(ee-1).<1e-10) );
    success = 1;
    if(length(i1)==1)
      invd = real(ev[:,i1]);
      invd = invd / sum(invd);
      if(minimum(invd).<-1e-8)
        success = 0;
      end
    else
      print("dimension of invariant subspace = ",length(i1))
      println("; largest eigenvalues of transition matrix:")
      println(ee)
      warn("could not determine invariant distribution from eigenvalues")
      success = 0;
   end
 else
  success = 0
end

  if success>0
    invd = max.(invd,0.0)
    invd = invd / sum(invd);
    resid = FM2*invd - invd;
    if maximum(abs,resid)>1e-8
      println(maximum(abs,resid))
      warn("resid in invdistr too big; now try iteration");
      success = 0;
    end
  end
  if success==0
    n = size(FM2,1);
    invd = ones(n,1) / n;
    for i=1:10000; 
      invd2 = FM2*invd;
      if maximum(abs,invd2-invd)<1e-10
        break;
      end
      invd = invd2
    end
    invd = invd / sum(invd);
    maxres = maximum(abs,FM2*invd-invd)
    if maxres>1e-10
      @printf("resid in invdistr: %e\n",maxres);
    end
  end
  if nDrop>0
    InvD = zeros(n0)
    InvD[iKeep] = invd;
  else
    InvD = invd;
  end
  return InvD;
end


# forwfunc: takes an int, and gives resulting distribution as a sparse matrix
function forward2mat(forwfunc,n1,n2)
  nn = n1*n2;
  nz = 0;
  Ds = Array{SparseMatrixCSC}(undef,nn);
  for i=1:nn
    Ds[i] = forwfunc(i);
    nz += nnz(Ds[i]);
  end
  IFrom = Array{Int}(undef,nz);
  ITo = Array{Int}(undef,nz);
  Val = Array{Float64}(undef,nz);
  iz = 0;
  for i=1:nn
    (I,J,V) = findnz(Ds[i]); # (I,J,V) gives distribution after forwarding
    nz = nnz(Ds[i])
    IFrom[iz+1:iz+nz] = i;
    ITo[iz+1:iz+nz] = s2i((n1,n2),I,J);
    Val[iz+1:iz+nz] = V;
    iz+=nz;
  end
  return sparse(ITo,IFrom,Val,nn,nn);;
end

# forwfunc: takes an int, and gives resulting distribution as a sparse matrix in (I,J,V) form
function forward2matIJ(forwfunc,n1,n2)
  nn = n1*n2;
  nz = 0;
  I = Array{Array{Int}}(undef,nn);
  J = Array{Array{Int}}(undef,nn);
  V = Array{Array{Float64}}(undef,nn);
  for i=1:nn
    (I[i],J[i],V[i]) = forwfunc(i);
    nz += length(I[i]);
  end
  IFrom = Array{Int}(undef,nz);
  ITo = Array{Int}(undef,nz);
  Val = Array{Float64}(undef,nz);
  iz = 0;
  for i=1:nn
    nz = length(I[i]);
    IFrom[iz+1:iz+nz] = i;
    ITo[iz+1:iz+nz] = s2i((n1,n2),I[i],J[i]); # (I,J,V) gives distribution after forwarding
    Val[iz+1:iz+nz] = V[i];
    iz+=nz;
  end
  return sparse(ITo,IFrom,Val,nn,nn);;
end

# ForwardMatrix for 1-dimensional grid
forwardMat1(forwfunc::Function,grid) = forward2matIJ(i->transition1(forwfunc,grid,i,intp_trunc,intp_trunc), length(grid),1);
lsp(a,b,n::Int) = linspace(convert(Float64,a),convert(Float64,b),n)'';

#inputs:
# func1: transition function xBeg -> xEnd
# grid:  grid for distribution
# i      starting grid point
# Output: vector of end-of-period distribution
function transition1(func1,grid,i,lowb=intp_trunc, uppb=intp_trunc)
  n = length(grid)
  pos = PosInGrid();
  (xEnd,probs) = func1(grid[i]);
  m = length(probs)
  iRow = Array{Int}(undef,2*m);
  iCol = Array{Int}(undef,2*m);
  Val = Array{Float64}(undef,2*m);
  for j=1:m
    interp1!(pos, grid,xEnd[j],lowb,uppb)
    iCol[2*j-1:2*j] = 1;
    iRow[2*j-1] = pos.jLow;
    iRow[2*j] = pos.jLow + 1;
    Val[2*j-1] = probs[j]*pos.weight0;
    Val[2*j] = probs[j]*pos.weight1;
  end
  return (iRow,iCol,Val)
end

## function forward2mat(forwfunc,nn)
##   iFrom = Array{Array{Int}}(undef,nn);
##   iTo = Array{Array{Int}}(undef,nn);
##   val = Array{Array{Float64}}(nn);
##   nz = 0;
##   for i=1:nn
##     (iFrom[i],iTo[i],val[i]) = forwfunc(sparse([i],[1],1.0,nn,1))
##     nz+=length(iFrom[i]);
##   end
##   IFrom = Array{Int}(nz);
##   ITo = Array{Int}(nz);
##   Val = Array{Float64}(nz);
##   iz = 0;
##   for i=1:nn

##     ll = length(iFrom[i]);
##     IFrom[iz+1:iz+ll] = iFrom[i];
##     ITo[iz+1:iz+ll] = iTo[i];
##     Val[iz+1:iz+ll] = val[i];
##     iz+=ll;
##   end
##   return sparse(ITo,IFrom,Val,nn,nn);;
## end
function SmoothingFunc(v,eps=1e-4)
  m = maximum(v);
  weights = map(x->max(x+eps-m,0.),v)
  sw = sum(weights)
  probs = map(x->x/sw,weights);
  probs0 = map(x -> abs(x)<1e-10 ? 0.0 : x, probs)
  return probs0
end

function simulDistrib(forward,D0::Array{Float64,1},doWhat,iSeriesExog,nn,iDim)
  D = copy(D0)
  nExog = nn[iDim];
  @assert(all(iSeriesExog.<=nExog))
  grid = tensprod(hcat,map(i->1:i,nn)...)
  iSelect = Array{Array{Int}}(undef,nExog)
  for i=1:nExog
    iSelect[i] = mfind(grid[:,iDim].==i)
  end
  T = length(iSeriesExog)
  result = Array{Any}(undef,T+1)
  result[1] = doWhat(D)
  for t=1:T
    Dnext = forward(D)
    fill!(D,0.) 
    ii = iSelect[iSeriesExog[t]]
    D[ii] = Dnext[ii] / sum(Dnext[ii])
    result[t+1] = doWhat(D)
  end
  return hcat(result...)
end

function checkProbMatrix(T)
  if any(abs.(sum(T,2)-1).>1e-12)
    println("rows don't sum to unity")
    return false
  end
  if any(T.<0)
    println("negative entries")
    return false
  end
  return true
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function decompress(mom,nVarBig,redS::ReduceState,redV::ReduceValue)
  ivar = union(redS.ivar,redV.ivar)
  ikeepvar = setdiff(1:nVarBig,ivar)
  x = zeros(nVarBig,size(mom,2))
  nAggrVar = size(mom,1) - size(redS.selectMom,1) - size(redV.project,1)
  nVarBig2 = nAggrVar + size(redS.selectMom,2) + size(redV.project,2)
  @assert(nVarBig==nVarBig2)

  n = size(redS.proxyD,2)
  x[redS.ivar,:] = redS.proxyD*mom[1:n,:];
  offs = n
  n = size(redV.basis,2)
  x[redV.ivar,:] = redV.basis*mom[offs .+ (1:n),:];
  offs += n;
  x[ikeepvar,:] = mom[offs .+ 1:end,:]
  return x;
end
decompress(mom,sol) = decompress(mom,nVar(sol),sol.redS,sol.redV)

# get full value vector from variable vector of reduced model (input "mom")
function valueAtReduc(mom,redS::ReduceState,redV::ReduceValue)
  nS = size(redS.proxyD,2)
  nV = size(redV.basis,2)
  return redV.basis*mom[(nS+1):(nS+nV),:]
end
function momsAtReduc(mom,redS::ReduceState,redV::ReduceValue)
  nS = size(redS.proxyD,2)
  return mom[1:nS,:];
end
function endogAtReduc(mom,redS::ReduceState,redV::ReduceValue)
  nS = size(redS.proxyD,2)
  nV = size(redV.basis,2)
  return mom[(nS+nV+1):end,:]
end
#OLD NAME: function valueAtMom(mom,redS::ReduceState,redV::ReduceValue)


# compress matrix A to reduced form
# variable order:
#   1) state variables
#   2) value variables
#   3) other variables
function compress(A,redS::ReduceState,redV::ReduceValue)
  n = size(A,1);
  iequ = union(redS.iequ,redV.iequ)
  ivar = union(redS.ivar,redV.ivar)
  ikeepequ = setdiff(1:n,iequ)
  ikeepvar = setdiff(1:n,ivar)

  H1 = redS.selectMom;
  (r1,c1) = size(H1)
  H2 = redV.project;
  (r2,c2) = size(H2)
  
  m = r1+r2+length(ikeepequ)

  B1 = redS.proxyD;
  (r1,c1) = size(B1)
  B2 = redV.basis;
  (r2,c2) = size(B2)
  @assert(m == c1+c2+length(ikeepvar))


  Areduc = zeros(m,m)

  ies = (redS.iequ,redV.iequ,ikeepequ)
  ivs = (redS.ivar,redV.ivar,ikeepvar)
  basis = (redS.proxyD,redV.basis,mspeye(length(ikeepvar)))
  proj = (redS.selectMom,redV.project,mspeye(length(ikeepequ)))

  offsV = 0;
  local nRows,nCols
  local offsE,offsV
  for j=1:3
    offsE = 0;
    nCols = size(basis[j],2)
    for i=1:3
      Aij = A[ies[i],ivs[j]]
      #println(size(Aij))
      #println(size(proj[i]))
      nRows = size(proj[i],1)
      for k=1:nCols
        a = Aij*basis[j][:,k]
        Areduc[offsE .+ (1:nRows),offsV+k] = proj[i]*a
      end
      offsE += nRows
    end
    offsV += nCols
  end
  @assert(offsV==m)
  @assert(offsE==m)
  iZero = mfind(abs.(Areduc).<1e-14)
  Areduc[iZero] .= 0.0;
  return Areduc
end

function compressEqus(A,redS::ReduceState,redV::ReduceValue)
  n = size(A,1);
  iequ = union(redS.iequ,redV.iequ)
  ikeepequ = setdiff(1:n,iequ)

  H1 = redS.selectMom;
  (r1,c1) = size(H1)
  H2 = redV.project;
  (r2,c2) = size(H2)

  m = r1+r2+length(ikeepequ)



  Areduc = zeros(m,size(A,2))

  ies = (redS.iequ,redV.iequ,ikeepequ)
  proj = (redS.selectMom,redV.project,mspeye(length(ikeepequ)))

  local nRows,nCols
  local offsE,offsV
  offsE = 0;
  for i=1:3
    Aij = A[ies[i],:]
    nRows = size(proj[i],1)
    Areduc[offsE .+ (1:nRows),:] = proj[i]*Aij;
    offsE += nRows
  end
  @assert(offsE==m)
  iZero = mfind(abs.(Areduc).<1e-14)
  Areduc[iZero] .= 0.0;
  return Areduc
end


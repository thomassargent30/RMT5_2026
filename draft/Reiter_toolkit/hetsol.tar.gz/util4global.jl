# func returns both the residual that should be set to zero,
# as well as some intermediate results from the calculation
# those intermediate results will then also be returned by solveSimple
function solveSimple!(func,xVec::Array{Float64,1},jac::Array{Float64,2},maxiter,ytol)
  x = copy(xVec)
  local xOld,residOld,funcOutput
  for iter=1:maxiter
    funcOutput = func(x)
    resid = funcOutput[1];
    if abs(resid)<ytol
      return (x,0,funcOutput);
    end
    if iter>1
      jac[1] = ((resid-residOld)./(x[1]-xOld))[1]
    end
    xOld = x[1]
    residOld = copy(resid)
    x[1] -= resid/jac[1]
  end
  return (x,1,funcOutput) # not converged
end

# function interpValueAggr(mom,iZ,Vcoef::Array{Float64,3},fspaceM,transAggr)
#   (n1,nM,nZ) = size(Vcont)
#   Vz = reshape(Vcoef,n1*nM,nZ) * transAggr[iZ,:]';
#   V = reshape(Vz,n1,nM);
#   Vi = feval(fspaceM,V,coef)
#   return Vi;
# end

function mEndFuncLinear(sol,mom,exogVar)
  dpProbl = sol.dpProblem;

  Dstst = vec(sol.Dstst);
  Zstst = sol.StatesStSt;
  mstst = sol.redS.selectMom*vcat(Dstst,Zstst);
  momz = vcat(mom,exogVar)
  ii = 1:length(momz)
  momzEnd = sol.A[ii,ii] * (momz-mstst);
  mEnd = mstst + momzEnd;
  return mEnd[1:length(mom)];
end

# function to solve for temporary equilibrium
# Inputs:
#   sol: solution of linearized model
#   Dbeg:  distribution at beginning of period
#   VcoefAggr: coefficient of value function, for end of period value
#   iZ:  index of aggregate discrete state, this period
#   exogVars: value of the exogenous variables, corresponding to iZ
#   aggrFunc:  function creating the structure that contains the aggregate variables
#   mEndFunc: function that contains perceived law of motion momBeg -> momEnd
#   initial guess for equilibrium variables ("prices")
#   initial guess for Jacobian of residuals w.r.t. equilibrium variables 

# function tempEquil(Dbeg,exogState, fspace::MultiDimApprox,
#                    vcoef::Array{Float64,2}, # approx of value function
#                    aggrFunc, mEnd0,pricesInit,jacInit0)
#   @assert(false)
#   global _dpProblemGlob,_selectMomGlob,_QcontAzGlob,_parsGlob,_ststValueGlob;
#   dpProbl = _dpProblemGlob;
#   m = _selectMomGlob*vcat(vec(Dbeg),exogState)
#   aggr = aggrFunc(equVars,m)
#   mEnd = vcat(mEnd0,exogState)
# 
#   Vstst = _ststValueGlob;
#   Vend = reshape(feval(fspace,mEnd,vcoef),size(Vstst.V));
#   Qend = _QcontAzGlob;
#   dpVal = DynProgVal(Vstst.grid,NaN*Vend,Vend,NaN*Qend,Qend);
# 
#   # knownAggrVars = (m,exogState) # more compact???
#   tEqu(x) = equFuncGenerator(x,aggrFunc,Dbeg,m,dpVal);
#   jacInit = copy(jacInit0)
#   if length(pricesInit)==1
#     # jacInit will be overwritten
#     (x,flag,pricesOutput) = solveSimple!(tEqu,pricesInit,jacInit,40,1e-6)
#     if flag!=0
#       warn("solveSimple not converged")
#     end
#   else
#     error("not yet implemented for vectors")
#   end
#   dpPolEqu = pricesOutput[2]
#   (tmat,Tendog) = transMat(dpProbl,dpPolEqu,_parsGlob);
#   Dend = reshape(Tendog*vec(Dbeg),size(Dbeg))
#   Dnext = reshape(tmat*vec(Dbeg),size(Dbeg))
#   return (Dnext,Dend,x,dpPolEqu,dpVal.Vend,jacInit)
# end


using SparseArrays
function findSparse(A)
  ii = findall(x->x!=0,A);
  n = length(ii);
  II = fill(0,n)
  JJ = fill(0,n)
  for i=1:n
    II[i] = ii[i][1]
    JJ[i] = ii[i][2]
  end
  return (II,JJ)
end


function countnzrows(A)
  (I,J) = findSparse(A);
  N = fill(0,size(A,1))
  for i in I
    N[i] += 1;
  end
  return N;
end
function countnzrows2(A)
  (I,J) = findSparse(A);
  N = fill(0,size(A,1))
  M = fill(0,size(A,1))
  n = length(J)
  for i=1:n
    iRow = I[i]
    iCol = J[i]
    N[iRow] += 1;
    M[iRow] = iCol; # column index of last nz item in Row
  end
  return (N,M);
end


function findexog(Gamma,Lambda,Phi)
  (neG,colIndxG) = countnzrows2(Gamma);
  neL = countnzrows(Lambda);
  neLG = countnzrows(abs.(Gamma) + abs.(Lambda)); # to test whether variables are the same
  neP = countnzrows(Phi);
  n = length(neG)
  exogVars = fill(1,0)
  for i=1:n
    if neG[i]==1 && neL[i]==1 && neP[i]==0 && neLG[i]==1
      iVar = colIndxG[i]
      push!(exogVars,iVar)
      if @isdefined(varNames)
        println("exog Variable: ",findIndexInDict(varNames,iVar))
      else
        println("exog Variable: $iVar")
      end
    end
  end
  return exogVars;
end


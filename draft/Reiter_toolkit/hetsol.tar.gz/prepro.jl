# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

using Printf
include("splitargs.jl")
include("diffsubs.jl")
tupled(s::String) = "(" * s * ")"
function prf(x::Real,width::Int=14,prec::Int=6)
  dest = " "^100;
  if isa(x,Float64)
    if (width>0 && abs(x)>10^width) || (x!=0 && abs(x)<1/10^prec)
      fmt = "%" * string(width) * "." * string(prec) * "e";
    else
      fmt = "%" * string(width) * "." * string(prec) * "f";
    end
    nCheck = ccall(:sprintf, Int,  (Ptr{UInt8},Ptr{UInt8},Float64), pointer(dest),pointer(fmt), x)
  elseif isa(x,Int)
    fmt = "%" * string(width)  * "d";
    nCheck = ccall(:sprintf, Int,  (Ptr{UInt8},Ptr{UInt8},Int), pointer(dest),pointer(fmt), x)
  else
    error("wrong type")
  end
  return dest[1:nCheck]
end
function FindFields(str0,myStruct::Array{String,1})
  flds = Array{Symbol}(undef,0)
  for name in myStruct
    # allow for things like "2a":
    re = Regex("\\b\\d*" * name * "\\b");
    if occursin(re,str0)
      push!(flds,Symbol(name));
    end
  end
  return flds;
end
function replaceNamesbyField(str0,myStruct::Array{String,1},prefix)
  str = str0;
  for name in myStruct
    # allow for things like "2a":
    str = replace(str, Regex("\\b(\\d+)" * name * "\\b") =>  
                  Base.SubstitutionString{String}("\\1*$prefix.$name"))
    # do not apply to fields of structure:
    str = replace(str,Regex("(?<![0-9a-zA-Z_.])" * name * "\\b") => prefix * "." * name)
  end
  return str;
end
function replaceNamesbyField(str0,myStruct,prefix)
  str = str0;
  for a in fieldnames(typeof(myStruct))
    name = string(a)
    # allow for things like "2a":
    str = replace(str,Regex("\\b(\\d+)" * name * "\\b") => Base.SubstitutionString{String}("\\1*$prefix.$name"))
    # do not apply to fields of structure:
    str = replace(str,Regex("(?<![0-9a-zA-Z_.])" * name * "\\b") => prefix * "." * name)
  end
  return str;
end
function insertParsAsArg(str0,myStruct::Dict,namePars)
  str = str0;
  for name in keys(myStruct)
    # do not apply to fields of structure:
    str = replace(str,Regex("(?<![0-9a-zA-Z_.])" * name * "\\(") => name*"($namePars,")
  end
  return str;
end
function checkDoesNotContain(args0,myStruct::Array{String,1})
  args = split(args0,",")
  for arg in args
    for name in myStruct
      if arg==name
        error(name * " is a parameter, cannot be a formal function argument")
      end
    end
  end
end
struct FuncBinder{p}
  f::Function
  ii::NTuple{p,Int}
end
function funcBinder(f::Function,args...)
  n = length(args)
  return FuncBinder{n}(f,args)
end
(x::FuncBinder)(t) = x.f(x.ii...,t)

function atoi(str0)
  str = convert(String,str0)
  return Base.parse(Int,str)
end
stripspace(s::String) = replace(s," " => "")
function string2dynare(ex)
  e = string(ex)
  e = replace(e,r"\b(\d+e[-+]?\d+)([a-zA-Z])" => s"\1*\2")
  e = replace(e,r"\b(\d+)e\+(\d+)\b" => s"\1*10^(\2)")
  e = replace(e,r"\b(\d+)e(\d+)\b" => s"\1*10^(\2)")
  e = replace(e,r"\b(\d+)e-(\d+)\b" => s"\1*10^(-\2)")
  e = replace(e,r"\b(\d+)([a-zA-Z])" => s"\1*\2")
end
function appendf(filename,txt)
  FF = open(filename,"a");
  println(FF,txt);
  close(FF)
end
function write2f(filename,txt)
  FF = open(filename,"w");
  println(FF,txt);
  close(FF)
end
function ppError(txt,iLine=0)
  println("in line ",iLine,":")
  error(txt)
end
c2s(x) = convert(String,x)
function initfile(file)
  F = open(file,"w")
  close(F)
end
function randomModule(prefix::String="module")
  i = rand(1:10^25)
  modname = prefix * string(i)
  Core.eval(Main,Meta.parse("module $modname; end"))
  return Core.eval(Main,Meta.parse(modname))
end
function splitEquName(ename)
  m = match(r"(\w+)(\[(?<args>.*)\])?",ename);
  if(isa(m[:args],Nothing))
    return (m.captures[1],"")
  else
    return (m.captures[1],m[:args])
  end
end
function splitVarequ(ve)
  ve = replace(ve,r"\s" => "")
  args = splitargs(ve,':')
  ni = length(args);
  if(ni==1)
    return (args[1],args[1])
  elseif(ni==2)
    return (args[1],args[2])
  else
    println(ve);
    ppError("syntax error in varname:equname");
  end
end
function addTimeIndex(var::String,allCali)
  varEx = Meta.parse(var)
  if isa(varEx,Symbol)
    if var in allCali
      var_t = var
    else
      var_t = var*"[t]" # t, not stst, to make it comparable to equ
    end
  else
    @assert(varEx.head==:ref)
    varname = string(varEx.args[1])
    if varname in allCali
      var_t = var
    else
      var_t = string(Expr(:ref,varEx.args...,:t))
    end
  end
  return var_t
end
function processLinArgs1(argi0)
  argi = split(argi0,":")
  var = argi[1];
  equ = argi[1];  # default: equation name same as variable name
  if(length(argi)==2)  # extra equation name given
    equ = argi[2];
  end
  m = match(r"(\w+)\[(.+)\]",equ)
  if m!=nothing
    f = c2s(m.captures[1])
    args = c2s(m.captures[2])
    equ = "funcBinder(_eq_$f,$args)"
  else
    equ = "_eq_"*equ
  end
  return (var,equ) # need _eq_ for equation arguments to LIN
end
function processLinArgs(args)
  txtArgs = Array{String}(undef,0);
  for i=1:length(args)
    (var,equ) =  processLinArgs1(args[i])
    push!(txtArgs,var)
    push!(txtArgs,equ)
  end
  return  txtArgs;
end
function getEquName(ename0)
  ename = replace(ename0,r"\[\s*t[-+ 1]*\]" => "") # replace pure time index
  ename = replace(ename,r"\[\s*stst*\]" => "") # replace pure time index
  # ename = replace(ename,r"\[-]" => "") # replace getindex of ParCali
  ename = replace(ename,r"\[]" => "") # replace getindex of ParCali
  ename = replace(ename,r",\s*t[-+ 1]*" => "") # replace time index as last index
  m = match(r"^\s*(\w+(\[[,\s\w]+\])?)\s*$",ename)
  if(m==nothing)
    println(ename)
    ppError("invalid name for equation")
  end
  return m.captures[1];
end

function evalasmacros(file)
  L = readlines(file)
  txt = ""
  for line in L
    txt *= replace(line,r"^_" => "@")
  end
  Core.eval(Main,Meta.parse(txt))
end
function handleMacro(functxt0)
  functxt = c2s(functxt0)
  m = match(r"(\w+)\(([\w, \t]*)\)\s*=\s*(.+)\s*;",functxt)
  if(m==nothing)
    println("MACRO ",functxt)
    ppError("syntax error in macro")
  end
  funcname = c2s(m.captures[1]);
  args = c2s(m.captures[2]);
  funcexpr = c2s(m.captures[3]);
  if !isempty(args)
    aa = split(args,',');
    for i=1:length(aa)
      ai = replace(aa[i],r"^\s*" => "");
      ai = replace(ai,r"\s*$" => "");
      funcexpr = replace(funcexpr,Regex("\\b" * ai * "\\b") => "\$"*ai);
    end
  end
  txtmac = @sprintf("macro %s(%s) return esc(:(%s)); end;",funcname,args,funcexpr)
  Core.eval(ppmod,Meta.parse(txtmac))
  return txtmac;
end
function handleVars4DP(Vars::Set{Symbol},nameVarStruct::String)
  txt = "aggr4DP = ("
  for v in Vars
    vs = string(v)
    txt *= "$v=$nameVarStruct.$v,";
  end
  txt *= ");"
end

## if !@isdefined(_DP)
##   global const _DP = Dict{String,DPVar}()
##   global const _DPOfModel = Dict{Int,Array{Symbol,1}}()
##   # global const _DPOfModel = Dict{Int,Module}()
## end

function prepro(hetfile,modelDir,modelIndex::Int)
  # _DPOfModel[modelIndex] = Array{Symbol}(undef,0)
  DPs = Array{DPVar}(undef,0)
  DPValues = Array{String}(undef,0)
  DPDistrs = Array{String}(undef,0)
  DPneedsVars = Set{Symbol}()
  global _shockNumbers = Dict{String,Int}()
  nShk = 0;
  global hetsolDir;
  templ = "$templDir/sym4ss.jl"
  templ2 = "$hetsolDir/diffsubs.jl"
  txtTransf = "";
  txtInvTransf = "";
  txtDependParams = "";
  inDependParams = false
  FTEX = open(modelDir * "model.tex","w")
  # templ3 = "$hetsolDir/mydiff/diffincl.jl"
  # if !@isdefined(ppmod)
    # Core.eval(Meta.parse("module ppmod; using mydiff;end"))
    global ppmod = randomModule("ppmod")
    dircmd = :(hetsolDir=$hetsolDir)
    Core.eval(ppmod,dircmd)
    Core.eval(ppmod,:(include($templ)))
    # Core.eval(ppmod,:(include($templ3)))
    Core.eval(ppmod,:(include($templ2)))
    Core.eval(ppmod,:(inStSt=true))
    Core.eval(ppmod,:(import Main.ifif))
  # end
  global allFuncs = Dict{String,String}()
  global allEqus = Dict{String,String}()
  function append2both(filebase,keyw,args...)
    fb = modelDir * filebase;
    FP = open(fb * ".mpp","a")
    a = "(" * join(args,",") * ")"
    println(FP,"_" * keyw * a)
    close(FP)
  end
  function append2decl(filebase,txt)
    fb = modelDir * filebase;
    FP = open(fb * ".mpp","a")
    println(FP,txt)
    close(FP)
  end
  lines = readlines(hetfile * ".het")
  initfile(modelDir * "guess.mpp")
  initfile(modelDir * "par.mpp") # for parameter declarations
  initfile(modelDir * "setpar.mpp") # to generate file that sets parameters
  initfile(modelDir * "var.mpp")
  initfile(modelDir * "func.mpp")
  initfile(modelDir * "func2.jl")
  initfile(modelDir * "macro.mpp")
  append2decl("macro","_def _FUNC(name,args,body) _conc(name,args) = body");
  initfile(modelDir * "equ.mpp")
  initfile(modelDir * "model.mpp")
  initfile(modelDir * "nonlin.mpp")
  initfile(modelDir * "tex.mpp")
  initfile(modelDir * "stst.mpp")
  initfile(modelDir * "stst.log")
  initfile(modelDir * "files2incl.jl")
  FNL = open(modelDir * "getnonlin.jl","w")
  preprolog = modelDir * "prepro.log"
  function printlog(txt::String,doAppend=true)
    if(doAppend)
      FLOG = open(preprolog,"a")
    else
      FLOG = open(preprolog,"w")
    end
    println(FLOG,txt)
    close(FLOG)
  end

  inTransfState = 0; # 0: never started: 1: in Transf; 2: in invTransf; 3: already passed
  continueLine = false;
  inDynprog = false;
  inNonlin = false;
  inStSt = false;
  _inGuess = false;
  inModel = false;
  inDecl = true;
  inFunc = false;
  ####################################################################
  #  MAIN LOOP:
  ####################################################################
  local cmd::String;
  local cmd0::String;
  local _CondExprLevel = 0; # preprocessor commands: conditional evaluation
  local _CondEvaluation = Array{Bool}(undef,10); # maximum recursion level 10
  local _DoneEvaluation = Array{Bool}(undef,10);
  local _CondEvaluationLine = Array{Int}(undef,10);
  printlog("Start prepro")
  i = 1;
  # first include files:
  allCali = fill("",(0,))
  allPars = fill("",(0,))
  allVars = fill("",(0,))
  dpargs = Dict{String,Array{String}}()
  dpmodel = Dict{String,Array{String}}() # collects the DP models
  while i<length(lines)
    if occursin(r"^\s*!!include\b",lines[i])
      m = match(r"^\s*!!include\s+(\S+)\s*$",lines[i])
      if m==nothing
        println(lines[i])
        error("syntax error file inclusion")
      else
        fname = c2s(m.captures[1])
        lines2 = readlines(fname)
        lines = [lines[1:i-1];lines2;lines[i+1:end]]
      end
    else
      i+=1;
    end
  end
  # print new version to file, so that line numbers refer to new file!!

  dpname = ""
  iLine = 0;
  while iLine<length(lines)
    iLine += 1;
    printlog(lines[iLine])
    cmd0 = lines[iLine];
    # eliminate comments
    if( (m=match(r"^(.*?)#!(.*)",cmd0)) != nothing )
      comm = replace(m.captures[2],r"[\n\r]+" => " ");
      comm = replace(m.captures[2],r"^\s*" => " ");
      append2decl("tex",comm);
      cmd0 = m.captures[1];
    end
    if( (m=match(r"^(.*?)#",cmd0)) == nothing )
      cmd0 = replace(cmd0,r"[\n\r]+" => s" ");
    else
      cmd0 = m.captures[1];
    end
    # eliminate empty lines
    if(occursin(r"^\s*$",cmd0))
      @assert(continueLine==false,@printf("input line %d\ncontinue with empty line",iLine))
      continue;
    end
    # CONDITIONAL EVALUATION (can happen within multi-line commands)
    if(occursin(r"^\s*!!",cmd0))
      m = match(r"^\s*!!(\w+)(.+)?",cmd0)
      if(m==nothing)
        print(cmd0)
        ppError("wrong preprocessor command")
      end
      pCmd = m.captures[1];
      pExpr = m.captures[2];
      if(pCmd == "eval")
        Core.eval(Meta.parse(Main,pExpr));
      elseif(pCmd == "if")
        pCond = Core.eval(Main,Meta.parse(pExpr));
        if(!isa(pCond,Bool))
          println(cmd0)
          ppError("!!if must be followed by boolean expression")
        end
        _CondExprLevel += 1;
        if(_CondExprLevel>10)
          ppError("maximum recursion level for conditional preprocessing (10) exceeded")
        end
        _CondEvaluation[_CondExprLevel] = pCond;
        _DoneEvaluation[_CondExprLevel] = pCond;
        _CondEvaluationLine[_CondExprLevel] = iLine;
      elseif(pCmd == "elseif")
        pCond = Core.eval(Main,Meta.parse(pExpr));
        _CondEvaluation[_CondExprLevel] = (!_DoneEvaluation[_CondExprLevel]) && pCond
        _DoneEvaluation[_CondExprLevel] = _DoneEvaluation[_CondExprLevel] || pCond;
      elseif(pCmd == "else")
        _CondEvaluation[_CondExprLevel] = !_DoneEvaluation[_CondExprLevel]
      elseif(pCmd == "end")
        _CondExprLevel -= 1;
        if(_CondExprLevel<0)
          ppError(@sprintf("unmatched !!end_ in line %d",iLine));
        end
      else
        print(cmd0)
        ppError("wrong preprocessor command")
      end
      continue
    end
    if(_CondExprLevel>0)
      if(any(_CondEvaluation[1:_CondExprLevel] .== false))
        continue;
      end
    end
    # accumulate cmd until semicolon is found
    if(continueLine)
      cmd *= cmd0;
    else
      cmd = cmd0;
    end
    nSemicolon = count(x->x==';',cmd);
    if nSemicolon==1
      continueLine = false;
    end
    if occursin(r"^\s*DEPEND:\s*$",cmd)
      if !inDecl
        error("statement 'DEPEND:' only possible in declaration section")
      end
      inDependParams = true
      continue
    end
    if occursin(r"\bVAR\b",cmd)
      inDependParams = false
    end
    if inDecl && inDependParams
      txtDependParams *= replaceNamesbyField(cmd,allPars,"_p") * "\n";
      continue
    end
    if(inDynprog)
      if(occursin(r"^\s*END\b",cmd))
        inDynprog = false;
        writeDP(dpname,dpargs[dpname],dpmodel[dpname],modelDir,modelIndex)
        txtDependParams *= handleVars4DP(DPneedsVars,"_vars")
        # @show txtDependParams
      else
        cmd = replaceNamesbyField(cmd,allPars,"_p");
        DPneedsVars = union!(DPneedsVars,FindFields(cmd,allVars));
        # DPneedsVars = unique(DPneedsVars,FindFields(cmd,allVars));
        cmd = replaceNamesbyField(cmd,allVars,"_A");
        cmd = insertParsAsArg(cmd,allFuncs,"_p");
        cmd = replace(cmd,r"\bMINGRID\b" => "_p.$(dpname)_xmin");
        cmd = replace(cmd,r"\bMAXGRID\b" => "_p.$(dpname)_xmax");
        push!(dpmodel[dpname],cmd*"\n")
      end
      continue
    end
    if(occursin(r"^\s*DYNPROG\b",cmd))
      if inModel
        m = match(r"DYNPROG\(\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*\)",cmd)
        if(m==nothing)
          appendf(preprolog,cmd)
          ppError("syntax error in model section in line ",iLine)
        end
        dpname = c2s(m.captures[1]);
        push!(DPs,DPVar(dpname, c2s(m.captures[2]), c2s(m.captures[3])))
        txt = writeLinDP(DPs[end])
        append2both("equ","EQUFUNCDP",dpname,"0",txt)
        append2both("model","EQUDP",dpname)
        continue;
      elseif inStSt
        m = match(r"DYNPROG\(\s*(\w+)\s*,\s*(\w+)\s*,\s*(\w+)\s*\)",cmd)
        if(m==nothing)
          appendf(preprolog,cmd)
          ppError("syntax error in model section");
        end
        dpname = c2s(m.captures[1]);
        gV = c2s(m.captures[2]);
        gD = c2s(m.captures[3]);
        # print stst information

        txt = writeStStDP(DPs[end],gV,gD)
        append2decl("stst",txt)
        continue;
      else
        if !( inDecl || inFunc )
          error("DYNPROG command in wrong section of program, probably line $iLine")
        end
        if !@isdefined markovappr
          error("you seem to have used linsol rather than linsolHA")
        end
        m = match(r"^\s*DYNPROG\s+([a-zA-Z]\w*)\(([\w\s,]+)\)\s*;",cmd)
        if(m==nothing)
          appendf(preprolog,cmd)
          ppError("syntax error in DYNPROG declaration, line ",iLine)
        end
        dpname = c2s(m.captures[1])
        append2both("par","PAR",dpname*"_xmin","Float64","0")
        append2both("par","PAR",dpname*"_xmax","Float64","0")
        append2both("setpar","PAR",dpname*"_xmin","Float64","0",NaN)
        append2both("setpar","PAR",dpname*"_xmax","Float64","0",NaN)
        _currDPname = dpname;
        dpargs[dpname] = split(c2s(m.captures[2]),",")
        if any(map(x->in(x,allPars),dpargs[dpname]))
          intrs = intersect(allPars,dpargs[dpname])
          println(intrs)
          error("arguments of $dpname contain a parameter")
        end
        if any(map(x->in(x,allVars),dpargs[dpname]))
          intrs = intersect(allVars,dpargs[dpname])
          println(intrs)
          error("arguments of $dpname contain a variable")
        end
        if in(dpname,allVars)
          println(dpname)
          error("name of DP problem: $dpname equals a variable name")
        end
        dpmodel[dpname] = Array{String}(undef,0)
        # DPs[dpname] = DPVar();
        inDynprog = true;
        inDecl = false;
        inModel = false;
        inFunc = false;
        inStSt = false;
        inNonlin = false;
      end
    end
    # make sure only one command is handled:
    if(inModel)
      if(nSemicolon==0)
        if(occursin(r"&=",cmd)) # continuation only allowed if first line contains &=
          continueLine = true
          continue
        end
      elseif(nSemicolon>1)
        @printf("line %d contains %d semicolons\n",iLine,nSemicolon)
        appendf(preprolog,cmd);
        appendf(preprolog,"syntax warning")
      else
        continueLine = false;
      end
    end
    # end of section:
    ###############################################################
    # PROCESS EACH LINE:
    ###############################################################
    ###############################################################
    # Commands for nonlinear solution can be anywhere, so far:
    local args::Array{String,1}
    if( (m=match(r"^\s*TEXSYM\s*\((.+)\)",cmd)) != nothing)
      arg = c2s(m.captures[1]);
      args = splitargs(arg,',')
      @assert(length(args)==2)
      append2both("tex","TEXSYM",arg)
      continue
    end
    if( (m=match(r"^\s*MACRO\s+(.+)",cmd)) != nothing)
      txt = handleMacro(m.captures[1])
      append2decl("macro",txt)
      continue;
    end
    if( (m=match(r"^\s*FUNC\s+(.+)",cmd)) != nothing)
      functxt = c2s( m.captures[1])
      m = match(r"(\w+)\(([\w, \t]+)\)\s*=\s*(.+)\s*;",functxt)
      if(m==nothing)
        println("FUNC ",functxt)
        ppError("syntax error in function")
      end
      Core.eval(ppmod,Meta.parse(functxt))
      funcname = c2s(m.captures[1]);
      fargs = stripspace(c2s(m.captures[2]));
      checkDoesNotContain(fargs,allPars)
      funcexpr = c2s(m.captures[3]);
      allFuncs[funcname] = fargs
      append2both("func","FUNC",funcname,tupled(fargs),funcexpr)
      appendf(modelDir*"func2.jl","$funcname(_p,"*fargs*") = " * 
                  replaceNamesbyField(funcexpr,allPars,"_p"))
      continue;
    end
    if( occursin(r"^\s*FUNCDIFF\b",cmd))
      # Core.eval(mpp2,:(include(hetsolDir * "exprsubs.jl")))
      m=match(r"^\s*FUNCDIFF\s+(\w+)\s+(\w+)\s+(\w+)\s*;",cmd)
      if(m==nothing)
        ppError("syntax error in FUNCDIFF")
      end
      dfuncname = c2s(m.captures[1]);
      funcname = c2s(m.captures[2]);
      firstarg = c2s(m.captures[3]);
      fargs = allFuncs[funcname]
      fargsym = join(map(x->"e2syme(:"*x*")",split(fargs,",")),",")
      diffcmd = "sym2e(diff_($funcname($fargsym),e2syme(:$firstarg)))"
      # println(diffcmd)
      # diffcmd = "sym2e(mydiff.diff_($funcname($fargsym),:$firstarg))"
      rr = Core.eval(ppmod,Meta.parse(diffcmd))
      append2both("func","FUNC",dfuncname,tupled(fargs),rr)
      functxt = "$dfuncname($fargs) = $rr"
      # println("decl dfunc: ",functxt)
      allFuncs[dfuncname] = fargs
      Core.eval(ppmod,Meta.parse(functxt))
      continue;
    end
    ###########################################
    # COMMANDS FOR NONLINEAR PART:
    ###########################################
    if( occursin(r"^\s*(STATE|STATEMARKOV|PREDET|SOLVEDYN|SOLVETR|DEFINE|DEFINE1|DEFINE0|DEFEXP|APPROX|APPROX2|SETZERO)\b",cmd))
      @assert(inNonlin == true,appendf(preprolog,cmd),appendf(preprolog,"command must appear in NONLIN section"));
      m=match(r"\s*(STATE|STATEMARKOV|PREDET|SOLVEDYN|SOLVETR|DEFINE|DEFINE1|DEFINE0|DEFEXP|APPROX|APPROX2|SETZERO)\((.+)\)\s*;",cmd)
      if m == nothing 
        appendf(preprolog,cmd)
        ppError("syntax error");
      end
      keyw = c2s(m.captures[1]); #the nonlinear command name
      args = splitargs(m.captures[2],',')
      if occursin(r":",args[1])
        m1 = match(r"^\s*(.+?)\s*:\s*(.+?)\s*$",args[1])
        if(m1==nothing)
          println(cmd);
          error("syntax error")
        end
        var = c2s(m1.captures[1]);
        equ = c2s(m1.captures[2]);
      else
        m1 = match(r"^\s*(.+?)\s*$",args[1])
        var = c2s(m1.captures[1]);
        equ = var;
      end
      equ = "_eq_" * equ;
      if keyw=="STATEMARKOV"
        @assert(length(args)==2)
        varname = args[1]
        shockname = args[2]
        shocknumber = _shockNumbers[shockname]
        @printf(FNL,"STATEMARKOV_(\"%s\",%d)\n",varname,shocknumber)
        continue
      end
      # test if variable is an array:
      mbase = match(r"^(\w+)",var)
      varbase = c2s(mbase.captures[1])
      # if haskey(varDims,varbase)
      #   println(FNL,@sprintf("DECLARE_(\"%s\",\"%s\",\"%s\")",keyw,varbase,varDims[varbase]))
      #   delete!(varDims,varbase) # to avoid declaring twice
      # end
      if length(args)==1 # scalar variable and equation
        if(occursin(r"APPROX|SOLVEDYN|SETZERO",keyw)) # don't solve, just write equation
          Core.eval(ppmod,:(inStSt=false))
          ee = allEqus[equ];
          eeEval = Core.eval(ppmod,:(evalat($ee)))
          @printf(FNL,"%s_(\"%s\",\"%s\");\n",keyw,var,string(eeEval))
        else
          varT = var*"[t]"
          varT = replace(varT,"][" => ",")
          Core.eval(ppmod,:(inStSt=false))
          # equsol = Main.solveSymbolic1(allEqus[equ],Meta.parse(varT))
          ee = allEqus[equ];
          equsol = Core.eval(ppmod,:(solveat($ee,$varT)))
          @printf(FNL,"%s_(\"%s\",\"%s\");\n",keyw,var,equsol)
        end
      elseif length(args)==3 # vector variable and/or equation
        indx = args[2];
        if(occursin(r"APPROX|SOLVEDYN|SETZERO",keyw))# don't solve, just write equation
          @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",\"%s\");\n",
          keyw,var,string(allEqus[equ]),indx,args[3])
        else
          println(allEqus[equ])
          var2solve = var*"[t]"
          var2solve = replace(var2solve,"][" => ",")
          println(var2solve)
          equsol = Main.solveSymbolic1(allEqus[equ],Meta.parse(var2solve))
          @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",\"%s\");\n",
          keyw,var,equsol,indx,args[3])
        end
      elseif length(args)==4 # vector variable and/or equation
        indx = args[2];
        #@printf(FNL,"for _i = (%s):(%s)\n",args[3],args[4])
        if(occursin(r"APPROX|SOLVEDYN|SETZERO",keyw))# don't solve, just write equation
          @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");\n",
          keyw,var,string(allEqus[equ]),indx,args[3],args[4])
          # @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",_i);\n",keyw,var,string(allEqus[equ]),indx)
        else
          println(allEqus[equ])
          var2solve = var*"[t]"
          var2solve = replace(var2solve,"][" => ",")
          println(var2solve)
          equsol = Main.solveSymbolic1(allEqus[equ],Meta.parse(var2solve))
          # equsol = replace(equsol,"9998" => indx)
          # equsol = replace(equsol,"9997" => indx*"-1")
          # equsol = replace(equsol,"9999" => indx*"+1")
          # @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",_i);\n",keyw,var,equsol,indx)
          @printf(FNL,"  %s_(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\");\n",
          keyw,var,equsol,indx,args[3],args[4])
        end
        #println(FNL,"end;")
      else
        println(cmd)
        error("wrong number of arguments to command")
      end
      continue;
    end
    if(occursin(r"^\s*TRANSF\b",cmd))
      inNonlin = false;
      inTransfState = 1;
      continue
    elseif(occursin(r"^\s*INVTRANSF\b",cmd))
      if inTransfState!=1
        ppError("give TransfState before giving InvTransfState")
      end
      inTransfState = 2;
      continue
    end
    if(inTransfState==1)
      if(occursin(r"^\s*END\b",cmd))
        ppError("give InvTransfState before finishing TRANSF section")
      end
      txtTransf *= cmd * "\n"
      continue
    elseif(inTransfState==2)
      if(occursin(r"^\s*END\b",cmd))
        inTransfState=3 # signal that there was a TRANSF section
      else
        txtInvTransf *= cmd * "\n";
      end
      continue
    end
    if(inNonlin)
      println(FNL,cmd)
    end
    ###########################################
    # END NONLINEAR PART
    ###########################################
    ###############################################################
    if(occursin(r"^\s*MODEL\b",cmd))
      inDecl = false;
      inFunc = false;
      inModel = true;
      # close the files related to declarations:
      continue
    end
    #if(occursin(r"^\s*GUESS\s*;",cmd))
    if(occursin(r"^\s*GUESS;",cmd))
      if(inStSt)
        ppError("GUESS command must come before STST")
      end
      _inGuess = true;
      inModel = false;
      inFunc = false;
      inStSt = false;
      continue
    end
    if(occursin(r"^\s*FUNCTIONS\s*;",cmd))
      inDecl = false;
      inModel = false;
      inStSt = false;
      inFunc = true;
      continue
    end
    if(occursin(r"^\s*STST\s*;",cmd))
      inDecl = false;
      inModel = false;
      inFunc = false;
      _inGuess = false;
      inStSt = true;
      continue
    end
    if(occursin(r"^\s*NONLIN\s*;",cmd))
      inDecl = false;
      inModel = false;
      inFunc = false;
      inStSt = false;
      inNonlin = true;
      # Core.eval(ppmod,:(include($modelDir * "macro.mpp"))) #????????????????? what is the purpose?
      initnonl()
      continue
    end
    if(inFunc)
      if !occursin(r"^\s*function\b",cmd0)
        cmd0 = replaceNamesbyField(cmd0,allPars,"_p");
        append2decl("macro",cmd0)
      else
        append2decl("macro",cmd0)
        # append2decl("macro","  _p = Main._pars") # MAKES IT VERY SLOW, since _pars is non-constant global!!
        append2decl("macro","  _incl(func2.jl)") # should functon defitionions be included?
        # append2decl("macro","  _incl(func.mpp)") # should functon defitionions be included?
      end
      continue;
    end
    #################################################################
    # process special commands
    #################################################################
    if(occursin(r"\bCSMEAN\b",cmd))
      m = match(r"CSMEAN\((?<name>\w+),(?<distr>.*),\s*\(\.\)\s*->(?<fexpr>.*)",cmd);
      if(m==nothing)
        @printf("line number %d\n",iLine);
        ppError("syntax error in CSMEAN");
      else
        dpname = m[:name];
        dist = m[:distr];
        funcbody::String = m[:fexpr];
        funcbody = replaceNamesbyField(funcbody,allPars,"_p");
        # funcbody = replaceNamesbyField(funcbody,allVars,"_v");
        (bef,args,aft) = splitbyfunc(cmd,"CSMEAN");
        cmd = bef * @sprintf("CrossSectionMean(%s_pol[t],%s,(%s,t)->%s)",
                             dpname,dist,join(dpargs[dpname],","),funcbody)
        if(occursin(r"\w",aft))
          ppError("junk ater CSMEAN command")
        end
      end
    end
    #################################################################
    # process separate sections
    #################################################################
    # |VAR|SHOCK
    if occursin(r"\bVAR|SHOCK\b",cmd)
      m=match(r"^\s*(?<KEYW>VAR|SHOCK)(?<DIM>{\d+})?\s+(?<ARGS>.*);",cmd)
      if m == nothing
        println(cmd)
        error("syntax error in declaration in line ",iLine)
      end
      keyw = m[:KEYW];
      dimArray = 0 # default: scalar
      if m[:DIM]!=nothing  # array
        dimstr = c2s(m[:DIM])[2:end-1]
        dimArray = atoi(dimstr)
      end
      args = splitargs(m[:ARGS],',');
      for i=1:length(args)
        mi = match(r"^\s*(\w+)",args[i]);
        if(mi==nothing)
          appendf(preprolog,cmd);
          ppError("syntax error in declaration",iLine);
        end
        namev = c2s(mi.captures[1]);
        if(dimArray==0)
          append2both("var",keyw*string(dimArray),namev);
        else
          mii = match(r"^\s*(\w+)(\(.*\))",args[i]);
          if(mii==nothing)
            println(args[i])
            ppError("incorrect syntax for declaration of VAR or SHOCK array");
          end
          sizeA = c2s(mii.captures[2]); 
          sizeA = replaceNamesbyField(sizeA,allPars,"_p");
          append2both("var",keyw*string(dimArray),namev,sizeA);
        end
        symcmd = Meta.parse("@VAR $namev")
        # println("now eval: ",symcmd)
        Core.eval(ppmod,symcmd)
        #if keyw == "VAR" && nShk>0
        #  ppError("SHOCKS must come after VAR declarations",iLine)
        #end
        if keyw=="VAR"
          if nShk>0
            ppError("Variable $namev declared after some Shocks have been declared;\n"
                    * "First declare all variables, then declare shocks")
          end
          push!(allVars,namev)
        end
        if keyw=="SHOCK"
          @printf(FNL,"SHOCK_(\"%s\")\n",namev);
          nShk += 1;
          _shockNumbers[namev] = nShk;
        end
      end
      continue
    end
    if occursin(r"\bPAR|PARCALI|PARDEF|INT|BOOL\b",cmd)
      m=match(r"^\s*(?<KEYW>PAR|PARCALI|PARDEF|INT|BOOL)(?<DIM>{\d+})?\s+(?<ARGS>.*);",cmd)
      if m == nothing
        println(cmd)
        error("syntax error in declaration in line ",iLine)
      end
      keyw = m[:KEYW];
      dimArray = 0 # default: scalar
      if m[:DIM]!=nothing  # array
        dimstr = c2s(m[:DIM])[2:end-1]
        dimArray = atoi(dimstr)
      end
      if occursin(r"^\s*INT",cmd)
        numType = "Int64";
      elseif occursin(r"^\s*BOOL",cmd)
        numType = "Bool";
      else
        numType = "Float64";
      end
      args = splitargs(m[:ARGS],',');
      for i=1:length(args)
        mi = match(r"^\s*(\w+)(\([^=]+\))?\s*(=\s*(.+))?$",args[i]);
        # mi = match(r"^\s*(\w+)\s*(=\s*(.+))?",args[i]);
        if(mi==nothing)
          appendf(preprolog,cmd);
          error("syntax error in declaration in line ",iLine)
        end
        namev = c2s(mi.captures[1]);
        sizeA = mi.captures[2];
        if sizeA!=nothing
          sizeA = c2s(sizeA)
          # sizeA = replaceNamesbyField(sizeA,allPars,"_p"); # NO; will be sued in setpars
        end
        value = mi.captures[4];
        # if keyw=="INT" # those can enter if statements !!!???
        #   vvv = c2s(value)
        #   cmdI = Meta.parse("$namev = $vvv")
        #   Core.eval(ppmod,cmdI)
        # end
        if value==nothing
          if keyw!="PARCALI"
            if(dimArray==0)
              println(cmd)
              ppError("scalar parameter must be initialized",iLine)
            else
              if sizeA==nothing
                if value==nothing
                  value = "Array{" * numType * "}(undef," * "0,"^dimArray * ")"
                else
                  println(args[i])
                  error("cannot give both dimension and value in declaration")
                end
              else
                value = "fill(zero(" * numType * "),$sizeA)"
                # value = "Array{" * numType * "}$sizeA"
              end
            end
          end
        else
          if keyw=="PARCALI"
            ppwarn("value for PARCALI will be ignored",iLine)
          end
          if occursin(r"\bGLOBAL\b",value)
            value = "Main." * namev;
          end
        end
        if(keyw == "PARCALI")
          append2both("par",keyw,namev,string(dimArray))
          append2both("setpar",keyw,namev,string(dimArray))
          push!(allCali,namev)
        else
          append2both("par","PAR",namev,numType,string(dimArray))
          append2both("setpar","PAR",namev,numType,string(dimArray),value)
        end
        push!(allPars,namev)
        symcmd = Meta.parse("@PAR($namev)")
        # println("now eval: ",symcmd)
        Core.eval(ppmod,symcmd)
      end
      continue
    end
    if(inDecl) # in declaration, but not a keyword command
      append2decl("setpar",cmd)
    end  # end if(inDecl)
    if(inModel)
      # if(occursin(r"\(\.\)",cmd))  # applies to DYNPROG!!!
      #   allargs = @sprintf("(%s)->",currDP.ARGS);
      #   cmd = replace(cmd,r"\(\.\)\s*->" => allargs);
      # end
      if(occursin(r"^\s*COMPSLACK\b",cmd))
        (bef,args,aft) = splitbyfunc(cmd,"COMPSLACK");
        if(length(args)!=2)
          appendf(preprolog,cmd);
          ppError("COMPSLACK needs this format: COMPSLACK(variable:equname,multiplier)\n  (variable is required to be  >0]");
        end
        _nConstr += 1;
        (var,equVar,iLag,varWithoutTime) = splitVarequ(args[1]); # variable
        @assert(iLag==0)
        (lagr,equLagr,iLag,lagrWithoutTime) = splitVarequ(args[2]); # multiplier
        @assert(iLag==0)
                equs = @sprintf("100*((1-_glob.isBinding[%d])*%s[t] + _glob.isBinding[%d]*(%s[t]))",
        _nConstr,lagrWithoutTime,_nConstr,varWithoutTime)
        txtGetEqus *= @sprintf("%s = %s\n",equnameDecl(args[2]),equs)
        _EquStrings[args[2]] = equs;
                @printf(FMODEL,"_Res = _eq_%s(t);",equLagr)
        (base,argsE) = splitEquName(equLagr);
        @printf(FMODEL,"register(\"%s\",_Res,%s);",base,argsE)
        @printf(FMODEL,"handleRes(_Res);\n")
        # test equation, still necessary?? :
        #equs = @sprintf("%s[t] + %s[t]",var,args[2]);
        #txtGetEqus *= @sprintf("_testcs%s = %s\n",equnameDecl(args[1]),equs)
        #_EquStrings["_testcs"*args[1]] = equs;
                #@printf(FNL,"LAGR(\"%s\",\"%s\",%d);\n",var,equLagr,iLag);
        #@printf(FNL,"TESTCS(\"_testcs%s\");\n",equLagr);
                @printf(FNL,"COMPSLACK_(\"%s\",\"%s\",\"%s\");\n",varWithoutTime,lagrWithoutTime,equVar);
        continue
      end
      if(occursin(r"&=",cmd))  # MODEL EQUATIONS
        local lhs,rhs,equname,lhs2,rhs2;
        extraStStEqu = false;
        if(occursin(r"\bSTST:",cmd))
          m=match(r"^\s*((?<ename>\w[^:&=]*?)\s*:)?\s*(?<lhs>[^:=]+)&=\s*(?<rhs>[^=]+?)\s*STST:\s*(?<lhs2>[^:=]+)&=\s*(?<rhs2>[^=]+?)\s*;",cmd);
          if(m==nothing)
            appendf(preprolog,cmd)
            ppError("syntax error in equation")
          end
          extraStStEqu = true;
          isCali = false;
          lhs = c2s(m[:lhs]);
          rhs = c2s(m[:rhs]);
          lhs2 = c2s(m[:lhs2]);
          rhs2 = c2s(m[:rhs2]);
          if(isa(m[:ename],Nothing))
            equname = getEquName(lhs);
          else
            equname = getEquName(m[:ename]);
          end
        elseif( (m=match(r"\s*(?<stst>CALI\b)?\s*(?<ename>\w[^:&=]*)\s*:\s*(?<lhs>[^:=]+)&=\s*(?<rhs>[^&]+);",cmd)) != nothing) # fix: which characters are allowed in rhs ??? !!!
          isCali = m[:stst]!=nothing ;
          lhs = c2s(m[:lhs]);
          rhs = c2s(m[:rhs]);
          #lhs = c2s(m[:lhs]);
          #rhs = c2s(m[:rhs]);
          equname = getEquName(m[:ename]);
        elseif( (m=match(r"\s*(?<stst>CALI\b)?\s*(?<lhs>[^:=]+)&=\s*(?<rhs>[^&]+);",cmd)) != nothing)
          isCali = m[:stst]!=nothing ;
          lhs = c2s(m[:lhs]);
          rhs = c2s(m[:rhs]);
          # lhs = c2s(m[:lhs]);
          #rhs = c2s(m[:rhs]);
          equname = getEquName(m[:lhs]);
        else
          println(cmd)
          ppError("command does not match")
        end
        lhs = replace(lhs,r"\s*$" => "");
        if @isdefined latexAll
          texlhs = latexAll(lhs)
          texrhs = latexAll(rhs)
          println(FTEX,"\\begin{equation}") 
          println(FTEX,"\\label{eq:$equname}") 
          println(FTEX," $texlhs =  $texrhs");
          println(FTEX,"\\end{equation}") 
        end
        (base,argstr) = splitEquName(equname);
        allEqus["_eq_"*base] = "$rhs - ($lhs)"
        if isempty(argstr)
          allargs = [];
          nArgs = "0"
        else
          allargs = split(argstr,",")
          nArgs = string(length(allargs))
        end
        append2both("equ","EQUFUNC"*nArgs,base,allargs...,lhs,rhs)
        if(extraStStEqu)
          append2both("equ","STSTFUNC"*nArgs,base,allargs...,lhs2,rhs2)
        end
        if(isCali)
          append2both("model","CALI"*nArgs,base,allargs...)
        else
          append2both("model","EQU"*nArgs,base,allargs...)
        end
      else
        append2decl("model",cmd)  # for-loops etc.
      end
      continue;
    end  #  if(inModel)
    if(_inGuess)
      if( (m=match(r"([^=]+)=(.+?)IN\s*\[(.*)\]\s*;",cmd)) != nothing )
        var = m.captures[1];
        guess = replace(m.captures[2],":" => ",")
        bounds = splitargs(m.captures[3],',');
        append2both("guess","GUESS",var,guess,bounds...)  # for-loops etc.
      else
        append2decl("guess",cmd)
      end
      continue
    end
    if(inStSt)
      while(occursin(r"\bBISECT\b",cmd)) # solve nonlinear equation
        (bef,args,aft) = splitbyfunc(cmd,"BISECT");
        cmd = bef;
        (var,equ) = processLinArgs1(args[1])
        if(length(args)==3)
          cmd *= @sprintf("(__x,_flag) = bisectTr(\"%s\",function (x) setstst!(%s,x); return %s(stst); end,%s,%s)\n",var,var,equ,args[2],args[3]);
        elseif(length(args)>=4)
          cmd *= @sprintf("(__x,_flag) = bisectTr(\"%s\",function (x) setstst!(%s,x);",var,var);
          for i=4:length(args)
            cmd *= args[i] * ";";
          end
          cmd *= @sprintf("return %s(stst); end,%s,%s)\n",equ,args[2],args[3]);
        end
        cmd *= @sprintf("setstst!(%s,__x)\n",var)
        cmd *= aft;
      end
      if(occursin(r"^\s*@?RESID\b",cmd)) # residual equation; will be passed to stst.jl
        m = match(r"^\s*@?RESID\s+(?<resname>\w+(\[.*\])?)",cmd) 
        equ = m[:resname];
        append2both("stst","RESID",equ)  # for-loops etc.
        continue
      end
      if(occursin(r"^\s*KNOW\b",cmd)) # residual equation; will be passed to stst.jl
        m = match(r"^\s*KNOW\s*\((.*)=(.*)\)\s*;\s*$",cmd) 
        if m == nothing
          println(cmd)
          ppError("syntax error");
        else
          (var,equ) = splitVarequ(m.captures[1]);
          value = m.captures[2];
          append2both("stst","KNOW",var,equ,value)
          continue
        end
      end
      if(occursin(r"^\s*!\s*\w",cmd)) 
        m = match(r"^\s*!\s*([\w:,\[\]]+)\s*;\s*$",cmd)
        if m == nothing
          println(cmd)
          ppError("syntax error ! in line ",iLine);
        else
          args = split(c2s(m.captures[1]),',')
          txtArgs = processLinArgs(args)
          if length(txtArgs)==2
            v = txtArgs[1];
            ee = allEqus[txtArgs[2]]
            vsym = addTimeIndex(v,allCali)
            sol = Core.eval(ppmod,:(solveat($ee,$vsym)))
            # println("sol: ",sol)
            append2decl("stst","setstst!($v,$sol)")
          else
            error("not hyet imp.")
            #sol = Main.solvestst(txtArgs,allEqus,allParCali,FS)
            #printlog(@sprintf("solvestst2: %s\n",string(sol)))
          end
        end
        continue
      end
      if(occursin(r"^\s*NL\s+\w",cmd)) 
        m = match(r"^\s*NL\s*([\w:,\[\]]+)\s*;\s*$",cmd)
        if m == nothing
          println(cmd)
          ppError("syntax error ! in line ",iLine);
        else
          args = split(c2s(m.captures[1]),',')
          txtArgs = processLinArgs(args)
          if length(txtArgs)==2
            v = txtArgs[1];
            vsym = Symbol(v);
            ee = Meta.parse(allEqus[txtArgs[2]])
            vsym = String(v);
            ee = allEqus[txtArgs[2]]
            sol = Core.eval(ppmod,:(solveNLatstst($ee,$vsym)))
            println(sol)
            append2decl("stst","setstst!($vsym,$sol)")
          else
            error("NL can only solve on equation")
          end
        end
        continue
      end
      if(nSemicolon==0 && occursin(r"\bLIN\b",cmd))
        continueLine = true;
        continue
      end
      while(occursin(r"\bLIN\b",cmd)) # solve linear system of equations
        local args;
        if(occursin(r"\bLIN\(",cmd)) # arguments given in function form
          (bef,args,aft) = splitbyfunc(cmd,"LIN");
          txtArgs = processLinArgs(args)
          cmd = bef * "slss!(" * join(txtArgs,',') * ")" * aft;
          appendf(preprolog,cmd)
        elseif( (m=match(r"^\s*LIN\s+([\w,:\[\]]+)\s*;\s*$",cmd))!= nothing) # arguments given in function form
          args = split(c2s(m.captures[1]),",");
          txtArgs = processLinArgs(args)
          cmd = "slss!(" * join(txtArgs,',') * ")";
          appendf(preprolog,cmd)
        else
          appendf(preprolog,cmd)
          ppError("incorrect syntax in LIN command",iLine)
        end
      end
      if(occursin(r"^\s*USING\b",cmd))
        appendf(preprolog,"USING")
        appendf(preprolog,cmd)
        (bef,args,aft) = splitbyfunc(cmd,"USING");
        #args = splitargs(m.captures[1],',')
        textAfterUsing = "";
        for i=1:length(args)
          m = match(r"(.+)=(.*)",args[i]);
          if(m==nothing)
            appendf(preprolog,args[i])
            ppError("wrong argument for USING")
          end
          varname = m.captures[1];
          # @printf(FS,"if(_iStStrun==1 && ststSet(%s)) ppError(\"USING: %s already set\");end\n", varname,varname);
          append2decl("stst",@sprintf("setstst!(%s,convert(Float64,%s),false);\n",varname,m.captures[2]))
          textAfterUsing *= @sprintf("setstst!(%s,NaN,false);\n",varname);
        end
        cmd = aft * textAfterUsing;
      end
      append2decl("stst",cmd)
    end  # if(inStSt)
  end
  if inTransfState>0
    if inTransfState!=3
      ppError("transfer section not ended")
    end
    write_transferFunc(modelDir * "transffuncs.jl",txtTransf,txtInvTransf)
  end
  # if(_nAuxStates>0)  # CHECKAGAIN LATER; POSTPONE THIS TO NONLIN.JL
  #   FS = open(modelDir * "dimensions.jl","w");
  #   @printf(FS,"nApproxExt = %d\n",_nApproxExt);
  #   @printf(FS,"nAuxStates = %d\n",_nAuxStates);
  #   @printf(FS,"nComplSlack = %d\n",_nComplSlack);
  #   close(FS);
  # end
  if(_CondExprLevel>0)
    ppError(@sprintf("missing !!end for !!if in line %d",_CondEvaluationLine[end]));
  elseif(_CondExprLevel<0)
    ppError("unmatched preprocessor !!end")
  end
  close(FNL)
  write2f(modelDir * "ststdepend.mpp",txtDependParams)
  close(FTEX)
  return DPs
end


function writeDP(dpname,args,lines,modelDir,modelIndex)
  funcs = Dict{String,String}()
  done = Dict{String,Bool}()
  prepVariables = Array{String}(undef,0)
  funcs["UTIL"] = "function _util(_p,_A,_pt," * join(args,",") * ",t)\n";
  funcs["UTIL"] *= "@assert(_pt.iDC == " * args[5] * ");\n"; 
  funcs["DISC"] = "function _disc(_p,_A," * join(args[2:3],",") * ",t)\n";
  funcs["PREP"] = "function _prep!(_p,_A,_pt," * join(args[[1:3;5]],",") * ",t)\n";
  funcs["PREP"] *= "  _pt.iDC = " * args[5] * ";\n";
  funcs["RANGE"] = "function _range(_p,_A,_pt," * join(args[[1:3;5]],",") * ",t)\n";
  funcs["TEXOG"] = "function _transExog(_p,_A,t)\n";
  funcs["NDC"] = "function _nDC(_p)\n";

  done["UTIL"] = false
  done["DISC"] = false
  done["PREP"] = false
  done["RANGE"] = false
  done["TEXOG"] = false
  done["NDC"] = false
  done["IEND"] = false

  needsKeyword = true  #  you need to start a new section
  local keyw
  for line in lines
    if occursin(r"^\s*$",line)
      continue
    end
    if done["PREP"]
      line = replaceNamesbyField(line,prepVariables,"_pt");
    end
    # if(occursin(r"^\s*(TEXOG|NDC)\b",line))
    #   m = match(r"^\s*(TEXOG|NDC)\s*=\s*(.*)",line)
    #   if m==nothing
    #     println(line)
    #     error("syntax error")
    #   end
    #   keyw = convert(String,m.captures[1])
    #   done[keyw] = true
    #   expr = convert(String,m.captures[2])
    #   funcs[keyw] = expr;
    if(occursin(r"^\s*SET\b",line))
      if !(keyw=="PREP")
        error("SET command only possible in PREP section")
      end
      m = match(r"^\s*SET\s*(\w+)\s*=\s*(.*)",line)
      if m==nothing
        println(line)
        error("syntax error")
      end
      name = convert(String,m.captures[1])
      expr = convert(String,m.captures[2])
      funcs[keyw] *= "_pt.$name = $expr\n"
      push!(prepVariables,name)
    elseif(occursin(r"^\s*IEND\b",line))
      if !(keyw=="PREP")
        error("IEND command only possible in PREP section")
      end
      m = match(r"^\s*IEND\s*=\s*(.*)",line)
      if m==nothing
        println(line)
        error("syntax error")
      end
      expr = convert(String,m.captures[1])
      funcs[keyw] *= "_pt.iDE = $expr\n"
      done["IEND"] = true
    elseif(occursin(r"^\s*(UTIL|PREP|DISC|RANGE|TEXOG|NDC)\b",line))
      m = match(r"^\s*(UTIL|PREP|DISC|RANGE|TEXOG|NDC)\s*([:=])(.*)?",line)
      if m==nothing
        println(line)
        error("syntax error")
      end
      keyw = convert(String,m.captures[1])
      done[keyw] = true
      op = convert(String,m.captures[2])
      if op=="="
        expr = convert(String,m.captures[3])
        funcs[keyw] *= "return " * expr * "\n";
        needsKeyword = true 
      else
        if(m.captures[3]!=nothing)
          funcs[keyw] *= m.captures[3]
        end
        needsKeyword = false 
      end
    else
      if needsKeyword
        println(line)
        error("keyword expression needed in this place")
      end
      funcs[keyw] *= line
    end
  end
  for keyw in ["UTIL";"PREP";"DISC";"RANGE";"TEXOG";"NDC"]
    if done[keyw]==false
      error("section $keyw is missing")
    end
    if !occursin(r"\breturn\b",funcs[keyw]) && !(keyw=="PREP")
      error("section $keyw has no return statement")
    end
    funcs[keyw] *= "end\n"
  end

  if done["IEND"]==false
    error("End of period discrete state not set in section PREP")
  end
  appendf(modelDir*"files2incl.jl","include(\"dp_$dpname.jl\")")
  F = open(modelDir*"dp_$dpname.jl","w")
  println(F,"module $dpname")
  println(F,"# const _pars = Main._pars")
  println(F,"include(\"func2.jl\")")
  println(F,"include(\"func3.jl\")")
  println(F,"""
  const INFEASIBLE = (-1,(NaN,NaN))
  POINT(a) = (0,(a,NaN))
  INTERVAL(a,b) = b>a ? (2,(a,b)) : (b==a ? POINT(a) : INFEASIBLE)
  """);
  println(F,"mutable struct TempParam{T}\n  iDC::Int\n  iDE::Int\n")
  for v in prepVariables
    println(F,"  $v::T")
  end
  println(F,"""function TempParam{T}() where T
    TP = new()
    return TP;
  end
  end""");
  for keyw in ["UTIL";"PREP";"DISC";"RANGE";"TEXOG";"NDC"]
    println(F,funcs[keyw])
  end
  println(F,"end") # end the module definition
  #appendf(modelDir*"stst.mpp","$(dpname)_nDC = " * replace(funcs["NDC"],"_p\." => "_pars."))
  #appendf(modelDir*"stst.mpp","$(dpname)_TExog = " * replace(funcs["TEXOG"],"_p\." => "_pars."))
  # push!(_DPOfModel,Symbol(dpname));
  # push!(_DPOfModel[modelIndex],Symbol(dpname));
  close(F)
  return (funcs,prepVariables)
end

# insert text into steady state routine to solve for StSt of dynamic programming problem:
function writeStStDP(dp,nameGrid,nameGridD)
dpname = dp.name
  nameVsym = dp.V;
  nameDsym = dp.D;
  nameV = dp.V * "[stst]"
  nameD = dp.D * "[stst]"
  txt = """
  @assert($nameGrid[1]==$nameGridD[1]);
  @assert($nameGrid[end]==$nameGridD[end]);
  _p.$(dpname)_xmin = $nameGrid[1];
  _p.$(dpname)_xmax = $nameGrid[end];
  if(!isfinite(_vars.$nameV[1]))
    _vars.$nameV .= 0
  end
  global $(dpname)_val = dynProgVal($nameGrid,_vars.$nameV)
  # Core.eval($dpname,:(_val = Main.dpval));
  global $(dpname)_pol4v = dpNonConvex1d!($dpname,_p, aggr4DP,$(dpname)_val, _linsol.nAccel, stst)
  # @time global $(dpname)_pol4v = dpNonConvex1d!($dpname,_p, _vars,$(dpname)_val, _linsol.nAccel, stst)
  # global deriv1test = getDeriv1($dpname,_p,_vars,$(dpname)_val,$(dpname)_po4v) 
  $(dpname)_polS = evalPol($dpname,_p, _vars,$(dpname)_val.grid,$(dpname)_val.V,$(dpname)_val.Q, $nameGridD,stst);
  $(dpname)_polF = dynProgPol(Deriv4hs,$(dpname)_polS) 
  global $(dpname)_pol = DynProgPol2($(dpname)_polS,$(dpname)_polF);
  # Core.eval($dpname,:(_pol = Main.dppol));
  Core.eval($dpname,:(const _D = :$nameDsym))
  Core.eval($dpname,:(const _V = :$nameVsym))
  global $(dpname)_mat = transMat($(dpname),$(dpname)_polS,_p,_v,stst,nothing)[1];
  $nameD .= reshape(InvDistrib($(dpname)_mat),size($nameD));
  """
  return txt
end
# insert text into linear perturbation routine
function writeLinDP(dp)
  dpname = dp.name;
  nameV = dp.V;
  nameD = dp.D;
  return "residDP($dpname,_p,_v,_vars.$nameV,_vars.$nameD,$(dpname)_val,$(dpname)_pol,$(dpname)_pol4v,t)"
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# most precise simulation of reduced model
function simulHA(mod::LinModel,Ar,Br,redS,redV,eps;
                 x0 = zeros(nStates(mod)),
                 Hser = meye(0))
  if size(Br,2)!=size(eps,1)
    error("number of rows in shock series must equal number of shocks in model")
  end
  if size(x0,2)>1
    T = 1
    @assert(size(eps,2)==size(x0,2))
  else
    T = size(eps,2)
  end
  n = nVar(mod)
  (nr,nSt) = size(Ar)
  if isempty(Hser)
    X = zeros(n,T)
  else
    X = zeros(size(Hser,1),T)
    (rH,cH) = size(Hser)
    if cH != n;
      Hser = hcat(Hser,zeros(rH,n-cH))
    end
  end
  # prepare solution of state equations
  ies = redS.iequ;
  ivs = redS.ivar;
  nStBig = nStates(mod)
  L2 = mod.Lambda[ies,1:nStBig]
  G2 = mod.Gamma[ies,:]
  G2[:,ivs] .= 0.0; # drop effect of current states; will then be solved for
  F2 = mod.Phi[ies,:]
  P2 = mod.Psi[ies,:]
  GamInv = lu(mod.Gamma[ies,ivs])
  xLast = x0;
  nStBig = size(redS.selectMom,2)
  mom = redS.selectMom * x0[1:nStBig,:];
  for i=1:T
    # compute current "moments"
    if T==1
      mom = Ar*mom[1:nSt,:] + Br*eps;
    else
      mom = Ar*mom[1:nSt,:] + Br*eps[:,i];
    end
    # compute expected moments for next period:
    momExp = Ar*mom[1:nSt,:];
    # compute all current variables, unding state and value reduction:
    x = decompress(mom,n,redS,redV);
    # compute all expected future variables:
    xExp = decompress(momExp,n,redS,redV);
    # compute current states using current and future expected decision variables:
    # 1) compute residual from state equations:
    tmp = L2*xLast[1:nStBig,:] + G2*x + F2*xExp .+ P2*eps[:,i];
    # 2) choose current states to satisfy state equatons:
    xs = -(GamInv\tmp)
    x[ivs,:] = xs;

    # selected variables for output:
    if isempty(Hser)
      if size(x0,2)>1
        return x;
      end
      X[:,i] = x
    else
      X[:,i] = Hser*x
    end
    xLast = x[1:nStBig];
  end
  return X;  # each variable in a row
end

function forwardHA(mod::LinModel,Ar,Br,redS,redV,eps,x0)
  if size(Br,2)!=size(eps,1)
    error("number of rows in shock series must equal number of shocks in model")
  end
  n = nVar(mod)
  (nr,nc) = size(x0)
  xLast = vcat(x0,zeros(n-nr,nc));
  mom = redS.selectMom * x0;
  nMom = size(mom,1)
  # prepare solution of state equations
  ies = redS.iequ;
  ivs = redS.ivar;
  L2 = mod.Lambda[ies,:]
  G2 = mod.Gamma[ies,:]
  G2[:,ivs] .= 0.0; # drop effect of current states; will then be solved for
  F2 = mod.Phi[ies,:]
  P2 = mod.Psi[ies,:]
  GamInv = lu(mod.Gamma[ies,ivs])
  Ar2 = Ar[:,1:nMom]

  # compute current "moments"
  mom = Ar2*mom .+ Br*eps
  # compute expected moments for next period:
  momExp = Ar2*mom[1:nMom,:];
  # compute all current variables, unding state and value reduction:
  x = decompress(mom,n,redS,redV);
  # compute all expected future variables:
  xExp = decompress(momExp,n,redS,redV);
  # compute current states using current and future expected decision variables:
  # 1) compute residual from state equations:
  tmp = L2*xLast + G2*x + F2*xExp .+ P2*eps;
  # 2) choose current states to satisfy state equatons:
  xs = -(GamInv\tmp)
  x[ivs,:] = xs;
  return x;  # each variable in a row
end
function forwardHA(sol::LinSolHA,eps::Array{Float64,1}; x0 = zeros(size(sol.redS.selectMom,2),1));
  return forwardHA(sol.model,sol.A,sol.B,sol.redS,sol.redV,eps,x0);
end

function selectMat(m::Union{LinSol,LinModel,LinSolHA},vars::Array{Symbol,1})
  if isa(m,LinSolHA)
    vstst = m.model.vstst
    n = nVar(m.model)
    vnames = m.model.varNames
  else
    vstst = m.vstst
    n = nVar(m)
    vnames = m.varNames
  end
  Hstst = vcat(map(x->getfield(vstst,x),vars)...)
  ii = vcat(map(i->vnames[vars[i]],1:length(vars))...)
  nV = length(ii)
  H = sparse(1:nV,ii,ones(nV),nV,n);
  return (H,Hstst);
end
function simulHA(sol::LinSolHA,eps::Array{Float64,2}; Hser = meye(0),
                 x0 = zeros(nStates(sol.model)));
  return simulHA(sol.model,sol.A,sol.B,sol.redS,sol.redV,eps; x0=x0,Hser = Hser);
end
function simulHA(sol::LinSolHA,eps::Array{Float64,2},var1::Symbol,vars...)
  if length(vars)==1
    @show typeof(vars)
    vv = convert(Array{Symbol,1},vcat(var1,vars[1]))
  else
    vv = convert(Array{Symbol,1},vcat(var1,vars...))
  end
  (Hser,ststv) = selectMat(sol.model,vv)
  X = simulHA(sol.model,sol.A,sol.B,sol.redS,sol.redV,eps; Hser = Hser);
  return (X',ststv)
end


function LinSolHA(model,Ar,Br,redS,redV)
  dpName = model.info.dp[1].name
  dpmodule::Module = Core.eval(Main,Symbol(dpName));
  Dname = Symbol(model.info.dp[1].D)
  iiD = model.varNames[Dname];
  iiStates = setdiff(redS.ivar,iiD)
  ststVector = stackFields(Float64,model.vstst);

  sss = ststVector[iiStates];
  nStateReduc = size(redS.selectMom,1);
  val::DynProgVal{Float64} = Core.eval(Main,Symbol(dpName*"_val"));
  pol::DynProgPol2{Deriv4hs} = Core.eval(Main,Symbol(dpName*"_pol"));
  return LinSolHA(model,Ar[:,1:nStateReduc],Br,redS,redV,dpmodule,val,pol,sss);
end

function proxyFromStSt(HA0,ststVector,expo::Real,epsReg=1e-12) # ,nExog::Int)
  inclConstant = true
  if inclConstant
    nExog = 1
    println("adjust for cons")
    ee = [ones(1,size(HA0,2)-nExog) zeros(1,nExog)];
    HA = vcat(HA0,ee) # enforce zero sum deviation
  else
    HA = HA0
  end
  Omega=max.(ststVector.^expo,epsReg);
  OmH = Omega.*HA';
  HOH = HA*OmH;
  PD = OmH/Array(HOH);
  if inclConstant
    return PD[:,1:end-1]
  else
    return PD
  end
end
roundI(x) = convert(Int,round(x))
function spreadCol(x::AbstractArray{Float64,1},nSplit)
  n = length(x)
  if nSplit==1
    return x
  end
  if nSplit==n
    return mdiagm(x)
  end
  @assert(nSplit>0)
  @assert(nSplit<=n)
  I = roundI.(linspace(1,n+1,nSplit+1));
  ranges = map(i->I[i]:I[i+1]-1,1:nSplit)
  X = zeros(n,nSplit)
  for i=1:nSplit
    ii = ranges[i]
    X[ii,i] = x[ii]
  end
  return X
end
function getHA(BigModel,pol,SI=nothing)
  if SI==nothing
    (ieS,ieV,ieY) = splitequ(BigModel)
    SI = stateSpaceInfo(BigModel,ieS,ieV,ieY);
  end
  nSt = nnzcols(BigModel.Lambda);

  dpmodule::Module = Core.eval(Main,Symbol(BigModel.info.dp[1].name));
  Dname = Symbol(BigModel.info.dp[1].D)
  sizeD = length(getfield(BigModel.vstst,Dname))
  nExogAggr = nSt - sizeD
  if _linsol.iStateReduc==0
    (HA,hatT) = gramianspace(SI,200);
    PD = HA';
  elseif _linsol.iStateReduc==-1# use simple aggregation with nAggr states combined into one bin
    nAggr = _linsol.iSpreadReduc; # number of bins to aggregate; set to 0 for optimal aggregation
    (HA,PD) = aggrbin(BigModel,dpmodule,nAggr,SI);
  elseif _linsol.iStateReduc>0# use simple aggregation with nAggr states combined into one bin
    grid = pol.grid;
    gridmid = (grid[1:end-1]+grid[2:end])/2;
    (n1Unused,nDEndog , nDExog)  = size(pol.CC);
    nDS = nDEndog*nDExog
    iSpr = _linsol.iSpreadReduc
    Hmean = kron(meye(nDS),spreadCol(gridmid,iSpr));
    if nDEndog>1
      error("not impl")
    else
      Hfrac = zeros(size(Hmean,1),0)
    end
    critQR = 1e-10; # criterium for dropping dependent moments:
    if _linsol.iStateReduc==1# use simple aggregation with nAggr states combined into one bin
      HA = blockdiag(dropDependentCols([Hmean Hfrac SI.C[:,1:size(Hmean,1)]'],critQR),meye(nExogAggr))';
      # HA = blockdiag(orth([Hmean Hfrac SI.C[:,1:size(Hmean,1)]']),meye(nExogAggr))';
    else
      Hquad = kron(meye(nDS),spreadCol(gridmid.^2,iSpr));
      HA = blockdiag(dropDependentCols([Hmean Hfrac Hquad SI.C[:,1:size(Hmean,1)]'],critQR),meye(nExogAggr))';
    end
    @assert(rank(HA)==size(HA,1))
    ststVector = stackFields(Float64,BigModel.vstst)[1:nSt];
    PD = proxyFromStSt(HA,ststVector,2)
  else  
    error("wrong iStateReduc")
  end
  # (HA,PD) = separateExogVar(HA,PD,1);  # FIX ?????????????????
  return (HA,PD)
end
function linsolHA(modelName,equStates::Array{String}=fill("",0),HA0=nothing,PD0=nothing)

  nameproblem = _modelinfo[modelName].dp[1].name;

  # generate matrices for model:
  global BigModel = linmodel(modelName)


  # REDUCE DIMENSION OF VALUE SPACE:
  println("reduceV")
  @time redV = reduceV(BigModel,nameproblem,200)

  # PREPARE STATE REDUCTION:
  # split equations into different types
  (ieS,ieV,ieY) = splitequ(BigModel,equStates);
  # eliminate unit root due to dynamics of distribution:
  removeUnitRoot!(BigModel,ieS[1]);
  # further info for state reduction
  global ieSglob = ieS;
  SI = stateSpaceInfo(BigModel,ieS,ieV,ieY);
  global SIglob = SI;
  # DO STATE REDUCTION:
  pol = Core.eval(Main,Symbol(nameproblem*"_pol"));
  if HA0==nothing
    (HA,PD) = getHA(BigModel,pol,SI)
    global HAglob = HA;
  else
    HA = HA0;
    PD = PD0;
  end
  println("reduceS:")
  redS = ReduceState(HA,PD,ieS,findnzcols(BigModel.Lambda))


  # generate matrices for reduced model:
  global ReducedModel = reduceModel(BigModel,redS,redV,SI);

  doOpt = 0 # 1: use almost-exact state reduction; 0: simple state reduction
  doQZ = size(ReducedModel[1],1) <= _linsol.nDoQZ; # 0: use linear iterative solver; 1: use QZ decomposition

  if doQZ
    println("solve by QZ")
    (exuni,Ar, Br,eigv) = solveQZ( ReducedModel...);
    @assert(all(exuni.==true))
  else
    println("solve by backward iteration")
    (Ar, Br) = solveIter( ReducedModel...);
  end
  println("solveLIN:")
  return LinSolHA(BigModel,Ar,Br,redS,redV);
end

function exogVars(sol::LinSolHA)
  iiStates = sol.redS.ivar;
  distrName = Symbol(sol.model.info.dp[1].D)
  iiDist = sol.model.varNames[distrName]
  nRest = setdiff(iiStates,iiDist);
  return map(i->findIndexInDict(sol.model.varNames,i),nRest);
end
function updateHA(sol::LinSolHA,HA,PD)
  dpproblem = sol.dpProblem;
  # dpproblem = _eval(Main,DPOfModel[modelid(sol.model)])

  doOpt = 1 # 1: use almost-exact state reduction; 0: simple state reduction
  doQZ = 0 # 0: use linear iterative solver; 1: use QZ decomposition

  redV = sol.redV;
  # split equations into different types
  (ieS,ieV,ieY) = splitequ(sol.model,fill("",0));
  SI = stateSpaceInfo(sol.model,ieS,ieV,ieY);
  redS = ReduceState(HA,PD,ieS,findnzcols(sol.model.Lambda))

  # generate matrices for reduced model:
  ReducedModel = reduceModel(sol.model,redS,redV,SI);

  if doQZ>0
    (exuni,Ar, Br,eigv) = solveQZ( ReducedModel...);
    @assert(all(exuni.==true))
  else
    (Ar, Br) = solveIter( ReducedModel...);
  end
  return LinSolHA(sol.model,Ar,Br,redS,redV);
end


function irsim(sol::Union{LinSol,LinSolHA},iShock,sizeShock,T)
  n = nVar(sol);
  nz = nShock(sol);
  x = zeros(n,1);
  TT = T+1;
  shocks = zeros(nz,TT); # to allow for a few forwards
  if(iShock<0)
    tStart = 0;
    x[-iShock] += sizeShock; # this is defined in terms of original variable
  else
    tStart = 1;
    shocks[iShock,1] = sizeShock;
  end
  if isa(sol,LinSol)
    A = LinSol.A
    B = LinSol.B
    IR0 = zeros(TT,n)
    for t=1:T+1
      eps = shocks[:,t];
      if(tStart==0)
        IR0[t,:] = x;
        x = A*x + B*eps;
      else
        x = A*x + B*eps;
        IR0[t,:] = x;
      end
    end
  else
    IR0 = simulHA(sol,shocks;x0=x);
  end
  return IR0;
end
function checkAccuracy(sol::LinSolHA,sizeImpulse::Real = 0.01,T::Int=10)
  nz = size(sol.B,2)
  for i=1:nz
    eps = zeros(nz,T)
    eps[i,1] = sizeImpulse;
    global X = simulHA(sol.model,sol.A,sol.B,sol.redS,sol.redV,eps);
    println("Accuracy for IR to shock $i")
    global errsc = checkAccuracy(sol.model,X);
  end
end
# show CS distribution around switch points
# depends on global variables, should be changed ?????????????????
function plotDistrAtSwitch(sol::LinSolHA,iiSwitch;D = ststDistr(sol), width=11,relative=false,file="")
  D = reshape(D,size(ststDistr(sol)))
  varsStSt = stst(sol)
  switches = sol.pol.stst.switches
    ee = -width:width
  X = zeros(length(ee),length(iiSwitch))
  leg = fill("",0)
  lauf = 1;
  for i in iiSwitch
    (iCS,iEndog,iExog) = switches[i].iState
    iClose = iCS .+ ee
    if relative
      refPoint = D[iCS,iEndog,iExog];
    else
      refPoint = 0;
    end
    X[:,lauf] = D[iClose,iEndog,iExog] .- refPoint;
    lauf += 1;
    push!(leg,string(switches[i].iState))
  end
  x0 = -width*(1.7)
  x1 = width+1
  gplot(ee,X,"set xrange [$x0 : $x1]";x="Bin relative to threshold",t="Density around threshold",leg=leg,file=file,legpos="top left")
end
# show CS distribution around switch points
# depends on global variables, should be changed ?????????????????
function iiNeighborhoodSwitch(switches::Array{Switch{Float64},1}, width=11)
  nSw = length(switches)
  D = ststDistr(sol)
  nD = size(D,1)
  ee = -width:width
  X = Array{Array{Int,1}}(undef,nSw)
  for i = 1:nSw
    (iCS,iEndog,iExog) = switches[i].iState
    iClose = intersect(iCS .+ ee,1:nD)
    X[i] = cart2lin(D,iClose,iEndog,iExog)
  end
  return X;
end
function iiNeighborhoodSwitch(sol::LinSolHA, width=11)
  switches = sol.pol.stst.switches
  return iiNeighborhoodSwitch(switches, width)
end
function distNeighborhoodSwitch2(sw::Switch,D,width=11);
  switches = [sw]
  ii = iiNeighborhoodSwitch(switches,width)[1]
  @show ii
  return D[ii];
end

function massNeighborhoodSwitch(sol::LinSolHA, Xsim::AbstractArray{Float64,2},width=11)
  ii = iiNeighborhoodSwitch(sol, width)
  T = size(Xsim,2);
  n = length(ii)
  mass = zeros(T,n)
  for t=1:T
    for j=1:n
      mass[t,j] = sum(Xsim[ii[j],t])
    end
  end
  return mass
end
massNeighborhoodSwitch(sol::LinSolHA, Xsim::AbstractArray{Float64,1},width=11) = massNeighborhoodSwitch(sol, reshape(Xsim,length(Xsim),1),width)

function irSwitch(mod::LinSolHA,iIR::Integer,sizeShock::Float64,T::Int)
  nZ = size(mod.B,2)
  epsIR = zeros(nZ,T);
  epsIR[iIR,1] = sizeShock;
  IRall = simulHA(mod,epsIR);
  HH = IRall[pos(sol,:H),:]
  n = nVar(mod);

  pol = mod.pol.fluct
  nSw = length(pol.switches)
  Y = zeros(nSw,T-1)

  Sw = pol.switches
  xLast = zeros(n)
  g = pol.grid
  # width of grid at threshold:
  dx = [g[Sw[i].iState[1]+1] - g[Sw[i].iState[1]] for i=1:nSw]
  D = ststDistr(sol);
  massAtBin = [D[Sw[i].iState...] for i=1:nSw]
  densAtBin = massAtBin ./ dx;
  for i=1:size(epsIR,2)-1
    X = [xLast;IRall[:,i];IRall[:,i+1];epsIR[:,i];zeros(2)];
    # change in threshold relative to width of bin:
    dp = map(i-> dot(Sw[i].fracLeft.d,X),1:nSw)
    # total change in threshold:
    Y[:,i] = dp .* dx;
    @show dot(dp,massAtBin)/HH[i]
  end
  return (Y,densAtBin);
end

# represent a covariance matrix in the form  U*Sigma*V'
struct CovmatSparse2
  U::Array{Float64,2}
  Sigma::Array{Float64,2}
  V::Array{Float64,2}
end
full(C::CovmatSparse2) = C.U*C.Sigma*C.V';
import Base.*
*(H::AbstractArray{Float64},C::CovmatSparse2) = CovmatSparse2(H*C.U,C.Sigma,C.V);
*(C::CovmatSparse2,H::AbstractArray{Float64}) = CovmatSparse2(C.U,C.Sigma,H'*C.V);
import Statistics.cov
cov(C::CovmatSparse2,H::AbstractArray{Float64}) = Array(H*C*H');
import Base.size
size(C::CovmatSparse2) = (size(C.U,1),size(C.V,1))
function Base.getindex(x::CovmatSparse2,i,j) 
  if isa(i,Int)
    b1 = x.U[i:i,:]
  else
    b1 = x.U[i,:]
  end
  if isa(j,Int)
    b2 = x.V[j:j,:];
  else
    b2 = x.V[j,:];
  end
  if size(b1,1) > size(b2,1)
    bs = x.Sigma*b2';
    return b1*bs;
  else
    bs = b1*x.Sigma;
    return bs*b2';
  end
end

# compute covariance matrix for solution given by sol
function covmat(sol::LinSolHA,std::Array{Float64,1},T::Int=800,nAugmStates=0)
  nz = size(sol.B,2);
  nSt = size(sol.redS.selectMom,2) + nAugmStates;
  nx = nVar(sol);
  local IR
  for i=1:nz
    shocks = zeros(nz,T)
    shocks[i,1] = 1;
    IR0 = simulHA(sol,shocks);
    if i==1
      IR = IR0;
    else
      IR = hcat(IR,IR0);
    end
  end
  (U,s,V) = svd(IR[1:nSt,:]);
  n = length(mfind(s.>s[1]*1e-14))
  global U = U[:,1:n];
  global Unext = forwardHA(sol,zeros(nz);x0=U);
  Unext = Unext[1:nSt,:];
  global A = U'*Unext;
  @show maximum(abs,Unext-U*A);
  @show maximum(abs,eigen(A).values)
  global B = zeros(n,nz)
  for i=1:nz
    eps = zeros(nz)
    eps[i] = 1
    Bi = forwardHA(sol,eps);
    B[:,i] = U'*Bi[1:nSt];
  end
  sigU = doubling(A,B,mdiagm(std.^2),30);
  return CovmatSparse2(U,sigU,U);
end
function proxyCondExp(H,Sigma::CovmatSparse2,eps::Float64=1e-12)
  HSH = Array(H*Sigma*H') + eps*H*H';
  SH = Array(Sigma*H') + eps*H';
  return SH/HSH;
end
#=
Design:
s = U*m  and  m = U's

m(t-1) = I   ==>
1) s(t-1) = U
2) m(t) = A
3) s(t) = U*A 
==>
A = U'*s(t)


=#

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# Impulse response for linear model
# Inputs:
# A,B system matrices
# varsStSt: structure of variables in steady state
# iShock:
#   if positive: shock number
#   if negative: absolute value is number of variable that deviates from steady state
# sizeShock:
#   size of initial deviation
# T: length of impulse response
# vars0: Array of variables, consisting of any number of records dat_i
#        each dat_i is of one of the following forms:
#function plot2file(outfile)
#  fig = gcf()
#  plot2file(fig,outfile)
#  close(fig)
#end
function tuple2arrayany(a)
  n = length(a)
  x = Array{Any}(undef,n)
  @inbounds for i=1:n
    x[i] = a[i];
  end
  return x;
end
function irlin(sol,varNames,varsStSt,
  iShock::Int, sizeShock::Float64,T::Int,
  vars::Array{Any,1})
  # vars = convert(Array{Any},vars0)
  nz = nShock(sol);
  n = nVar(sol);
  TT = T+1;
  if isa(sol,LinSol)
    x = zeros(n,1);
    shocks = zeros(nz,TT); # to allow for a few forwards
    if(iShock<0)
      tStart = 0;
      x[-iShock] += sizeShock; # this is defined in terms of original variable
    else
      tStart = 1;
      shocks[iShock,1] = sizeShock;
    end
    IR0 = zeros(TT,n)
    for t=1:T+1
      eps = shocks[:,t];
      if(tStart==0)
        IR0[t,:] = x;
        x = sol.A*x + sol.B*eps;
      else
        x = sol.A*x + sol.B*eps;
        IR0[t,:] = x;
      end
    end
  else
    IR0 = irsim(sol,iShock,sizeShock,T)'; # transform to one column per variable
  end
  doPlot = true

  IR = fill(0.,(TT,0))
  Legend = Array{String}(undef,0);
  i=1;
  # default output: percentage deviation, unless stst=0
  scalStSt = true
  addStSt = false
  plotFile = ""
  xLabel = ""
  yLabel = ""
  ttl = ""
  period = 1; # default: show model periods
  while(i<=length(vars))
    iIncr=1;
    if(isa(vars[i],Float64)) # scaling
      IR[:,end] = IR[:,end] .* vars[i];
    elseif(isa(vars[i],Int))
      error("misplaced Integer in irlin")
    elseif(isa(vars[i],Function)) # apply function to output
      # apply function to original variable:
      if(vars[i]==diff)  # difference
        IR[:,end] = [IR[1,end];diff(IR[:,end])]
      else
        IR[:,end] = map(vars[i],IR[:,end])
      end
    elseif(isa(vars[i],String)) # special functions
      if(vars[i]=="abs")  # absolute deviation
        scalStSt = false
        addStSt = true
      elseif(vars[i]=="dev")  # absolute deviation
        scalStSt = false
        addStSt = false
      elseif(vars[i]=="perc")  # percentage deviation, unless stst=0
        scalStSt = true
        addStSt = false
      elseif(vars[i]=="noplot" || vars[i]=="nograph") 
        doPlot = false
      elseif(length(vars[i])>=5 && vars[i][1:5]=="file=") 
        plotFile = vars[i][6:end];
        doPlot = true
      elseif(length(vars[i])>=2 && vars[i][1:2]=="x=") 
        xLabel = vars[i][3:end];
      elseif(length(vars[i])>=2 && vars[i][1:2]=="y=") 
        yLabel = vars[i][3:end];
      elseif(length(vars[i])>=6 && vars[i][1:6]=="title=") 
        ttl = vars[i][7:end];
      elseif(length(vars[i])>=5 && vars[i][1:5]=="forw=")  # shift curve forward in time
        iLag = parse(Int,vars[i][6:end])
        if iLag>0
          IR[:,end] = vcat(fill(NaN,(iLag,)),IR[1:end-iLag,end])
        else
          iLag = -iLag;
          IR[:,end] = vcat(IR[iLag+1:end,end],fill(NaN,(iLag,)))
        end
      elseif(vars[i]=="norm")  # normalize to IR[iNorm]=0 by additive shift
        @assert(i<length(vars) && isa(vars[i+1],Int),
                println("normalization needs following Int"))
        iNorm = vars[i+1]
        assert(iNorm>0 && iNorm<=TT)
        iIncr=2;
        IR[:,end] = IR[:,end] .- IR[iNorm,end]
      elseif(vars[i][1:4]=="leg=")  # difference
        Legend[end] = vars[i][5:end]
      elseif(vars[i][1:7]=="period=")  # difference
        period = eval(Meta.parse(vars[i][8:end]))
      else
        error("unknwon commmand string in irlin: " * vars[i])
      end
    elseif(isa(vars[i],Symbol))
      iPos = varNames[vars[i]]
      # iPos = posInStruct(varsStSt,vars[i])
      if length(iPos) == 1
        iVar = iPos
        vstst = getfield(varsStSt,vars[i])
        leg = string(vars[i])
      else  # case of array variab le
        if i==length(vars)
          error("Array " * string(vars[i])*" needs following subscript, none given");
        end
        if !(isa(vars[i+1],Int) || isa(vars[i+1],AbstractArray{Int,1}))
          error("Array " * string(vars[i])*" needs following subscript of type Int or AbstractArray{Int,1}, but type " * string(typeof(vars[i+1])) * " given")
        end
        iSubscr = vars[i+1]
        iVar = iPos[iSubscr]
        if length(iSubscr)==1
          leg = string(vars[i]) * "[" * string(iSubscr) * "]"
        else
          leg = map(j->string(vars[i]) * "[" * string(j) * "]",iSubscr)
        end
        vstst = getfield(varsStSt,vars[i])[iSubscr]
        iIncr=2;
      end
      Legend = vcat(Legend,leg)
      xAdd = addStSt ? vstst : 0;
      xMul = (scalStSt && all(vstst.!=0)) ? 1.0 ./ vstst' : 1.0
      IR = hcat(IR,xMul.*IR0[:,iVar] .+ xAdd)
    end
    i+=iIncr;
  end
  if !doPlot 
    return (IR,Legend)
  end
  tt = seqa(0,(1/period),size(IR,1))
  if @isdefined Plots
    pl = Plots.plot(tt,IR,linewidth=2,label=Legend,xlabel=xLabel,ylabel=yLabel,title=ttl);
    if !isempty(plotFile)
      savefig("$plotFile.pdf")
    end
    return pl
  elseif @isdefined gplot
    gplot(tt,IR;leg=Legend,x=xLabel,y=yLabel,t=ttl,lw=3.0,file=plotFile)
  else
    @warn("no plotting package")
  end
end
function irlinRaw(A::Array{Float64,2},B::Array{Float64,2},varsStSt,
                  iShock::Int, sizeShock::Float64,T::Int,
                  vars::Array)
  # vars = convert(Array{Any},vars0)
  nz = size(B,2);
  n = size(A,1);
  x = zeros(n,1);
  TT = T+1;
  shocks = zeros(nz,TT); # to allow for a few forwards
  if(iShock<0)
    tStart = 0;
    x[-iShock] += sizeShock; # this is defined in terms of original variable
  else
    tStart = 1;
    shocks[iShock,1] = sizeShock;
  end
  Legend = Array{String}(0);
  indxVars = Array{Int}(0)
  funcs = Array{Function}(0)
  allScal = Array{Float64}(0)
  allAdd = Array{Float64}(0)
  i=1;
  # default output: percentage deviation, unless stst=0
  scalStSt = true
  addStSt = false
  currScal = 1.0
  currFunc = x->x
  while(i<=length(vars))
    iIncr=1;
    if(isa(vars[i],Float64)) # scaling
      allScal[end] *= vars[i];
    elseif(isa(vars[i],Int))
      error("misplaced Integer in irlin")
    elseif(isa(vars[i],Function)) # apply function to output
      # apply function to original variable:
      currFunc = vars[i];
    elseif(isa(vars[i],String)) # special functions
      if(vars[i]=="abs")  # absolute deviation
        scalStSt = false
        addStSt = true
      elseif(vars[i]=="dev")  # absolute deviation
        scalStSt = false
        addStSt = false
      elseif(vars[i]==:"perc")  # percentage deviation, unless stst=0
        scalStSt = true
        addStSt = false
      end
    elseif(isa(vars[i],Symbol))
      iPos = posInStruct(varsStSt,vars[i])
      if isa(iPos,Int) # scalar variable
        iVar = iPos
      else  # case of array variab le
        @assert(i<length(vars) && isa(vars[i+1],Int),
                println(string(vars[i])*" is array, needs following subscript"))
        iSubscr = vars[i+1]
        iVar = iPos[iSubscr]
        iIncr=2;
      end
      push!(indxVars,iVar)
      push!(Legend,string(vars[i]))
      push!(funcs,currFunc)
      vstst = getfield(varsStSt,vars[i])
      if scalStSt && vstst!=0
        currScal /= vstst;
      end
      push!(allScal,currScal);
      if addStSt && vstst!=0
        push!(allAdd,vstst);
      else
        push!(allAdd,0.);
      end
      currScal = 1.0
      currFunc = x->x
    end
    i+=iIncr;
  end
  IR = zeros(TT,length(indxVars));
  for t=1:T+1
    eps = shocks[:,t];
    if(tStart==0)
      IR[t,:] = x[indxVars];
      x = A*x + B*eps;
    else
      x = A*x + B*eps;
      IR[t,:] = x[indxVars];
    end
  end
  for j=1:size(IR,2)
    if funcs[j]==x->x
      IR[:,j] = map(funcs[j],allScal[j].*IR[:,j].+allAdd[j])
    end
  end
  #plot(IR,linewidth=2);
  #legend(Legend);
  return (IR,Legend)
end
function irlin(sol::LinSol,
               iShock::Int, sizeShock::Float64,T::Int,
               vars...)
  return irlin(sol,sol.varNames,sol.vstst, iShock,sizeShock,T,tuple2arrayany(vars))
end
function irlin(sol::LinSolHA,
               iShock::Int, sizeShock::Float64,T::Int,
               vars...)
  return irlin(sol,sol.model.varNames,sol.model.vstst, iShock,sizeShock,T,tuple2arrayany(vars))
end
function irlin(model::LinSol,
               nameShock::Symbol, 
               sizeShock::Float64,T::Int,
               vars...)
  iiShock = possh(model,nameShock)
  if length(iiShock)>1
    error(string(nameShock) * " is a vector, give index")
  else
    iShock = iiShock[1]
  end
  return irlin(model,iShock,sizeShock,T,"title=Shock $nameShock",tuple2arrayany(vars))
end
function irlin(model::LinSol,
               nameShock::Symbol, 
               indexShock::Int,
               sizeShock::Float64,T::Int,
               vars...)
  iiShock = possh(model,nameShock)
  if length(iiShock)==1
    error(string(nameShock) * " is a scalar, do not give index")
  else
    iShock = iiShock[indexShock]
  end
  stringShock = string(nameShock) * "[$indexShock]"
  return irlin(model,iShock,sizeShock,T,"title=IR to $stringShock",tuple2arrayany(vars))
end
function irlin(model::LinSol,
               nameShock::Symbol, 
               indexShock::AbstractArray{Int},
               sizeShock::Float64,T::Int,
               vars...)
  iiShock = possh(model,nameShock)
  if length(iiShock)==1
    error(string(nameShock) * " is a scalar, do not give index")
  else
    iiShock = iiShock[indexShock]
  end
  stringShock = string(nameShock);
  IR = zeros(T+1,0)
  leg = fill("",(0))
  for i=1:length(iiShock)
    iShock = iiShock[i]
    IRleg = irlin(model,iShock,sizeShock,T,"noplot",tuple2arrayany(vars))
    IR = hcat(IR,IRleg[1])
    ii = indexShock[i]
    if size(IRleg[1],2)==1
      push!(leg,"$stringShock[$ii]")
    else
      leg = vcat(leg,IRleg[2] .*"[$ii]")
    end
  end
  if @isdefined PyPlot
    plot(IR)
    legend(leg)
    title("IR to " * stringShock)
  else
    ttl = stringShock*"[]"
    plotg(IR,1.0,leg,"","",ttl,3.0) # missing: extract (period,start)
    # plotg(IR,(period,0.0),leg,xLabel,yLabel,ttl,3.0)
  end
end
function plotleg(x,leg)
  plot(x)
  legend(leg)
end
function irlinp(args...)
  plotleg(irlin(args...))
end


# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function getDeriv1(model,pars,aggr,dpVal,dpPol) # in steady state
  (nCS,nDS,nExog) = size(dpVal.V)
  gridCS = dpVal.grid;
  TransExogPrime = model._transExog(pars,aggr,StStIndex(0))'
  deriv1 = fill(zero(Float64),(nCS,nDS,nExog))
  pT = model.TempParam{Deriv1F{2}}()
  derivcontrol = similar(deriv1)

  t = StStIndex(0)
  deriv1_ = reshape(deriv1,nCS,nDS*nExog)*TransExogPrime; 
  deriv1end = reshape(deriv1_,nCS,nDS,nExog)
  for iZ=1:nExog # for each value of exogenous state
    for iDS=1:nDS # for each value of endogenous dscrete state
      disc = model._disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
      for iCS=1:nCS # for each value of endogenous continuous state
        xCS = gridCS[iCS];
        dCS = indep(Deriv1F{2},xCS,1)
        iDC = dpPol.DC[iCS,iDS,iZ]
        model._prep!(pars,aggr,pT,dCS,iDS,iZ,iDC,t) 
        pT.iDE = dpPol.DE[iCS,iDS,iZ]
        (isDiscrete,ccRange) =model._range(pars,aggr,pT,dCS,iDS,iZ,iDC,t)
        b = dpPol.B[iCS,iDS,iZ]
        if isDiscrete ==2 && b==0 
          cc = dpPol.CC[iCS,iDS,iZ]
          deriv1[iCS,iDS,iZ] = envelope(model,pars,aggr,pT,xCS,iDS,iZ,cc,iDC,t);
        else
          if iCS==1
            deriv1[iCS,iDS,iZ] = (dpVal.V[2,iDS,iZ]-dpVal.V[1,iDS,iZ])/ (gridCS[2]-gridCS[1])
          elseif iCS==nCS
            deriv1[iCS,iDS,iZ] = (dpVal.V[nCS,iDS,iZ]-dpVal.V[nCS-1,iDS,iZ])/ 
            (gridCS[nCS]-gridCS[nCS-1])
          else
            deriv1[iCS,iDS,iZ] = (dpVal.V[iCS+1,iDS,iZ]-dpVal.V[iCS-1,iDS,iZ])/ 
            (gridCS[iCS+1]-gridCS[iCS-1])
          end
        end
      end
    end
  end
  # saveT("der.bmt",deriv1,dpPol.CC,dpVal.grid,dpVal.V); error("done")
  return deriv1
end
function splitWithDC(DC)
  A = Array{typeof(1:3),1}(undef,0)
  n = length(DC)
  start = 1;
  while start<=n
    j = DC[start]
    for i=start+1:n+1
      if i>n
        push!(A,start:n)
        start = n+1;
        break;
      end
      if DC[i]!=j
        push!(A,start:i-1)
        start = i;
        break;
      end
    end
  end
  return A;
end
function setQ2!(Q,der1::Array{Float64,3},grid::Array{Float64,1},dpPolV,width::Int)
  (n1,n2,n3) = size(der1)
  @assert(length(grid)==n1)
  defaultVal = 0.0;
  adjustQ = diff(grid).^2 / 2
  for k=1:n3
    for j=1:n2
      ranges = splitWithDC(dpPolV.DC[:,j,k])
      @assert(ranges[end][end]==size(Q,1))
      for iR=1:length(ranges)
        ii = ranges[iR]
        m = length(ii)
        if m==1
          i = ii[1]
          Q[i,j,k] = defaultVal;
        elseif m==2
          i = ii[1]
          deltax = grid[i+1]-grid[i]
          der2 = (der1[i+1,j,k]-der1[i,j,k]) / deltax
          Q[i,j,k] = min(der2,defaultVal) * adjustQ[i]
          Q[i+1,j,k] = defaultVal;
        elseif m<=2*width+1
          x = grid[ii]
          X = hcat(ones(m),x,x.^2)
          b = X\der1[ii,j,k]
          for i in ii[1:end-1]
            Q[i,j,k] = (b[2] + 2*b[3]*grid[i]) * adjustQ[i];
          end
          i = ii[end]
          Q[i,j,k] = Q[ii[end-1],j,k];
          # Q[i,j,k] = defaultVal;
        else
          x = grid[ii]
          Y = der1[ii,j,k]
          for i in ii[1:end-1]
            (err,dv2) = localRegression(x,Y,i-ii[1]+1,width,2)
            Q[i,j,k] = dv2 * adjustQ[i];
          end
          i = ii[end]
          Q[i,j,k] = defaultVal;
        end
      end
    end
  end
end

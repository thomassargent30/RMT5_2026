# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# maximize function f withint bounds (a,b) by golden search with fixed number of steps n:
function maxGoldenN(f,a,b,nSteps)

  alpha1 = (3-sqrt(5))/2;
  alpha2 = (sqrt(5)-1)/2;
  d  = b-a;
  x1 = a+alpha1*d;
  x2 = a+alpha2*d;
  f1 = f(x1);
  f2 = f(x2);

  d = alpha1*alpha2*d;
  #while d>tol  # use criterion for x
  for iStep=1:nSteps
    d = d*alpha2;
    if f2<f1 # x2 is new upper bound
      x2 = x1; 
      x1 = x1-d; 
      f2 = f1; 
      f1 = f(x1);
    else     # x1 is new lower bound
      x1 = x2; 
      x2 = x2+d; 
      f1 = f2; 
      f2 = f(x2);
    end
  end
  return f1>=f2 ?  (x1,f1) : (x2,f2);
end

function bisect(f, a, b, tolX=1e-8)
  fa = f(a);
  if(fa==0)
    return (a,0);
  end
  fb = f(b);
  if(fb==0)
    return (b,0);
  end
  if(!(fa*fb<0))
    return (NaN,-1); # -1 signals root not bracketed
  end

  # Iteration loop
  while (b-a>tolX)
    mid = (a+b)/2;
    fmid = f(mid);
    if(fmid==0)
      return (mid,0);
    end
    if(fmid*fb>0) # new interval is (a,mid)
      b = mid;
      fb = fmid;
    else
      a = mid;
      fa = fmid;
    end
  end
  return ((a+b)/2,0);
end

# Grid search for local maxima of the function f between a and b, using N steps
# dimension of N: level of search
# N[i] gives size of grid in level i
# Example: (B,V) = MaxSearch!(x->sin(x),-0.2,15.3,[30 10 10]);
function MaxSearch!(f,a,b,N,B=[],V=[],vBounds=[])
  n = N[1];
  @assert(n>2)
  if(isempty(B))
    B = zeros(2,0);
    V = zeros(3,0);
  end
  X = linspace(a,b,n)
  Y = zeros(n,1);
  for i=2:(n-1)
    Y[i] = f(X[i]);
  end
  if(isempty(vBounds))
    Y[1] = f(X[1]);
    Y[n] = f(X[n]);
  else
    Y[1] = vBounds[1]
    Y[n] = vBounds[2]
  end
  for i=1:n
    i0 = 0;
    if(i==1)
      if(Y[1]>=Y[2])
        i0 = 1;
        i1 = 2;
        imax = 1;
      end
    elseif(i==n)
      if(Y[n]>=Y[n-1])
        i0 = n-1;
        i1 = n;
        imax = n;
      end
    else
      if(Y[i]>=Y[i-1] && Y[i]>=Y[i+1])
        i0 = i-1;
        i1 = i+1;
        imax = i;
      end
    end
    if(i0>0) # found a local maximum
      if(length(N)==1)
        B = [B X[[i0;i1]]];
        V = [V Y[[i0;i1;imax]]];
      else
        (B,V) = MaxSearch!(f,X[i0],X[i1],N[2:end],B,V,Y[[i0;i1]])
      end
    end
  end
  return (B,V)
end


function MaxThorough(f,a,b,nGrid,nGolden)
  if(a==b) # special case: no choice
    return (a,f(a))
  elseif(a>b) 
    error(@sprintf("feasible set empty in MaxThorough: a=%f, b=%f\n",a,b));
    return (a,f(a)) # never get here
  end
  (B,V) = MaxSearch!(f,a,b,nGrid);
  n = size(B,2)
  if(!(n>0))
    @printf("error in MaxThorough: a=%f, b=%f, f(a) = %e, f(b)=%e\n",a,b,f(a),f(b));
    @assert(false)
  end
  fTry = zeros(n,1);
  xTry = zeros(n,1);
  for i=1:n
    (xTry[i],fTry[i]) = maxGoldenN(f,B[1,i],B[2,i],nGolden)
  end
  iOpt = argmax(fTry);
  xOpt = xTry[iOpt]
  fOpt = fTry[iOpt]
  myEps = max(1e-6,(b-a)*1e-8)
  if(xOpt<a+myEps && xOpt>a)
    fa = f(a);
    if(fa>fOpt)
      return (a,fa)
    else
      # @printf("Warning: optimum close to lower boundary: %f, %e", a,xOpt-a)
    end
  end
  if(xOpt>b-myEps && xOpt<b)
    fb = f(b);
    if(fb>fOpt)
      return (b,fb)
    else
      @printf("Warning: optimum close to upper boundary: %f, %e", b,b-xOpt)
    end
  end
  return (xOpt,fOpt);
end
function goldenSearchMax(f,ax,bx,cx,tol)
  R =  0.61803399
  C =  (1.0-R)

  x0=ax;
  x3=cx;
  if (abs(cx-bx) < abs(bx-ax)) 
    x1=bx;
    x2=bx+C*(cx-bx);
  else
    x2=bx;
    x1=bx-C*(bx-ax);
  end
  f0=f(x0);
  f1=f(x1);
  f2=f(x2);
  f3=f(x3);
  while (abs(x3-x0) > tol*(max(1,abs(x1)+abs(x2)))) 
    if (f2 > f1 || (f2==f1 && f3>f2)) 
      x0=x1;x1=x2;x2=R*x1+C*x3
      f0=f1;f1=f2;f2=f(x2)
    else
      x3=x2;x2=x1;x1=R*x2+C*x0
      f3=f2;f2=f1;f1=f(x1)
    end
  end
  #println([f0 f1 f2 f3])
  if (f2 > f1 || (f2==f1 && f3>f2)) 
    if (f2 > f3) 
      return (x2,f2);
    else
      return (x3,f3);
    end
  else
    if (f0 > f1) 
      return (x0,f0);
    else
      return (x1,f1);
    end
  end
end



#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

function goldenSearch(f,ax,bx,cx,tol)
  R =  0.61803399
  C =  (1.0-R)

  x0=ax;
  x3=cx;
  if (abs(cx-bx) > abs(bx-ax)) 
    x1=bx;
    x2=bx+C*(cx-bx);
  else
    x2=bx;
    x1=bx-C*(bx-ax);
  end
  f0=f(x0);
  f1=f(x1);
  f2=f(x2);
  f3=f(x3);
  while (abs(x3-x0) > tol*(max(1,abs(x1)+abs(x2)))) 
    if (f2 < f1 || (f2==f1 && f3<f2)) 
      x0=x1;x1=x2;x2=R*x1+C*x3
      f0=f1;f1=f2;f2=f(x2)
    else
      x3=x2;x2=x1;x1=R*x2+C*x0
      f3=f2;f2=f1;f1=f(x1)
    end
  end
  #println([f0 f1 f2 f3])
  if (f2 < f1 || (f2==f1 && f3<f2)) 
    if (f2 < f3) 
      return (x2,f2);
    else
      return (x3,f3);
    end
  else
    if (f0 < f1) 
      return (x0,f0);
    else
      return (x1,f1);
    end
  end
end

# x and y are Lagrange multiplieres
# funcx and funcy are inequality constraints, >=0
function complSlack2(funcx,funcy,x0,y0,boundx=1000,boundy=1000,step=1e-5,tol=1e-8)
  # first try the case that is given by initial guess:
  if(x0==0 && y0==0)
    fx0 = funcx(x0,y0);
    fy0 = funcy(x0,y0);
    if(fx0>=0 && fy0>=0)
      return ([x0,y0],0); # both constraints not binding
    end
  elseif(x0==0)
    (yOpt,flag) = complSlack1(y->funcy(x0,y),y0,boundy,step,tol);
    if(flag==0 && funcx(x0,yOpt)>=0) # first constraint is binding
      return ([x0,yOpt],0)
    end
  elseif(y0==0)
    (xOpt,flag) = complSlack1(x->funcx(x,y0),x0,boundx,step,tol);
    if(flag==0 && funcy(xOpt,y0)>=0) # second constraint  is binding
      return ([xOpt,y0],0)
    end
  else
    func2 = X -> [funcx(X[1],X[2]);funcy(X[1],X[2])];
    (XOpt,flag) = broydn(func2,[x0;y0],tolf=tol,doPrint=0);
    if(flag==0 && XOpt[1]>=0 && XOpt[2]>=0) # both constraints are binding
      return (XOpt,0);
    end
  end
  # if we reach this, none of the above has worked; start from scratch,
  #   try all cases unconditionally
  # following is not optimal, could be made more efficient:
  x0=0;
  y0==0
  fx0 = funcx(x0,y0);
  fy0 = funcy(x0,y0);
  if(fx0>=0 && fy>=0)
    return ([x0,y0],0); # both constraints not binding
  end
  (yOpt,flag) = complSlack1(y->funcy(x0,y),y0,boundy,step,tol);
  if(flag==0 && funcx(x0,yOpt)>=0) # first constraint is binding
    return ([x0,yOpt],0)
  end
  (xOpt,flag) = complSlack1(x->funcx(x,y0),x0,boundx,step,tol);
  if(flag==0 && funcy(xOpt,y0)>=0) # second constraint  is binding
    return ([xOpt,y0],0)
  end
  func2 = X -> [funcx(X[1],X[2]);funcy(X[1],X[2])];
  (XOpt,flag) = broydn(func2,[x0;y0],tolf=tol,doPrint=0);
  if(flag==0 && XOpt[1]>=0 && XOpt[2]>=0) # both constraints are binding
    return (XOpt,0);
  end
  return (zeros(2),4)
end

# x should be lagrange multiplier
function complSlack1(func,x0,bound=1000,step=1e-5,tol=1e-8)
  if(x0==0) # starting value: constraint is binding
    f0 = func(x0);
    if(f0>0) # guess: complementary slackness satisfied
      return (x0,0);
    else
      x1 = step
      f1 = func(x1);
      while(f1<0 && x0<bound)
        x1 = min(bound,x0 + step);
        f1 = func(x1);
        if(f1>0)
          return fzero(func,x0,x1,f0,f1,tol);
        end
        x0 = x1;
        f0 = f1;
        step*= 2;
      end
      return (x0,4);
    end
  else # guess: interior
    (xOpt,flag) =  fzero_search(func,x0,x0+step,0,bound,tol)
    if(flag==0) # found interior solution
      return (xOpt,flag);
    elseif(func(0.0)>0) # compl. slackeness satisfied
      return (xOpt,0)
    else
      return (xOpt,4) # no solution found
    end
  end
end


function fzero_search(func,a,b,lowB=-1e6,uppB=1e6,tol=1e-8)
  @assert(b>a)
  step = (b-a)/2;
  fa = func(a);
  fb = func(b);
  while(fa*fb>0)
    step *= 2;
    #println(step)
    if(abs(fa)<abs(fb))
      c = max(lowB,a-step);
      fc = func(c);
      if(fc*fa<0)
        return fzero( func, c,a,fc,fa,tol)
      end
      #println([a b c])
      #println([fa fb fc])
      if(abs(fc)>abs(fa))
        return(c,3)
      end
      if(c==lowB)
        return (c,4)
      end
      a = c;
      fa = fc;
    else
      c = min(uppB,b+step);
      fc = func(c);
      if(fc*fb<0)
        return fzero( func, b,c,fb,fc,tol)
      end
      if(abs(fc)>abs(fb))
        error("2: not brackated and not monotonic");
      end
      if(c==uppB)
        return (c,4)
      end
      b = c;
      fb = fc;
    end
  end
end

function fzero( func, a,b,tol=1e-8)
  fa=func(a);
  fb=func(b);
  return fzero(func,a,b,fa,fb,tol)
end

function fzero( func, a,b,fa,fb,tol=1e-8)
  # Output: 
  # 1) xZero
  # 2) iflag:   0  if success
  #             1  if not converged
  #             -1 if initial values do not bracket a zero

  @assert(isfinite(fa))
  @assert(isfinite(fb))
  EPS  = 3.0e-15
  SIGN(a,b)  = (b >= 0.0 ? abs(a) : -abs(a));

  c=b;d=0;e=0;

  if(fa*fb>=0)
    if(fa==0)
      return (a,0);
    end
    if(fb==0)
      return (b,0);
    end
    return (NaN,-1);# -1 signals root not bracketed
  end
  iflag = 0;

  fc=fb;
  for its=1:200
    if ((fb > 0.0 && fc > 0.0) || (fb < 0.0 && fc < 0.0)) 
      c=a;
      fc=fa;
      e=d=b-a;
    end
    if (abs(fc) < abs(fb)) 
      a=b;
      b=c;
      c=a;
      fa=fb;
      fb=fc;
      fc=fa;
    end
    tol1=2.0*EPS*abs(b)+0.5*tol;
    xm=0.5*(c-b);
    if (abs(xm) <= tol1 || fb == 0.0)
      # @printf("%20.14f %20.14f; %e %e\n", a,b,fa,fb)
      if abs(fa)<abs(fb)
        return (a,0);
      else
        return (b,0);
      end
    end
    if (abs(e) >= tol1 && abs(fa) > abs(fb)) 
      s=fb/fa;
      if (a == c) 
        p=2.0*xm*s;
        q=1.0-s;
      else 
        q=fa/fc;
        r=fb/fc;
        p=s*(2.0*xm*q*(q-r)-(b-a)*(r-1.0));
        q=(q-1.0)*(r-1.0)*(s-1.0);
      end
      if (p > 0.0) q = -q; end
      p=abs(p);
      min1=3.0*xm*q-abs(tol1*q);
      min2=abs(e*q);
      if (2.0*p < (min1 < min2 ? min1 : min2)) 
        e=d;
        d=p/q;
      else 
        d=xm;
        e=d;
      end
    else 
      d=xm;
      e=d;
    end
    a=b;
    fa=fb;
    if (abs(d) > tol1)
      b += d;
    else
      b += SIGN(tol1,xm);
    end
    fb=func(b);
  end
  return (b,1);
end

# one-dim rootfinding, try to bracket the zero if not originally bracketed
function fzerobracket( func, xLo,xHi,tol=1e-8,minstepfactor=0.25)
  @assert(xHi>xLo,println("upper bound higher than lower bound in fzerobracket"))
  maxstep = (xHi-xLo);
  minstep = minstepfactor*(xHi-xLo); # make this factor a parameter!!
  fLo=func(xLo);
  fHi=func(xHi);
  df = NaN
  flag = 1;
  for iter=1:100 # max 100 steps
    if fLo*fHi<=0
      # println("successfully bracketed")
      return fzero(func,xLo,xHi,fLo,fHi,tol)
    end
    if !isfinite(df)
      df = (fHi-fLo)/(xHi-xLo)
    end
    local xNew,fNew
    if df==0
      error("no change in f from $xLo to $xHi")
    elseif abs(fHi)<abs(fLo)
      step =  - 2*fHi/df
      if abs(step)>maxstep
        step *= maxstep/abs(step)
      elseif abs(step)<minstep
        step *= minstep/abs(step)
      end
      @assert(step>0,@show(step,fHi,df))
      for i=1:20 # 20 steps
        xNew = xHi + step
        fNew = func(xNew)
        if abs(fNew)<10*abs(fHi) # signals failure
          flag = 1;
          break;
        else
          step /= 2;
        end
      end
      @assert(abs(fNew)<10*abs(fHi))
      if fNew*fHi<=0 # short-cut, use former upper bound
        return fzero(func,xHi,xNew,fHi,fNew,tol)
      end
      dfTry = (fNew-fHi) / (xNew/xHi)
      if df*dfTry>0 # same sign
        df = dfTry
      end
      xHi = xNew
      fHi = fNew
    else
      step =  - 2 * fLo/df
      if abs(step)>maxstep
        step *= maxstep/abs(step)
      end
      @assert(step<0)
      for i=1:20 # 20 steps
        xNew = xLo + step
        fNew = func(xNew)
        if abs(fNew)<10*abs(fHi) # signals failure
          flag = 1;
          break;
        else
          # @show [xNew fNew]
          step /= 2;
        end
      end
      @assert(abs(fNew)<10*abs(fHi))
      if fNew*fLo<=0
        return fzero(func,xNew,xLo,fNew,fLo,tol)
      end
      dfTry = (fNew-fLo) / (xNew-xLo)
      if df*dfTry>0 # same sign
        df = dfTry
      end
      xLo = xNew
      fLo = fNew
    end
  end
  error("could not bracket")
  return fzero(func,xHi,xNew,fHi,fNew,tol) # never get here
end
# one-dim rootfinding, try to bracket the zero if not originally bracketed
function fzerobracket2( func::Function, xLo::Float64,xHi::Float64,xMin::Float64,xMax::Float64,tol::Float64=1e-8) :: Tuple{Float64,Int}
  @assert(xHi>xLo,println("upper bound higher than lower bound in fzerobracket"))
  step = (xHi-xLo)/2;
  fLo=func(xLo);
  fHi=func(xHi);
  if fLo*fHi<=0
    return fzero(func,xLo,xHi,fLo,fHi,tol)
  end
  if abs(fHi)<abs(fLo)
    orders = [1;-1]
  else
    orders = [-1;1]
  end
  for order in orders
    if order==1
      while xHi < xMax
        xHi2 = min(xHi+step,xMax)
        fHi2 = func(xHi2)
        if fHi2*fHi<=0
          return fzero(func,xHi,xHi2,fHi,fHi2,tol)
        else
          xHi = xHi2
          fHi = fHi2;
        end
      end
    else
      while xLo > xMin
        xLo2 = min(xLo-step,xMin)
        fLo2 = func(xLo2)
        if fLo2*fLo<=0
          return fzero(func,xLo2,xLo,fLo2,fLo,tol)
        else
          xLo = xLo2
          fLo = fLo2;
        end
      end
    end
  end
  return (NaN,-1);
end


# taken from boost, slightly modified
function brent2(f, xa, xb,  tolerance)
  # bits = (std::min)(policies::digits<T, policies::policy<> >() / 2, bits);
  # T tolerance = static_cast<T>(ldexp(1.0, 1-bits));
  # T x;  // minima so far
  # T w;  // second best point
  # T v;  // previous value of w
  # T u;  // most recent evaluation point
  # T delta;  // The distance moved in the last step
  # T delta2; // The distance moved in the step before last
  # T fu, fv, fw, fx;  // function evaluations at u, v, w, x
  # T mid; // midpoint of min and xb
  # T fract1, fract2;  // minimal relative movement in x

  golden = 0.3819660;  # golden ratio, don't need too much precision here!

  x = w = v = xb;
  fw = fv = fx = f(x);
  delta2 = delta = 0.;



  max_iter = 100
  flag = 1;
  for iter=1:max_iter
    # get midpoint
    mid = (xa + xb) / 2;
    # work out if we're done already:
    fract1 = tolerance * abs(x) + tolerance / 4;
    fract2 = 2 * fract1;
    if(abs(x - mid) <= (fract2 - (xb - xa) / 2))
      flag = 0;
      break;
    end

    if(abs(delta2) > fract1)
      # try and construct a parabolic fit:
       r = (x - w) * (fx - fv);
       q = (x - v) * (fx - fw);
       p = (x - v) * q - (x - w) * r;
      q = 2 * (q - r);
      if(q > 0)
        p = -p;
      end
      q = abs(q);
       td = delta2;
      delta2 = delta;
      # determine whether a parabolic step is acceptible or not:
      if((abs(p) >= abs(q * td / 2)) || (p <= q * (xa - x)) || (p >= q * (xb - x)))

        # nope, try golden section instead
        delta2 = (x >= mid) ? xa - x : xb - x;
        delta = golden * delta2;
      else

        # whew, parabolic fit:
        delta = p / q;
        u = x + delta;
        if(((u - xa) < fract2) || ((xb- u) < fract2))
          delta = (mid - x) < 0 ? -abs(fract1) : abs(fract1);
        end
      end
    else

      # golden section:
      delta2 = (x >= mid) ? xa - x : xb - x;
      delta = golden * delta2;
    end
    # update current position:
    u = (abs(delta) >= fract1) ? (x + delta) : (delta > 0 ? (x + abs(fract1)) : (x - abs(fract1)));
    fu = f(u);
    if(fu <= fx)

      # good new point is an improvement!
      # update brackets:
      if(u >= x)
        xa = x;
      else
        xb = x;
      end
      # update control points:
      v = w;
      w = x;
      x = u;
      fv = fw;
      fw = fx;
      fx = fu;
    else

      # Oh dear, point u is worse than what we have already,
      # even so it *must* be better than one of our endpoints:
      if(u < x)
        xa = u;
      else
        xb = u;
      end
      if((fu <= fw) || (w == x))

        # however it is at least second best:
        v = w;
        w = u;
        fv = fw;
        fw = fu;
      elseif((fu <= fv) || (v == x) || (v == w))

        # third best:
        v = u;
        fv = fu;
      end
    end
  end

  return (x, fx,flag);
end





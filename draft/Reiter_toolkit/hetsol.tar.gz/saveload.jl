# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function printShort(x::Int,name::String,F=stdout)
  @printf(F,"%20s: %14d\n",name,x)
end
function printShort(x::Symbol,name::String,F=stdout)
  @printf(F,"%20s: %0s\n",name,string(x))
end
function printShort(x::Char,name::String,F=stdout)
  @printf(F,"%20s:            '%1s'\n",name,x)
end
function printShort(x::Float64,name::String,F=stdout)
  @printf(F,"%20s: %14.8g\n",name,x)
end
function printShort(x::String,name::String,F=stdout)
  @printf(F,"%20s: %s\n",name,x)
end
function printShort(x::Bool,name::String,F=stdout)
  @printf(F,"%20s: %s\n",name,x)
end
function printShort(x::Array{T,1},name::String,F=stdout) where T
  @printf(F,"%20s: ",name)
  if(length(x)<=10)
    println(F,x)
  else
    Base.print(F,typeof(x))
    println(F,size(x))
  end
end
function printShort(x::Array{T,2},name::String,F=stdout) where T
  @printf(F,"%20s: ",name)
  (nr,nc) = size(x)
  if(nr<=5 && nc<=8)
    for i=1:nr
      println(F,x[i,:])
    end
  else
    Base.print(F,typeof(x))
    println(F,size(x))
  end
end
function printShort(x::Array{T},name::String,F=stdout) where T
  @printf(F,"%20s: ",name)
  Base.print(F,typeof(x))
  println(F,size(x))
end
function printShort(x,name::String,F=stdout)
  @printf(F,"%20s: ",name)
  println(F,typeof(x))
end

function printStruct(dest,F::IO=stdout,prefix::String="")
  for a in fieldnames(typeof(dest))
    if isdefined(dest,a)
      ai = getfield(dest,a)
      if isa(ai,String) || isempty(fieldnames(typeof(ai)))
        Base.print(F,prefix)
        printShort(ai,string(a),F)
      elseif isa(ai,Tuple) && length(ai)<10 && all(map(x->isa(x,Real),ai))
        @printf(F,"%20s:   ",string(a))
        println(ai)
      else
        Base.print(F,string(a),": ")
        println(F,typeof(ai))
        # println(F,string(a),": ")
        # printStruct(ai,F,"  ")
      end
    else
      println(F,string(a),": UNDEFINED")
    end
  end
end
function printStruct(dest,fname::String,prefix::String="")
  F = open(fname,"w")
  printStruct(dest,F)
  close(F)
end
function printStructShort(dest,F::IO=stdout,prefix::String="")
  for a in fieldnames(typeof(dest))
    ai = getfield(dest,a)
    if isempty(fieldnames(typeof(ai)))
      Base.print(prefix)
      printShort(ai,string(a),F)
    else
      println(string(a),": ",typeof(ai))
    end
  end
end

function printDict(D,F=stdout)
  for a in keys(D)
    ai = D[a]
    printShort(ai,string(a),F)
  end
end
# save through serialization; not consistent across Julia versions
using Serialization:serialize
using Serialization:deserialize
function saveT(filename,args...)
  F = open(filename,"w");
  if length(args)==1
    n = serialize(F,args[1]);
  else
    n = serialize(F,args);
  end
  close(F);
  return n;
end
function loadT(filename)
  F = open(filename);
  X = deserialize(F);
  close(F);
  return X
end
function loadT(filename,n::Integer)
  F = open(filename);
  X = deserialize(F);
  close(F);
  return X[1:n];
end

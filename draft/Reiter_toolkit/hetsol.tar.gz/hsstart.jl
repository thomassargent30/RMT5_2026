# This version is from June 16, 2018 !!!
# 
# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

@everywhere include("$hetsolDir/utils2.jl") 
@everywhere include("$hetsolDir/timeindex.jl")
@everywhere include("$hetsolDir/approx.jl")
@everywhere include("$hetsolDir/timeseries.jl")
@everywhere include("$hetsolDir/deriv1ad.jl")
@everywhere include("$hetsolDir/deriv2ad.jl")
@everywhere include("$hetsolDir/hstypes.jl")
@everywhere include("$hetsolDir/linsoltypes.jl")
const _linsol = LinsolParams();
# getLinSol() = return LinSol(_A,_B,_pars,_varsStSt)
macro emptyLinSol(id::Int)
  typePar = Symbol("StructPars"*string(id));
  typeVar = Symbol("StructVarsStSt"*string(id));
  return esc( :(LinSol("model1",zeros(0,0),zeros(0,0),$typePar(),$typeVar{Float64}(),
                       Dict{String,UnitRange{Int}}(),
                       Dict{Symbol,UnitRange{Int}}(),$id,zeros(0))))
end
function emptyLinSol(id::Int)
  typePar = Core.eval(Main,Symbol("StructPars"*string(id)));
  typeVar = Core.eval(Main,Symbol("StructVarsStSt"*string(id)));
  return LinSol("",zeros(0,0),zeros(0,0),typePar(),typeVar{Float64}(),
                       Dict{String,UnitRange{Int}}(),
                       Dict{Symbol,UnitRange{Int}}(),id,zeros(0))
end
function emptyLinSol(x::LinSol)
  typePar = typeof(x.pars);
  typeVar = typeof(x.vstst);
  return LinSol("",zeros(0,0),zeros(0,0),typePar(),typeVar(),
                       Dict{String,UnitRange{Int}}(),
                       Dict{Symbol,UnitRange{Int}}(),x.id,zeros(0))
end
function loadLinSol(x::LinSol,filename)
  sol = emptyLinSol(x);
  load1!(filename*".bmt",sol)
  return sol;
end
import Base.show
function Base.show(io::IO, x::LinSol)
  printStruct(x)
end
function save(F::IO,x::LinSol)
  saveRaw(F,x.name)
  saveRaw(F,x.A)
  saveRaw(F,x.B)
  saveRaw(F,x.guess)
  saveStruct(F,x.pars);
  saveStruct(F,x.vstst);
  saveDict(F,x.equNames)
  saveDict(F,x.varNames)
end
function save(fname::String,x::LinSol) # default: composite type
  F = open(fname,"w")
  save(F,x)
  close(F)
end
function load1!(F::IO,x::LinSol)
  x.name = loadRaw(F,String);
  x.A = loadRaw(F,Array{Float64,2})
  x.B = loadRaw(F,Array{Float64,2})
  x.guess = loadRaw(F,Array{Float64,1})
  loadStruct!(F,x.pars);
  loadStruct!(F,x.vstst);
  x.equNames = loadDict(F);
  x.varNames = loadDict(F);
end
function load1!(fname::String,x::LinSol) # default: composite type
  F = open(fname)
  load1!(F,x)
  close(F)
end
function loadLinSol(fname::String,modelname::String)
  modelIndex::Int=_modelinfo[modelname].id
  x = emptyLinSol(modelIndex)
  F = open(fname)
  load1!(F,x)
  close(F)
  x.id = modelIndex;
  return x;
end



@everywhere pow(a,b) = a.^b
templDir = "$hetsolDir/"
#templDir = "$hetsolDir/templates/"

@everywhere include("$hetsolDir/saveload.jl") 
include("$hetsolDir/mpp.jl") 
include("$hetsolDir/prepro.jl") 
@everywhere include("$hetsolDir/option.jl") 
@everywhere include("$hetsolDir/broydn.jl") 
@everywhere include("$hetsolDir/golden.jl") 
@everywhere include("$hetsolDir/util4stst.jl") 
include("$hetsolDir/checkeu.jl") 
@everywhere include("$hetsolDir/util4fluct.jl") 
include("$hetsolDir/statslin.jl") 
@everywhere include("$hetsolDir/irlin.jl") 
@everywhere include("$hetsolDir/multidim.jl")
@everywhere include("$hetsolDir/util4nonl.jl")
@everywhere include("$hetsolDir/write2mat.jl")

macro GUESS(name)
  namestr = string(name)
  return esc(
             quote
               _iGuess += 1;
               _FF = open(_modelDir*"stst.log","a")
               # @printf(_FF,"Guess %s = %0.8g\n",$namestr,_x[_iGuess]);
               @printf("Guess %s = %0.8g\n",$namestr,_x[_iGuess]);
               close(_FF)
               if  length(_lowbGuess)>1 &&  # only applies in multivariate case
                 (_x[_iGuess]<_lowbGuess[_iGuess] || _x[_iGuess]>_uppbGuess[_iGuess])
                 return [1e100];
               end
               setstst!($name,_x[_iGuess]);
             end
            )
end
macro RESID(eqname)
  eq = Symbol("_eq_",eqname);
  eqstr = string(eq)
  return esc(
             quote
               _res = $eq(stst);
               _FF = open(_modelDir*"stst.log","a")
               @printf(_FF,"Resid %s = %0.8g\n",$eqstr,_res);
               close(_FF)
    @printf("Resid %s = %0.8g\n",$eqstr,_res);
    if(isa(_x,Float64))
      _resid = _res;
    else
      _iResid += 1;
      _resid[_iResid] = _res;
    end
  end
  )
end

if !@isdefined _highestModelIndex
  _highestModelIndex = 0
end
function defmodel(doPrePro::Bool,hetfile,indx,args...)
  fileDir = hetfile * "_files/"
  if !isdir(fileDir)
    @assert(!isfile(fileDir))
    mkdir(fileDir)
  end
  global _modelDir = fileDir;
  broadcastVar(:_modelDir,fileDir); # why needed?
  istr = string(indx)
  write2f("$templDir/currindx.mpp","_def(_structIndx,$istr)")
  n = length(args)
  for i=1:2:n
    symbi = args[i]
    vali = args[i+1]
    Core.eval(Main,:($symbi=$vali))
  end
  if doPrePro
    _modelinfo[hetfile] = ModelInfo(indx,prepro(hetfile,fileDir,indx))
    mpp(templDir*"structs.mpp","$fileDir/types.jl",Main,fileDir,"$templDir/")
    mpp(templDir*"stst.mpp","$fileDir/linsol.jl",Main,fileDir,"$templDir/")
    mpp("$fileDir/macro.mpp","$fileDir/func3.jl",Main,fileDir)
    include(fileDir*"types.jl");
    for j=2:maximum(workers())
      remotecall_fetch(include,j,fileDir*"types.jl")
    end
    include(fileDir*"linsol.jl")
    # include(fileDir*"files2incl.jl") # DO LATER, CF. BELOW
  end
  if !(@isdefined(_pars) &&  string(typeof(_pars))=="StructPars$istr")
    println("********** Parameters will be initialized!")
    cmd = " _vars = StructVars$istr(); _shks = StructShks$istr(); _pars = StructPars$istr(); _varsStSt = StructVarsStSt$istr{Float64}();"
    Core.eval(Main,Meta.parse(cmd))
    cmd = "_setPars!(_pars);init!(_pars,_vars,_shks);_initGuess(_pars)"
    Core.eval(Main,Meta.parse(cmd))
  end
  if doPrePro
    include(fileDir*"files2incl.jl") # defines modules, must not be redefined without preprocssing, because of _D (at least)
  end
  for j=2:maximum(workers())
    remotecall_fetch(include,j,fileDir*"files2incl.jl")
  end
  global _iStStrun = 0;
  global _lastModel = hetfile; # global marker for model index
  Core.eval(Main,Meta.parse(hetfile*"_id = " * string(indx)))
  _modelNames[indx] = hetfile;
  return indx;
end
modelid(m::LinModel) = m.id
function defmodel(hetfile::String,args...)
  if !@isdefined(prepro)
    @hetsol
  end
  if haskey(_modelinfo,hetfile) &&  !isnewer(hetfile*".het",hetfile*"_files/linsol.jl")
    return defmodel(false,hetfile,_modelinfo[hetfile].id);
  end
  global _highestModelIndex += 1
  return defmodel(true,hetfile,_highestModelIndex,args...);
end
function initnonl()
  @everywhere include("$hetsolDir/shocks.jl")
  @everywhere include("$hetsolDir/polyapprox.jl")
  @everywhere include("$hetsolDir/hsnonlin.jl")
end
function initha()
  if !@isdefined(reduceV)
    @everywhere include("$hetsolDir/markovappr.jl")
    @everywhere include("$hetsolDir/lininterp.jl")
    @everywhere include("$hetsolDir/invdistr.jl")
    @everywhere include("$hetsolDir/deriv21.jl")
    @everywhere include("$hetsolDir/dp.jl")
    @everywhere include("$hetsolDir/distrib.jl")
    @everywhere include("$hetsolDir/reduc.jl")
    @everywhere include("$hetsolDir/solveiterre.jl")
    @everywhere include("$hetsolDir/simreduc.jl")
    @everywhere include("$hetsolDir/compress.jl")
    # if nworkers()>1
    #   @everywhere include("$hetsolDir/every.jl")
    # end
  end
end
using SpecialFunctions:erf
using StaticArrays
EXP(x) = x

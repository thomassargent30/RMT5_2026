# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if(!@isdefined(ExpAccum))
  type ExpAccum{N}
    e::Deriv1a{N};
  end
end
convert{N}(::Type{Deriv1a{N}},x::ExpAccum{N}) = x.e;
import Base.zero
zero{N}(::Type{ExpAccum{N}}) = ExpAccum{N}(zero(Deriv1a{N}))

function _mulBas(expr::Float64,basis0,nA,nPar)
  return convert(Deriv1a{nA*nPar},expr)
end
function _mulBas{N}(expr::Deriv1F{N},basis0,nA,nB)
  return mulWithBasis(expr,basis0,nA,nB)
end
function _mulBas{N}(_expr::ExpAccum{N},basis0,nA,nB)
  return  _expr.e;
end

function mulWithBasis{N}(x::ExpAccum{N},basis::Array{Float64,1},_nApprox,nB)
  return mulWithBasis(x.e,basis,_nApprox,nB)
end
function mulWithBasis{N}(x::Deriv1F{N},basis::Array{Float64,1},_nApprox,nB)
  for i=_nApprox+1:2*_nApprox
    assert(x.d[i]==0.0);
  end
  d = Array{Float64}(_nApprox*nB)
  for i=1:_nApprox
    offs = (i-1)*nB
    d0 = x.d[i];
    for j=1:nB
      d[offs+j] = d0*basis[j];
    end
  end
  return Deriv1a{_nApprox*nB}(x.v,d)
end
function mulWithBasis{N}(x::Deriv1a{N},basis::Array{Float64,1},_nApprox,nB)
  for i=_nApprox+1:2*_nApprox
    assert(x.d[i]==0.0);
  end
  d = Array{Float64}(_nApprox*nB)
  for i=1:_nApprox
    offs = (i-1)*nB
    d0 = x.d[i];
    for j=1:nB
      d[offs+j] = d0*basis[j];
    end
  end
  return Deriv1a{_nApprox*nB}(x.v,d)
end
macro doExpAccum(opname)
  return esc(
  quote
    import Base.$opname
    function $opname{N,nA}(e::ExpAccum{N},x::Deriv1F{nA})
      x2 = mulWithBasis(x,basis0,nApprox,div(N,nApprox))
      return ExpAccum{N}($opname(e.e, x2))
    end
    function $opname{N,nA}(x::Deriv1F{nA},e::ExpAccum{N})
      x2 = mulWithBasis(x,basis0,nApprox,div(N,nApprox))
      return ExpAccum{N}($opname(x2,e.e))
    end
    function $opname{N}(e::ExpAccum{N},x::Real)
      return ExpAccum{N}($opname(e.e,x));
    end
    function $opname{N}(x::Real,e::ExpAccum{N})
      return ExpAccum{N}($opname(x,e.e));
    end
    # function $opname{N}(e::ExpAccum{N},x::ParCali)
    #   return ExpAccum{N}($opname(e.e,x[]));
    # end
    # function $opname{N}(x::ParCali,e::ExpAccum{N})
    #   return ExpAccum{N}($opname(x[],e.e));
    # end
    function $opname{N}(e1::ExpAccum{N},e2::ExpAccum{N})
      return ExpAccum{N}($opname(e1.e,e2.e));
    end
  end
  )
end
@doExpAccum(+)
@doExpAccum(-)
@doExpAccum(*)
@doExpAccum(/)
function -{N}(e::ExpAccum{N})
  return ExpAccum{N}(-e.e);
end

function concatDeriv!(E,R,basis0,nB,approx1,basis1)
  dR = getjac(R);
  nY = nApprox; # number of approximated functions
  #R_AB = getjac(R);
  #R_A = R_AB[1:nY]';
  #R_B = R_AB[nY+1:2*nY]';
  # totalDA = R_A+R_B*B_A[:,1:nY]  # total deriv w.r.t. Approx[t]
  totalDA = Array{Float64}(nY)
  for i=1:nY
    totalDA[i] = dR[i]
    for j=1:nY
      totalDA[i] += dR[nY+j]*approx1[j].d[i]  # total deriv w.r.t. Approx[t]
    end
  end
  check = false
  if(check)
    R_AB = getjac(R);
    R_A = R_AB[1:nY]';
    R_B = R_AB[nY+1:2*nY]';
    B_A = getjac(approx1)
    totalDA2 = R_A+R_B*B_A[:,1:nY]  # total deriv w.r.t. Approx[t]
    assert(maxabs(vec(totalDA2)-totalDA)<1e-10)
  end
  E.v += getval(R)
  for i=1:nY
    offs = (i-1)*nB
    d0 = totalDA[i]; # deriv w.r.t. Approx[t]
    d1 = dR[nY+i]; # deriv w.r.t. Approx[t+1]
    if(false)
      for j=1:nB
        E.d[offs+j] += d0*basis0[j] + d1*basis1[j]
      end
    else
      addp2at!( E.d,offs, d0, basis0, d1, basis1, nB)
      # ccall( (:addp2,"mylib"), Void,  (Ptr{Float64},Float64,Ptr{Float64},Float64,Ptr{Float64}, Int32) , pointer(E.d,offs+1), d0, pointer(basis0), d1, pointer(basis1), convert(Int32,nB))
    end
  end
end


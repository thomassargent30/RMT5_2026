# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

include("tensorappr.jl")
#= 
type GridOfApprox{T,dim} <: MultiDimApprox
  f::T;
  nn::NTuple{dim,Int}
end
=#
function fptosi(x::Float64) # llvm.pdf, page 147
    Base.llvmcall("""
        %res = fptosi double %0 to i64
        ret i64 %res
        """, Int64, Tuple{Float64,}, x)
end
function saveRaw(F::IOStream,x::GridOfApprox{T,dim}) where {T,dim}
  saveRaw(F,x.f)
  saveRaw(F,x.nn)
end
# function saveT(F::IOStream,x::GridOfApprox{T,dim}) where {T,dim}
#   i = _typeNumber(GridOfApprox)
#   writeInt(F,i);
#   saveRaw(F,x);
# end
function loadGridAppr(F::IOStream)
  f = loadTensor(F)
  nn = loadTuple(F,Int)
  return GridOfApprox(f,nn)
end
function nodes(F::GridOfApprox{T,dim}) where {T,dim}
  grid = tensprod(hcat,map(i->1:i,F.nn)...)
  nodesf = nodes(F.f)
  return tensprod(nodesf,grid)
end
function Base.copy(x::GridOfApprox{T,dim}) where {T,dim}
  return GridOfApprox{T,dim}(copy(x.f),x.nn)
end
nCoeff(F::GridOfApprox{T,dim}) where {T,dim} = nCoeff(F.f)*prod(F.nn);
gridDim(F::GridOfApprox{T,dim}) where {T,dim} = (gridDim(F.f)...,F.nn...)
dimen(F::GridOfApprox{T,dim}) where {T,dim} = dimen(F.f) + dim
function gridFunc_default(fspace::GridOfApprox{T,dim}) where {T,dim}
  return nodes(fspace)

  global grid0
  d = dimen(fspace.f)
  grid1 = copy(grid0)
  grid1[:,1:d] = scalUp(fspace.f,grid0[:,1:d])
  return grid1
end

function basis(F::GridOfApprox{T,dim},x0::Array{Tx,2}) where {T,dim,Tx}
  n2 = size(x0,2)

  return basis(F.f,x0)
end

function fitxy(F::GridOfApprox{T,dim},y::Array{Tx,1}) where {T,dim,Tx}
  d1 = dimen(F.f)
  n = nCoeff(F.f)
  z = reshape(y,n,div(length(y),n))
  coef0 = basis(F.f,nodes(F.f))\z;
  return vec(coef0)
end
function fitxy(F::GridOfApprox{T,dim},x::Array{Float64,2},y::Array{Float64,2}) where {T,dim}
  d1 = dimen(F.f)
  n1 = nCoeff(F.f)
  n2 = prod(F.nn);
  (ry,cy) = size(y)
  @assert(ry==n2*size(x,1),println(ry," ",n2," ",size(x,1)))
  z = reshape(y,div(ry,n2),n2*cy)
  B = basis(F.f,x)
  coef0 = B\z;
  return reshape(coef0,n1*n2,cy)
end
# special: we need the x only for the first dimensions:
function fitfun(F::GridOfApprox{T,dim},func::Function) where {T,dim}
  g = nodes(F)
  y = map(i->func(g[i,:]),1:size(g,1))
  return fitxy(F,nodes(F.f),y)
end
function fitfun2(F::GridOfApprox{T,dim},func::Function) where {T,dim}
  g = nodes(F)
  y = hcat(map(i->func(g[i,:]),1:size(g,1))...)
  return fitxy(F,nodes(F.f),y')
end
function fitfun2(F::GridOfApprox{T,dim},func::Function,xp) where {T,dim}
  g = nodes(F)
  nxp = length(xp)
  for jj=1:nxp
    j = size(g,2)-nxp  + jj
    for i=1:size(g,1)
      ij = fptosi(g[i,j])
      g[i,j] = xp[jj][ij]
    end
  end
  y = hcat(map(i->func(g[i,:]),1:size(g,1))...)
  return fitxy(F,nodes(F.f),y')
end

function feval(F::GridOfApprox{T,dim},x0::Array{Float64,1},coeff::Array{Float64}) where {T,dim}
  d1 = dimen(F.f)
  n = nCoeff(F.f)
  I = Array{Int}(dim)
  for i=1:dim
    # I[i] = reinterpret(Int,x0[d1+i])
    I[i] = fptosi(x0[d1+i])
  end
  offs = (s2i(F.nn,I...)-1)*n
  if ndims(coeff)==1
    return feval(F.f,x0[1:d1],coeff[offs+1:offs+n])
  else
    return feval(F.f,x0[1:d1],coeff[offs+1:offs+n,:])
  end
end
function fevalAll(F::GridOfApprox{T,dim},x0::Array{Float64,1},coeff::Array{Float64,2}) where {T,dim}
  d1 = dimen(F.f)
  n1 = nCoeff(F.f)
  n2 = prod(F.nn);
  nc = size(coeff,2)
  cc = reshape(coeff,n1,n2*nc)
  #B = basis(F.f,x0[1:d1])
  #(I,BV) = findnz(B)
  (I,BV,n_notneeded) = basisI(F.f,x0[1:d1])
  if true
    # a = full(B)'*cc;
    I4 = I[1:4:length(I)]
    a = zeros(n2*nc)
    evalcub!(a,I4,BV,cc); 
  else
    cct = cc'
    println(length(BV))
    println(size(cc[I,:]))
    local a,a2,ccI,cctI,a3,a4
    cctI = cct[:,I]
    Bt = full(B')
    println(I)
    println(I4)
    @time for i=1:100000; ccI = cc[I,:]; end
    @time for i=1:100000; cctI = cct[:,I]; end
    @time for i=1:100000; a = BV'*ccI;end
    @time for i=1:100000; a2 = (cctI*BV)'; end
    @time for i=1:100000; a3 = Bt*cc; end
    a4 = similar(a3)
    @time for i=1:100000; evalcub!(a4,I4,BV,cc); end
    println(maximum(abs,a-a4))
    global aa = a;
    global aa4 = a4;
    stop()
  end
  return reshape(a,n2,nc)
end
function feval(F::GridOfApprox{T,dim},x0::Array{Deriv1F{nF},1},coeff::Array{Float64,2}) where {T,dim,nF}
  d1 = dimen(F.f)
  n = nCoeff(F.f)
  I = Array{Int}(dim)
  for i=1:dim
    # I[i] = reinterpret(Int,x0[d1+i])
    I[i] = fptosi(getval(x0[d1+i]))
  end
  offs = (s2i(F.nn,I...)-1)*n
  cc = coeff[offs+1:offs+n,:]

  dxdIndep = getjac(x0[1:d1])
  nC = size(coeff,2)
  dx0 = indep(Deriv1F{d1},getval(x0[1:d1]))
  B = basis(F.f,dx0)
  dxdx = B'*cc;
  y = Array{Deriv1F{nF}}(nC)
  for j=1:nC
    dxi = dxdx[j]
    y[j] = Deriv1F{nF}(getval(dxi),arr2tuple(Val{nF},getjac(dxi)'*dxdIndep))
  end
  return y
end
function fevalAll(F::GridOfApprox{T,dim},x0::Array{Deriv1F{nF},1},coeff::Array{Float64,2}) where {T,dim,nF}
  d1 = dimen(F.f)
  n1 = nCoeff(F.f)
  n2 = prod(F.nn);
  nC = size(coeff,2)

  dxdIndep = getjac(x0[1:d1])

  nC = size(coeff,2)
  dx0 = indep(Deriv1F{d1},getval(x0[1:d1]))
  B = basis(F.f,dx0)
  cc = reshape(coeff,n1,n2*nC)
  (I,BV) = findnz(B)
  dxdx = BV'*cc[I,:];
  # dxdx = B'*cc;
  y = Array{Deriv1F{nF}}(n2,nC)
  for j=1:n2*nC
    dxi = dxdx[j]
    y[j] = Deriv1F{nF}(getval(dxi),arr2tuple(Val{nF},getjac(dxi)'*dxdIndep))
  end
  return y
end
function Base.show(io::IO, x::GridOfApprox{T,dim}) where {T,dim}
  show(x.f)
  println(x.nn)
end
function setBounds!(fspace::GridOfApprox{T,dim},
                    xLow::Array{Float64,1},xUpp::Array{Float64,1},center::Array{Float64,1}) where {T,dim}
  d = dimen(fspace.f)
  setBounds!(fspace.f,xLow[1:d],xUpp[1:d],center[1:d])
end
function spreadBounds!(fspace::GridOfApprox{T,dim}, spread) where {T,dim}
  ab = getBounds(fspace.f)
  a = ab[:,1]
  b = ab[:,2]
  center = (a+b)/2
  a2 = center + spread*(a-center)
  b2 = center + spread*(b-center)
  setBounds!(fspace.f,a2,b2,center)
end

#=
f = bSpl(linspace(1,2,11),3)
f2 = TensorSparse(f,f)
ff = GridOfApprox(f2,(2,3))
grid = nodes(ff)
x = [1.2; 2.0;2.0]
y = feval(f,x,rand(nCoeff(ff)))

# c = fitfun(ff,x->(x[3]*x[4])*log(x[1]+x[2]))
c2 = fitfun2(ff,x->(x[3]*x[4])*log(x[1]+x[2])*ones(3))
c3 = fitfun2(ff,x->(x[3]*x[4])*log(x[1]+x[2])*ones(3),([1.;2.],[1.;2.;3.]))
=#
function changeScale(coef::Array{Float64,2},fspaceOld::GridOfApprox{T,dim},fspace::GridOfApprox{T,dim}) where {T,dim}
  Grid = nodes(fspace.f)
  B = basis(fspace.f,Grid)
  Bf = lufact(B)
  n1 = size(Grid,1)
  n2 = prod(fspace.nn)
  nc = size(coef,2)

  depVar = zeros(n1,n2,nc)
  for i=1:n1
    depVar[i,:,:] = fevalAll(fspace,Grid[i,:],coef)
  end
  coef2 = Array{Float64}(n1,n2,nc)
  for i=1:n2
    coef2[:,i,:] = Bf\depVar[:,i,:]
  end
  return reshape(coef2,n1*n2,nc)
end
function fevalAlongDim(F::MultiDimApprox,coeff::Array{Float64,1},iDim::Int,nSteps::Int,x0=F.center)
  x = copy(x0)
  res = zeros(nSteps)
  for i=1:nSteps
    x[iDim] = F.a[iDim] + (i-1)/(nSteps-1) * (F.b[iDim]-F.a[iDim])
    res[i] = feval(F,x,coeff)
  end
  return res;
end
function plotAlongDim(F::MultiDimApprox,coeff::Array{Float64,1},iDim::Int,nSteps::Int,x0=F.center)
  res = fevalAlongDim(F,coeff,iDim,nSteps,x0)
  gplot(linspace(F.a[iDim],F.b[iDim],nSteps),res)
end
function feval2(x,F::MultiDimApprox,coef,nonlfunc::Function,F2::MultiDimApprox,coef2)
  x2 = feval(F,x,coef)
  x2f = nonlfunc(x2)
  y = feval(F2,[x x2f],coef2);
  return y;
end
function feval2(x,F::MultiDimApprox,coef,nonlfunc::Function,indices, F2,coef2)
  y = feval(F,x,coef)
  nz = size(coef2,2)
  @assert(sum(length.(indices)) == nz)
  if ndims(x)==1
    z = zeros(nz)
  else
    z = zeros(size(x,1),nz)
  end
  for i=1:length(indices)
    yi = nonlfunc(y,i)
    ii = indices[i]
    if ndims(x)==1
      z[ii] = feval(F2[i],[x;vec(yi)],coef2[:,ii])
    else
      z[:,ii] = feval(F2[i],[x yi],coef2[:,ii])
    end
  end
  return z;
end
struct Approx2Stage
  fs1:: MultiDimApprox
  fs2
  nonlfunc::Function
  indices
end
dimen(F::Approx2Stage) = dimen(F.fs1)
feval(F::Approx2Stage,x,coef) = feval2(x,F.fs1,coef[1],F.nonlfunc,F.indices, F.fs2,coef[2])

#function fitxy2(F::MultiDimApprox,nonlfunc::Function,indices::Array{AbstractArray{Int,1},1}, F2::Array{MultiDimApprox,1},x,y,z)
function fitxy2(F::MultiDimApprox,nonlfunc::Function,indices, F2,x,y,z,useFitted1::Bool=true)
  coef1 = fitxy(F,x,y)
  yest = feval(F,x,coef1)
  nz = size(z,2)
  @assert(sum(length.(indices)) == nz)
  coef2 = zeros(nCoeff(F2[1]),nz)
  for i=1:length(indices)
    if useFitted1
      yi = nonlfunc(yest,i)
    else
      yi = nonlfunc(y,i)
    end
    ii = indices[i]
    coef2[:,ii] = fitxy(F2[i],[x yi],z[:,ii])
  end
  return (coef1,coef2)
end
fitxy2(F::Approx2Stage,x,y,z,useFitted1::Bool=true) = fitxy2(F.fs1,F.nonlfunc,F.indices, F.fs2,x,y,z,useFitted1)


# HetSol: This file is part of the HetSol Toolkit
# Michael Reiter (IHS, Vienna and NYU Abu Dhabi), 2018
# solve the discrete housing model, making first some choices about solution method
@hetsolHA  # initialize toolkit with heterogeneous agent files
_linsol.stepJacob = 1e-4
_linsol.useQuad = false
_linsol.ytolStSt = 1e-4
_linsol.printLevel = 0
@linsolHA house5 # solve it


# HetSol: This file is part of the HetSol Toolkit
# Michael Reiter (IHS, Vienna and NYU Abu Dhabi), 2018
# compute linearized solution first:
rbclin = @linsol rbcnonl

# define shock process:
(x,p) = qnwnorm1(51,0.,0.007);  # approximate normal distribution with standard deviation 0.007
shock1 = DiscreteIID(x,p); # make it a type DiscreteIID
xp = (shock1,);  # transform to Tuple
# define nonlinear model:
rbcnonl = defmodelnl(rbclin,xp);

# define approximation:
fspace = PolyAppr(2,8);  # degree-8 polynominal in 2 dimensions (2 states)
opt = Options();
opt.printSimul = 1;
coef = iterNonl(rbcnonl,fspace,xp;opts=opt); # solve iteratively

# check Accuracy:
Grid = randomGrid(fspace,20.0);
res = residnl(_nl,Grid,fspace,coef,xp)
statsResid(res)


# do a simulation:
x0 = stateDetermStSt(rbcnonl);  # starting point: deterministic steady state
sim = simulnl(_nl,x0,fspace,coef,xp,rand(1,400));

# policy function: vary state variable 2  around steady state;
pol = policynl(gridVaryState(fspace,2,101), 1, _pars,_varsStSt,fspace,coef,xp);
plot(pol[:z],pol[:k]);



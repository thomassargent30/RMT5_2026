# HetSol: This file is part of the HetSol Toolkit
# Michael Reiter (IHS, Vienna and NYU Abu Dhabi), 2018
# solve and simulate the Chang/Kim model
@hetsolHA
@linsolHA changkim;
checkAccuracy(changkim);
include("simulck.jl");



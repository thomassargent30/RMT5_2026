# HetSol: This file is part of the HetSol Toolkit
# Michael Reiter (IHS, Vienna and NYU Abu Dhabi), 2018
# simulate the Chang/Kim model
vars = [:GDP;:C;:Inv;:H;:L;:wage;:r;:z;:K];
(Hser,ststv) = selectMat(BigModel,vars)

println("Start simulation for 2000 periods")
shocks = 0.01*randn(1,2000);
X = simulHA(changkim,shocks;Hser=Hser)';
println("Simulation finished")

ser = X[101:end,:]; # drop first 100 points
serb = ser - hpfilter(ser,1600); # detrend 
serlog = serb ./ ststv';  # express as percent of steady state 
stdlog = stdev(serlog,1);
stdrel = stdlog/stdlog[1];
pos1(x) = findall(vars.==x)[1]
logc = serlog[:,pos1(:C)];
logw = serlog[:,pos1(:wage)];
logy = serlog[:,pos1(:GDP)];
logh = serlog[:,pos1(:H)];
map(i->@printf("%20s: %0.3f\n",vars[i],stdrel[i]),1:length(vars));
# definition labor wedge: Takahashi page 1458, fifth line before Conclusions
wedge = logh/1.5+logc - logy + logh;
@show stdev(wedge)/stdev(logy);
@show cor(wedge,logh);


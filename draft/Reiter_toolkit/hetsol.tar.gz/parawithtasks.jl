
        # aggr2 = (wage=aggr.wage,r=aggr.r)
        # aggr2 = (w=aggr.w,z=aggr.z,qM=aggr.qM,MUC=aggr.MUC)
        #### for p in workers() # start tasks on the workers to process requests in parallel
        ####   remote_do(do_work2, p, data,jobs, results)
        #### end
        #### vgrid = dpVal.grid
        #### ngs = _opt.nGridSearch[1]
        #### (_d,_u,_p,_r) = (model._disc, model._util, model._prep!, model._range);
        #### # Problem: aggr is all variables, can have Deriv2ad, way to big!!!??? fix it!
        #### allarg = (pars,aggr,  #  _d,_u,_p,_r,  
        ####           pT, gridCS,nDC,vgrid, ngs, _linsol,t);
        #### for iW=1:nworkers()
        ####   put!(data,allarg);
        #### end
        #### for j=1:nExog # for each value of exogenous state
        ####   @inbounds Ve = dpVal.Vend[:,:,j]
        ####   Qe = dpVal.Qend[:,:,j]
        ####   put!(jobs,(j, Ve,Qe));
        #### end
        #### for j=1:nExog # for each value of exogenous state
        ####   allargs = take!(results);
        ####   j = allargs[1];
        ####   # println("got ",j," at ",time_ns()/1e9)
        ####   (dpVal.V[:,:,j], dpPol.CC[:,:,j],dpPol.DC[:,:,j],dpPol.I[:,:,j],
        ####    dpPol.P[:,:,j],dpPol.DE[:,:,j],dpPol.U[:,:,j],dpPol.B[:,:,j]) = 
        ####   allargs[2:end];
        #### end
        #### for j=1:nExog # for each value of exogenous state
        ####   x = zeros(1,1);
        ####   put!(jobs,(0, x,x)); # stop processes
        #### end
        # for j=1:nExog # for each value of exogenous state
        # Ve = dpVal.Vend[:,:,j]
        # Qe = dpVal.Qend[:,:,j]

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


@generated function arr2tuple(::Type{Val{T}},A::AbstractArray{Float64}) where T
  A = Array{Any}(0)
  for i=1:T
    push!(A,Expr(:ref,:A,i))
  end
  return Expr(:tuple,A...)
end
@generated function arr2tuple(::Type{Val{T}},A::AbstractArray{Int}) where T
  A = Array{Any}(0)
  for i=1:T
    push!(A,Expr(:ref,:A,i))
  end
  return Expr(:tuple,A...)
end
function tuple2array(x::NTuple{N,T}) where {N,T}
  Ti = typeof(x[1]) # we assume x is non-empty
  y = Array{Ti}(N)
  for i=1:N
    y[i] = x[i]
  end
  return y;
end
sumsqr(x) = dot(x,x)
getval(x::Float64) = x;
getval(x::Array{Float64}) = x;

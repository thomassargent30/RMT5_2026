function do_work2(data,jobs, results) # define work function everywhere
  allargs = take!(data);
  (pars,aggr,
   # _OLDdisc::Function,
   # _OLDutil::Function,
   # _OLDprep!::Function,
   # _OLDrange::Function,
   tpFunc,
   gridCS::Array{Float64,1},
   nDC::Int,
   gridV,
   widthStep,
   linsol::LinsolParams,
   t)  = allargs;
  pT = tpFunc()

  util(_p,c,H) = log(c) - _p.eta*H

  function _util(_p,_A,_pt,Kbeg,iDSunused,iProdtty,Kend,iH,t)
    @assert(_pt.iDC == iH);
    cons = _pt.CashoH-Kend;
    @assert(cons>0)
    return util(_p,cons,_pt.h); 
  end

  function _prep!(_p,_A,_pt,Kbeg,iDSunused,iProdtty,iH,t)
    _pt.iDC = iH;
    _pt.h = _p.Hours[iH];
    _pt.CashoH = (1+_A.r[t])*Kbeg + _A.wage[t]*_p.indProdtty[iProdtty]*_pt.h; 
    _pt.iDE = 1;   
  end

  function _disc(_p,_A,iDSunused,iProdtty,t)
    return  _p.beta;  
  end

  function _range(_p,_A,_pt,Kbeg,iDSunused,iProdtty,iH,t)
    cclower = _p.hhprob_xmin; 
    ccupper = min(_pt.CashoH,_p.hhprob_xmax) - 1e-10;  
    return INTERVAL(cclower,ccupper);
  end

  while true
    job_descr = take!(jobs)
    (iZ, Vend::Array{Float64,2}, Qend) = job_descr;
    #println("start working at ",time_ns()/1e9)
    if iZ==0
      break;
    end
    res = optimAtExog(pars,aggr, _disc, _util, _prep!, _range, pT,
                      iZ,gridCS,nDC, Vend,Qend,gridV,widthStep,linsol,t);
   #println("done with ", iZ, " at ",time_ns()/1e9)
   put!(results, (iZ,res[3:end]))
   #println("posted ", iZ, " at ",time_ns()/1e9)
  end
end
function optimAtExog(pars,aggr,
                     _disc::Function,
                     _util::Function,
                     _prep!::Function,
                     _range::Function,
                     tpFunc,
                     iZ::Int,
                     gridCS::Array{Float64,1},
                     nDC::Int,
                     VendUndisconted::Array{Float64,3},
                     QendUndisconted,
                     gridV,
                     widthStep,
                     linsol::LinsolParams,
                     t) 
  nCS = length(gridCS)
  nxD = size(VendUndisconted,2)
  V = fill(0.,(nCS,nxD))
  nV = length(gridV)
  dpPol_CC = fill(0.,(nCS,nxD));
  dpPol_DC = fill(0,(nCS,nxD));
  dpPol_I = fill(0,(nCS,nxD));
  dpPol_P = fill(0.,(nCS,nxD));
  dpPol_DE = fill(0,(nCS,nxD));
  dpPol_U = fill(0.,(nCS,nxD));
  dpPol_B = fill(0,(nCS,nxD));

  tolVmax = 10.;
  pT = tpFunc()
  vOptJ = fill(-1e100,(nDC,))
  pOptJ = fill(0.,(nDC,)) # optimial continuous choice
  iOptJ = fill(-1,(nDC,))   # discrete state end of period
  eOptJ = fill(-1,(nDC,))   # discrete state end of period
  bOptJ = fill(-1,(nDC,))   # bounds binding
  for iDS=1:nxD
    disc = _disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
    VendJ = disc*VendUndisconted[:,:,iZ] # end of period, after discounting
    QendJ = disc*QendUndisconted[:,:,iZ] # end of period, after discounting
    VendJval = getval(VendJ)
    iStartSearch = fill(1,(nDC))
    for iEndog=1:nCS
      # if iEndog>1; error("done"); end
      xCS::Float64 = gridCS[iEndog];
      local iDE::Int
      for iDC = 1:nDC
        widthSearch = 16
        if iEndog==1 # first try
          iLo = 1
          iHi = length(gridV)-1;
        else
          iMid::Int = iStartSearch[iDC]
          iLo = iMid-widthSearch+1
          iHi = iMid+widthSearch
        end
        (vOptJ[iDC],cBest,bOptJ[iDC],iOptJ[iDC],pOptJ[iDC],eOptJ[iDC]) = 
        optimAtPoint(pars,aggr,
                     xCS,iDS,iDC, iZ,iLo,iHi,
                     _disc,
                     _util,
                     _prep!,
                     _range,
                     pT,
                     VendJ,QendJ,
                     gridV,
                     linsol,
                     t) 
        iStartSearch[iDC] = iOptJ[iDC]
      end
      iaBest = argmax(vOptJ)
      _prep!(pars,aggr,pT,xCS,iDS,iZ,iaBest,t) 
      V[iEndog,iDS] = vOptJ[iaBest] 
      if V[iEndog,iDS]<-1e99
        @show [iEndog;iDS;iZ]
        @show vOptJ
        error("seems infeasible")
      end
      dpPol_B[iEndog,iDS] = bOptJ[iaBest] 
      p = pOptJ[iaBest];
      iI = iOptJ[iaBest];
      xCC = (1-p)*gridV[iI] + p*gridV[iI+1];
      dpPol_CC[iEndog,iDS] = xCC 
      dpPol_DC[iEndog,iDS] = iaBest # optimal discrete choice
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t); error("done")
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,indep(Deriv21,xCC),iaBest,t); error("done")
      ut = _util(pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t);
      xCE = xCC;
      (dpPol_I[iEndog,iDS],dpPol_P[iEndog,iDS]) = posInGrid(gridCS,xCE)
      dpPol_U[iEndog,iDS] = ut;
      dpPol_DE[iEndog,iDS] = eOptJ[iaBest];
    end
  end
  return (dpPol_DC, dpPol_I, dpPol_P, dpPol_DE, dpPol_U, dpPol_B);
  # return (V, dpPol_CC, dpPol_DC, dpPol_I, dpPol_P, dpPol_DE, dpPol_U, dpPol_B);
end

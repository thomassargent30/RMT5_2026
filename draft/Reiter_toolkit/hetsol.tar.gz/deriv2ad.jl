# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# df(z) / dx1 = f'(z) * dz/dx1
# d2f(z) / dx1 dx2 = d[f'(z) * dz/dx1] / dx2 = f''(z)*dz/dx1*dz/dx2 + f'(z)*d2z/dx1dx2

# dg(z1,z2) / dx1 = g_1(z_1,z_2)*dz1/dx1 + g_2(z_1,z_2)*dz2/dx1
# d2g(z1,z2) /dx1dx2 = 
#   (g_11(z_1,z_2)*dz1/dx2 + g_12(z_1,z_2)*dz2/dx2)*dz1/dx1 + g_1(z_1,z_2)*d2z1/dx1dx2 
#   + 
#   (g_21(z_1,z_2)*dz1/dx2 + g_22(z_1,z_2)*dz2/dx2)*dz1/dx1 + g_2(z_1,z_2)*d2z1/dx1dx2 

abstract type Deriv2 <: Number end
import Base.conj
conj(x::Deriv2) = x;
# import FixedSizeArrays # eliminate
if(!@isdefined(Deriv2a))
  const _nIndepSparse = fill(-1,(10,))
  const _DoSecondSparse = fill(false,(10,))
  # type Deriv2F{T} <: Deriv2
  #   v::Float64;
  #   d::FixedSizeArrays.Vec{T,Float64};
  #   H::FixedSizeArrays.Mat{T,T,Float64}
  # end
  mutable struct Deriv2a{T} <: Deriv2
    v::Float64;
    d::Array{Float64,1};
    H::Array{Float64,2};
  end
  mutable struct Deriv2S{T} <: Deriv2
    v::Float64;
    d::SparseVector{Float64,Int}; 
    H::SparseVector{Float64,Int}; # vector rather than matrix, to avoid overhead with very large sstems
  end
  mutable struct Deriv2Aggr{T,TM} <: Deriv2
    v::Float64;
    ddir::SparseVector{Float64,Int}; 
    dmom::Array{Float64,1}; 
    Hdir::SparseMatrixCSC{Float64,Int}; # direct effect
    Hcrs::SparseMatrixCSC{Float64,Int};
    Hmom::Array{Float64,2};
    Aggr::SparseMatrixCSC{Float64,Int}; ## aggregator matrix
  end
end
function indep(::Type{Deriv2Aggr{T,M}},v::Float64,i::Int,A::SparseMatrixCSC{Float64,Int}) where {T,M}
  return Deriv2Aggr{T,M}(v,sparsevec([i],[1.0],T),zeros(M),
  spzeros(T,T),spzeros(T,M),zeros(M,M),A);
end

import Base.convert;
import Base.promote_rule;
import Base.isfinite
const Deriv2s = Deriv2S{1}

convert(::Type{Deriv2a{T}},x::Real) where T = Deriv2a{T}(convert(Float64,x),zeros(T),zeros(T,T));
convert(::Type{Deriv2S{T}},x::Real) where T = Deriv2S{T}(x,spzeros(_nIndepSparse[T]),spzeros(_nIndepSparse[T]*_nIndepSparse[T]))
# convert(::Type{Deriv2Aggr{T,TM}},x::Real) where T,TM = Deriv2Aggr{T,M}(x,spzeros(T),spzeros(T,T),spzeros(T,TM),zeros(TM,TM))
function Deriv2s(v::Real,d::SparseVector{Float64,Int})
  n = length(d)
  @assert(n==_nIndepSparse[1])
  return Deriv2s(v,d,spzeros(n*n))
end
  
nIndep(::Type{Deriv2a{T}}) where T = T
nIndep(::Type{Deriv2S{T}}) where T = _nIndepSparse[T];


# function indep(::Type{Deriv2F{T}},v::Float64,i::Int) where T
#   a = zeros(T)
#   a[i] = 1;
#   if T==1
#     vc = FixedSizeArrays.Vec{T,Float64}((a[1],))
#   else
#     vc = FixedSizeArrays.Vec{T,Float64}(a...)
#   end
#   return Deriv2F{T}(v,vc,zero(FixedSizeArrays.Mat{T,T,Float64}))
# end
function indep(::Type{Deriv2a{T}},v::Float64,i::Int) where T
  d = zeros(T);
  d[i] = 1.0;
  H = zeros(T,T)
  return Deriv2a{T}(v,d,H);
end
function indep(::Type{Deriv2S{T}},v::Float64,i::Int) where T
  n = _nIndepSparse[T];
  return Deriv2S{T}(v,sparsevec([i],[1.0],n),spzeros(n*n));
end
function getjac!(J::Array{Float64,2},x::Array{Deriv2a{T}}) where T
  n = length(x);
  if(!(size(J)==(n,T)))
    @printf("%d,%d vs. %d,%d\n",size(J,1),size(J,2),n,T)
    error("wrong size in getjac")
  end
  for i=1:n
    xi = x[i]
    for j=1:T
      J[i,j] = xi.d[j]
    end
  end
  return J;
end
getjac(x::Deriv2a{T}) where T = x.d
function getjac(x::Array{Deriv2a{T}}) where T
  n = length(x);
  J = Array{Float64}(undef,n,T);
  getjac!(J,x)
  return J;
end


getjac(x::Deriv2S{T}) where T = x.d
function gethes(x::Deriv2S{T}) where T 
  n = length(x.d)
  (I,V) = findnz(x.H);
  (ir,ic) = ind2sub((n,n),I);
  return sparse(ir,ic,V,n,n);
end
function myind2sub(n1,n2,I)
  J = I .- 1;
  ic = div.(J,n1);
  ir = J - ic.*n1;
  return (ir.+1,ic.+1);
end
function gethesCol(x::Deriv2S{T},j::Int) where T 
  n = length(x.d)
  (I,V) = findnz(x.H);
  (ir,ic) = myind2sub(n,n,I);
  ii = mfind(ir.==j)
  return sparsevec(ic[ii],V[ii],n);
end
function gethes(x::Deriv2Aggr{T,M}) where {T,M} 
  hh = Hcrs*Aggr
  return Hdir + hh + hh' + Aggr'*Hmom*Aggr;
end
function getjac(x::Array{Deriv2S{T}}) where T
  n = length(x);
  p = length(x[1].d);
  # println([n p])
  nz = 0;
  for i=1:n
    nz += nnz(x[i].d)
  end
  iRow = Array{Int}(undef,nz);
  iCol = Array{Int}(undef,nz);
  Val = Array{Float64}(undef,nz);
  nz2 = 0;
  for i=1:n
    # @assert(length(x[i].d)==p,@printf("i = %d; p = %d; p[i] = %d\n",i,p,length(x[i].d)))
    (I,V) = findnz(x[i].d)
    iz =  length(I)
    iRow[nz2+1:nz2+iz] .= i;
    iCol[nz2+1:nz2+iz] = I
    Val[nz2+1:nz2+iz] = V
    nz2 += iz;
  end
  if(nz2==nz)
    return sparse(iRow,iCol,Val,n,p);
  else # because nnz can be bigger than number of really nonzero entries
    return sparse(iRow[1:nz2],iCol[1:nz2],Val[1:nz2],n,p);
  end
end

len2(n) = div(n*(n+1),2)
function tensloc2
end
# function compress2(dx::FixedSizeArrays.Vec{T,Float64}) where T
#   return dx*dx';
# end
# function compress2(dx::FixedSizeArrays.Vec{T,Float64},dy::FixedSizeArrays.Vec{T,Float64}) where T
#   return dx*dy';
# end
function compress2(dx::Array{Float64,1})
  return dx*dx';
end
function compress2(dx::Array{Float64,1},dy::Array{Float64,1})
  return dx*dy';
  # n = length(dx)
  # assert(n==length(dy))
  # n2 = len2(n)
  # H = Array{Float64}(n2)
  # for i=1:n
  #   for j=i:n
  #     H[loc2(i,j)] = dx[i]*dy[j]
  #   end
  # end
end
function compress2(dx::SparseVector{Float64,Int},dy::SparseVector{Float64,Int})
  n = length(dx)
  @assert(n==length(dy))
  (i1,x1) = findnz(dx)
  (i2,x2) = findnz(dy)
  n1 = length(i1)
  n2 = length(i2)
  N2 = n1*n2;
  I = Array{Int}(undef,N2)
  J = Array{Int}(undef,N2)
  V = Array{Float64}(undef,N2)

  lauf = 0
  for i=1:n1
    for j=1:n2
      lauf += 1;
      I[lauf]= i1[i] + n*(i2[j]-1);
      V[lauf]= x1[i]*x2[j];
    end
  end
  return sparsevec(I,V,n*n)
end
function compress2(dx::SparseVector{Float64,Int})
  return compress2(dx,dx)
end


function Deriv2Aggr(v2::Float64,D1::Deriv2Aggr{T,M},df1::Real,df2::Real) where {T,M}
  return Deriv2Aggr{T,M}(v2,
  D1.ddir*df1,
  D1.dmom*df1,
  df1*D1.Hdir + df2*D1.ddir*sparse(D1.ddir'),
  df1*D1.Hcrs + sparse(df2*D1.ddir*D1.dmom'),
  df1*D1.Hmom + df2*D1.dmom*D1.dmom',
  D1.Aggr)
end

# for Der2 in (:Deriv2a,:Deriv2S,:Deriv2F)
for Der2 in (:Deriv2a,:Deriv2S)
  @eval begin
    function $Der2(v2::Float64,D1::$Der2{T},df1::Real,df2::Real) where T
      if(isa(D1,Deriv2S{T}) && _DoSecondSparse[T]==false)
        n = length(D1.d)
        return $Der2{T}(v2,D1.d*df1,spzeros(n*n,1))
      end
      return $Der2{T}(v2,D1.d*df1,D1.H*df1 + compress2(D1.d)*df2)
    end
    function $Der2(v2::Float64,D1::$Der2{T},df1::Real,D2::$Der2{T},df2::Real,
      df11::Real, df22::Real, df12::Real) where {T}
      if(isa(D1,Deriv2S{T}) && _DoSecondSparse[T]==false)
        n = length(D1.d)
        return $Der2{T}(v2,D1.d*df1 + D2.d*df2,spzeros(n*n))
      end
      return $Der2{T}(v2,
      D1.d*df1 + D2.d*df2,
      df11*compress2(D1.d) 
      + df12*(compress2(D1.d,D2.d)  + compress2(D2.d,D1.d)) 
      + df22*compress2(D2.d) 
      + df1*D1.H
      + df2*D2.H
      )
    end
  end
end

# for Der2 in (:Deriv2a,:Deriv2S,:Deriv2F)
for Der2 in (:Deriv2a,:Deriv2S)
  @eval begin
    # $Der2(x::Float64) where T = convert($Der2,x);
    # Base.zero(x::$Der2{T}) where T = $Der2{T}(0.0);
    promote_rule(::Type{$Der2{T}}, ::Type{Float64} ) where T = $Der2{T}
    promote_rule(::Type{$Der2{T}}, ::Type{Int} ) where T = $Der2{T}
    getval(x::$Der2{T}) where T = x.v
    isfinite(x::$Der2{T}) where T = isfinite(x.v);
    function indep(::Type{$Der2{T}},v::Array{Float64}) where T
      n = length(v)
      if($Der2==Deriv2S)
        _nIndepSparse[T] = n
      else
        @assert(T == n)
      end
      D = Array{$Der2{T}}(undef,n)
      for i=1:n
        D[i] = indep($Der2{T},v[i],i)
      end
      return D;
    end
    function indep(::Type{$Der2{T}},v::Array{Float64},offs::Int) where T
      nv = length(v);
      if($Der2==Deriv2S)
        nI = _nIndepSparse[T]
      else
        nI = T
      end
      @assert(nv+offs<=nI);
      D = Array{$Der2{T}}(undef,nv)
      for i=1:nv
        D[i] = indep($Der2{T},v[i],offs+i)
      end
      return D;
    end
    function getval(x::Array{$Der2{T}}) where T
      nn = size(x)
      n = length(x);
      v = zeros(nn);
      for i=1:n
        v[i] = x[i].v;
      end
      return v;
    end
  end
end




macro defD2FFunc1(Der2,ff,ex1,ex11)
  if(eval(Der2)==Deriv2Aggr)
    return esc(
    quote
      function $ff(X::$Der2{n,m}) where {n,m}
        x = X.v;
        dx = $ex1;
        dy = $ex11;
        return $Der2($ff(x),X,dx,dy);
      end
    end
    )
  else
    return esc(
    quote
      function $ff(X::$Der2{n}) where n
        x = X.v;
        dx = $ex1;
        dy = $ex11;
        return $Der2($ff(x),X,dx,dy);
      end
    end
    )
end
end
macro defD2FFunc2(Der2,op,ex1,ex2,ex11,ex22,ex12)
  return esc(
  quote
    function $op(X::$Der2{n}, Y::$Der2{n}) where n
      x = X.v;
      y = Y.v;
      dx = $ex1;
      dy = $ex2;
      dxx = $ex11;
      dyy = $ex22;
      dxy = $ex12;
      return $Der2($op(x,y),X,dx,Y,dy,dxx,dyy,dxy);
    end
    function $op(X::$Der2{n}, y::Float64) where n
      x = X.v;
      dx = $ex1;
      dxx = $ex11;
      return $Der2($op(x,y),X,dx,dxx);
    end
    function $op(x::Float64, Y::$Der2{n}) where n
      y = Y.v;
      dy = $ex2;
      dyy = $ex22;
      return $Der2($op(x,y),Y,dy,dyy);
    end
    $op(X::$Der2{n}, y::Int) where n = $op(X,convert(Float64,y));
    $op(x::Int, Y::$Der2{n}) where n = $op(convert(Float64,x), Y);
  end
  )
end
macro defD2FBool(Der2,fop)
  return esc(
  quote
    function $fop(x::$Der2{n}, y::$Der2{n}) where n
      return  $fop(x.v,y.v)
    end
    function $fop(x::$Der2{n}, yv::Float64) where n
      return  $fop(x.v,yv)
    end
    function $fop(xv::Float64,y::$Der2{n}) where n
      return  $fop(xv,y.v)
    end
    function $fop(x::$Der2{n}, yv::Int) where n
      return  $fop(x.v,yv)
    end
    function $fop(xv::Int,y::$Der2{n}) where n
      return  $fop(xv,y.v)
    end
  end
  )
end

import Base.+
import Base.-
import Base.*
import Base./
import Base.^
import Base.==
import Base.!=
import Base.>
import Base.>=
import Base.<
import Base.<=
import Base.min
import Base.max
import Base.convert;
import Base.zero;

import Base.exp
import Base.sqrt
import Base.log
import Base.abs
import SpecialFunctions.erf
import Base.sin
import Base.cos
import Base.tan

# for Der2 in (:Deriv2a,:Deriv2S,:Deriv2F,Deriv2Aggr)
for Der2 in (:Deriv2a,:Deriv2S,Deriv2Aggr)
  @eval begin
    @defD2FFunc1($Der2,-,-1,0)
    @defD2FFunc1($Der2,log,1/x,-1/x^2)
    @defD2FFunc1($Der2,exp,exp(x),exp(x))
    @defD2FFunc1($Der2,sqrt,1/(2*sqrt(x)),-1/(4*x^(3/2)))
    @defD2FFunc1($Der2,erf,2*exp(-x^2)/sqrt(pi),-4*x*exp(-x^2)/sqrt(pi))
    @defD2FFunc1($Der2,sin,cos(x),-sin(x))
    @defD2FFunc1($Der2,cos,-sin(x),-cos(x))
    @defD2FFunc1($Der2,tan,tan(x)^2 + 1,(2*tan(x)^2 + 2)*tan(x))
    @defD2FFunc1($Der2,abs,x>=0.0 ? 1.0 : -1.0,0.0);
  end
end

# for Der2 in (:Deriv2a,:Deriv2S,:Deriv2F)
for Der2 in (:Deriv2a,:Deriv2S)
  @eval begin
    @defD2FFunc2($Der2,+,1,1,0,0,0)
    @defD2FFunc2($Der2,-,1,-1,0,0,0)
    @defD2FFunc2($Der2,*,y,x,0,0,1)
    @defD2FFunc2($Der2,/,1/y,-x/y^2,0,2*x/y^3,-1/y^2)
    @defD2FFunc2($Der2,^,x^(y - 1)*y,x^y*log(x),x^(y - 2)*y*(y - 1),x^y*log(x)^2,x^(y - 1)*(y*log(x) + 1))

    @defD2FFunc2($Der2,min,x<y ? 1.0 : 0.0,x<y ? 0.0 : 1.0,0.0,0.0,0.0);
    @defD2FFunc2($Der2,max,x>y ? 1.0 : 0.0,x>y ? 0.0 : 1.0,0.0,0.0,0.0);

    ## @defD2FFunc2($Der2,*,y,x,0.0,0.0,1.0);
    ## # @defD2FFunc2($Der2,/,1.0/y,-x/y^2);
    ## @defD2FFunc2($Der2,-,1.0,-1.0,0.0,0.0,0.0);
    ## @defD2FFunc2($Der2,+,1.0,1.0,0.0,0.0,0.0);
    ## # @defD2FFunc2($Der2,^,y*(x^(y-1)),(x^y)*log(x));

    ## @defD2FFunc1($Der2,-,-1.0,0.0);
    ## @defD2FFunc1($Der2,sqrt,0.5*x^(-0.5),-0.25*x^(-1.5));
    ## @defD2FFunc1($Der2,exp,exp(x),exp(x));
    ## @defD2FFunc1($Der2,log,1.0/x,-1.0/(x*x));
      ## @defD2FFunc1($Der2,erf,2/sqrt(acos(-1))*exp(-x^2));

      @defD2FBool($Der2,==);
      @defD2FBool($Der2,!=);
      @defD2FBool($Der2,>);
      @defD2FBool($Der2,>=);
      @defD2FBool($Der2,<);
      @defD2FBool($Der2,<=);
    end
  end


  # if(isdefined(:PolyAppr))
  #   for Der2 in (:Deriv2a) # would have to be changed for :Deriv2S
  #     @eval begin
  #       function feval!(y::Array{$Der2{T},1},P::PolyAppr,x0::Array{$Der2{T},1},c::Array{Float64,2}) where T
  #         ny = size(c,2)
  #         dxdIndep = getjac(x0)
  #         (f,dxdx) = fevalDer(P,getval(x0),c',IntObj{ny}())
  #         J = dxdx*dxdIndep
  #         for i=1:ny
#           y[i] = $Der2{T}(f[i],J[i,:])
#         end
#       end
#       function feval(P::PolyAppr,x0::Array{$Der2{T},1},c::Array{Float64,2}) where T
#         ny = size(c,2)
#         y = Array{$Der2{T}}(ny)
#         feval!(y,P,x0,c)
#         return y;
#       end
#     end
#   end
# end


+(X::Deriv2a{n}, Y::Deriv2a{n}) where n = Deriv2a{n}(X.v+Y.v,X.d+Y.d,X.H+Y.H)
*(X::Deriv2a{n}, Y::Float64) where n = Deriv2a{n}(X.v*Y,X.d*Y,X.H*Y)


function optimAtExogPara!(dpPol::DynProgPol{Float64},pars,aggr,
                      _disc::Function,
                      _util::Function,
                      _prep!::Function,
                      _range::Function,
                      pT,
                      iZ::Int,
                      gridCS::Array{Float64,1},
                      ::Type{Val{nDC}},
                      VendUndisconted::Array{Float64,2},
                      QendUndisconted,
                      gridV,
                      widthStep,
                      t) where {nDC}
  nCS = length(gridCS)
  nxD = size(VendUndisconted,2)
  V = fillzero(Float64,(nCS,nxD))
  nV = length(gridV)

  tolVmax = 10.;
  # vOptJ = fill(-1e100,(nDC,))
  # pOptJ = fillzero(Float64,(nDC,)) # optimial continuous choice
  # iOptJ = fill(-1,(nDC,))   # discrete state end of period
  # eOptJ = fill(-1,(nDC,))   # discrete state end of period
  # bOptJ = fill(-1,(nDC,))   # bounds binding
  for iDS=1:nxD
    disc = _disc(pars,aggr,iDS,iZ,t) # discount factor depends only on discrete states
    VendJ = disc*VendUndisconted # end of period, after discounting
    QendJ = disc*QendUndisconted # end of period, after discounting
    VendJval = getval(VendJ)
    iStartSearch = fill(1,(nDC))
    for iEndog=1:nCS
      # if iEndog>1; error("done"); end
      xCS::Float64 = gridCS[iEndog];
      vOptJ = MVector{nDC,Float64}(undef)
      pOptJ = MVector{nDC,Float64}(undef) # optimial continuous choice
      iOptJ = MVector{nDC,Int}(undef)   # discrete state end of period
      eOptJ = MVector{nDC,Int}(undef)   # discrete state end of period
      bOptJ = MVector{nDC,Float64}(undef)   # bounds binding
      # vOptJ .= -1e100;
      # pOptJ .= 0.0;
      # iOptJ .= -1
      # eOptJ .= -1
      # bOptJ .= -1
      local iDE::Int
      for iDC = 1:nDC
        widthSearch = 16
        if iEndog==1 # first try
          iLo = 1
          iHi = length(gridV)-1;
        else
          iMid::Int = iStartSearch[iDC]
          iLo = iMid-widthSearch+1
          iHi = iMid+widthSearch
        end
        (vOptJ[iDC],cBest,bOptJ[iDC],iOptJ[iDC],pOptJ[iDC],eOptJ[iDC]) = 
        remotecall_fetch(optimAtPoint2,iDC+1,pars,aggr,
        # optimAtPoint2(pars,aggr,
                     xCS,iDS,iDC, iZ,iLo,iHi,
                     _disc,
                     _util,
                     _prep!,
                     _range,
                     pT,
                     VendJ,QendJ,
                     gridV,
                     _linsol.robustOptim,
                     t) 
        iStartSearch[iDC] = iOptJ[iDC]
      end
      iaBest = argmax(vOptJ)
      _prep!(pars,aggr,pT,xCS,iDS,iZ,iaBest,t) 
      V[iEndog,iDS] = vOptJ[iaBest] 
      if V[iEndog,iDS]<-1e99
        println(vOptJ)
        error("seems infeasible")
      end
      dpPol.B[iEndog,iDS,iZ] = bOptJ[iaBest] 
      p = pOptJ[iaBest];
      iI = iOptJ[iaBest];
      xCC = (1-p)*gridV[iI] + p*gridV[iI+1];
      dpPol.CC[iEndog,iDS,iZ] = xCC 
      dpPol.DC[iEndog,iDS,iZ] = iaBest # optimal discrete choice
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t); error("done")
      # mywarntype("util.out", _util,pars,aggr,pT,xCS,iDS,iZ,indep(Deriv21,xCC),iaBest,t); error("done")
      ut = _util(pars,aggr,pT,xCS,iDS,iZ,xCC,iaBest,t);
      xCE = xCC;
      (dpPol.I[iEndog,iDS,iZ],dpPol.P[iEndog,iDS,iZ]) = posInGrid(gridCS,xCE)
      dpPol.U[iEndog,iDS,iZ] = ut;
      dpPol.DE[iEndog,iDS,iZ] = eOptJ[iaBest];
    end
  end
  return V;
end

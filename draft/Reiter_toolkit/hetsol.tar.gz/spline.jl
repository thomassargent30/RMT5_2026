# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if !@isdefined(CubicSpl)
  type CubicSpl{TypeY}
    x::Array{Float64,1}
    y::Array{TypeY,1}
    y2::Array{TypeY,1}
  end
end
function spline(x::Array{Float64,1}, y::Array{TY,1}, yp1=1e100, ypn=1e100) where TY
  n = length(x)
  assert(length(y)==n)
  y2 = fill(zero(TY),n)
  u = fill(zero(TY),n-1)
  if (yp1 > 0.99e30)
    y2[1]=u[1]=0.0;
  else 
    y2[1] = -0.5;
    u[1]=(3.0/(x[2]-x[1]))*((y[2]-y[1])/(x[2]-x[1])-yp1);
  end
  for i=2:n-1
    sig=(x[i]-x[i-1])/(x[i+1]-x[i-1]);
    p=sig*y2[i-1]+2.0;
    y2[i]=(sig-1.0)/p;
    u[i]=(y[i+1]-y[i])/(x[i+1]-x[i]) - (y[i]-y[i-1])/(x[i]-x[i-1]);
    u[i]=(6.0*u[i]/(x[i+1]-x[i-1])-sig*u[i-1])/p;
  end
  if (ypn > 0.99e30)
    qn=un=0.0;
  else 
    qn=0.5;
    un=(3.0/(x[n]-x[n-1]))*(ypn-(y[n]-y[n-1])/(x[n]-x[n-1]));
  end
  y2[n]=(un-qn*u[n-1])/(qn*y2[n-1]+1.0);
  for k=n-1:-1:1
    y2[k]=y2[k]*y2[k+1]+u[k];
  end
  return CubicSpl{TY}(x,y,y2)
end

function splint(xa,  ya,  y2a, x)
  n = length(xa)
  klo=1;
  khi=n;
  while (khi-klo > 1) 
    k=div(khi+klo,2);
    if (xa[k] > x) 
      khi=k;
    else 
      klo=k;
    end
  end
  h=xa[khi]-xa[klo];
  a=(xa[khi]-x)/h;
  b=(x-xa[klo])/h;
  y=a*ya[klo]+b*ya[khi]+((a*a*a-a)*y2a[klo]+(b*b*b-b)*y2a[khi])*(h*h)/6.0;
  return y;
end
feval(S::CubicSpl{T},x) where T = splint(S.x,S.y,S.y2,x);
function feval2(S::CubicSpl{T},x::Array{Tx,1}) where {T,Tx}
  z1 = feval(S,x[1])
  n = length(x)
  Z = fill(z1,n)
  for i=2:n
    Z[i] = feval(S,x[i])
  end
  return Z
end


# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

# Program to check existence and uniqueness in linear RE models
# Input:
#   g0,g1,psi,pi,div: as defined in Sims' paper
# Output:
#   eu: stable solution exists iff eu(1)==1
#       solution is unique iff eu(2)==1
#   eigvals: generalized eigenvalues
# Michael Reiter, November2005
function  checkeu(g0,g1,psi,pi,div,iCheckThorough=true)

  G1 = fill(0.0,(0,0));
  impact = fill(0.0,(0,0));

  #[Lambda Omega q z]=qz(g0,g1);  #5th argument not needed!
  GS = schur(complex(g0),complex(g1));
  Q = GS.Q;
  Z = GS.Z;
  Omega = GS.T;
  Lambda = GS.S;
  ee = diag(Omega)./diag(Lambda);
  # Note that q'*Lambda*z' = g0 etc.,
  #  NOT  q*Lambda*z = g0 (as the Matlab help says!)
  realsmall = 1e-10; #much stricter than Sims
  dLambda = abs.(diag(Lambda));
  dOmega = abs.(diag(Omega));
#   if(any((dLambda.<realsmall) & (dOmega.<realsmall)))
#     # taken from Sims:
#     error("Coincident zeros.  Indeterminacy and/or nonexistence.")
#     eu=[-2;-2];
#     return (eu,G1,impact,eigvals);
#   end

  ev = abs.(diag(Omega)./diag(Lambda));
  select = ev.<div;
  n_stable = count(x->x,select)
  n = size(Lambda,1);
  n_unstable = n-n_stable;
  eu = [true;true]
  n_unstable_required = nnzrows(pi)
  ev = diag(Omega)./diag(Lambda);
  eigvals = sort(ev,by=abs)
  if(n_unstable>n_unstable_required)
    @printf("n_unstable = %d > %d = n_unstable_required\n",n_unstable,n_unstable_required)
    if(!iCheckThorough)
      warn("counting criterion yields instability");
    else
      warn("counting criterion yields instability");
    end
    eu[1] = false;
  end
  if(n_unstable<n_unstable_required)
    @printf("n_unstable = %d < %d = n_unstable_required\n",n_unstable,n_unstable_required)
    if(!iCheckThorough)
      warn("counting criterion yields indeterminacy");
    else
      warn("counting criterion yields indeterminacy");
    end
    eu[2] = false;
  end

  ordschur!(GS,select);
  Q = GS.Q;
  Z = GS.Z;
  Omega = GS.T;
  Lambda = GS.S;
  Q = Q';
  # but not Z = Z'  !!!!

  iStable = 1:n-n_unstable;
  iUnstable = n-n_unstable+1:n;
  q1=Q[iStable,:];
  q2=Q[iUnstable,:];
  q1pi=q1*pi;
  q2pi=q2*pi;
  q2psi=q2*psi;

  if(iCheckThorough)
    rq2pi = rank(q2pi);
    rqq = rank([q2psi q2pi]);
    # println([rq2pi rqq])
    rQpi = rank(Q*pi);
    iExist = rq2pi == rqq;
    iUnique = rQpi == rq2pi;
    eu = [iExist;iUnique];
    if(!all(eu))
      @printf("Q = (%d,%d); q2 = (%d,%d); psi = (%d,%d); pi = (%d,%d)\n",
      size(Q,1),size(Q,2), size(q2,1),size(q2,2), size(psi,1),size(psi,2), size(pi,1),size(pi,2));
      @printf("rank(q2*pi) = %d;rank([q2*psi q2*pi]) = %d; rank(Q*pi) = %d\n", rq2pi, rqq , rQpi);
      warn(@sprintf("exist = %d, unique = %d\n",convert(Int,eu[1]),convert(Int,eu[2])))
      # return (eu,[],[],eigvals)
    end
  end
  if(!all(eu))
    return (eu,G1,impact,eigvals);
  end

  Phi = q1pi/q2pi;  #Sims, equ. (42)
  #clear q1pi q2pi;


  z1 = Z[:,iStable];
  #  z2 = z(:,iUnstable); # NOT NEEDED
  L11 = Lambda[iStable,iStable];
  L12 = Lambda[iStable,iUnstable];
  L22 = Lambda[iUnstable,iUnstable];
  #clear Lambda;
  O11 = Omega[iStable,iStable];
  O12 = Omega[iStable,iUnstable];
  O22 = Omega[iUnstable,iUnstable];
  #clear Omega;

  #Sims, equ. (45)
  L11inv = inv(L11);
  #clear L11;
  aux = [O11 (O12-Phi*O22)]*Z';
  #clear O11 O12 O22;
  aux2 = z1*L11inv;
  #clear z1;
  G1 = real(aux2*aux);
  #clear aux aux2;
  aux = [L11inv -L11inv*(L12-Phi*L22);zeros(n_unstable,n_stable) meye(n_unstable)];
  #clear L11inv L12 L22;
  H = Z*aux;
  #clear Z;
  impact = real(H*[q1-Phi*q2;zeros(n_unstable,size(psi,1))]*psi);
  return (eu,G1,impact,eigvals);
end

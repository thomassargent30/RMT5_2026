# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


newton_init_B = [];
newton_out_B = [];
newton_output_file = [];

function newtonScaled(fname,xold,opts,dfname=x->x);
  global newton_init_B;
  global newton_output_file;
  # global Parameter newton_init_B does not interfere with recursive calling of newton,
  #  since only used in the beginning to initialize B, must be set anew before
  #  each call of newton

  if(length(opts)>0)
    TOLF = opts[1];
  else  #default
    TOLF = 1e-6;
  end
  if(length(opts)>1)
    iAD = opts[2];
  else  #default
    iAD = 0;
  end
  if(length(opts)>2)
    iprint = opts[3];
  else  #default
    iprint = 0;
  end
  if(length(opts)>3)
    step_jacob = opts[4];
  else  #default
    step_jacob = 1e-6;
  end
  if(length(opts)>=5)
    MAXITS = opts[5];
  else  #default
    MAXITS = 200;
  end
  if(length(opts)>=6)
    newton_init_B = opts[6];
  end

  # initialize outputs:
  B = newton_init_B;
  newton_init_B = [];  #must be set each time before calling newton!

  xold = xold[:];
  x = xold;

  EPS = 1.0e-7;
  TOLX = EPS;
  STPMX = 100.0;
  TOLMIN = 1.0e-6;
  n=size(x,1);

  (f,fvec)=fmin_br(x,fname);
  fvcold = fvec;
  fold=f;
  fx = fvec;
  if abs(fvec[1])>=1e100
    warn("overflow in function given to newton at initial vector");
    return (x, -1)
  end;
  test = maximum(abs,fvec);
  if (test<TOLF)  #changed from 0.01*TOLF to TOLF;
    return (x, 0)
  end;
  #stpmax=STPMX*max(sqrt(dot(x,x)),n);
  stpmax=1000.;
  if(isempty(B))
    restrt=1;
  else
    restrt=0;
  end
  since_restrt = 0;
  alam = 1;
  local BscaledI, maxr, maxc
  for its=1:MAXITS
    since_restrt = since_restrt+1;
    txt = @sprintf("its:  %d; f:  %e; step size taken: %e\n",its,getval(f),alam);
    if(fileexists("newton_stop"))
      return (x,4);
    end
    if(iprint>0)
      print(txt)
      if(!isempty(newton_output_file))
        FF = open(newton_output_file,"a");
        print(FF,txt);
        if(iprint>2)
          println(FF,x);
          println(FF,fvec);
        end
        close(FF)
      end;
    end
    # determine whether restart (new computation of Jacobian):
    if(fileexists("newton_restrt.txt"))
      system("del newton_restrt.txt");
      restrt=1;
    end
    if(restrt==1 || since_restrt>=3*n) #compute Jacobian at 3n iterations since last restart
      since_restrt = 0;
      if(iAD==1)
        if(iprint>1)
          println("now do Jacobian")
        end
        t1 = time_ns()
        B = dfname(x);
        t2 = time_ns()
        println("time for jacob = ",(t2-t1)/1e9)
      else
        B = jacob(fname,x,step_jacob);
      end;
      @assert(size(B,1)==size(B,2),@printf("size(B) = %d,%d\n",size(B,1),size(B,2)))
      if(!issparse(B) && !all(isfinite.(B)))
        saveT("bnotfinite.dat",B,x)
        error("Jacobian B in newton not finite; (B,x) saved to bnotfinite.bmt")
      end
      global newton_out_B;
      newton_out_B = B;
      maxr = 1.0 ./ maximum(abs.(B),2);
      Bscaled = broadcast(*,B,maxr);
      maxc = 1.0 ./ maximum(abs.(Bscaled),1);
      Bscaled = broadcast(*,Bscaled,maxc);
      try
        t1 = time_ns()
        BscaledI = lufact(Bscaled)
        t2 = time_ns()
        println("time for solve in newton = ",(t2-t1)/1e9)
      catch
        saveT("newtonB.bmt",B,Bscaled,fvec)
        error("failure to solve for Newton step; Jacobian and scaled Jac. and fvec in newtonB.bmt")
      end
    end;
    p = - (BscaledI\(fvec.*maxr)) .* maxc';
    p = p[:]
    g = B'*fvec;
    xold = x;
    fvcold = fvec;
    fold=f;
    check::Int = 1;
    try
      (x,f,fvec,check,alam) = lnsrch_br(xold,fold,g,p,stpmax,fname);
      fx = fvec;
      test = maximum(abs.(fvec));
      if (test < TOLF)
        if(iprint>0)
          @printf("maxerror at exit of newtonScaled: %0.3e",test)
        end
        return (x, 0)
      end;
    catch
      # saveT("newton.out",x,f,fvec,check,xold,fold,g,p,stpmax,fname);
    end
    if check==1
      if (restrt>0)
        return (x, 1)
      else 
        test=0.0;
        den=max(f,0.5*n);
        test = maximum(abs.(g) .* maximum([abs.(x');ones(1,n)])') / den;
        if (test < TOLMIN)
          return (x, 0)
        else
          restrt=1;
        end;
      end;
    else 
      restrt=0;
      if(alam<1e-3)
        restrt=1;
      end
      test= maximum(abs.(x-xold) ./ maximum([abs.(x');ones(1,n)])');
      if (test < TOLX)
        return (x, 0)
      end;
    end;
  end;
  # warning("MXITS exceeded in newton");
  return (x, 3)
end

# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

if(!@isdefined(ComplPolyIndx))
  abstract type MultiDimApprox end
  struct IntObj{T}
  end
  int(i::IntObj{T}) where T = T;
  mutable struct ComplPolyIndx
    B::Array{Int64,2}
    Changes::Array{Int64,2}
    ChangesDer::Array{Int64,2}
  end
  function Base.show(io::IO, x::ComplPolyIndx)
    printStruct(x)
  end
  mutable struct PolyAppr <: MultiDimApprox
    # lower range for Cheb. polynomials:
    a::Array{Float64,1}
    # upper range for Cheb. polynomials:
    b::Array{Float64,1}
    # dimension:
    dim::Int64
    # order of approximation:
    degree::Int64
    maxdegree::Int64
    center::Array{Float64,1}
    scal::Array{Float64,1}
    indx::ComplPolyIndx
  end
  function Base.show(io::IO, x::PolyAppr)
    printStruct(x)
  end


  mutable struct PolyApprExt
    P1::PolyAppr 
    PExt::PolyAppr 
    nAuxS::Int  # number of auxiliary states
    nAppSmall::Int  # number of variables that are approximated from original states (not aux.states)
    # nApprox = nApproxExt + nAuxS + nAppSmall;
  end
  import Base.copy
  copy(x::PolyApprExt) = PolyApprExt(copy(x.P1),copy(x.PExt),x.nAuxS,x.nAppSmall);

  copy(x::PolyAppr) = PolyAppr(copy(x.a),copy(x.b),x.dim,x.degree,x.maxdegree,copy(x.center),copy(x.scal),copy(x.indx));
  copy(x::ComplPolyIndx) = ComplPolyIndx(copy(x.B),copy(x.Changes),copy(x.ChangesDer));
end


function saveRaw(F::IOStream,x::PolyAppr)
  saveRaw(F,x.a)
  saveRaw(F,x.b)
  write(F,convert(Int64,x.degree))
  write(F,convert(Int64,x.maxdegree))
  saveRaw(F,x.center)
  saveRaw(F,x.scal)
  saveRaw(F,x.indx.B)
  saveRaw(F,x.indx.Changes)
  saveRaw(F,x.indx.ChangesDer)
end
function loadRaw(F::IOStream,::Type{PolyAppr})
  a = loadRaw(F,Array{Float64,1})
  b = loadRaw(F,Array{Float64,1})
  dim = length(a)
  degree = read(F,Int64)
  maxdegree = read(F,Int64)
  center = loadRaw(F,Array{Float64,1})
  scal = loadRaw(F,Array{Float64,1})
  B = loadRaw(F,Array{Int64,2})
  Changes = loadRaw(F,Array{Int64,2})
  ChangesDer = loadRaw(F,Array{Int64,2})
  indx = ComplPolyIndx(B,Changes,ChangesDer)
  return PolyAppr(a,b,dim,degree,maxdegree,center,scal,indx);
end


if Sys.islinux()
  using Yeppp;
  function yepdot(x::Array{Float64},ix, y::Array{Float64},iy, n::Int, res::Array{Float64},iz)
    status = ccall( (:yepCore_DotProduct_V64fV64f_S64f, Yeppp.libyeppp), Cint, (Ptr{Float64}, Ptr{Float64}, Ptr{Float64}, Culong), pointer(x,ix), pointer(y,iy), 
                         pointer(res,iz), n)
    status != 0 && error("yepCore_DotProduct_V64fV64f_S64f: error: ", status)
  end
else
  function yepdot(x::Array{Float64},ix, y::Array{Float64},iy, n::Int, res::Array{Float64},iz)
    z = 0;
    for i=0:n-1
      z += x[ix+i]*y[iy+i];
    end
    res[iz] = z
  end
end

# Input:  g01 is grid in [0,1]^dim
# Output: gcirc is grid in dim-dimensional unit ball
function rect2ball(g01)
  dim = size(g01,2);
  g = map(x->quantile(Normal(0.,1.),x),g01);
  sumsqu = (sum(g.^2,2)); # squared norm is chi2 !!
  sumsqu = max.(sumsqu,1e-12); # handle special case x = 0;
  prob = map(x->cdf(Chisq(dim),x),sumsqu);
  scal = prob.^(1.0/dim) ./ sqrt.(sumsqu);# power is applied because the volume grows with radius^d
  gCirc = broadcast(*,g,scal);
  return gCirc;
end

# grid01: grid in unit ball
function rotatedGrid(grid01,Sigma,width,minwidth,stst=zeros(size(Sigma,1)))
  Sigma = (Sigma+Sigma')/2; # make sure exactly symmetric
  # do PCA:
  (ew,evec) = eigen(Sigma);
  grid = grid01[:,1]*(evec[:,1]'*ew[1]);
  for i=1:size(Sigma,1)
    grid += grid01[:,i]*(evec[:,i]'*max(minwidth,width*sqrt(abs(ew[i]))));
  end
  grid += broadcast(+,grid,vec(stst)');
  return grid;
end

function scaldown(x,xmin,xmax)
  if(xmax==xmin) # allow degenerate case
    return xmin;
  else
    return -1 + 2*(x-xmin)/(xmax-xmin);
  end
end
# number of basis functions of complete polynomial when dimension is d and
# degree is p
function nCoeff(d::Int,p::Int)
  if(p==-2) # special case: order 1+
    return 1+2*d
  end
  n = 1;
  for i=1:p
    m = d;
    for j=1:i-1
      m *= (d+j);
      m = div(m,j+1); 
    end
    n += m;
  end
  return n;
end


function ComplPolyIndx(d::Int,p::Int,selectFunc=0)
  nC = nCoeff(d,p);
  B = fill(0,(d,nC));
  Changes = fill(0,(3,nC));

  if(p==-2) # special case: order 1+
    for i=1:d
      B[i,i+1] = 1;
      B[i,d+i+1] = 2;
    end
  else
    z = fill(0,d)
    lauf = 0;
    while(z[1]<=p)
      for i=0:p+1
        z[d] = i;
        if(sum(z)>p)
          succ = 0;
          for m=d-1:-1:2
            if(sum(z[1:m])<p)
              z[m]=z[m]+1;
              z[m+1:d].=0;
              succ = 1;	    
              break;
            end
          end
          if(succ==0)
            z[1] = z[1]+1;
            z[2:d] .= 0;
          end
          break;
        end
        lauf += 1;
        B[:,lauf]= z;
      end
    end
    @assert(lauf==nC);
  end
  B = reverse(B,dims=1) # make first variables come first
  if isa(selectFunc,Function)
    doKeep = map(i->selectFunc(B[:,i]),1:size(B,2))
    B = B[:,doKeep]
    nC = size(B,2)
    println(size(B))
  end
  # sort in ascending order of polynomial degree:
  indx = sortperm(vec(sum(B,dims=1)));
  #B = B[:,indx];  

  for j=2:nC
    b0 = B[:,j];
    iChange=argmax(b0);# which dimension to change  # indmin does not work
    degChange = b0[iChange];
    b0[iChange] = 0;
    succ = false;
    for k=1:j-1
      if(B[:,k]==b0)
        Changes[1,j] = k; # which basis element to start from
        Changes[2,j] = iChange;# which dimension to change
        Changes[3,j] = degChange;#factor to multiply with
        succ = true;
        break;
      end
    end
    @assert(succ);
  end
  Changes[1,1] = 0; # which basis element to start from
  Changes[2,1] = 0;# which dimension to change
  Changes[3,1] = 0;#factor to multiply with

  ChangesDer = Array{Int}(undef,4,0)
  for i=1:d
    has_i = findall(B[i,:] .> 0)
    Bi = B[:,has_i]
    n = length(has_i)
    iBasis = Array{Int}(undef,n)
    for j=1:n
      bi = Bi[:,j];
      bi[i] = 0;
      iBas = findall(i->B[:,i] == bi,1:nC) # seems to be inefficient!!
      @assert(length(iBas)==1)
      iBasis[j] = iBas[1]
    end
    CDi = [fill(i,(n)) vec(has_i) vec(iBasis) vec(Bi[i,:])]'
    ChangesDer = [ChangesDer CDi]
  end
  @assert(d<1024)
  # lexicographic criterion: first the number of the coefficient, then dimension of derivative
  indx = ChangesDer[1,:] + 1024*ChangesDer[2,:] 
  ii = sortperm(indx)
  ChangesDer = ChangesDer[:,ii]
  return ComplPolyIndx(B,Changes,ChangesDer);
end

function PolyAppr(degree,a::AbstractArray{Float64,1},b,selectFunc=0,AddedPoly=0)
  dim = length(a);
  @assert(length(b)==dim,@printf("#a = %d, #b = %d",length(a),length(b)))
  center = (a+b)./2  # stored because often used in evaluation
  scal = 2.0 ./ (b-a)  # stored because often used in evaluation
  if AddedPoly==0
    indx = ComplPolyIndx(length(a),degree,selectFunc);
    maxdegree = abs(degree) # handle case degree = -2
  else
    indx = ComplPolyIndx2(length(a),degree,selectFunc,AddedPoly);
    maxdegree = maximum(sum(indx.B,dims=1)); 
  end
  return PolyAppr(a,b,dim,degree,maxdegree,center,scal,indx);
end
function PolyAppr(degree,X::AbstractArray{Float64,2},selectFunc=0,AddedPoly=0)
  return PolyAppr(degree,vec(minimum(X,dims=1)),vec(maximum(X,dims=1)),selectFunc,AddedPoly)
end
function PolyAppr(dim::Int,degree::Int,selectFunc=0)
  return PolyAppr(degree,-1*ones(dim),ones(dim),selectFunc)
end
function close2Bound(fspace,x)
  crit = maxabs((x-fspace.center).*fspace.scal);
  return crit;
end
function putInBound(fspace,x0,range::Float64=1.0)
  if(range==1)
    x = max(x0,fspace.a);
    x = min(x,fspace.b);
  else
    x = max(x0,fspace.center - range./fspace.scal);
    x = min(x,fspace.center + range./fspace.scal);
  end
  return x;
end

# sets a and b:
function setBounds!(fspace,xLow::Array{Float64,1},xUpp::Array{Float64,1},center::Array{Float64,1})
  @assert(length(xLow)==fspace.dim);
  @assert(length(xUpp)==fspace.dim);
  fspace.a = xLow;
  fspace.b = xUpp;
  fspace.center = center;
  fspace.scal = 2.0 ./ (fspace.b-fspace.a)  # stored because often used in evaluation
end
# sets a and b:
function setBounds!(fspace,xLow::Array{Float64},xUpp::Array{Float64})
  center = (xLow+xUpp)./2  # stored because often used in evaluation
  setBounds!(fspace,xLow,xUpp,center)
end

dimen(P::PolyAppr) = P.dim
nCoeff(P::PolyAppr) = size(P.indx.B,2)
# nCoeff(P::PolyAppr) = nCoeff(P.dim,P.degree) # not true if selector function applied

function chebpol(degree::Int, x)
  ord = degree+1; 
  cheb = Array{typeof(x)}(undef,ord);
  cheb[1] = 1.0;
  cheb[2] = x;
  for i=3:ord
    cheb[i] = 2*x*cheb[i-1]-cheb[i-2];
  end
  return cheb;
end

function chebpol!(cheb,jCol,degree::Int, x)
  ord = degree+1; 
  #cheb = Array{typeof(x)}(ord);
  cheb[1,jCol] = 1.0;
  cheb[2,jCol] = x;
  for i=3:ord
    cheb[i,jCol] = 2*x*cheb[i-1,jCol]-cheb[i-2,jCol];
  end
end
function chebpol!(cheb::Array{T}, x::T) where T
  ord = length(cheb)
  cheb[1] = convert(T,1.0)
  if(ord>1)
    cheb[2] = x;
  end
  for i=3:ord
    cheb[i] = 2*x*cheb[i-1]-cheb[i-2];
  end
end
function chebpol!(cheb::Array{T,2},xvec::Array{T,1},center,scal) where T
  (ord,dimx) = size(cheb)
  for jCol = 1:dimx
    x = scal[jCol]*(xvec[jCol]-center[jCol])
    cheb[1,jCol] = 1.0;
    if(ord>1)
      cheb[2,jCol] = x;
    end
    for i=3:ord
      cheb[i,jCol] = 2*x*cheb[i-1,jCol]-cheb[i-2,jCol];
    end
  end
end

function chebpol!(cheb::Array{Float64,2},chebDer::Array{Float64,2}, xvec::Array{Float64,1},center,scal)
  (ord,dimx) = size(cheb)
  for jCol = 1:length(xvec)
    x = scal[jCol]*(xvec[jCol]-center[jCol])
    dx = scal[jCol]
    cheb[1,jCol] = 1.0;
    chebDer[1,jCol] = 0.0;
    if(ord>1)
      cheb[2,jCol] = x;
      chebDer[2,jCol] = dx;
    end
    for i=3:ord
      cheb[i,jCol] = 2*x*cheb[i-1,jCol]-cheb[i-2,jCol];
      chebDer[i,jCol] = 2*(dx*cheb[i-1,jCol]+x*chebDer[i-1,jCol])-chebDer[i-2,jCol];
    end
  end
end


function monom2cheb(degree::Int)
  # cheb[i] = 2*x*cheb[i-1]-cheb[i-2];
  ord = degree+1;
  #Chebpol(x) = M * Monom(x)
  M = meye(ord)
  for i=3:ord
    M[:,i] = 2*[0;M[1:end-1,i-1]] - M[:,i-2]
  end
  return M
end
quadform(grad::Array{Float64,1},Hess) = dot(grad,Hess*grad)
function quadform(H::AbstractArray{Float64,2},S::AbstractArray{Float64,2})
  q = H*S*H';
  q = (q+q')./2
  return q;
end
### function quad2monom(fspace,x,a,grad,Hess)
###   m = nCoeff(fspace)
###   cMonom = zeros(m)
###   c = fspace.center
###   dx = x-c;
###   a_at_c = a - dot(dx,grad) + dot(dx,Hess*dx);
###   cMonom[1] = a_at_c;
###   sc = fspace.scal
###   gradSc = grad.*sc
###   HessSc = Hess .* (sc*sc')
###   B = fspace.indx.B
###   n = size(B,2)
###   for i=2:n # first one is constant
###     indx = mfind(B[:,i] .> 0)
###     if length(indx)==1
###       j = indx[1]
###       if B[j,i]==1
###         cMonom[i] = gradSc[j]
###       else
###         cMonom[i] = HessSc[j,j]
###       end
###     else
###       cMonom[i] = gradSc[indx[1]] * gradSc[indx[2]]
###     end
###   end
###   return cMonom;
### end
# y = sum_i c_i C_i(a+b*x)
#   = sum_i sum_j Mi_ij m_j M_j(a+b*x)
# dy  = sum_i sum_j Mi_ij m_j dM_j(a+b*x) *b
# dy  = sum_i sum_j Mi_ij sum_k D_jk c_k dC_j(a+b*x) *b
function dChebpol(degree::Int,stretch)
  # cheb[i] = 2*x*cheb[i-1]-cheb[i-2];
  ord = degree+1;

  #Chebpol(x) = M * Monom(x)
  M = meye(ord)
  for i=3:ord
    M[:,i] = 2*[0;M[1:end-1,i-1]] - M[:,i-2]
  end
  # dMonom(x)/dx = D*monom(x)
  D = zeros(ord,ord)
  D[1,2] = 1
  for i=2:ord
    deg = i-1
    D[i-1,i] = deg / stretch;
  end
  #dChebpol(x)/dx = M*dMonom(x)/dx = M*D*monom(x) = M*D*inv(M)
  DC = M\D*M
  return (DC,M,D)
end
function dChebpol(fspace,iD)
  (DC,m1,m2) = dChebpol(fspace.degree,1/fspace.scal[iD])
  d = fspace.dim
  if(d==1)
    return DC;
  end
  B = fspace.indx.B
  n = size(B,2)
  DC2 = zeros(n,n)
  for i=1:n
    deg = B[iD,i]
    coeffD = DC[:,deg+1]
    for j=1:length(coeffD)
      if(coeffD[j]!=0)
        b = B[:,i]
        b[iD] = j-1
        k = findall(map(i->B[:,i]==b,1:i-1))
        @assert(length(k)==1)
        DC2[k[1],i] += coeffD[j]
      end
    end
  end
  return DC2
end
function chebpolDerCoeff(cheb::Array{Float64,2},chebDer::Array{Float64,2}, xvec::Array{Float64,1},center,scal)
  (ord,dimx) = size(cheb)
  for jCol = 1:length(xvec)
    x = scal[jCol]*(xvec[jCol]-center[jCol])
    dx = scal[jCol]
    cheb[1,jCol] = 1.0;
    chebDer[1,jCol] = 0.0;
    cheb[2,jCol] = x;
    chebDer[2,jCol] = dx;
    for i=3:ord
      cheb[i,jCol] = 2*x*cheb[i-1,jCol]-cheb[i-2,jCol];
      chebDer[i,jCol] = 2*(dx*cheb[i-1,jCol]+x*chebDer[i-1,jCol])-chebDer[i-2,jCol];
    end
  end
end


function feval(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,1},basis::Array{Float64,1})
  dimx = P.dim
  @assert(dimx == length(x0))
  chebbas = Array{Float64}(undef,P.maxdegree+1,dimx)
  chebpol!(chebbas,x0,P.center,P.scal)
  global cb = chebbas
  nP = nCoeff(P)
  if(nP!=size(coeff,1))
    println(nP)
    println(size(coeff))
    error("wrong size in feval")
  end
  basis[1] = 1;
  Y = coeff[1];
  ch = P.indx.Changes
  nc = size(coeff,1)
  nY = size(coeff,2)
  @assert(nP==nc)
  @inbounds for i=2:nP
    k = ch[1,i]; # which basis element to start from
    iChange = ch[2,i];# which dimension to change
    degChange = ch[3,i];#factor to multiply with
    basis[i] = basis[k] * chebbas[degChange+1,iChange];
    # println("am here at $i with basis $(basis[i])")
    Y += basis[i]*coeff[i];
  end
  return Y;
end
function feval(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,1})
  basis = Array{Float64}(undef,nCoeff(P))
  return feval(P,x0,coeff,basis);
end
# assumes that the COLUMNS of coeff contain coefficients for the different variables to approximate
function feval!(Y::Array{Float64,1},P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2},basis::Array{Float64,1})
  dimx = P.dim
  if dimx != length(x0)
    println("x has dimension ",length(x0)," but Polynomial has dimension ",dimx)
    error("wrong dimension")
  end
  chebbas = Array{Float64}(undef,P.maxdegree+1,dimx)
  chebpol!(chebbas,x0,P.center,P.scal)
  nP = nCoeff(P)
  if(nP!=size(coeff,1))
    @show(nP)
    @show size(coeff)
    error("wrong size in feval")
  end
  basis[1] = 1;
  ch = P.indx.Changes
  nc = size(coeff,1)
  nY = size(coeff,2)
  @assert(nP==nc)
  @inbounds for i=2:nP
    k = ch[1,i]; # which basis element to start from
    iChange = ch[2,i];# which dimension to change
    degChange = ch[3,i];#factor to multiply with
    basis[i] = basis[k] * chebbas[degChange+1,iChange];
  end
  @assert(length(Y)==nY)
  for i=1:nY
    @inbounds yepdot(basis,1,coeff,(i-1)*nP+1,nP,Y,i)
  end
end
function feval!(Y::Array{Float64,1},P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2})
  basis = Array{Float64}(nCoeff(P))
  feval!(Y,P,x0,coeff,basis)
end
function feval(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2},basis::Array{Float64,1})
  Y = zeros(size(coeff,2))
  feval!(Y,P,x0,coeff,basis)
  return Y;
end
# same, but use basis of P as workspace
function feval(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2})
  basis = Array{Float64}(undef,nCoeff(P))
  return feval(P,x0,coeff,basis)
end

## # assumes that the ROWS of coeff contain coefficients for the different variables to approximate
## function feval{nA}(P::PolyAppr,x0::Array{Float64,1},c::Array{Float64,2}, _unused::IntObj{nA})
##   dimx = P.dim
##   @assert(dimx == length(x0))
##   chebbas = Array{Float64}(P.degree+1,dimx)
##   chebpol!(chebbas,x0,P.center,P.scal)
##   nP = nCoeff(P)
##   P.basis[1] = 1;
##   ch = P.indx.Changes
##   if(!(size(c)==(nA,nP)))
##     println("error in feval")
##     println(size(c))
##     println(nA,nP)
##     @assert(false)
##   end
##   Y = c[:,1]
##   @inbounds for i=2:nP
##     k = ch[1,i]; # which basis element to start from
##     iChange = ch[2,i];# which dimension to change
##     degChange = ch[3,i];#factor to multiply with
## 
##     b = P.basis[k] * chebbas[degChange+1,iChange];
##     @inbounds @simd for j=1:nA
##       Y[j] += b*c[j,i]
##     end
##     P.basis[i] = b;
##   end
##   return Y;
## end

# commented out on April 12, 2017 !!
function fevalDer(P::PolyAppr,x0::Array{Float64,1},coeff,basis::Array{Float64,1},_i::IntObj{nA}) where nA
  dimx = P.dim
  @assert(dimx == length(x0),println("state size is ",length(x0)," rather than ",dimx))
  chebbas = Array{Float64}(P.maxdegree+1,dimx)
  chebDer = Array{Float64}(P.maxdegree+1,dimx)
  chebpol!(chebbas,chebDer,x0,P.center,P.scal)
  nP = nCoeff(P)
  (nA2,nc) = size(coeff)
  @assert(nP==nc,println(size(coeff)," vs. ",nP))
  @assert(nA==nA2)

  YDer = zeros(nA,dimx)
  basis[1] = 1;
  ch = P.indx.Changes
  c = coeff
  Y = c[:,1]
  @inbounds for i=2:nP
    k = ch[1,i]; # which basis element to start from
    iChange = ch[2,i];# which dimension to change
    degChange = ch[3,i];#factor to multiply with
    b = basis[k] * chebbas[degChange+1,iChange];
    @inbounds @simd for j=1:nA
      Y[j] += b*c[j,i]
    end
    basis[i] = b;
  end
  ch = P.indx.ChangesDer
  for i=1:size(ch,2)
    iD = ch[1,i]; # deriv. w.r.t. variable iD
    iCoeff = ch[2,i];# which coefficient is relevant
    iBasis = ch[3,i];# basis vector to start from
    deg = ch[4,i];#derivative of polynomial deg
    basisCD = basis[iBasis] * chebDer[deg+1,iD];
    @inbounds @simd for j=1:nA
      YDer[j,iD] += basisCD*c[j,iCoeff]
    end
  end
  return (Y,YDer)
end


function basis(P::PolyAppr,x0::AbstractVector{Float64})
  n = length(x0);
  x = zeros(1,n)
  for i=1:n
    x[i] = x0[i]
  end
  return basis(P,x)
end
function basis(P::PolyAppr,x0::AbstractArray{Float64,2})
  (nPoints,nx) = size(x0)
  nB = nCoeff(P);
  if nx!=dimen(P)
    @show nx,dimen(P)
    error("dimension of grid not equal to dim of polynomial")
  end
  x = zeros(nx)
  chebbas = zeros(P.maxdegree+1,dimen(P));
  B = ones(nPoints,nB)
  for j=1:nPoints
    for i=1:dimen(P)
      x[i] = scaldown(x0[j,i],P.a[i],P.b[i]);
      chebbas[:,i] = chebpol(P.maxdegree,x[i]);
    end
    # println(chebbas)
    B[:,1] .= 1;
    for i=2:nB
      k = P.indx.Changes[1,i]; # which basis element to start from
      iChange = P.indx.Changes[2,i];# which dimension to change
      degChange = P.indx.Changes[3,i];#factor to multiply with
      B[j,i] = B[j,k] * chebbas[degChange+1,iChange];
    end
  end
  return B;
end

function feval(P::MultiDimApprox,Grid::AbstractArray{Float64,2},coef::Array{Float64,2})
  nG = size(Grid,1);
  nA = size(coef,2);
  DepVar = zeros(nG,nA)
  for i=1:nG
    DepVar[i,:] = feval(P,vec(Grid[i,:]),coef);
  end
  return DepVar;
end
feval(P::MultiDimApprox,Grid::Array{Float64,2},coef::Array{Float64,1}) = feval(P,Grid,reshape(coef,length(coef),1));

# function feval2(P::MultiDimApprox,Grid,coef)
#   nG = size(Grid,1);
#   nA = size(coef,2);
#   DepVar = zeros(nG,nA)
#   for i=1:nG
#     DepVar[i,:] = feval(P,vec(Grid[i,:]),coef);
#   end
#   return DepVar;
# end

function changeScale(coef,fspaceOld,fspace,Grid)
  DepVar = feval(fspaceOld,Grid,coef);
  B = basis(fspace,Grid);
  coefNew = B\DepVar;
  resid = DepVar - B*coefNew;
  #println("R2 in changeScale:")
  #println(1 - var(resid,1)./var(DepVar))
  return coefNew;
end
## # old: depends on normalized Grid and global variable grid0, obsolete
## function changeScale(coef,fspaceOld,fspace)
##   grid0 = normalizedGrid(fspaceOld,1.5);
##   Grid = scalUp(fspaceOld,grid0);
##   return changeScale(coef,fspaceOld,fspace,Grid)
## end
function changeScale(coef::Array{Float64},fspaceOld,fspace)
  Grid = nodes(fspace)
  n = size(Grid,1)
  B = basis(fspace,Grid)
  if ndims(coef)==1
    DepVar = Array{Float64}(n)
    for i=1:n
      DepVar[i] = feval(fspaceOld,Grid[i,:],coef)
    end
  else
    nC = size(coef,2)
    DepVar = Array{Float64}(n,nC)
    for i=1:n
      DepVar[i,:] = feval(fspaceOld,Grid[i,:],coef)
    end
  end
  return B\DepVar;
end

function changeStateVecs(coef,fspaceOld,fspace)
  grid0 = normalizedGrid(fspaceOld,3);
  Grid = scalUp(fspaceOld,grid0);
  DepVar = feval(fspaceOld,Grid,coef);
  nNewStates = length(fspace.a) - length(fspaceOld.a);
  Grid2 = scalUp(fspace,[grid0 rand(size(Grid,1),nNewStates)]);
  B = basis(fspace,Grid2);
  coefNew = B\DepVar;
  return coefNew;
end

# function feval(P::PolyApprExt,x0::Array{Float64},coeff::Array{Float64})
#   (coeff1,coeff2) = splitCoeff(P,coeff);
#   a1 = max(0.0,feval(P.P1,x0,coeff1));
#   a2 = [a1 feval(P.PExt,[x0 a1[:,1:P.nAuxS]],coeff2)];
#   return a2;
# end
function indxExtCoeff(P::PolyApprExt,coeff::Array{Float64})
  (coeff1,coeff2) = splitCoeff(P,coeff);
  n1 = length(coeff1);
  indxExt = dimen(P.P1)+1:dimen(P.PExt);
  ii = findnzcols(P.PExt.indx.B[indxExt,:]);
  #println(ii)
  indx = n1 + ii;
  (nr,nc) = size(coeff2)
  for j=2:nc
    indx = [indx;n1+(j-1)*nr + ii];
  end
  return sort(indx);
end

# 3 types of approximated variables:
#   - nAuxS variables that are subject to non-negativity constraint (function of states only)
#     (called auxiliary states)
#   - nAppSmall variables (often Lagrange multiplies) that satisfy complementary 
#     slackness conditions  with auxiliary states (function of states only); 
#     can be 0 to nAuxS of those
#   - nApproxExt other variaables, approximated as function states and auxiliary states
function splitCoeff(P::PolyApprExt,coeff::Array{Float64})
  nCoef = nCoeff(P.P1);
  nCoefExt = nCoeff(P.PExt);
  n1 = (P.nAuxS+P.nAppSmall)* nCoef;
  nC = length(coeff)
  nApproxExt = div(nC-n1,nCoefExt)
  n2 = nApproxExt*nCoefExt
  @assert(nC == n1 + n2);
  coeff1 = reshape(coeff[1:n1],nCoef,P.nAuxS+P.nAppSmall);
  coeff2 = reshape(coeff[n1+1:n1+n2],nCoefExt,nApproxExt);
  return (coeff1,coeff2);
end

function changeScale!(coef,fspaceOld::PolyApprExt,fspace::PolyApprExt,xLow,xUpp)
  fspace.PExt.a = xLow;
  fspace.PExt.b = xUpp;
  fspace.P1.a = xLow[1:dimen(fspace.P1)];
  fspace.P1.b = xUpp[1:dimen(fspace.P1)];
  (coef1,coef2) = splitCoeff(fspaceOld,coef);
  coef1new = changeScale(coef1,fspaceOld.P1,fspace.P1)
  coef2new = changeScale(coef2,fspaceOld.PExt,fspace.PExt)
  return [vec(coef1new);vec(coef2new)]
end


function extendPolyAppr(fspace::PolyAppr,Grid::Array{Float64},coeff::Array{Float64},nAuxS,nAppSmall)
  nAux = nAuxS + nAppSmall;
  coef1 = coef0[:,1:nAux];
  coef2small = coef0[:,nAux+1:end];

  grid0 = normalizedGrid(fspace,3);
  Grid = scalUp(fspace,grid0);
  AuxStates = feval(fspace,Grid,coeff[:,1:nAuxS]);
  xLow = [fspace.a;zeros(nAppSmall)];
  xUpp = [fspace.b;maximum(AuxStates,1)'];
  #xLow = [fspace.a;minimum(AuxStates,1)'];
  #xUpp = [fspace.b;zeros(nAppSmall)]; # mmake mor general choice here!!!!!!!!!!
  fspaceExt = PolyAppr(xLow,xUpp,fspace.degree)
  coef2 = changeStateVecs(coef2small,fspace,fspaceExt);
  coef = [vec(coef1);vec(coef2)];
  B = basis(fspace,Grid);
  Grid2 = scalUp(fspaceExt,[grid0 (-1+2*rand(size(grid0,1),nAuxS))]);
  B2 = basis(fspaceExt,Grid2);
  return (PolyApprExt(fspace,fspaceExt,nAuxS,nAppSmall),coef,(B',B2'))
end



## # for different types of x0; probably obsolete through use of fevalDer
## function feval!{TX}(P::PolyAppr,x0::Array{TX,1},coeff::Array{Float64,2}, Y::Array{TX,1})
##   (nP,nY) = size(coeff);
##   order = P.degree + 1;
##   chebbas = Array{Array{TX,1}}(P.dim);
##   for i=1:P.dim
##     chebbas[i] = Array{TX}(order)
##   end
##   for i=1:dimen(P)
##     xi = scaldown(x0[i],P.a[i],P.b[i]);
##     chebpol!(chebbas[i],xi);
##   end
##   isBases = fill(0,(nP));
##   for i=2:nP
##     isBases[P.indx.Changes[1,i]] = 1;
##   end
##   Bases = Array{TX}(nP)
##   Bases[1] = convert(TX,1.0);
##   for j=1:nY
##     Y[j] = convert(TX,coeff[1,j]);
##   end
##   tmpBas = zero(TX)
##   # tmpBas = convert(TX,0.0)
##   for i=2:nP
##     k = P.indx.Changes[1,i]; # which basis element to start from
##     iChange = P.indx.Changes[2,i];# which dimension to change
##     degChange = P.indx.Changes[3,i];#factor to multiply with
##     mul!(tmpBas,Bases[k],chebbas[iChange][degChange+1]);
##     for j=1:nY
##       # Y[j] += tmpBas * coeff[i,j]
##       addmul!(Y[j],tmpBas,coeff[i,j])
##     end
##     if(isBases[i]==1)
##       Bases[i] = copy(tmpBas)
##     end
##   end
## end


function fitxy(P::MultiDimApprox,Grid::AbstractArray{Float64,2},Appr::AbstractArray{Float64,2}, eps=0.0,iPrint=false)
  B = basis(P,Grid);
  if(eps==0)
    coef = B\Appr
  else
    coef = ols_ridge(B,Appr,eps)
  end
  if(iPrint)
    resid = Appr - B*coef;
    R2 = var(resid,dims=1)./var(Appr,dims=1)
    F = open("fitxyr2.out","a")
    println(F,"R2 in fitxy: \n",R2)
    close(F)
  end
  return coef;
end

# applies to func that returns scalar
function fitfun(F::MultiDimApprox,func::Function)
  g = nodes(F)
  y = map(i->func(g[i,:]),1:size(g,1))
  return fitxy(F,g,y)
end
# applies to func that returns vector
function fitfun2(F::MultiDimApprox,func::Function)
  g = nodes(F)
  yy = g;
  y = hcat(map(i->func(g[i,:]),1:size(g,1))...)
  return fitxy(F,g,y')
end

function fevalDer(P::PolyAppr,x0::Array{Float64,1},coeff::Array{T,1},basis::Array{Float64,1}) where T
  dimx = P.dim
  @assert(dimx == length(x0))
  chebbas = Array{Float64}(P.maxdegree+1,dimx)
  chebDer = Array{Float64}(P.maxdegree+1,dimx)
  chebpol!(chebbas,chebDer,x0,P.center,P.scal)
  nP = nCoeff(P)
  nc = length(coeff)
  @assert(nP==nc,println(length(coeff)))

  YDer = fill(zero(typeof(coeff[1])),(dimx,))
  basis[1] = 1;
  ch = P.indx.Changes
  c = coeff
  Y = c[1]
  @inbounds for i=2:nP
    k = ch[1,i]; # which basis element to start from
    iChange = ch[2,i];# which dimension to change
    degChange = ch[3,i];#factor to multiply with
    b = basis[k] * chebbas[degChange+1,iChange];
    Y += b*c[i]
    basis[i] = b;
  end
  ch = P.indx.ChangesDer
  for i=1:size(ch,2)
    iD = ch[1,i]; # deriv. w.r.t. variable iD
    iCoeff = ch[2,i];# which coefficient is relevant
    iBasis = ch[3,i];# basis vector to start from
    deg = ch[4,i];#derivative of polynomial deg
    basisCD = basis[iBasis] * chebDer[deg+1,iD];
    YDer[iD] = YDer[iD] + basisCD*c[iCoeff]
  end
  return (Y,YDer)
end

if @isdefined(Deriv1a)
  function feval(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Deriv1S{N},1}) where N
    basis = Array{Float64}(nCoeff(P))
    Y = feval(P,x0,getval(coeff),basis);
    n = _nIndepSparse[N]
    return Deriv1a{n}(Y,vec(basis' * getjac(coeff)))
  end
  function feval(P::MultiDimApprox,x0::Array{Deriv1a{T},1},c::Array{Float64,1}) where T
    basis = Array{Float64}(nCoeff(P))
    dxdIndep = getjac(x0)
    (f,dxdx) = fevalDer(P,getval(x0),c,basis)
    J = dxdx'*dxdIndep
    y = Deriv1a{T}(f,vec(J))
  end

  function feval(P::MultiDimApprox,x0::Array{Deriv1a{T},1},c::Array{Deriv1S{TS},1}) where {T,TS}
    basis = Array{Float64}(nCoeff(P))
    dxdIndep = getjac(x0)
    (f,dxdx) = fevalDer(P,getval(x0),getval(c),basis)
    J1 = dxdx'*dxdIndep
    J2 = basis'*getjac(c)
    y = Deriv1a{T}(f,vec(J1+J2))
  end
  function feval(P::MultiDimApprox,x0::Array{Deriv1a{T},1},c::Array{Float64,2},
    basis::Array{Float64,1}) where {T}
    dxdIndep = getjac(x0)
    nC = size(c,2)
    (f,dxdx) = fevalDer(P,getval(x0),c',basis,IntObj{nC}())
    J1 = dxdx*dxdIndep
    y = map(i->Deriv1a{T}(f[i],J1[i,:]),1:nC)
    # J2 = basis'*getjac(c)
    # y = Deriv1a{T}(f,vec(J1+J2))
  end
  function feval(P::MultiDimApprox,x0::Array{Deriv1F{T},1},c::Array{Float64,2},
    basis::Array{Float64,1}) where {T}
    dxdIndep = getjac(x0)
    nC = size(c,2)
    (f,dxdx) = fevalDer(P,getval(x0),c',basis,IntObj{nC}())
    J1 = dxdx*dxdIndep
    y = map(i->Deriv1a{T}(f[i],J1[i,:]),1:nC)
    # J2 = basis'*getjac(c)
    # y = Deriv1a{T}(f,vec(J1+J2))
  end
  function feval(P::MultiDimApprox,x0::Array{Deriv1a{T},1},c::Array{Float64,2}) where T
    basis = Array{Float64}(nCoeff(P))
    dxdIndep = getjac(x0)
    nC = size(c,2)
    (f,dxdx) = fevalDer(P,getval(x0),c',basis,IntObj{nC}())
    J1 = dxdx*dxdIndep
    y = map(i->Deriv1a{T}(f[i],J1[i,:]),1:nC)
    # J2 = basis'*getjac(c)
    # y = Deriv1a{T}(f,vec(J1+J2))
  end
  function feval(P::MultiDimApprox,x0::Array{Deriv1S{T},1},c::Array{Float64,2}) where T
    basis = Array{Float64}(nCoeff(P))
    dxdIndep = getjac(x0)
    nC = size(c,2)
    (f,dxdx) = fevalDer(P,getval(x0),c',basis,IntObj{nC}())
    J1 = dxdx*dxdIndep
    y = map(i->Deriv1S{T}(f[i],sparsevec(J1[i,:])),1:nC)
    # J2 = basis'*getjac(c)
    # y = Deriv1a{T}(f,vec(J1+J2))
  end

  for Der1 in (:Deriv1F,:Deriv1a) # would have to be changed for :Deriv1S
    @eval begin
      function feval!(y::Array{$Der1{T},1},P::MultiDimApprox,x0::Array{$Der1{T},1},c::Array{Float64,2},basis::Array{Float64,1}) where T
        ny = size(c,2)
        global dxdIndep = getjac(x0)
        (f,dxdx) = fevalDer(P,getval(x0),c',basis,IntObj{ny}())
        J = dxdx*dxdIndep
        for i=1:ny
          y[i] = $Der1(Val{T},f[i],RowView(J,i)) # RowView reduces time by a factor of almost 10!! (under noboundscheck)
          #y[i] = $Der1(Val{T},f[i],view(J,i,:))
        end
      end
      function fevalTr!(y::Array{$Der1{T},1},P::MultiDimApprox,x0::Array{$Der1{T},1},cTr::Array{Float64,2},basis::Array{Float64,1}) where T
        ny = size(cTr,1)
        global dxdIndep = getjacTr(x0)
        (f,dxdx) = fevalDer(P,getval(x0),cTr,basis,IntObj{ny}())
        J = dxdIndep*dxdx'
        for i=1:ny
          y[i] = $Der1(Val{T},f[i],ColView(J,i)) # RowView reduces time by a factor of almost 10!! (under noboundscheck)
          # y[i] = $Der1(Val{T},f[i],view(J,:,i))
        end
      end
      function feval(P::MultiDimApprox,x0::Array{$Der1{T},1},c::Array{Float64,2},basis::Array{Float64,1}) where T
        ny = size(c,2)
        y = Array{$Der1{T}}(ny)
        feval!(y,P,x0,c,basis)
        return y;
      end
      function feval(P::MultiDimApprox,x0::Array{$Der1{T},1},c::Array{Float64,2}) where T
        nPar = nCoeff(P);
        basis = Array{Float64}(undef,nPar)
        ny = size(c,2)
        y = Array{$Der1{T}}(undef,ny)
        feval!(y,P,x0,c,basis)
        return y;
      end
    end
  end
  if @isdefined(Deriv2a)
    function feval(P::PolyAppr,x0::Array{Deriv2a{T},1},coeff::Array{Float64,2}) where T
      dimx = P.dim
      @assert(dimx == length(x0))

      TX = typeof(x0[1])
      chebbas = Array{TX}(P.maxdegree+1,dimx)
      chebpol!(chebbas,x0,P.center,P.scal)

      (nc,nY) = size(coeff)
      if(nCoeff(P)!=nc)
        error("wrong size in feval")
      end
      basis = Array{TX,1}(nc)
      basis[1] = 1;
      cTr = coeff'

      Y = Array{TX}(nY)
      for j=1:nY
        Y[j] = cTr[j,1]
      end
      ch = P.indx.Changes
      @inbounds for i=2:nc
        k = ch[1,i]; # which basis element to start from
        iChange = ch[2,i];# which dimension to change
        degChange = ch[3,i];#factor to multiply with
        bbi = basis[k] * chebbas[degChange+1,iChange];
        if sum(P.indx.B[:,i])<P.degree # needed for further base elements
          basis[i] = bbi
        end
        for j=1:nY
          Y[j].v += bbi.v*cTr[j,i];
          Y[j].d += bbi.d*cTr[j,i];
          Y[j].H += bbi.H*cTr[j,i];
          # Y[j] += basis[i]*cTr[j,i];
        end
      end
      global mybasis = basis;
      return Y;
    end
  end
end

function fevalDirect(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2},
  direct::Array{Float64,1})

  nP = nCoeff(P)
  nc = size(coeff,1)
  nY = size(coeff,2)
  basis = Array{Float64}(length(coeff))
  @assert(nP==nc);
  dimx = P.dim
  @assert(dimx == length(x0))
  chebbas = Array{Float64}(P.maxdegree+1,dimx)
  chebpol!(chebbas,x0,P.center,P.scal)
  basis[1] = 1;
  ch = P.indx.Changes
  @assert(nP==nc)
  @inbounds for i=2:nP
    k = ch[1,i]; # which basis element to start from
    iChange = ch[2,i];# which dimension to change
    degChange = ch[3,i];#factor to multiply with
    basis[i] = basis[k] * chebbas[degChange+1,iChange];
  end
  Y = Array{Deriv1F{1}}(nY)
  @assert(length(Y)==nY)
  tmp = Array{Float64}(2)
  for i=1:nY
    @inbounds yepdot(basis,1,coeff,(i-1)*nP+1,nP,tmp,1)
    @inbounds yepdot(basis,1,direct,(i-1)*nP+1,nP,tmp,2)
    Y[i] = Deriv1F{1}(tmp[1],(tmp[2],))
  end
  return Y;
end
if @isdefined SparseMatrixCSC
  function fevalDirect!(P::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2},
                        direct::Array{SparseMatrixCSC{Float64,Int},1},
                        dDirect::Array{Array{Float64,1},1} )

    nP = nCoeff(P)
    nc = size(coeff,1)
    nY = size(coeff,2)
    @assert(length(direct)==nY)

    basis = Array{Float64}(1,nP)
    @assert(nP==nc);
    dimx = P.dim
    @assert(dimx == length(x0))
    chebbas = Array{Float64}(P.maxdegree+1,dimx)
    chebpol!(chebbas,x0,P.center,P.scal)
    basis[1] = 1;
    ch = P.indx.Changes
    @assert(nP==nc)
    @inbounds for i=2:nP
      k = ch[1,i]; # which basis element to start from
      iChange = ch[2,i];# which dimension to change
      degChange = ch[3,i];#factor to multiply with
      basis[i] = basis[k] * chebbas[degChange+1,iChange];
    end


    ii = Array{Array{Int,1}}(nY)
    nDirect = 0;
    for i=1:nY
      n = size(direct[i],1);
      ii[i] = nDirect + (1:n);
      nDirect += n;
    end

    Y = Array{Float64}(nY)
    for i=1:nY
      @inbounds yepdot(basis,1,coeff,(i-1)*nP+1,nP,Y,i)
      dDirect[i] = vec(basis*direct[i])
    end
    return Y;
  end
end
#= 
Y = basis*coeff
d_Y/d_vec(coeff) = kron(meye(nY),basis)
If vec(coeff) = M Lambda  then
d_vec(coeff)/d_vec(Lambda) = M Lambda  then
=#

# Problem 1:
# f(x(Coef1),Coef2) 
# df/dCoef1 = df(x,Coef2)/dx * dx/dCoef1
# Problem 2:
# f(x(Coef1),Coef2(Coef1)) 
# df/dCoef1 = df(x,Coef2)/dx * dx/dCoef1 + basis(x,Coef1)*dCoef2/dCoef1

pos(P::PolyAppr,indx::Array{Int,1}) = mfind(map(i->P.indx.B[:,i]==indx,1:nCoeff(P)))[1]
function linCoeff(P::PolyAppr,coef,iDim)
  d = P.dim
  indx = fill(0,(d,))
  indx[iDim] = 1
  p = pos(P,indx);
  cScaled = coef[p,:]
  return 2*cScaled./(P.b[iDim]-P.a[iDim])
end

function chebnode(n)
  k=pi*range(0.5,stop=n-0.5,length=n);
  x=-cos.(k/n);
end

# gives nodes in [-1,-1]^d space
function nodes01(P::PolyAppr)
  (dim,nC) = size(P.indx.B)
  deg = P.maxdegree
  if deg == 1 || # special case; more points than basis functions
    deg == -2# special case: linear plus quadratic, without cross terms
    grid = zeros(1+2*dim,dim)
    for i=1:dim
      grid[i+1,i] = 0.999; # stay stricly inside; allows rect2ball
      grid[i+1+dim,i] = -0.999;
    end
  elseif deg == 2  # another special case; more points than basis functions
    grid = zeros(1+2*dim+2*dim*(dim-1),dim)
    lauf = 2; # first ones is all zero
    for i=2:nC
      b = P.indx.B[:,i]
      if sum(b)==1
        j = findall(b.>0)[1]
        grid[lauf,j] = 0.999; # stay stricly inside; allows rect2ball
        grid[lauf+1,j] = -0.999;
        lauf += 2;
      else
        @assert(sum(b)==2)
        k = findall(b.>0)
        if length(k)==2 # power 2 already handled before
          j1 = k[1]
          j2 = k[2]
          grid[lauf,j1] = 0.7; 
          grid[lauf,j2] = 0.7; 
          grid[lauf+1,j1] = 0.7; 
          grid[lauf+1,j2] = -0.7; 
          grid[lauf+2,j1] = -0.7; 
          grid[lauf+2,j2] = 0.7; 
          grid[lauf+3,j1] = -0.7; 
          grid[lauf+3,j2] = -0.7; 
          lauf += 4;
        end
      end
    end
  else
    cheb = chebnode(deg+1)
    n2 = div(length(cheb),2)
    chebOrdered = vec(vcat(reverse(cheb[end-n2+1:end])',cheb[1:n2]'))
    points = [0;chebOrdered]

    grid = Array{Float64}(undef,nC,dim)
    for j=1:nC
      # p = 0;
      for i=1:dim
        p = P.indx.B[i,j]
        grid[j,i] = points[p+1]
      end
    end
  end
  return grid;
end
function nodes(P::PolyAppr)
  grid01 = nodes01(P)
  c = ((P.a+P.b)/2)'
  grid = c .+ grid01.*(c-P.a')
  if size(grid,1)<nCoeff(P)
    @warn("fewer nodes than basis function; probably due to extra polynomials inserted")
  end
  return grid; 
end

function neighbors(fspace,Grid,iiNotConv,nNeighbors)
  grid0 = scalDown(fspace,Grid)'

  n = length(iiNotConv)
  Neighbor = fill(0,(nNeighbors,n))
  for i=1:n
    gg = broadcast(-,grid0,grid0[:,iiNotConv[i]])
    dist = vec(sum(gg.^2,1))
    indx = sortperm(dist)
    Neighbor[:,i] = indx[2:nNeighbors+1] # first one dropped, is point itself
  end
  return Neighbor
end

function fevalAll(F::PolyAppr,x0::Array{Float64,1},coeff::Array{Float64,2})
  return feval(F,x0,coeff);
end


# allow additional basis functions, with powers chosen manually
# notice that this does not generate extra nodes, they must be 
function ComplPolyIndx2(d::Int,p::Int,selectFunc=0,AddedPoly=0)
  nC = nCoeff(d,p);

  B = fill(0,(d,nC));

  if(p==-2) # special case: order 1+
    for i=1:d
      B[i,i+1] = 1;
      B[i,d+i+1] = 2;
    end
  else
    z = fill(0,d)
    lauf = 0;
    while(z[1]<=p)
      for i=0:p+1
        z[d] = i;
        if(sum(z)>p)
          succ = 0;
          for m=d-1:-1:2
            if(sum(z[1:m])<p)
              z[m]=z[m]+1;
              z[m+1:d].=0;
              succ = 1;	    
              break;
            end
          end
          if(succ==0)
            z[1] = z[1]+1;
            z[2:d] .= 0;
          end
          break;
        end
        lauf += 1;
        B[:,lauf]= z;
      end
    end
    @assert(lauf==nC);
  end
  if isa(selectFunc,Function)
    doKeep = map(i->selectFunc(B[:,i]),1:size(B,2))
    B = B[:,doKeep]
    nC = size(B,2)
    println(size(B))
  end
  if isa(AddedPoly,AbstractArray{Int})
    B = [B AddedPoly]
    nC += size(AddedPoly,2)
  else
    @assert(AddedPoly==0) # make sure that input AddedPoly has right type
  end
  Changes = fill(0,(3,nC));
  # sort in ascending order of polynomial degree:
  indx = sortperm(vec(sum(B,dims=1)));
  #B = B[:,indx];  

  for j=2:nC
    b0 = B[:,j];
    iChange=argmax(b0);# which dimension to change  # indmin does not work
    degChange = b0[iChange];
    b0[iChange] = 0;
    succ = false;
    for k=1:j-1
      if(B[:,k]==b0)
        Changes[1,j] = k; # which basis element to start from
        Changes[2,j] = iChange;# which dimension to change
        Changes[3,j] = degChange;#factor to multiply with
        succ = true;
        break;
      end
    end
    @assert(succ);
  end
  Changes[1,1] = 0; # which basis element to start from
  Changes[2,1] = 0;# which dimension to change
  Changes[3,1] = 0;#factor to multiply with

  ChangesDer = Array{Int}(undef,4,0)
  for i=1:d
    has_i = findall(B[i,:] .> 0)
    Bi = B[:,has_i]
    n = length(has_i)
    iBasis = Array{Int}(undef,n)
    for j=1:n
      bi = Bi[:,j];
      bi[i] = 0;
      iBas = findall(i->B[:,i] == bi,1:nC) # seems to be inefficient!!
      @assert(length(iBas)==1)
      iBasis[j] = iBas[1]
    end
    CDi = [fill(i,(n)) vec(has_i) vec(iBasis) vec(Bi[i,:])]'
    ChangesDer = [ChangesDer CDi]
  end
  @assert(d<1024)
  # lexicographic criterion: first the number of the coefficient, then dimension of derivative
  indx = ChangesDer[1,:] + 1024*ChangesDer[2,:] 
  ii = sortperm(indx)
  ChangesDer = ChangesDer[:,ii]
  return ComplPolyIndx(B,Changes,ChangesDer);
end

# generate the index matrix B for a polynominal of dimension dim and degree maxdegree;
# then select the elements with degree at least minDegree
# put them into the rows iiBig of a bigger B with dimension dimBig
function addPoly(dim,maxdegree,minDegree=maxdegree,dimBig=dim,iiBig=1:dim)
  B = ComplPolyIndx(dim,maxdegree).B
  ii = findall(vec(sum(B,dims=1)).>=minDegree)
  Bbig = fill(0,dimBig,length(ii))
  Bbig[iiBig,:] = B[:,ii]
  return Bbig;
end

withinBounds(x,a,b) = min.(max.(x,a),b)
withinBounds(x,fspace::PolyAppr) = withinBounds(x,fspace.a,fspace.b)

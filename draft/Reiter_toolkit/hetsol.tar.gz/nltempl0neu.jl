# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import Base.-
_incl(varnames_scalarform.mpp)

_incl(accum.jl)

_incl(dimension.jl)
_incl(transffuncs.jl)
function addp2at!(x::Array{Float64}, offs,a, y,b, z,n)
  @inbounds @simd for i=1:n
    x[offs+i] += a*y[i] + b*z[i];
  end
end
function fptosi(x::Float64) # llvm.pdf, page 147
    Base.llvmcall("""
        %res = fptosi double %0 to i64
        ret i64 %res
        """, Int64, Tuple{Float64,}, x)
end

#####################################################################
## now define problem-specific functions:
#####################################################################
_def _ASSIGN(x,expr) x = expr; 
# _def _SHOCK(i,name) name = _xShock[_iEps,i]
_def _SHOCK(i,name) (name,_probi) = realiz(_xp[i],_ii[i]);_prob*= _probi
function colloc_z(_coef0,_p,_vss::StructVarsStSt{Float64},_grid,_fspace,_xp,
  _ResWeights::Array{Float64,2});
  _lenC = length(_coef0);
  _nCoef::Int = nCoeff(_fspace);
  _nA = div(_lenC,_nCoef);
  assert(_lenC == _nA*_nCoef);
  _coef = reshape(_coef0,_nCoef,nApprox)
  _resid = Array{Float64}(1,nApprox)
  _resAll = Array{Float64}(size(_grid,1),nApprox);

  _gridNext = Array{Float64}(size(_grid,2)); ## allocate gridNext
  _exp = fill(0.0,nEXPECT)
  for _iG = 1:size(_grid,1)
    _gridCurr = vec(_grid[_iG,:]); # the grid is in transformed variables
    _approxCurr = feval(_fspace,_gridCurr,_coef);
    invtransfState!(_gridCurr,_p)  # transform back to original variabales
    # extract state variables:
    _varcur
    _def _STATE(i,name) name = _gridCurr[i]
    _incl(states.jl)

    _def _APPROX(i,name) name = _approxCurr[i]
    _incl(approx.jl)
    _incl(getvars0.jl)
    _def _EXPECT(nr,expr) _exp[nr] = 0.0
    _incl(expects0.jl)
    _incl(settrans0.jl)
    for _iEps=1:nRealiz 
      _prob = 1.0;
      _ii = ind2sub(nnRealiz,_iEps)
      _incl(settrans1.jl)
      _varfor
      _def _STATE(i,name) _gridNext[i] = name
      _incl(states.jl)
      transfState!(_gridNext,_p)  # transform back to original variabales
      # inBounds!(_gridNext,_fspace)
      _approxNext = feval(_fspace,_gridNext,_coef);
      _def _APPROX(i,name) name = _approxNext[i]
      _incl(approx.jl)
      _varcur
      _incl(getvars1.jl)
      _def _EXPECT(nr,expr) _exp[nr]  += _prob*(expr);
      _incl(expects0.jl)
    end
    _def _RESID(i,expr) _resid[i] = expr
    _incl(residequz.jl)
    if(!all(isfinite.(_resid)))
      println(_iG)
      println(_resid)
      error("not finite")
    end
    _resAll[_iG,:] = _resid;
  end 
  if(!isempty(_ResWeights))
    _resAll = _ResWeights*_resAll;
  end;
  return vec(_resAll);
end;
function eulerresid(_func,_gridCurr0,_p,_xShock,_pShock)
  _resid = Array{Float64}(nApprox)
  _gridCurr = copy(_gridCurr0)

  _gridNext = similar(_gridCurr)
  _approxCurr = _func(_gridCurr)
  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  for _iEps=1:nRealiz 
    _incl(settrans1.jl)
    _varfor
    _def _STATE(i,name) _gridNext[i] = name
    _incl(states.jl)
    transfState!(_gridNext,_p)  # transform back to original variabales
  _approxNext = _func(_gridNext)
    _def _APPROX(i,name) name = _approxNext[i]
    _incl(approx.jl)
    _varcur
    _incl(getvars1.jl)
    _def _EXPECT(nr,expr) _exp[nr]  += _pShock[_iEps]*(expr);
    _incl(expects0.jl)
  end
  _def _RESID(i,expr) _resid[i] = expr
  _incl(residequz.jl)
  return _resid;
end;

_solveCalled = 0;
function solve1_z{_T}(_approxCurr::Array{_T,1},_coef,_p::StructPars,_vss,
                      _gridCurr0,_fspace,
                      _xp::NTuple{nShocks,Main.SingleShock})

  # global _solveCalled += 1;
  _resid = 0.0*_approxCurr;
  _nCoef = Main.nCoeff(_fspace);

  _gridCurr = copy(_gridCurr0)
  _gridNext = Array{_T}(length(_gridCurr));
  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _def _STATEMARKOV(i,j,name) name = _xp[j].X[fptosi(_gridCurr[i])]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _exp = fillzero(_T,nEXPECT)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  local _approxNextAll
  _approxNext = Array{_T}(nApprox)
  for _iEps=1:nRealiz 
    _prob = 1.0;
    _ii = ind2sub(nnRealiz,_iEps)
    _incl(settrans1.jl)
    _varfor
    _def _STATE(i,name) _gridNext[i] = name
    _def _STATEMARKOV(i,j,name) _gridNext[i] = _ii[j]
    _incl(states.jl)
    transfState!(_gridNext,_p)  # transform back to original variabales
    # inBounds!(_gridNext,_fspace)
    if isa(_fspace,GridOfApprox)
      if _iEps==1
        _approxNextAll = Main.fevalAll(_fspace,_gridNext,_coef);
      end
      _approxNext .= _approxNextAll[_iEps,:]
    else
      _approxNext = feval(_fspace,_gridNext,_coef);
    end
    _def _APPROX(i,name) name = _approxNext[i]
    _incl(approx.jl)
    _varcur
    _incl(getvars1.jl)
    _def _EXPECT(nr,expr) _exp[nr]  += _prob*(expr);
    _incl(expects0.jl)
  end
  _def _RESID(i,expr) _resid[i] = expr
  _incl(residequz.jl)
  return vec(_resid);
end;
function solve1d_z{_T}(_approxCurr::Array{_T,1},_coef,_p::StructPars,_vss,
                       _gridCurr0,_fspace,
                       _xp::NTuple{nShocks,Main.SingleShock})

  # global _solveCalled += 1;
  _resid = 0.0*_approxCurr;
  _nCoef = Main.nCoeff(_fspace);

  _gridCurr = copy(_gridCurr0)
  _gridNext = Array{_T}(length(_gridCurr));
  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _def _STATEMARKOV(i,j,name) name = _xp[j].X[fptosi(_gridCurr[i])]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _exp = fillzero(_T,nEXPECT)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  local _approxNextAll
  _approxNext = Array{_T}(nApprox)
  for _iEps=1:nRealiz 
    _prob = 1.0;
    _ii = ind2sub(nnRealiz,_iEps)
    _incl(settrans1.jl)
    _varfor
    _def _STATE(i,name) _gridNext[i] = name
    _def _STATEMARKOV(i,j,name) _gridNext[i] = _ii[j]
    _incl(states.jl)
    transfState!(_gridNext,_p)  # transform back to original variabales
    # inBounds!(_gridNext,_fspace)
    if isa(_fspace,GridOfApprox)
      if _iEps==1
        _approxNextAll = Main.fevalAll(_fspace,_gridNext,_coef);
      end
      _approxNext .= _approxNextAll[_iEps,:]
    else
      _approxNext = feval(_fspace,_gridNext,_coef);
    end
    _approxNext .= _approxNextAll[_iEps,:]
    _def _APPROX(i,name) name = _approxNext[i]
    _incl(approx.jl)
    _varcur
    _incl(getvars1.jl)
    _def _EXPECT(nr,expr) _exp[nr]  += _prob*(expr);
    _incl(expects0.jl)
  end
  _def _RESID(i,expr) _resid[i] = expr
  _incl(residequz.jl)
  return vec(_resid);
end;
function bounds1{_T}(_approxCurr::Array{_T,1},_coef,_p::StructPars,_vss,
                     _gridCurr0,_fspace,
                      _xp::NTuple{nShocks,Main.SingleShock})
  # global _solveCalled += 1;
  _nCoef = Main.nCoeff(_fspace);
  _gridCurr = copy(_gridCurr0)
  _gridNext = Array{_T}(length(_gridCurr));
  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _def _STATEMARKOV(i,j,name) name = _xp[j].X[fptosi(_gridCurr[i])]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _exp = fillzero(_T,nEXPECT)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  _iEps=1 # endogenous part of gridNext independent of shock realization
  _prob = 1.0;
  _ii = ind2sub(nnRealiz,_iEps)
  _incl(settrans1.jl)
  _varfor
  _def _STATE(i,name) _gridNext[i] = name
  _def _STATEMARKOV(i,j,name) _gridNext[i] = _ii[j]
  _incl(states.jl)
  transfState!(_gridNext,_p)  # transform back to original variabales
  return _gridNext
end;
function solve1a_z{_T}(_approxCurr::Array{_T,1},_coef,_p::StructPars,_vss,
                       _gridCurr0,_fspace,
                       _xp::NTuple{nShocks,Main.SingleShock})

  _resid = 0.0*_approxCurr;
  _nCoef = Main.nCoeff(_fspace);

  _gridCurr = copy(_gridCurr0)
  _gridNext = Array{_T}(length(_gridCurr));
  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _def _STATEMARKOV(i,j,name) name = _xp[j].X[fptosi(_gridCurr[i])]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _exp = fillzero(_T,nEXPECT)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  for _iEps=1:nRealiz 
    _prob = 1.0;
    _ii = ind2sub(nnRealiz,_iEps)
    _incl(settrans1.jl)
    _varfor
    _def _STATE(i,name) _gridNext[i] = name
    _def _STATEMARKOV(i,j,name) _gridNext[i] = _ii[j]
    _incl(states.jl)
    transfState!(_gridNext,_p)  # transform back to original variabales
    # inBounds!(_gridNext,_fspace)
    _approxNext = feval(_fspace,_gridNext,_coef);
    _def _APPROX(i,name) name = _approxNext[i]
    _incl(approx.jl)
    _varcur
    _incl(getvars1.jl)
    _def _EXPECT(nr,expr) _exp[nr]  += _prob*(expr);
    _incl(expects0.jl)
  end
  _def _RESID(i,expr) _resid[i] = expr
  _incl(residequz.jl)
  return vec(_resid);
end;

function solveDeterm_z{_T,_T2}(_x::Array{_T,1},_xnext::Array{_T2,1},_p::StructPars,_nShocks)
  # only one realization:
  _xShock = zeros(1,_nShocks)
  _pShock = ones(1)
  _nSt = length(iState)
  _gridCurr = _x[1:_nSt]
  _approxCurr = _x[_nSt+1:end]
  _resid = 0.0*_approxCurr;

  _gridNextTarget = _xnext[1:_nSt]
  _approxNext = _xnext[_nSt+1:end]
  _gridNext = 0.0*_gridCurr;

  invtransfState!(_gridCurr,_p)  # transform back to original variabales
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridCurr[i]
  _def _STATEMARKOV(i,j,name) name = _xp[j].X[fptosi(_gridCurr[i])]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)
  _def _EXPECT(nr,expr) _exp[nr] = 0.0
  _incl(expects0.jl)
  _incl(settrans0.jl)
  _iEps=1 # only one realization, namely 0
    _incl(settrans1.jl)
    _varfor
    _def _STATE(i,name) _gridNext[i] = name
    _def _STATEMARKOV(i,j,name) _gridNext[i] = _ii[j]
    _incl(states.jl)
    transfState!(_gridNext,_p)  # transform back to original variabales
    # _approxNext = feval(_fspace,_gridNext,_coef);
    _def _APPROX(i,name) name = _approxNext[i]
    _incl(approx.jl)
    _varcur
    _incl(getvars1.jl)
    _def _EXPECT(nr,expr) _exp[nr]  += _pShock[_iEps]*(expr);
    _incl(expects0.jl)

  _def _RESID(i,expr) _resid[i] = expr
  _incl(residequz.jl)
  return [vec(_gridNextTarget-_gridNext);vec(_resid)]
end;


_def _SHOCK(i,name) name = _xShock[i]
function colloc_fshort(_approxCurr,_gridCurr,_p,_xShock)
  _nSt = length(_gridCurr)
  _gridNext = Array{typeof(_approxCurr[1]+_gridCurr[1])}(_nSt); 
  _gridOrig = invtransfState(_gridCurr,_p) # transform back to original variables
  # extract state variables:
  _varcur
  _def _STATE(i,name) name = _gridOrig[i]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)

  _incl(settrans0.jl)
  _incl(settrans1.jl)
  _varfor
  _def _STATE(i,name) _gridNext[i] = name
  _incl(states.jl)
  transfState!(_gridNext,_p)  # transform 
  @assert(all(isfinite.(_gridNext)),println("error at ",_gridCurr));
  return _gridNext;
end;

_def _SHOCK(i,name) name = xRealiz(_xp[i],_iiEps[i])
function colloc_f(_approxCurr,_p,_vss,_gridCurr,_xp::NTuple{nShocks,Main.SingleShock},_randUnif::Array{Float64,1})

  _gridNext = similar(_gridCurr)
  _gridOrig = invtransfState(_gridCurr,_p) # transform back to original variables
  _varcur
  (_iEps,_iiEps) = iRealiz(_xp,_randUnif)
  _def _STATE(i,name) name = _gridOrig[i]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)

  _incl(settrans0.jl)
  _incl(settrans1.jl)
  _varfor
  _def _STATE(i,name) _gridNext[i] = name
  _incl(states.jl)
  transfState!(_gridNext,_p)  # transform 
  @assert(all(isfinite.(_gridNext)),println(_gridCurr));
  return _gridNext;
end;

macro Deriv1Approx()
  return esc(:(Deriv1F{2*nApprox}))
end
_def _SHOCK(i,name) (name,_probi) = realiz(_xp[i],_ii[i]);_prob*= _probi
function colloc_d2{_nC}(_j::Main.IntObj{_nC},
  _coef::Array{Float64,2}, _p,_vss,_grid,_fspace,_xp::NTuple{nShocks,Main.SingleShock},_ResWeights)
  _resid = Array{Deriv1a{_nC}}(1,nApprox)
  _resAll = Array{Deriv1a{_nC}}(size(_grid,1),nApprox);
  _nCoef = Main.nCoeff(_fspace);
  fsBasis = Array{Float64}(_nCoef)
  global basis0 = Array{Float64}(_nCoef) # must be global, used for ExpAccum

  _gridNext = Array{@Deriv1Approx,1}(size(_grid,2)); ## allocate gridNext
  ## GET ALL VARIABLES 
  ##try 
  for _iG = 1:size(_grid,1)
    _gridCurr = vec(_grid[_iG,:]); # the grid is in transformed variables
    _approxCurr = feval(_fspace,_gridCurr,_coef,fsBasis);
     basis0 .= fsBasis

    invtransfState!(_gridCurr,_p)  # transform back to original variabales
    # extract state variables:
    _varcur
    _def _STATE(i,name) name = _gridCurr[i]
    _incl(states.jl)

    _def _APPROX(i,name) name = indep(@Deriv1Approx,_approxCurr[i],i)
    _incl(approx.jl)
    _incl(getvars0.jl)
    _incl(settrans0.jl)
    _exp = fillzero(ExpAccum{_nC},nEXPECT)
    for _iEps=1:nRealiz 
      _prob = 1.0;
      _ii = ind2sub(nnRealiz,_iEps)
      _incl(settrans1.jl)
      _varfor
      _def _STATE(i,name) _gridNext[i] = name
      _incl(states.jl)
      transfState!(_gridNext,_p)  # transform back to original variabales
      # inBounds!(_gridNext,_fspace)

      _approxNext2 = feval(_fspace,_gridNext,_coef,fsBasis);

      _def _APPROX(i,name) name = indep(@Deriv1Approx,getval(_approxNext2[i]),nApprox+i)
      _incl(approx.jl)
      _varcur
      _incl(getvars1.jl)
      _def _EXPECT(nr,expr) concatDeriv!(_exp[nr].e,_prob*(expr),basis0,_nCoef,_approxNext2,fsBasis)
      _incl(expects0.jl)
    end
    _def _ASSIGN_STAT(x,expr) x = mulWithBasis(expr,basis0,nApprox,_nCoef);
    _def _ASSIGN_EXP(x,expr) x = (expr).e; 
    _incl(residequd.jl)
    if(!all(isfinite.(_resid)))
      println(_iG)
      println(_resid)
      error("not finite")
    end
    _resAll[_iG,:] = _resid;
  end 
  ## catch
  ##   return 1e100 + 0.0*_coef[1];  ## same type as _coef
  ## end
  ## return weighted residuals:
  _v = vec(getval(_resAll))
  if(isempty(_ResWeights))
    return (_v,getjac(_resAll[:]));
  else
    (nr,nk) = size(_ResWeights)  ## nr < nk
    JJ = getjac(_resAll);
    _lenC = length(_coef)
    Jac = _ResWeights * reshape(JJ,(nk,_lenC*nApprox))
    Jac = reshape(Jac,(_lenC,_lenC))
    return (_v,Jac)
  end;
  _r = vec(_resAll);
  return (getval(_r),getjac(_r))
end;
function colloc_d(par0::Array{Float64,1},_p,_vss,_grid,_fspace,_xp,_ResWeights)
  _nCoef = Main.nCoeff(_fspace);
  nA = div(length(par0),_nCoef);
  assert(nApprox == nA)
  par = reshape(par0,(_nCoef,nA))
  return colloc_d2(Main.IntObj{nA*_nCoef}(),par,_p,_vss,_grid,_fspace,_xp,_ResWeights)
end

_def _SHOCK(i,name) name = xRealiz(_xp[i],_iiEps[i])
_incl(varnames_structform.mpp)
function colloc_f!(_c,_l,_f,_approxCurr,_p,_vss,_gridCurr,_xp::NTuple{nShocks,Main.SingleShock},_randUnif::Array{Float64,1})
  _gridNext = similar(_gridCurr)
  _gridOrig = invtransfState(_gridCurr,_p) # transform back to original variables
  _varcur
  (_iEps,_iiEps) = iRealiz(_xp,_randUnif)
  _def _STATE(i,name) name = _gridOrig[i]
  _incl(states.jl)

  _def _APPROX(i,name) name = _approxCurr[i]
  _incl(approx.jl)
  _incl(getvars0.jl)

  _incl(settrans0.jl)
  _incl(settrans1.jl)
  _varfor
  _def _STATE(i,name) _gridNext[i] = name
  _incl(states.jl)
  transfState!(_gridNext,_p)  # transform 

  @assert(all(isfinite.(_gridNext)),println(_gridCurr));
  return _gridNext;
end;

# skal() =  Expr(:call,:_skal)
_def _ASSIGN(x,expr) x = handleAssign(expr)
_incl(varnames_scalarform.mpp)
_def _SHOCK(i,name) name = _eps()*_shock(i)
function funcpert(_p)
  Main.importFieldsAsSymbols(_p)
  global _coefs = Main._coefs

  _resid = Array{Any}(nApprox)
   _states = Array{Any}(nStates);
   _gridNext = Array{Any}(nStates);

    # extract state variables:
    _varcur
    _def _STATE(i,name) _states[i] = _conc(:_x,i)
    _incl(states.jl)
     _def _APPROX(i,name) name = Expr(:call,:_a,degApprox(i),i)
    _incl(approx.jl)

    invtransfState!(_states,_p)  # transform back to original variabales
    _def _STATE(i,name) name = _states[i]
    _incl(states.jl)

    _incl(getvars0.jl)
    _incl(settrans0.jl)

      _incl(settrans1.jl)
      _varfor
      # _def _STATE(i,name) _gridNext[i] = name
      _def _STATE(i,name) _gridNext[i] = name
      _incl(states.jl)

      transfState!(_gridNext,_p)  # transform back to original variabales
      _def _APPROX(i,name) name = Expr(:call,:_A,degApprox(i),i);
      _incl(approx.jl)
      _varcur
      _incl(getvars1.jl)
      _def _EXPECT(nr,expr) _exp[nr]  = _EXP(expr);
      _incl(expects0.jl)

    _def _RESID(i,expr) _resid[i] = expr
    _incl(residequz.jl)

  return (_resid,_gridNext)
end;

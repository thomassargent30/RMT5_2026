# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

mutable struct GridGeneration
  useFixed::Bool
  useNodes::Bool
  useSimul::Bool
  width::Float64
  simulMoments::Bool
  solve4Simul::Bool
  nRandom::Float64
  path::Array{Float64,2}
  grid0::Array{Float64,2}
  grid::Array{Float64,2}
  function GridGeneration()
    useFixed = false
    #  use fixed grid
    useNodes = true
    #  generate grid from nodes(fspace)
    useSimul = false
    # width of grid in terms of standard deviations:
    width = 4.0
    #  use simulated grid
    simulMoments = true
    #  use simulation to get scaling of grid
    solve4Simul = false
    #  solve for equilibrium variables in simulating grid
    nRandom = 3.0
    #  generate random grid with nRandom*nCoeff points
    path = Array{Float64}(undef,0,0)
    #  simulated grid
    grid0 = Array{Float64}(undef,0,0)
    #  grid that is used if useFixed
    grid = Array{Float64}(undef,0,0)
    #  grid that is used if useFixed
    return new(useFixed,useNodes,useSimul,width,simulMoments,solve4Simul,nRandom,path,grid0,grid)
  end
end
function Base.show(io::IO, x::GridGeneration)
printStruct(x)
end
function GridGeneration(s::Symbol,x,args...)
S = GridGeneration()
setfield!(S,s,x)
n = div(length(args),2)
for i=1:n
offs = (i-1)*2
setfield!(S,args[offs+1],args[offs+2])
end
return S;
end
mutable struct Options
  checkUnique::Int64
  nGolden::Int64
  nGridSearch::Array{Int64,1}
  linIter::Int64
  tolLinear::Float64
  stopAfterIter::Int64
  doAggregate::Bool
  lenSimul::Int64
  lenSkipSimul::Int64
  printSimul::Int64
  doTimeIter::Int64
  maxTimeIter::Int64
  ftolTimeIter::Float64
  grid::GridGeneration
  function Options()
    checkUnique = 100
    #  check thoroughly (using rank conditions rather than just counting criterion)
# for existence and uniqueness of stable linear solution (default: false):
# if 0: never check thorougly
# if 1: always check thorougly
# if n>1: check thouroughly only if number of variables is smaller than n
    nGolden = 30
    #  number of steps in golden search method (function MaxThorough)
    nGridSearch = [60, 20]
    #  number of steps for global grid search (cf. function MaxThorough)
    linIter = 2000
    #  whether linear solution is obtained from QZ decomposition or by backward iteration
# if -1: decides based on number of variables
# if 0: never do interation
# if 1: always do interation
# if n>1: do iteration if number of variables is larger than n
    tolLinear = 1.0e-6
    #  tolerance level for the iterative solution of the linear approximation
# (only relevant if iterative solver is used)
    stopAfterIter = 1000000000
    #  stop iterative method after stopAfterIter iterations; 
    doAggregate = false
    #  whether to use simple aggregation before solving linearly
    lenSimul = 0
    #  length of simulation; 
    lenSkipSimul = 0
    # number of periods to skip; 
    printSimul = 1
    # print simulation output
    doTimeIter = 0
    #  do time iterations (0 = none; 1 = standard; 2 = accelerated)
    maxTimeIter = 2000
    #  maximum number of iterations in time iteration
    ftolTimeIter = 1.0e-6
    #  convergence tolerance in time iteration
    grid = GridGeneration()
    #  grid description
    return new( checkUnique,
               nGolden,
               nGridSearch,
               linIter,
               tolLinear,
               stopAfterIter,
               doAggregate,
               lenSimul,
               lenSkipSimul,
               printSimul,
               doTimeIter,
               maxTimeIter,
               ftolTimeIter,
               grid)

  end
end
function Base.show(io::IO, x::Options)
  printStruct(x)
end
function Options(s::Symbol,x,args...)
  S = Options()
  setfield!(S,s,x)
  n = div(length(args),2)
  for i=1:n
    offs = (i-1)*2
    setfield!(S,args[offs+1],args[offs+2])
  end
  return S;
end
if !@isdefined(_opt)
  const _opt = Options();
end
macro optset(field,val)
    return esc( :(global _opt; _opt.$field = $val)  )
end

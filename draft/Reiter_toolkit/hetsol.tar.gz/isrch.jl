# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

import SIMD;
using StaticArrays

function _util!(_V,_util,_offsK,_n,_p,_A,_pt,cStateBeg,iDState,iStateExog,xEndVec,iChoiceD,t)
  n4 = 0; # div(_n,4)
  for i=1:n4
    _offs = 4*(i-1)+1
    Kend = SIMD.vload(SIMD.Vec{4,Float64},xEndVec,_offs+_offsK)
    _u = _util(_p,_A,_pt,cStateBeg,iDState,iStateExog,Kend,iChoiceD,t)[1]
    SIMD.vstore(_u,_V,_offs);
  end
  for i=4*n4+1:_n
    Kend = xEndVec[i+_offsK];
    _u = _util(_p,_A,_pt,cStateBeg,iDState,iStateExog,Kend,iChoiceD,t)[1]
    _V[i] = _u;
  end
end

@noinline function myAssert(cond::Bool,txt...)
  if !cond
    for i=1:length(txt)
      println(txt[i])
    end
    error("assertion failed")
  end
end
@noinline function myWarn(cond::Bool,txt...)
  if !cond
    for i=1:length(txt)
      print(txt[i],"; ")
    end
    @warn("condition failed")
  end
end
@noinline function myAvoid(cond::Bool,txt...)
  if cond
    for i=1:length(txt)
      println(txt[i])
    end
    error("avoided condition true")
  end
end
function maxRange(x,jLo,jHi);
  xMax = x[jLo]
  jMax = jLo;
  for j=jLo+1:jHi
    if x[j]>xMax
      xMax = x[j]
      jMax = j
    end
  end
  return (xMax,jMax) 
end
function addmem!(a,n,b,offs)
  for i=1:n
    @inbounds a[i] += b[offs+i];
  end
end
function mymax(a)
  n = length(a)
  @inbounds m = a[1];
  @inbounds for i=2:n
    if a[i]>m
      m = a[i];
    end
  end
  return m
end
macro NLocalMax(); return 8; end
function addLocalMax(n,iiLocalMax,vLocalMax,j,v)
  if n<@NLocalMax
    n += 1
    iiLocalMax[n] = j;
    vLocalMax[n] = v;
  else
    k = argmin(vLocalMax)
    if v>vLocalMax[k]
      vLocalMax[k] = v;
      iiLocalMax[k] = j;
      return n;
    end
  end
  return n
end

# return location of local maximum, the @NLocalMax best ones:
function integerSearch2(f!,nTry::Int,iLo,iHi,iLow,iUpp,tol::Float64,
                        Vend::Array{Float64,2},icolV) :: Tuple{Int,MVector{@NLocalMax,Int}}
  iiLocalMax = MVector{@NLocalMax,Int}(undef)
  if iLo==iHi
    iiLocalMax[1] = iLo
    return (1,iiLocalMax)
  end
  vLocalMax = MVector{@NLocalMax,Float64}(undef)
  myAssert(iHi>=iLo)
  if iHi==iLo
      iiLocalMax[1] = iHi;
    return (1,iiLocalMax);
  end
  #iLo = max(iLo,iLow)
  #iHi = min(iHi,iUpp)
  offs = iLo-1
  nI = iHi-offs;
  @assert(nI==nTry)
  vTry = fill(0.,(nTry))
  f!(vTry,offs,nI);
  addmem!(vTry,nI,Vend,offs + (icolV-1)*size(Vend,1))
  vMax = maximum(vTry);

  # vTolerance = maximum(abs.(diff(vTry[1:nI])));


  nLocalMax = 0;
  if vTry[1]>=vTry[2] && vTry[1]>vMax-tol
    i = offs+1;
    if i>iLow
      return (-1,iiLocalMax) # maximum at lower bound
    end
    nLocalMax = addLocalMax(nLocalMax,iiLocalMax,vLocalMax,i,vTry[1])
    # nLocalMax += 1; iiLocalMax[nLocalMax] = i;
  end
  for j=2:nI-1
    # if vTry[j]>vMax-vTolerance
    if vTry[j]>=vTry[j-1] && vTry[j]>=vTry[j+1] && vTry[j]>vMax-tol
      nLocalMax = addLocalMax(nLocalMax,iiLocalMax,vLocalMax,offs+j,vTry[j])
      # nLocalMax += 1; iiLocalMax[nLocalMax] = offs+j;
    end
  end
  if nI<=0
    println([nTry,iLo,iHi,iLow,iUpp])
  end
  if vTry[nI]>=vTry[nI-1] && vTry[nI]>vMax-tol
    i = iHi
    if iHi<iUpp
      return (-2,iiLocalMax) # maximum at upper bound
    end
    nLocalMax = addLocalMax(nLocalMax,iiLocalMax,vLocalMax,i,vTry[nI])
    # nLocalMax += 1; iiLocalMax[nLocalMax] = i;
  end
  if nLocalMax ==0
    println(vTry[1:nI])
    println((iLo,iHi))
    println((iLow,iUpp))
    println(offs)
    println(tol)
    println(vMax)
    error("not found")
  end
  return (nLocalMax,iiLocalMax)
end
#if !@isdefined(_pp8)
#  global const _pp8 = zeros(8);
#end
function  maxIn01(f,ii,iRobustOptim,pStart,p0::Float64=0.0,p1::Float64=1.0)::Tuple{Float64,Float64}

  fii(p) = f(p,ii);
  fiiminus(p) = -f(p,ii);
  if iRobustOptim<=0 # Brent's method
    tolx = 1e-4*(p1-p0);
    (pmin, fmin,flag) = brent2(fiiminus,p0,p1,tolx)
    if true || pmin<p0+2*tolx # check for boundaries
      f0 = fiiminus(p0)
      if f0<=fmin
        return (p0,-f0)
      end
    elseif true || pmin>p1-2*tolx
      f1 = fiiminus(p1)
      if f1<=fmin
        return (p1,-f1)
      end
    end
    @assert(flag==0)
    return (pmin,-fmin);
  elseif iRobustOptim==1
    n = 8  # try 8 and then 8 again
    pp = linspace(p0,p1,n)
    ff = map(fii,pp)
    iBest = argmax(ff)
    if iBest==1
      pp2 = linspace(pp[1],pp[2],n)
    elseif iBest==n
      pp2 = linspace(pp[n-1],pp[n],n)
    else
      pp2 = linspace(pp[iBest-1],pp[iBest+1],n)
    end
    ff = map(fii,pp2)
    iBest = argmax(ff)
    return (pp2[iBest],ff[iBest])
  elseif iRobustOptim==2 # brute force: try 64 equispaced options
    pp = linspace(p0,p1,64) # 64 is hardwird here, make it a parameter
    ff = fii.(pp)
    iBest = argmax(ff)
    return (pp[iBest],ff[iBest])
  elseif iRobustOptim==3 # same, but vectorized, may allow other optimizations
    pp = linspace(p0,p1,64) # 64 is hardwird here, make it a parameter
    ff = fii(pp)
    iBest = argmax(ff)
    return (pp[iBest],ff[iBest])
  else
    error("wrong robustOptim: $robustOptim")
  end
end




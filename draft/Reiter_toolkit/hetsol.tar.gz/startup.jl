using Distributed
# change the following line to the directory where you have installed HetSol:
@everywhere const hetsolDir = "c:/Users/Michael/Documents/hetsol";
@everywhere include("$hetsolDir/inithetsol.jl");


# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

function normalizedGrid(dimX::Int,nCoef::Int,nGrid::Int)
  grid_a = 0.5*(1 - 2*rand(div(nGrid,2),dimX));
  grid_b = 1 - 2*rand(nGrid-1-div(nGrid,2),dimX);
  Grid0 = [zeros(1,dimX); grid_a ; grid_b];
  return Grid0;
end
function normalizedGrid(dimX::Int,nCoef::Int,nFactor::Float64=3.0)
  nGrid = convert(Int,ceil(nFactor * nCoef));
  return normalizedGrid(dimX,nCoef,nGrid)
end
function normalizedGrid(fspace::MultiDimApprox,nFactor::Int)
  return normalizedGrid(dimen(fspace),nCoeff(fspace),nFactor);
end
function normalizedGrid(fspace::MultiDimApprox,nFactor::Float64=3.0)
  return normalizedGrid(dimen(fspace),nCoeff(fspace),nFactor);
end
function randomGrid(fspace::MultiDimApprox,nFactor::Float64=3.0)
  g0 = normalizedGrid(fspace,nFactor);
  return scalUp(fspace,g0);
end
function residnl(NL,Grid,fspace,coef,xp)
  model = NL.linModel;
  res = colloc_z(coef,model.pars,model.vstst,Grid,fspace,xp,zeros(0,0));
  return reshape(res,(size(Grid,1),NL.nApprox));
end
function gridVaryState(fspace,iState,nPoints)
  x = fspace.center
  X = repmat(x',nPoints,1)
  X[:,iState] = linspace(fspace.a[iState], fspace.b[iState],nPoints);
  return X;
end
function tensprod(x::Array,y,op::Function=hcat)
  if op==hcat
    return op( kron(ones(size(y,1),1),x),kron(y,ones(size(x,1),1)));
  else
    return broadcast(op, kron(ones(size(y,1),1),x),kron(y,ones(size(x,1),1)));
  end
end
function tensprod3(x,y,z,op::Function=hcat)
  return tensprod(tensprod(x,y,op),z,op)
end
function tensprod(op::Function,x,y,z...)
  xy = tensprod(x,y,op)
  for i=1:length(z)
    xy = tensprod(xy,z[i],op)
  end
  return xy;
end
function write_transferFunc(fname::String,txtTransf,txtInvTransf)
  F = open(fname,"w")
  write_transferFunc(F,txtTransf,txtInvTransf)
  close(F)
end

function write_transferFunc(FF,txtTransf,txtInvTransf)
  println(FF,"function transfState!{_T}(x::Array{_T,1},_pars=0)")
  println(FF,txtTransf)
  print(FF,"end
function invtransfState!{_T}(x::Array{_T,1},_pars=0)\n");
  println(FF,txtInvTransf)
  print(FF,"end

# rest is all build on the above two functions:
function transfState{_T}(x::Array{_T,1},_pars=0)
  y = copy(x)
  transfState!(y,_pars)
  return y;
end
function invtransfState{_T}(x::Array{_T,1},_pars=0)
  y = copy(x)
  invtransfState!(y,_pars)
  return y;
end
function transfState{_T}(X::Array{_T,2},_pars=0)
  Y = similar(X)
  for i=1:size(X,1)
    y = X[i,:]
    transfState!(y,_pars)
    Y[i,:] = y
  end
  return Y;
end
function invtransfState{_T}(X::Array{_T,2},_pars=0)
  Y = similar(X)
  for i=1:size(X,1)
    y = X[i,:]
    invtransfState!(y,_pars)
    Y[i,:] = y
  end
  return Y;
end\n");
end

function imag2Real(evec)
  n = size(evec,2)
  X = zeros(n,n)
  i = 1;
  while i<=n
    v = evec[:,i];
    X[:,i] = real(v);
    if all(imag(v).==0)
      i += 1;
    else
      X[:,i+1] = imag(v);
      i += 2;
    end
  end
  return X;
end

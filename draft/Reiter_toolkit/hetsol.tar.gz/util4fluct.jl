# HetSol: This file is part of the
# HetSol Toolkit to solve Heterogenous Agent Models in Julia
#
# Copyright (C) 2018  Michael Reiter (IHS, Vienna and NYU Abu Dhabi)
#
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## function initDeriv!(V,S)
##   _nVAR = lenStruct(_v)
##   _nSHOCK = lenStruct(_s)
##   _nFL = 3*_nVAR+_nSHOCK;  # number of independent variables
##   _nIndepSparse[1] = _nFL+2; # set size of sparse derivative structure
##   _iVAR = 0;
##   for a in fieldnames(typeof(V))
##     _x = getfield(V,a);
##     if(isa(_x,Variable))
##       _iVAR +=1;
##       _x.der = 
##       [indep(Deriv4hs,_x.sv,_iVAR);
##       indep(Deriv4hs,_x.sv,_nVAR+_iVAR);
##       indep(Deriv4hs,_x.sv,2*_nVAR+_iVAR)];
##     elseif(isa(_x,ArrayVar))
##       _x.der = reshape([indep(Deriv4hs,_x.sv,_iVAR);
##       indep(Deriv4hs,_x.sv,_nVAR+_iVAR);
##       indep(Deriv4hs,_x.sv,2*_nVAR+_iVAR)],size(_x.sv,1),size(_x.sv,2),size(_x.sv,3),3);
##       _x.posName = _iVAR+1;
##       nv = length(_x.sv);
##       _iVAR +=nv;
##     else
##       error("wrong element in variable structure")
##     end
##   end
##   # mnow handle shocks:
##   _iSHOCK = 0;
##   for a in fieldnames(typeof(S))
##     _x = getfield(S,a);
##     if(isa(_x,VarShock))
##       _iSHOCK +=1;
##       _x.der = indep(Deriv4hs,_x.sv,3*_nVAR+_iSHOCK;)
##     elseif(isa(_x,Array{VarShock}))
##       _x.der = reshape(indep(Deriv4hs,_x.sv,3*_nVAR+_iSHOCK),
##       size(_x.sv,1),size(_x.sv,2));
##       _x.iName = _iSHOCK+1;
##       nv = length(_x.sv);
##       _iSHOCK +=nv;
##     else
##       error("wrong element in variable structure")
##     end
##   end
## end




function representSims(G,L,Phi,Psi,Pi)
  n = size(G,1);
  iEquForw = findnzrows(Phi);
  iEquForwLagg = intersect(iEquForw,findnzrows(L));
  if(!isempty(iEquForwLagg))
    iVar2Replace = findnzcols(L[iEquForwLagg,:])
    nExtra = length(iVar2Replace)
    println("introduce ",nExtra," additional equations")
    nn = n + nExtra;
    iVarExtra = n+1:nn;
    G0 = zeros(nn,nn)
    G1 = zeros(nn,nn)
    G0[1:n,1:n] = Matrix(G);
    G1[1:n,1:n] = Matrix(L);
    # forward looking equations are shifted backwards in time:
    G1[iEquForw,:] = G0[iEquForw,:]
    G0[iEquForw,1:n] = Phi[iEquForw,:]
    # now replace lagged variables by new auxiliary variables:
    G1[iEquForwLagg,iVarExtra] = L[iEquForwLagg,iVar2Replace]
    # G0[iForwLagg,iVar2Replace] = 0;

    G0[iVarExtra,iVarExtra] = meye(nExtra);
    G1[iVarExtra,iVar2Replace] = -meye(nExtra);

    Psi = vcat(Matrix(Psi),zeros(nExtra,size(Psi,2)))
    Pi = vcat(Matrix(Pi),zeros(nExtra,size(Pi,2)))
    # Pi[iiExtra,:] = Pi[iForwLagg,:];
    #Pi[iForwLagg,:] = 0;
  else
    Phi = Matrix(Phi);
    Pi = Matrix(Pi);
    G0 = Matrix(G);
    G1 = Matrix(L);
    G1[iEquForw,:] = G0[iEquForw,:]
    G0[iEquForw,:] = Phi[iEquForw,:]
  end
  G0 = -G0; 
  return (G0,G1,Psi,Pi)
end

# VERSION WHERE V IS REPLACED:
function representSims2(G,L,Phi,Psi,Pi)
  n = size(G,1);
  iEquForw = findnzrows(Phi);
  iEquForwLagg = intersect(iEquForw,findnzrows(L));
  if(!isempty(iEquForwLagg))
    iVar2Replace = findnzcols(Phi); # replce all forward variables
    nExtra = length(iVar2Replace)
    println("introduce ",nExtra," additional forward equations")
    nn = n + nExtra;
    iiExtra = n+1:nn;
    G0 = zeros(nn,nn)
    G1 = zeros(nn,nn)
    G0[1:n,1:n] = Matrix(G);
    G1[1:n,1:n] = Matrix(L);
    # G0[1:n,iVar2Replace] = 0.0
    G0[1:n,iiExtra] = Phi[:,iVar2Replace]
    G1[iiExtra,iiExtra] = meye(nExtra);
    G0[iiExtra,iVar2Replace] = -meye(nExtra);

    Psi0 = vcat(Psi,zeros(nExtra,size(Psi,2)))
    Pi0 = zeros(nn,nExtra);
    Pi0[iiExtra,:] = meye(nExtra);
  else
    Phi0 = Matrix(Phi);
    Pi0 = Matrix(Pi);
    Psi0 = Matrix(Psi);
    G0 = Matrix(G);
    G1 = Matrix(L);
    G1[iEquForw,:] = G0[iEquForw,:]
    G0[iEquForw,:] = Phi[iEquForw,:]
  end
  G0 = -G0; 
  return (G0,G1,Psi0,Pi0)
end
function solveQZ(G,L,Phi,Psi,Pi,checkThorough=true)
  global _linsol;
  div = _linsol.crit;
  (G0,G1,Psi,Pi) = representSims2(G,L,Phi,Psi,Pi);
  n = size(G,1)
  nAugm = size(G0,1) # can be larger if additional variables introduced
  # nF = length(iForw);
  # if(false)
  #   Pi = zeros(n,nF);
  #   Pi[iForw,:] = meye(nF);
  # end

  (eu,Amat, Bmat,eigv) = checkeu(G0,G1,Psi,Pi,div,checkThorough);
  if !all(eu)
    @show eu
    saveT("gg.bmt",G0,G1,Psi,Pi);
    @error("solution not existent or not unique, matrices saved in gg.bmt")
  end
  if nAugm>n
    maxZero = maximum(abs,Amat[1:n,n+1:end]);
    if maxZero>1e-14
      @warn("coefficients for added variables = $maxZero (should be zero)")
    end
  end
  return (eu,Amat[1:n,1:n], Bmat[1:n,:],eigv);
end
_glob.linappr_is_compiled = true;

function findIndexInDict(D::Dict,i::Int)
  for k in keys(D)
    ii = D[k];
    if i>=ii[1] && i<=ii[end]
      if length(ii)==1
        return string(k)
      else
        return string(k) * "[" * string(i-ii[1]+1) * "]";
      end
    end
  end
  return "NOTFOUND";
end
function setZeroEps!(A,eps)
  for i=1:length(A)
    if abs(A[i])<eps
      A[i] = 0.0;
    end
  end
end
function dolin(hetfile,_startGuess,_vars,_shks,_pars,_varsStSt,onlyStSt::Bool,onlyMat::Bool)
  iModel = _modelinfo[hetfile].id
  _glob.disableLog = 0 # write intermediate steady state calculations to stst.log
  _linsol.inStSt = true
  @time xx = dostst!(_startGuess,_vars,_shks,_pars,_varsStSt);
  global _nFL = 3*lenStruct(_vars)+lenStruct(_shks);  # number of independent variables
  _nIndepSparse[1] = _nFL+2; # set size of sparse derivative structure
  global equNames = Dict{String,UnitRange{Int}}()
  _linsol.inStSt = false
  _linsol.epsComplement = 1e-5
  res = _ststresid(_vars,_shks,_pars,equNames);
  global varNames = posInStruct(_varsStSt);
  FRES = open(_modelDir*"residstst.log","w")
  maxRes = maximum(abs,res)
  if maxRes > _linsol.tolResidStSt
    global resGlob = res;
    iMaxRes = argmax(abs.(res))
    eName = findIndexInDict(equNames,iMaxRes)
    @warn("res = ",res[iMaxRes]," in Equ. $eName, ",iMaxRes)
    println("should I continue?")
    answ = readline(stdin)
    if answ[1]!='y'
      error("stopped")
    end
  end
  close(FRES)
  if maxRes > 1e-6
    @warn("max residual at steady state: " * string(maximum(abs,res)))
  end
  writeStStRes();
  if onlyStSt
    return LinSol(hetfile,zeros(0,0),zeros(0,0),copyStruct0(_pars),copyStruct0(_varsStSt),equNames,varNames,iModel,xx)
  end
  # println("time for automatic differentiation:")
  println("compute Diff:")
  if true
    @time ( Gamma , Lambda , Phi , Psi , Pi_) = _linpert(_vars,_shks,_pars);
    # saveT("gg.bmt",Gamma , Lambda , Phi , Psi , Pi_);
  else
    ( Gamma , Lambda , Phi , Psi , Pi_) = loadT("gg.bmt",5)
  end
  ## if false
  ##   println("now improve stst:")
  ##   # ststv = stackFields(Float64,_varsStSt)[1:size(Gamma,1)]
  ##   correctStSt = -Matrix(Gamma+Lambda+Phi)\res;
  ##   saveT("corr.bmt",correctStSt,res,Matrix(Gamma+Lambda+Phi));
  ##   updateStSt(_vars,correctStSt)
  ##   res = _ststresid(_vars,_shks,_pars,equNames);
  ##   println("max residual at steady state: ",maximum(abs,res))
  ##   _linsol.inStSt=true
  ##   @time ( Gamma , Lambda , Phi , Psi , Pi_) = _linpert(_vars,_shks,_pars);
  ##   for iterU = 1:10
  ##     correctStSt = -Matrix(Gamma+Lambda+Phi)\res;
  ##     updateStSt(_vars,correctStSt)
  ##     res = _ststresid(_vars,_shks,_pars,equNames);
  ##     println("max residual at steady state: ",maximum(abs,res))
  ##   end
  ##   error("done")
  ## end

  res = _ststresid(_vars,_shks,_pars,equNames);



  if onlyMat  # return matrics
    return LinModel(_modelinfo[hetfile], [false;false],[NaN*im],
                    Gamma , Lambda , Phi , Matrix(Psi) , Pi_,
                    _pars,_varsStSt,equNames,varNames, xx)

  end
  global _A,_B;
  if size(Gamma,1)<= _linsol.nDoQZ
    @time (eu,_A, _B,eigv) = solveQZ( Gamma , Lambda , Phi , Psi , Pi_,_linsol.checkRankCond)
  else
    @warn("use solveIter")
    (_A,_B) = solveIter( Gamma , Lambda , Phi , Psi , Pi_)
    eu = [true;true]
  end
  # error("done")
  setZeroEps!(_A,_linsol.isZero)
  setZeroEps!(_B,_linsol.isZero)
  if !all(eu)
    println(eu)
    @warn("not a unique stable solution")
    return LinModel(_modelinfo[hetfile], eu,eigv,
                    Gamma , Lambda , Phi , Matrix(Psi) , Pi_,
                    _pars,_varsStSt,equNames,varNames,iModel,xx)
  end
  linRes = LinSol(hetfile,_A,_B,copyStruct0(_pars),copyStruct0(_varsStSt),equNames,varNames,iModel,xx)
  return linRes # return solution
end
linmodel(modelIdentifier) = dolin(modelIdentifier,_startGuess,_vars,_shks,_pars,_varsStSt,false,true);
dostst(modelIdentifier) = dolin(modelIdentifier,_startGuess,_vars,_shks,_pars,_varsStSt,true,true);
macro linmodel()
  return :(linmodel(_lastModel))
end
macro dostst()
  return :(dostst(_lastModel))
end

function writeDynare()
  global templDir;
  mpp(templDir*"symdyn.mpp",_modelDir*"gendynare.jl",Main,_modelDir,templDir)
  dynmod = randomModule("dynare")
  Core.eval(dynmod,:(include(Main._modelDir*"macro.mpp")))
  Core.eval(dynmod,:(include(Main._modelDir*"gendynare.jl")))
  Core.eval(dynmod,:(writedynare(Main._pars,Main._vars,Main._modelDir)) )
end

# insert residuals into system matrices Lambda, Gamma etc.:
function insertResDP(offs::Int,Res, Lambda, Gamma, Phi, Pi_, Psi)
  offs = insertRes(offs,Res[1], Lambda, Gamma, Phi, Pi_, Psi)
  offs = insertRes(offs,Res[2], Lambda, Gamma, Phi, Pi_, Psi)
  return offs;
end
function insertRes(offs::Int,Res, Lambda, Gamma, Phi, Pi_, Psi)
  global _nFL;
  nFL::Int = _nFL;
  nVAR = size(Lambda,1)
  if isa(Res,Array)
    n = length(Res)
    jacres = getjac(Res);
    skal = 1.0; # adjust skal!! ??
    ii = offs .+ (1:n);
    Lambda[ii,:] = jacres[:,1:nVAR]*skal;
    Gamma[ii,:] = jacres[:,nVAR+1:2*nVAR]*skal;
    Phi[ii,:] = jacres[:,2*nVAR+1:3*nVAR]*skal;
    Pi_[ii,:] = Phi[ii,:];
    Psi[ii,:] = jacres[:,3*nVAR+1:nFL]*skal;
    return offs+n
  else
    i = offs+1;
    skal = 1.0 / maximum(abs.(Res.d))
    if !isfinite(skal)
      println("equation zero or not finite at equation number $i; result in resd.bmt")
      saveT("resd.bmt",Res.d)
      # rd = Matrix(Res.d); saveT("resd.bmt",rd[1:nVAR],rd[nVAR+1:2*nVAR],rd[2*nVAR+1:3*nVAR],rd[3*nVAR+1:end])
      @assert(false)
    end
    Lambda[i,:] = Res.d[1:nVAR]'*skal;
    Gamma[i,:] = Res.d[nVAR+1:2*nVAR]'*skal;
    Phi[i,:] = Res.d[2*nVAR+1:3*nVAR]'*skal;
    Pi_[i,:] = Phi[i,:];
    Psi[i,:] = Res.d[3*nVAR+1:nFL]'*skal;
    return i;
  end
end

# create a sparse selection matrix that selects the rows with indices ii
# from a vector or matrix of n rows
function eyeii(n,ii)
  m = length(ii)
  I = spzeros(m,n)
  I[:,ii] = mspeye(m);
  return I;
end

# Sims representation:   
# s_t = As*s_{t-1] + Bs*eps_t
# y_t = Ay*s_{t-1] + By*eps_t
# state space representation
# y_t = Qy*s_{t] + Ry*eps_t
# conversion assumes As is regular
function sims2StateSpace(A,B,doTest=false)
  (n,nSt) = size(A)
  As = A[1:nSt,:]
  Ay = A[nSt+1:end,:]
  nJump = n-nSt;
  Qy = Ay/As;
  if doTest
    Ry = B[nSt+1:end,:] - Ay*(As\B[1:nSt,:]);
    println("Ry: ",maximum(abs,Ry))
    nz = size(B,2)
    slag = randn(nSt)
    eps = randn(nz)
    x = A*slag + B*eps
    s = x[1:nSt]
    y = x[nSt+1:end]
    y2 = Qy*s; #  + Ry*eps;
    println("maximum error in conversion Sims2StateSpae: ",maximum(abs,y2-y))
  end
  return Qy
end
